# Keep everything for this simple app
-keep class com.example.daftarche.** { *; }
