package com.example.daftarche;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;
import android.text.Editable;
import android.text.TextWatcher;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private LinearLayout root, listBox, topBar;
    private EditText searchBox;
    private ArrayList<Note> notes = new ArrayList<>();
    private SharedPreferences prefs;
    private boolean dark = false;
    private int bg, panel, text, muted, accent, fieldBg;
    private final SimpleDateFormat dateFmt = new SimpleDateFormat("yyyy/MM/dd - HH:mm", new Locale("fa"));

    static class Note {
        String id, title, body, date;
        Note(String i, String t, String b, String d) { id=i; title=t; body=b; date=d; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("notes_store", MODE_PRIVATE);
        dark = prefs.getBoolean("dark", false);
        loadNotes();
        applyPalette();
        buildUi();
        renderNotes("");
    }

    private void applyPalette() {
        if (dark) {
            bg=Color.rgb(17,24,39); panel=Color.rgb(31,41,55); text=Color.rgb(243,244,246);
            muted=Color.rgb(156,163,175); accent=Color.rgb(129,140,248); fieldBg=Color.rgb(55,65,81);
        } else {
            bg=Color.rgb(246,247,251); panel=Color.WHITE; text=Color.rgb(31,41,55);
            muted=Color.rgb(107,114,128); accent=Color.rgb(79,70,229); fieldBg=Color.rgb(238,240,247);
        }
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        getWindow().getDecorView().setSystemUiVisibility(dark ? 0 : View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(12), dp(18), dp(12));
        root.setBackgroundColor(bg);
        setContentView(root);

        topBar = new LinearLayout(this);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(topBar, new LinearLayout.LayoutParams(-1, dp(58)));

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        TextView title = label("دفترچه من", 25, text, true);
        TextView subtitle = label("فکرهایت را همین‌جا نگه دار", 12, muted, false);
        titleWrap.addView(title); titleWrap.addView(subtitle);
        topBar.addView(titleWrap, new LinearLayout.LayoutParams(0, -2, 1));

        Button themeBtn = button(dark ? "☀ روشن" : "☾ تاریک", panel, text);
        topBar.addView(themeBtn, new LinearLayout.LayoutParams(-2, dp(42)));
        themeBtn.setOnClickListener(v -> {
            dark = !dark; prefs.edit().putBoolean("dark", dark).apply();
            applyPalette(); buildUi(); renderNotes(searchBox == null ? "" : searchBox.getText().toString());
        });

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(15);
        searchBox.setHint("جست‌وجو در یادداشت‌ها...");
        searchBox.setHintTextColor(muted);
        searchBox.setTextColor(text);
        searchBox.setPadding(dp(14), 0, dp(14), 0);
        searchBox.setBackground(round(fieldBg, 16));
        LinearLayout.LayoutParams searchLp = new LinearLayout.LayoutParams(-1, dp(50));
        searchLp.setMargins(0, dp(16), 0, dp(14));
        root.addView(searchBox, searchLp);
        searchBox.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int before,int count){ renderNotes(s.toString()); }
            public void afterTextChanged(Editable e){}
        });

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        listBox = new LinearLayout(this);
        listBox.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(listBox);

        Button add = button("+   یادداشت جدید", accent, Color.WHITE);
        add.setTextSize(16);
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(-1, dp(54));
        addLp.setMargins(0, dp(12), 0, dp(4));
        root.addView(add, addLp);
        add.setOnClickListener(v -> showEditor(null));
    }

    private void renderNotes(String query) {
        if (listBox == null) return;
        listBox.removeAllViews();
        String q = query == null ? "" : query.trim().toLowerCase(new Locale("fa"));
        int count=0;
        for (int i=notes.size()-1; i>=0; i--) {
            Note n=notes.get(i);
            if (!q.isEmpty() && !(n.title.toLowerCase(new Locale("fa")).contains(q) || n.body.toLowerCase(new Locale("fa")).contains(q))) continue;
            count++;
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(16), dp(14), dp(16), dp(12));
            card.setBackground(round(panel, 18));
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.setMargins(0, 0, 0, dp(12));
            listBox.addView(card, cp);

            TextView t=label(n.title.isEmpty() ? "بدون عنوان" : n.title, 18, text, true);
            card.addView(t);
            TextView body=label(n.body, 14, muted, false);
            body.setMaxLines(4);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2); bp.setMargins(0, dp(7), 0, dp(8));
            card.addView(body,bp);
            TextView date=label(n.date, 11, muted, false);
            card.addView(date);

            LinearLayout actions = new LinearLayout(this);
            actions.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, dp(38)); ap.setMargins(0, dp(7), 0, 0);
            card.addView(actions, ap);
            Button edit=smallButton("ویرایش", accent);
            Button del=smallButton("حذف", Color.rgb(220,70,70));
            actions.addView(edit); actions.addView(space(dp(8))); actions.addView(del);
            edit.setOnClickListener(v -> showEditor(n));
            del.setOnClickListener(v -> confirmDelete(n));
            card.setOnClickListener(v -> showEditor(n));
        }
        if (count==0) {
            TextView empty=label(q.isEmpty() ? "هنوز یادداشتی نداری.\nبا دکمه پایین اولین یادداشتت را بنویس." : "یادداشتی پیدا نشد.", 15, muted, false);
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(dp(16), dp(42), dp(16), dp(42));
            listBox.addView(empty, new LinearLayout.LayoutParams(-1, -2));
        }
    }

    private void showEditor(Note old) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(4), dp(8), dp(4), dp(2));
        EditText titleInput = new EditText(this);
        titleInput.setSingleLine(true);
        titleInput.setTextSize(17);
        titleInput.setHint("عنوان یادداشت");
        titleInput.setTextColor(text); titleInput.setHintTextColor(muted);
        titleInput.setBackground(round(fieldBg, 12));
        titleInput.setPadding(dp(12), 0, dp(12), 0);
        EditText bodyInput = new EditText(this);
        bodyInput.setTextSize(15); bodyInput.setGravity(Gravity.TOP|Gravity.RIGHT);
        bodyInput.setHint("اینجا بنویس...");
        bodyInput.setMinLines(7); bodyInput.setTextColor(text); bodyInput.setHintTextColor(muted);
        bodyInput.setBackground(round(fieldBg, 12));
        bodyInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        box.addView(titleInput, new LinearLayout.LayoutParams(-1, dp(52)));
        LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(-1, dp(190)); bodyLp.setMargins(0,dp(10),0,0);
        box.addView(bodyInput, bodyLp);
        if (old != null) { titleInput.setText(old.title); bodyInput.setText(old.body); }
        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle(old == null ? "یادداشت جدید" : "ویرایش یادداشت")
            .setView(box)
            .setNegativeButton("انصراف", null)
            .setPositiveButton("ذخیره", null)
            .create();
        dialog.setOnShowListener(x -> {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                String t=titleInput.getText().toString().trim();
                String b=bodyInput.getText().toString().trim();
                if (t.isEmpty() && b.isEmpty()) { Toast.makeText(this,"متن یادداشت را وارد کن",Toast.LENGTH_SHORT).show(); return; }
                String now=dateFmt.format(new Date());
                if (old == null) notes.add(new Note(UUID.randomUUID().toString(), t, b, now));
                else { old.title=t; old.body=b; old.date=now; }
                saveNotes(); dialog.dismiss(); renderNotes(searchBox.getText().toString());
                Toast.makeText(this,"یادداشت ذخیره شد",Toast.LENGTH_SHORT).show();
            });
        });
        dialog.show();
    }

    private void confirmDelete(Note n) {
        new AlertDialog.Builder(this).setTitle("حذف یادداشت")
            .setMessage("این یادداشت حذف شود؟")
            .setNegativeButton("انصراف", null)
            .setPositiveButton("حذف", (d,w) -> {
                notes.remove(n); saveNotes(); renderNotes(searchBox.getText().toString());
                Toast.makeText(this,"یادداشت حذف شد",Toast.LENGTH_SHORT).show();
            }).show();
    }

    private void loadNotes() {
        notes.clear();
        try {
            JSONArray a=new JSONArray(prefs.getString("notes","[]"));
            for(int i=0;i<a.length();i++){
                JSONObject o=a.getJSONObject(i);
                notes.add(new Note(o.optString("id"),o.optString("title"),o.optString("body"),o.optString("date")));
            }
        } catch(Exception ignored) {}
    }
    private void saveNotes() {
        JSONArray a=new JSONArray();
        try {
            for(Note n:notes){
                JSONObject o=new JSONObject(); o.put("id",n.id); o.put("title",n.title); o.put("body",n.body); o.put("date",n.date); a.put(o);
            }
            prefs.edit().putString("notes",a.toString()).apply();
        } catch(Exception e) { Toast.makeText(this,"ذخیره‌سازی با خطا روبه‌رو شد",Toast.LENGTH_SHORT).show(); }
    }

    private TextView label(String s,int size,int color,boolean bold) {
        TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color);
        v.setGravity(Gravity.RIGHT); v.setTypeface(Typeface.DEFAULT, bold?Typeface.BOLD:Typeface.NORMAL);
        v.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        return v;
    }
    private Button button(String s,int color,int fg) {
        Button b=new Button(this); b.setText(s); b.setTextColor(fg); b.setTextSize(13);
        b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setBackground(round(color,15));
        return b;
    }
    private Button smallButton(String s,int color) {
        Button b=button(s,color,Color.WHITE); b.setTextSize(12);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,dp(36)); b.setLayoutParams(lp); return b;
    }
    private View space(int w) { View v=new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(w,1)); return v; }
    private GradientDrawable round(int color,int radius) {
        GradientDrawable d=new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private int dp(float n) { return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
}
