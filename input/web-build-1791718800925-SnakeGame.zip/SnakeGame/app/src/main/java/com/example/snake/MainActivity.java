package com.example.snake;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends Activity {
    private SnakeView snakeView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        snakeView = new SnakeView(this);
        setContentView(snakeView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        snakeView.resume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        snakeView.pause();
    }

    class SnakeView extends SurfaceView implements Runnable, GestureDetector.OnGestureListener {
        private Thread thread = null;
        private SurfaceHolder holder;
        private volatile boolean playing;
        private Canvas canvas;
        private Paint paint;
        private GestureDetector gestureDetector;

        private final int NUM_BLOCKS_WIDE = 20;
        private int blockSize;
        private int numBlocksHigh;

        private ArrayList<Point> snake = new ArrayList<>();
        private int snakeDirection = 1; // 0=up, 1=right, 2=down, 3=left
        private Point food;
        private int score = 0;
        private long nextFrameTime;
        private final long FPS = 8;
        private final long MILLIS_PER_FRAME = 1000 / FPS;
        private Random random = new Random();
        private boolean gameOver = false;

        public SnakeView(Context context) {
            super(context);
            holder = getHolder();
            paint = new Paint();
            gestureDetector = new GestureDetector(context, this);

            Point size = new Point();
            getWindowManager().getDefaultDisplay().getSize(size);
            blockSize = size.x / NUM_BLOCKS_WIDE;
            numBlocksHigh = size.y / blockSize;

            startGame();
        }

        private void startGame() {
            snake.clear();
            snake.add(new Point(5, 5));
            snake.add(new Point(4, 5));
            snake.add(new Point(3, 5));
            snakeDirection = 1;
            score = 0;
            gameOver = false;
            spawnFood();
            nextFrameTime = System.currentTimeMillis();
        }

        private void spawnFood() {
            food = new Point();
            food.x = random.nextInt(NUM_BLOCKS_WIDE - 2) + 1;
            food.y = random.nextInt(numBlocksHigh - 2) + 1;
            // avoid spawning on snake
            for (Point p : snake) {
                if (p.x == food.x && p.y == food.y) {
                    spawnFood();
                    return;
                }
            }
        }

        @Override
        public void run() {
            while (playing) {
                if (updateRequired()) {
                    update();
                    draw();
                }
            }
        }

        private boolean updateRequired() {
            if (nextFrameTime <= System.currentTimeMillis()) {
                nextFrameTime = System.currentTimeMillis() + MILLIS_PER_FRAME;
                return true;
            }
            return false;
        }

        private void update() {
            if (gameOver) return;

            Point head = snake.get(0);
            Point newHead = new Point(head.x, head.y);

            switch (snakeDirection) {
                case 0: newHead.y--; break; // up
                case 1: newHead.x++; break; // right
                case 2: newHead.y++; break; // down
                case 3: newHead.x--; break; // left
            }

            // Wall collision
            if (newHead.x < 0 || newHead.x >= NUM_BLOCKS_WIDE ||
                newHead.y < 0 || newHead.y >= numBlocksHigh) {
                gameOver = true;
                return;
            }

            // Self collision
            for (Point p : snake) {
                if (p.x == newHead.x && p.y == newHead.y) {
                    gameOver = true;
                    return;
                }
            }

            snake.add(0, newHead);

            // Eat food
            if (newHead.x == food.x && newHead.y == food.y) {
                score++;
                spawnFood();
            } else {
                snake.remove(snake.size() - 1);
            }
        }

        private void draw() {
            if (!holder.getSurface().isValid()) return;

            canvas = holder.lockCanvas();
            if (canvas == null) return;

            // Background
            canvas.drawColor(Color.rgb(15, 20, 25));

            // Grid (subtle)
            paint.setColor(Color.rgb(30, 35, 40));
            paint.setStrokeWidth(1);
            for (int i = 0; i <= NUM_BLOCKS_WIDE; i++) {
                canvas.drawLine(i * blockSize, 0, i * blockSize, numBlocksHigh * blockSize, paint);
            }
            for (int i = 0; i <= numBlocksHigh; i++) {
                canvas.drawLine(0, i * blockSize, NUM_BLOCKS_WIDE * blockSize, i * blockSize, paint);
            }

            // Snake
            for (int i = 0; i < snake.size(); i++) {
                Point p = snake.get(i);
                if (i == 0) {
                    paint.setColor(Color.rgb(50, 205, 50)); // head brighter
                } else {
                    paint.setColor(Color.rgb(34, 139, 34));
                }
                canvas.drawRect(
                    p.x * blockSize + 2,
                    p.y * blockSize + 2,
                    (p.x + 1) * blockSize - 2,
                    (p.y + 1) * blockSize - 2,
                    paint
                );
            }

            // Food
            paint.setColor(Color.rgb(220, 20, 60));
            canvas.drawRect(
                food.x * blockSize + 3,
                food.y * blockSize + 3,
                (food.x + 1) * blockSize - 3,
                (food.y + 1) * blockSize - 3,
                paint
            );

            // Score
            paint.setColor(Color.WHITE);
            paint.setTextSize(blockSize * 1.2f);
            paint.setTextAlign(Paint.Align.LEFT);
            canvas.drawText("امتیاز: " + score, 20, blockSize * 1.5f, paint);

            // Game Over
            if (gameOver) {
                paint.setColor(Color.argb(180, 0, 0, 0));
                canvas.drawRect(0, 0, getWidth(), getHeight(), paint);

                paint.setColor(Color.WHITE);
                paint.setTextSize(blockSize * 2f);
                paint.setTextAlign(Paint.Align.CENTER);
                canvas.drawText("بازی تمام!", getWidth() / 2f, getHeight() / 2f - blockSize, paint);

                paint.setTextSize(blockSize * 1.2f);
                canvas.drawText("امتیاز: " + score, getWidth() / 2f, getHeight() / 2f + blockSize, paint);
                canvas.drawText("برای شروع دوباره لمس کن", getWidth() / 2f, getHeight() / 2f + blockSize * 2.5f, paint);
            }

            holder.unlockCanvasAndPost(canvas);
        }

        public void pause() {
            playing = false;
            try {
                if (thread != null) thread.join();
            } catch (InterruptedException e) {}
        }

        public void resume() {
            playing = true;
            thread = new Thread(this);
            thread.start();
        }

        @Override
        public boolean onTouchEvent(MotionEvent event) {
            if (gameOver && event.getAction() == MotionEvent.ACTION_DOWN) {
                startGame();
                return true;
            }
            return gestureDetector.onTouchEvent(event);
        }

        @Override
        public boolean onDown(MotionEvent e) { return true; }

        @Override
        public void onShowPress(MotionEvent e) {}

        @Override
        public boolean onSingleTapUp(MotionEvent e) { return false; }

        @Override
        public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) { return false; }

        @Override
        public void onLongPress(MotionEvent e) {}

        @Override
        public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
            if (gameOver) return false;

            float absX = Math.abs(velocityX);
            float absY = Math.abs(velocityY);

            if (absX > absY) {
                // Horizontal
                if (velocityX > 0 && snakeDirection != 3) snakeDirection = 1; // right
                else if (velocityX < 0 && snakeDirection != 1) snakeDirection = 3; // left
            } else {
                // Vertical
                if (velocityY > 0 && snakeDirection != 0) snakeDirection = 2; // down
                else if (velocityY < 0 && snakeDirection != 2) snakeDirection = 0; // up
            }
            return true;
        }
    }
}
