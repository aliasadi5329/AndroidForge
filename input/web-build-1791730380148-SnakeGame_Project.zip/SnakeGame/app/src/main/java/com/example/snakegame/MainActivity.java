package com.example.snakegame;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import android.content.Context;
import java.util.*;

public class MainActivity extends Activity {
    GameView game;
    TextView scoreText, statusText;
    Button startButton;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(15,23,42));
        getWindow().setNavigationBarColor(Color.rgb(15,23,42));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(14, 8, 14, 8);
        root.setBackgroundColor(Color.rgb(15,23,42));

        TextView title = new TextView(this);
        title.setText("بازی مار");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(44)));

        scoreText = new TextView(this);
        scoreText.setText("امتیاز: ۰");
        scoreText.setTextColor(Color.rgb(134,239,172));
        scoreText.setTextSize(19);
        scoreText.setGravity(Gravity.CENTER);
        root.addView(scoreText, new LinearLayout.LayoutParams(-1, dp(30)));

        statusText = new TextView(this);
        statusText.setText("برای شروع، دکمه شروع را بزن");
        statusText.setTextColor(Color.rgb(203,213,225));
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        root.addView(statusText, new LinearLayout.LayoutParams(-1, dp(26)));

        game = new GameView(this);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, 0, 1f);
        gp.setMargins(0, dp(5), 0, dp(5));
        root.addView(game, gp);

        startButton = new Button(this);
        startButton.setText("شروع بازی");
        startButton.setOnClickListener(v -> {
            game.startGame();
            startButton.setText("شروع دوباره");
            statusText.setText("با کشیدن انگشت یا دکمه‌ها حرکت کن");
        });
        root.addView(startButton, new LinearLayout.LayoutParams(-1, dp(46)));

        LinearLayout r1 = new LinearLayout(this);
        r1.setGravity(Gravity.CENTER);
        r1.addView(dirButton("▲", 0, -1), buttonParams());
        root.addView(r1);
        LinearLayout r2 = new LinearLayout(this);
        r2.setGravity(Gravity.CENTER);
        r2.addView(dirButton("◀", -1, 0), buttonParams());
        r2.addView(dirButton("▼", 0, 1), buttonParams());
        r2.addView(dirButton("▶", 1, 0), buttonParams());
        root.addView(r2);
        setContentView(root);
    }

    Button dirButton(String label, int x, int y) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(19);
        b.setOnClickListener(v -> game.setDirection(x, y));
        return b;
    }
    LinearLayout.LayoutParams buttonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(72), dp(43));
        p.setMargins(dp(3), dp(1), dp(3), dp(1));
        return p;
    }
    int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    class GameView extends View {
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        ArrayList<Point> snake = new ArrayList<>();
        Random random = new Random();
        Point food = new Point(8, 8);
        int cols = 20, rows = 28, dx = 1, dy = 0, score = 0;
        float cell, ox, oy, downX, downY;
        boolean running = false, over = false;
        long lastStep = 0;

        GameView(Context c) { super(c); reset(); }
        void reset() {
            snake.clear();
            snake.add(new Point(7, 10)); snake.add(new Point(6, 10)); snake.add(new Point(5, 10));
            dx=1; dy=0; score=0; over=false; running=false;
            placeFood(); updateScore(); invalidate();
        }
        void startGame() {
            reset(); running=true; lastStep=System.currentTimeMillis();
            postDelayed(tick, 100); invalidate();
        }
        Runnable tick = new Runnable() {
            public void run() {
                if (!running) return;
                long now=System.currentTimeMillis();
                if (now-lastStep >= Math.max(75, 155-score*2)) { step(); lastStep=now; }
                invalidate();
                if (running) postDelayed(this, 35);
            }
        };
        void setDirection(int x, int y) {
            if (x == -dx && y == -dy) return;
            dx=x; dy=y;
        }
        void placeFood() {
            for (int i=0; i<300; i++) {
                int x=random.nextInt(Math.max(1, cols)), y=random.nextInt(Math.max(1, rows));
                boolean used=false;
                for (Point p:snake) if (p.x==x && p.y==y) { used=true; break; }
                if (!used) { food=new Point(x,y); return; }
            }
            food=new Point(1,1);
        }
        void step() {
            Point h=snake.get(0), n=new Point(h.x+dx,h.y+dy);
            if (n.x<0 || n.y<0 || n.x>=cols || n.y>=rows) { endGame(); return; }
            boolean eat=n.x==food.x && n.y==food.y;
            int limit=eat ? snake.size() : snake.size()-1;
            for (int i=0; i<limit; i++) {
                Point p=snake.get(i);
                if (p.x==n.x && p.y==n.y) { endGame(); return; }
            }
            snake.add(0,n);
            if (eat) { score++; updateScore(); placeFood(); }
            else snake.remove(snake.size()-1);
        }
        void endGame() {
            running=false; over=true;
            statusText.setText("بازی تمام شد! امتیاز: "+score);
            startButton.setText("بازی دوباره");
        }
        void updateScore() { scoreText.setText("امتیاز: "+score); }

        protected void onDraw(Canvas c) {
            super.onDraw(c);
            float w=getWidth(), h=getHeight();
            if (w<=0 || h<=0) return;
            cell=Math.min(w/cols,h/rows);
            cols=Math.max(8,(int)(w/cell)); rows=Math.max(10,(int)(h/cell));
            cell=Math.min(w/cols,h/rows);
            ox=(w-cols*cell)/2f; oy=(h-rows*cell)/2f;
            paint.setColor(Color.rgb(30,41,59));
            c.drawRoundRect(ox-3,oy-3,ox+cols*cell+3,oy+rows*cell+3,16,16,paint);
            paint.setColor(Color.rgb(22,40,54));
            c.drawRect(ox,oy,ox+cols*cell,oy+rows*cell,paint);
            paint.setColor(Color.rgb(35,57,70)); paint.setStrokeWidth(1);
            for(int x=0;x<=cols;x++) c.drawLine(ox+x*cell,oy,ox+x*cell,oy+rows*cell,paint);
            for(int y=0;y<=rows;y++) c.drawLine(ox,oy+y*cell,ox+cols*cell,oy+y*cell,paint);
            paint.setColor(Color.rgb(248,113,113));
            c.drawCircle(ox+(food.x+.5f)*cell,oy+(food.y+.5f)*cell,cell*.36f,paint);
            for(int i=snake.size()-1;i>=0;i--) {
                Point p=snake.get(i);
                paint.setColor(i==0 ? Color.rgb(74,222,128) : Color.rgb(34,197,94));
                float l=ox+p.x*cell+1.5f,t=oy+p.y*cell+1.5f;
                c.drawRoundRect(l,t,l+cell-3,t+cell-3,cell*.22f,cell*.22f,paint);
            }
            if(!running) {
                paint.setColor(Color.argb(190,15,23,42));
                c.drawRoundRect(ox+cell,oy+rows*cell*.42f,ox+(cols-1)*cell,oy+rows*cell*.58f,12,12,paint);
                paint.setColor(Color.WHITE); paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(Math.max(16,cell*.9f));
                c.drawText(over ? "بازی تمام شد" : "آماده‌ای؟",ox+cols*cell/2f,oy+rows*cell*.51f,paint);
            }
        }
        public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()==MotionEvent.ACTION_DOWN) { downX=e.getX(); downY=e.getY(); return true; }
            if(e.getAction()==MotionEvent.ACTION_UP) {
                float ax=e.getX()-downX, ay=e.getY()-downY;
                if(Math.max(Math.abs(ax),Math.abs(ay))>25) {
                    if(Math.abs(ax)>Math.abs(ay)) setDirection(ax>0?1:-1,0);
                    else setDirection(0,ay>0?1:-1);
                }
                return true;
            }
            return true;
        }
    }
}
