package com.example.dastnevis;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private EditText inputText;
    private ImageView preview;
    private LinearLayout root, colorRow, paperRow, fontRow;
    private int selectedColor = Color.rgb(0, 0, 180);
    private int selectedPaper = 1;
    private int selectedFont = 1;
    private Bitmap resultBitmap;
    private final String[] colorNames = {"آبی", "مشکی", "قرمز", "سبز", "زرد", "بنفش", "نارنجی"};
    private final int[] colors = {
            Color.rgb(0, 0, 200),
            Color.BLACK,
            Color.rgb(200, 0, 0),
            Color.rgb(0, 140, 0),
            Color.rgb(180, 140, 0),
            Color.rgb(120, 0, 160),
            Color.rgb(220, 100, 0)
    };
    private final String[] fontNames = {
            "فونت ۱", "فونت ۲", "فونت ۳", "فونت ۴", "فونت ۵",
            "فونت ۶", "فونت ۷", "فونت ۸", "فونت ۹"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().setStatusBarColor(Color.rgb(245, 247, 250));

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        // Title
        TextView title = new TextView(this);
        title.setText("دست‌نویس کلاسیک");
        title.setTextSize(22);
        title.setTextColor(Color.rgb(30, 40, 60));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(12));
        content.addView(title);

        // Text input
        inputText = new EditText(this);
        inputText.setHint("متن خود را اینجا بنویسید...");
        inputText.setMinLines(4);
        inputText.setMaxLines(8);
        inputText.setGravity(Gravity.TOP | Gravity.RIGHT);
        inputText.setTextSize(16);
        inputText.setPadding(dp(14), dp(12), dp(14), dp(12));
        inputText.setBackground(roundBg(Color.WHITE, 16));
        inputText.setTextColor(Color.rgb(30, 30, 30));
        content.addView(inputText, lp(-1, -2, 0, 0, 0, 12));

        // Color section
        content.addView(sectionLabel("رنگ متن"));
        colorRow = makeChipRow();
        for (int i = 0; i < colors.length; i++) {
            final int idx = i;
            Button b = chip(colorNames[i], colors[i] == selectedColor);
            b.setOnClickListener(v -> {
                selectedColor = colors[idx];
                refreshChips(colorRow, idx);
            });
            colorRow.addView(b);
        }
        content.addView(wrapH(colorRow));

        // Paper section
        content.addView(sectionLabel("کاغذ"));
        paperRow = makeChipRow();
        for (int i = 1; i <= 5; i++) {
            final int p = i;
            Button b = chip("کاغذ " + i, p == selectedPaper);
            b.setOnClickListener(v -> {
                selectedPaper = p;
                refreshChips(paperRow, p - 1);
            });
            paperRow.addView(b);
        }
        content.addView(wrapH(paperRow));

        // Font section
        content.addView(sectionLabel("فونت"));
        fontRow = makeChipRow();
        for (int i = 1; i <= 9; i++) {
            final int f = i;
            Button b = chip(fontNames[i - 1], f == selectedFont);
            b.setOnClickListener(v -> {
                selectedFont = f;
                refreshChips(fontRow, f - 1);
            });
            fontRow.addView(b);
        }
        content.addView(wrapH(fontRow));

        // Generate button
        Button gen = primaryBtn("ساخت دست‌نویس");
        gen.setOnClickListener(v -> generate());
        content.addView(gen, lp(-1, dp(52), 0, 16, 0, 12));

        // Preview
        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackground(roundBg(Color.WHITE, 12));
        preview.setPadding(dp(4), dp(4), dp(4), dp(4));
        content.addView(preview, lp(-1, -2, 0, 0, 0, 12));

        // Save / Share
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        Button save = secondaryBtn("ذخیره در گالری");
        Button share = secondaryBtn("اشتراک‌گذاری");
        save.setOnClickListener(v -> saveImage());
        share.setOnClickListener(v -> shareImage());
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(space(8));
        actions.addView(share, new LinearLayout.LayoutParams(0, dp(48), 1));
        content.addView(actions, lp(-1, -2, 0, 0, 0, 20));

        setContentView(root);
    }

    private void generate() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "لطفاً متن را وارد کنید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            // Load paper
            InputStream is = getAssets().open("papers/paper" + selectedPaper + ".jpg");
            Bitmap paper = BitmapFactory.decodeStream(is);
            is.close();
            if (paper == null) throw new Exception("کاغذ لود نشد");

            // Scale paper if too large
            int maxW = 1200;
            if (paper.getWidth() > maxW) {
                float scale = maxW / (float) paper.getWidth();
                paper = Bitmap.createScaledBitmap(paper, maxW, (int) (paper.getHeight() * scale), true);
            }

            Bitmap bmp = paper.copy(Bitmap.Config.ARGB_8888, true);
            Canvas canvas = new Canvas(bmp);

            // Load font
            Typeface tf = Typeface.createFromAsset(getAssets(), "fonts/font" + selectedFont + ".ttf");
            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setTypeface(tf);
            paint.setColor(selectedColor);
            paint.setTextSize(bmp.getWidth() * 0.055f);
            paint.setTextAlign(Paint.Align.RIGHT);

            float maxWidth = bmp.getWidth() - dp(80);
            float x = bmp.getWidth() - dp(40);
            float y = dp(60);
            float lineHeight = paint.getTextSize() * 1.45f;

            List<String> lines = wrapText(text, paint, maxWidth);
            for (String line : lines) {
                if (y + lineHeight > bmp.getHeight() - dp(40)) break;
                canvas.drawText(line, x, y, paint);
                y += lineHeight;
            }

            resultBitmap = bmp;
            preview.setImageBitmap(bmp);
            Toast.makeText(this, "آماده شد!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private List<String> wrapText(String text, Paint paint, float maxWidth) {
        List<String> result = new ArrayList<>();
        String[] paragraphs = text.split("\n");
        for (String para : paragraphs) {
            if (para.trim().isEmpty()) {
                result.add("");
                continue;
            }
            String[] words = para.split(" ");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String test = line.length() == 0 ? word : line + " " + word;
                if (paint.measureText(test) <= maxWidth) {
                    line = new StringBuilder(test);
                } else {
                    if (line.length() > 0) result.add(line.toString());
                    line = new StringBuilder(word);
                }
            }
            if (line.length() > 0) result.add(line.toString());
        }
        return result;
    }

    private void saveImage() {
        if (resultBitmap == null) {
            Toast.makeText(this, "اول متن را بسازید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String name = "Dastnevis_" + System.currentTimeMillis() + ".png";
            OutputStream out;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dastnevis");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                out = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Dastnevis");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, name);
                out = new FileOutputStream(file);
            }
            resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            Toast.makeText(this, "در گالری ذخیره شد", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "خطا در ذخیره: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void shareImage() {
        if (resultBitmap == null) {
            Toast.makeText(this, "اول متن را بسازید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "Dastnevis_share_" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29) {
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dastnevis");
            }
            Uri shareUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (shareUri == null) throw new Exception("نمی‌توان فایل موقت ساخت");
            OutputStream os = getContentResolver().openOutputStream(shareUri);
            resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();

            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_STREAM, shareUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "اشتراک‌گذاری دست‌نویس"));
        } catch (Exception e) {
            Toast.makeText(this, "خطا در اشتراک: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // UI helpers
    private TextView sectionLabel(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(14);
        v.setTextColor(Color.rgb(80, 90, 110));
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(10), 0, dp(6));
        return v;
    }

    private LinearLayout makeChipRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private HorizontalScrollView wrapH(View v) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(4);
        hsv.setLayoutParams(lp);
        return hsv;
    }

    private Button chip(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setPadding(dp(14), dp(6), dp(14), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(40));
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        if (selected) {
            b.setBackground(roundBg(Color.rgb(60, 90, 200), 20));
            b.setTextColor(Color.WHITE);
        } else {
            b.setBackground(roundBg(Color.WHITE, 20));
            b.setTextColor(Color.rgb(40, 50, 70));
        }
        return b;
    }

    private void refreshChips(LinearLayout row, int selectedIdx) {
        for (int i = 0; i < row.getChildCount(); i++) {
            Button b = (Button) row.getChildAt(i);
            if (i == selectedIdx) {
                b.setBackground(roundBg(Color.rgb(60, 90, 200), 20));
                b.setTextColor(Color.WHITE);
            } else {
                b.setBackground(roundBg(Color.WHITE, 20));
                b.setTextColor(Color.rgb(40, 50, 70));
            }
        }
    }

    private Button primaryBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(roundBg(Color.rgb(50, 90, 200), 14));
        return b;
    }

    private Button secondaryBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.rgb(40, 60, 120));
        b.setBackground(roundBg(Color.WHITE, 12));
        return b;
    }

    private GradientDrawable roundBg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private View space(int w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1));
        return v;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
