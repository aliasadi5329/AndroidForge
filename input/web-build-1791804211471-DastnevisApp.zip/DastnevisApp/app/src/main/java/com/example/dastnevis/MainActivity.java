package com.example.dastnevis;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int REQ_PAPER = 1001;
    private static final int REQ_FONT = 1002;
    private static final int REQ_PERM = 1003;
    private static final String PREFS = "dastnevis_prefs";
    private static final String KEY_FONTS = "saved_fonts";
    private static final String KEY_PAPERS = "saved_papers";

    private EditText inputText;
    private ImageView preview;
    private LinearLayout colorRow, paperRow, fontRow;
    private TextView sizeLabel, statusLabel;
    private SeekBar sizeSeek;

    private int selectedColorIndex = 0;
    private int selectedPaper = 1;          // 1-5 built-in
    private int selectedFont = 1;           // 1-9 built-in
    private float fontSizeScale = 1.0f;
    private Bitmap resultBitmap;

    // Custom selection
    private boolean useCustomPaper = false;
    private boolean useCustomFont = false;
    private String selectedSavedPaperId = null;  // filename in files dir
    private String selectedSavedFontId = null;

    // Loaded lists (ids = filenames stored in app files)
    private final List<String> savedPaperIds = new ArrayList<>();
    private final List<String> savedFontIds = new ArrayList<>();

    private boolean useCustomDual = false;
    private int customColor1 = Color.rgb(120, 0, 160);
    private int customColor2 = Color.rgb(0, 0, 200);

    private final String[] colorNames = {
            "آبی", "مشکی", "قرمز", "سبز", "زرد", "بنفش", "نارنجی",
            "آبی+قرمز", "مشکی+آبی", "مشکی+قرمز", "ترکیب دلخواه"
    };
    private final int[] color1Arr = {
            Color.rgb(0, 0, 200), Color.BLACK, Color.rgb(200, 0, 0),
            Color.rgb(0, 140, 0), Color.rgb(180, 140, 0),
            Color.rgb(120, 0, 160), Color.rgb(220, 100, 0),
            Color.rgb(0, 0, 200), Color.BLACK, Color.BLACK, 0
    };
    private final int[] color2Arr = {
            0, 0, 0, 0, 0, 0, 0,
            Color.rgb(200, 0, 0), Color.rgb(0, 0, 200), Color.rgb(200, 0, 0), 0
    };
    private final boolean[] isDualArr = {
            false, false, false, false, false, false, false,
            true, true, true, true
    };
    private final String[] fontNames = {
            "فونت ۱", "فونت ۲", "فونت ۳", "فونت ۴", "فونت ۵",
            "فونت ۶", "فونت ۷", "فونت ۸", "فونت ۹"
    };
    private final int[] palette = {
            Color.rgb(0, 0, 200), Color.BLACK, Color.rgb(200, 0, 0),
            Color.rgb(0, 140, 0), Color.rgb(180, 140, 0),
            Color.rgb(120, 0, 160), Color.rgb(220, 100, 0),
            Color.rgb(0, 150, 200), Color.rgb(180, 0, 100),
            Color.rgb(100, 60, 20), Color.rgb(0, 100, 80), Color.GRAY
    };

    private File fontsDir, papersDir;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().setStatusBarColor(Color.rgb(245, 247, 250));

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        fontsDir = new File(getFilesDir(), "custom_fonts");
        papersDir = new File(getFilesDir(), "custom_papers");
        if (!fontsDir.exists()) fontsDir.mkdirs();
        if (!papersDir.exists()) papersDir.mkdirs();
        loadSavedLists();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 247, 250));
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView title = new TextView(this);
        title.setText("دست‌نویس کلاسیک");
        title.setTextSize(22);
        title.setTextColor(Color.rgb(30, 40, 60));
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(12));
        content.addView(title);

        inputText = new EditText(this);
        inputText.setHint("متن خود را اینجا بنویسید...");
        inputText.setMinLines(4);
        inputText.setMaxLines(8);
        inputText.setGravity(Gravity.TOP | Gravity.RIGHT);
        inputText.setTextSize(16);
        inputText.setPadding(dp(14), dp(12), dp(14), dp(12));
        inputText.setBackground(roundBg(Color.WHITE, 16));
        inputText.setTextColor(Color.rgb(30, 30, 30));
        content.addView(inputText, lp(-1, -2, 0, 0, 0, 12));

        // Colors
        content.addView(sectionLabel("رنگ متن"));
        colorRow = makeChipRow();
        for (int i = 0; i < colorNames.length; i++) {
            final int idx = i;
            Button b = chip(colorNames[i], idx == selectedColorIndex);
            b.setOnClickListener(v -> {
                selectedColorIndex = idx;
                useCustomDual = (idx == colorNames.length - 1);
                refreshChips(colorRow, idx);
                if (useCustomDual) showCustomColorDialog();
            });
            colorRow.addView(b);
        }
        content.addView(wrapH(colorRow));

        // Paper section
        content.addView(sectionLabel("کاغذ"));
        paperRow = makeChipRow();
        rebuildPaperRow();
        content.addView(wrapH(paperRow));

        // Font section
        content.addView(sectionLabel("فونت"));
        fontRow = makeChipRow();
        rebuildFontRow();
        content.addView(wrapH(fontRow));

        // Font size
        content.addView(sectionLabel("اندازه فونت"));
        sizeLabel = new TextView(this);
        sizeLabel.setText("اندازه: متوسط");
        sizeLabel.setTextSize(13);
        sizeLabel.setTextColor(Color.rgb(60, 70, 90));
        sizeLabel.setPadding(0, 0, 0, dp(4));
        content.addView(sizeLabel);

        sizeSeek = new SeekBar(this);
        sizeSeek.setMax(18);
        sizeSeek.setProgress(6);
        sizeSeek.setPadding(dp(8), dp(4), dp(8), dp(4));
        sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                fontSizeScale = 0.7f + progress * 0.05f;
                String label;
                if (fontSizeScale < 0.9f) label = "کوچک";
                else if (fontSizeScale < 1.15f) label = "متوسط";
                else if (fontSizeScale < 1.4f) label = "بزرگ";
                else label = "خیلی بزرگ";
                sizeLabel.setText("اندازه: " + label + " (" + String.format("%.0f", fontSizeScale * 100) + "٪)");
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
        content.addView(sizeSeek, lp(-1, -2, 0, 0, 0, 8));

        statusLabel = new TextView(this);
        statusLabel.setTextSize(12);
        statusLabel.setTextColor(Color.rgb(90, 100, 120));
        statusLabel.setPadding(0, dp(4), 0, dp(4));
        content.addView(statusLabel);

        Button gen = primaryBtn("ساخت دست‌نویس");
        gen.setOnClickListener(v -> generate());
        content.addView(gen, lp(-1, dp(52), 0, 12, 0, 12));

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackground(roundBg(Color.WHITE, 12));
        preview.setPadding(dp(4), dp(4), dp(4), dp(4));
        content.addView(preview, lp(-1, -2, 0, 0, 0, 12));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        actions.setGravity(Gravity.CENTER);
        Button save = secondaryBtn("ذخیره در گالری");
        Button share = secondaryBtn("اشتراک‌گذاری");
        save.setOnClickListener(v -> saveImage());
        share.setOnClickListener(v -> shareImage());
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(space(8));
        actions.addView(share, new LinearLayout.LayoutParams(0, dp(48), 1));
        content.addView(actions, lp(-1, -2, 0, 0, 0, 20));

        setContentView(root);
        updateStatus();
    }

    // ─── Persistence ───────────────────────────────────────
    private void loadSavedLists() {
        savedFontIds.clear();
        savedPaperIds.clear();
        Set<String> fonts = prefs.getStringSet(KEY_FONTS, new HashSet<>());
        Set<String> papers = prefs.getStringSet(KEY_PAPERS, new HashSet<>());
        if (fonts != null) {
            for (String id : fonts) {
                if (new File(fontsDir, id).exists()) savedFontIds.add(id);
            }
        }
        if (papers != null) {
            for (String id : papers) {
                if (new File(papersDir, id).exists()) savedPaperIds.add(id);
            }
        }
    }

    private void persistLists() {
        prefs.edit()
                .putStringSet(KEY_FONTS, new HashSet<>(savedFontIds))
                .putStringSet(KEY_PAPERS, new HashSet<>(savedPaperIds))
                .apply();
    }

    private String displayName(String id) {
        // font_3.ttf -> فونت من ۳   paper_2.jpg -> کاغذ من ۲
        try {
            if (id.startsWith("font_")) {
                String n = id.replace("font_", "").replace(".ttf", "").replace(".otf", "");
                return "فونت من " + n;
            }
            if (id.startsWith("paper_")) {
                String n = id.replace("paper_", "").replace(".jpg", "").replace(".png", "");
                return "کاغذ من " + n;
            }
        } catch (Exception ignored) {}
        return id.length() > 12 ? id.substring(0, 10) + "…" : id;
    }

    private void rebuildPaperRow() {
        paperRow.removeAllViews();
        for (int i = 1; i <= 5; i++) {
            final int p = i;
            Button b = chip("کاغذ " + i, !useCustomPaper && selectedPaper == p);
            b.setOnClickListener(v -> {
                selectedPaper = p;
                useCustomPaper = false;
                selectedSavedPaperId = null;
                rebuildPaperRow();
                updateStatus();
            });
            paperRow.addView(b);
        }
        for (final String id : savedPaperIds) {
            Button b = chip(displayName(id), useCustomPaper && id.equals(selectedSavedPaperId));
            b.setOnClickListener(v -> {
                useCustomPaper = true;
                selectedSavedPaperId = id;
                rebuildPaperRow();
                updateStatus();
            });
            b.setOnLongClickListener(v -> {
                confirmDeletePaper(id);
                return true;
            });
            paperRow.addView(b);
        }
        Button add = chip("+ افزودن کاغذ", false);
        add.setOnClickListener(v -> pickPaper());
        paperRow.addView(add);
    }

    private void rebuildFontRow() {
        fontRow.removeAllViews();
        for (int i = 1; i <= 9; i++) {
            final int f = i;
            Button b = chip(fontNames[i - 1], !useCustomFont && selectedFont == f);
            b.setOnClickListener(v -> {
                selectedFont = f;
                useCustomFont = false;
                selectedSavedFontId = null;
                rebuildFontRow();
                updateStatus();
            });
            fontRow.addView(b);
        }
        for (final String id : savedFontIds) {
            Button b = chip(displayName(id), useCustomFont && id.equals(selectedSavedFontId));
            b.setOnClickListener(v -> {
                useCustomFont = true;
                selectedSavedFontId = id;
                rebuildFontRow();
                updateStatus();
            });
            b.setOnLongClickListener(v -> {
                confirmDeleteFont(id);
                return true;
            });
            fontRow.addView(b);
        }
        Button add = chip("+ افزودن فونت", false);
        add.setOnClickListener(v -> pickFont());
        fontRow.addView(add);
    }

    private void confirmDeleteFont(String id) {
        new AlertDialog.Builder(this)
                .setTitle("حذف فونت")
                .setMessage("«" + displayName(id) + "» حذف شود؟")
                .setPositiveButton("حذف", (d, w) -> {
                    new File(fontsDir, id).delete();
                    savedFontIds.remove(id);
                    if (id.equals(selectedSavedFontId)) {
                        useCustomFont = false;
                        selectedSavedFontId = null;
                    }
                    persistLists();
                    rebuildFontRow();
                    updateStatus();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void confirmDeletePaper(String id) {
        new AlertDialog.Builder(this)
                .setTitle("حذف کاغذ")
                .setMessage("«" + displayName(id) + "» حذف شود؟")
                .setPositiveButton("حذف", (d, w) -> {
                    new File(papersDir, id).delete();
                    savedPaperIds.remove(id);
                    if (id.equals(selectedSavedPaperId)) {
                        useCustomPaper = false;
                        selectedSavedPaperId = null;
                    }
                    persistLists();
                    rebuildPaperRow();
                    updateStatus();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void updateStatus() {
        String s = "";
        if (useCustomPaper) s += "📄 " + displayName(selectedSavedPaperId) + "  ";
        if (useCustomFont) s += "🔤 " + displayName(selectedSavedFontId) + "  ";
        if (useCustomDual) s += "🎨 ترکیب دلخواه";
        statusLabel.setText(s.trim());
    }

    // ─── Pickers ───────────────────────────────────────────
    private void pickPaper() {
        if (!ensurePermission()) return;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, "انتخاب کاغذ"), REQ_PAPER);
    }

    private void pickFont() {
        if (!ensurePermission()) return;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "font/ttf", "font/otf", "application/x-font-ttf", "application/octet-stream"});
        startActivityForResult(Intent.createChooser(i, "انتخاب فونت (ttf/otf)"), REQ_FONT);
    }

    private boolean ensurePermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_PERM);
                return false;
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_PERM) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "مجوز داده شد، دوباره انتخاب کنید", Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(this, "برای انتخاب فایل به مجوز نیاز است", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_PAPER) {
                int next = savedPaperIds.size() + 1;
                String id = "paper_" + next + ".jpg";
                // ensure unique
                while (new File(papersDir, id).exists()) {
                    next++;
                    id = "paper_" + next + ".jpg";
                }
                File dest = new File(papersDir, id);
                InputStream is = getContentResolver().openInputStream(uri);
                FileOutputStream fos = new FileOutputStream(dest);
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) fos.write(buf, 0, n);
                fos.close();
                is.close();
                savedPaperIds.add(id);
                persistLists();
                useCustomPaper = true;
                selectedSavedPaperId = id;
                rebuildPaperRow();
                updateStatus();
                Toast.makeText(this, "کاغذ ذخیره شد: " + displayName(id), Toast.LENGTH_SHORT).show();
            } else if (requestCode == REQ_FONT) {
                int next = savedFontIds.size() + 1;
                String id = "font_" + next + ".ttf";
                while (new File(fontsDir, id).exists()) {
                    next++;
                    id = "font_" + next + ".ttf";
                }
                File dest = new File(fontsDir, id);
                InputStream is = getContentResolver().openInputStream(uri);
                FileOutputStream fos = new FileOutputStream(dest);
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) > 0) fos.write(buf, 0, n);
                fos.close();
                is.close();
                // verify it's a valid font
                Typeface.createFromFile(dest);
                savedFontIds.add(id);
                persistLists();
                useCustomFont = true;
                selectedSavedFontId = id;
                rebuildFontRow();
                updateStatus();
                Toast.makeText(this, "فونت ذخیره شد: " + displayName(id), Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ─── Custom dual color ─────────────────────────────────
    private void showCustomColorDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(12), dp(20), dp(8));

        TextView t1 = new TextView(this);
        t1.setText("رنگ اول:");
        t1.setTextSize(14);
        t1.setTypeface(Typeface.DEFAULT_BOLD);
        box.addView(t1);
        LinearLayout row1 = makeChipRow();
        for (int c : palette) {
            final int col = c;
            Button b = colorDot(col, col == customColor1);
            b.setOnClickListener(v -> { customColor1 = col; highlightRow(row1, v); });
            row1.addView(b);
        }
        box.addView(wrapH(row1));

        TextView t2 = new TextView(this);
        t2.setText("رنگ دوم:");
        t2.setTextSize(14);
        t2.setTypeface(Typeface.DEFAULT_BOLD);
        t2.setPadding(0, dp(12), 0, 0);
        box.addView(t2);
        LinearLayout row2 = makeChipRow();
        for (int c : palette) {
            final int col = c;
            Button b = colorDot(col, col == customColor2);
            b.setOnClickListener(v -> { customColor2 = col; highlightRow(row2, v); });
            row2.addView(b);
        }
        box.addView(wrapH(row2));

        new AlertDialog.Builder(this)
                .setTitle("ترکیب رنگ دلخواه")
                .setView(box)
                .setPositiveButton("تأیید", (d, w) -> {
                    useCustomDual = true;
                    selectedColorIndex = colorNames.length - 1;
                    refreshChips(colorRow, selectedColorIndex);
                    updateStatus();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private Button colorDot(int color, boolean selected) {
        Button b = new Button(this);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(selected ? dp(3) : dp(1), selected ? Color.rgb(50, 90, 200) : Color.LTGRAY);
        b.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        b.setTag(color);
        return b;
    }

    private void highlightRow(LinearLayout row, View selected) {
        for (int i = 0; i < row.getChildCount(); i++) {
            View v = row.getChildAt(i);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor((Integer) v.getTag());
            d.setStroke(v == selected ? dp(3) : dp(1),
                    v == selected ? Color.rgb(50, 90, 200) : Color.LTGRAY);
            v.setBackground(d);
        }
    }

    // ─── Generate ──────────────────────────────────────────
    private void generate() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "لطفاً متن را وارد کنید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            Bitmap paper;
            if (useCustomPaper && selectedSavedPaperId != null) {
                File f = new File(papersDir, selectedSavedPaperId);
                paper = BitmapFactory.decodeStream(new FileInputStream(f));
            } else {
                InputStream is = getAssets().open("papers/paper" + selectedPaper + ".jpg");
                paper = BitmapFactory.decodeStream(is);
                is.close();
            }
            if (paper == null) throw new Exception("کاغذ لود نشد");

            int maxW = 1200;
            if (paper.getWidth() > maxW) {
                float scale = maxW / (float) paper.getWidth();
                paper = Bitmap.createScaledBitmap(paper, maxW, (int) (paper.getHeight() * scale), true);
            }

            Bitmap bmp = paper.copy(Bitmap.Config.ARGB_8888, true);
            Canvas canvas = new Canvas(bmp);

            Typeface tf;
            if (useCustomFont && selectedSavedFontId != null) {
                tf = Typeface.createFromFile(new File(fontsDir, selectedSavedFontId));
            } else {
                tf = Typeface.createFromAsset(getAssets(), "fonts/font" + selectedFont + ".ttf");
            }

            Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            paint.setTypeface(tf);
            paint.setTextSize(bmp.getWidth() * 0.05f * fontSizeScale);
            paint.setTextAlign(Paint.Align.RIGHT);

            float maxWidth = bmp.getWidth() - dp(80);
            float startX = bmp.getWidth() - dp(40);
            float y = dp(55);
            float lineHeight = paint.getTextSize() * 1.5f;

            boolean dual;
            int c1, c2;
            if (useCustomDual || selectedColorIndex == colorNames.length - 1) {
                dual = true; c1 = customColor1; c2 = customColor2;
            } else {
                dual = isDualArr[selectedColorIndex];
                c1 = color1Arr[selectedColorIndex];
                c2 = color2Arr[selectedColorIndex];
            }

            List<String> lines = wrapText(text, paint, maxWidth);
            int wordIndex = 0;
            for (String line : lines) {
                if (y + lineHeight > bmp.getHeight() - dp(35)) break;
                if (!dual) {
                    paint.setColor(c1);
                    canvas.drawText(line, startX, y, paint);
                } else {
                    String[] words = line.split(" ");
                    float x = startX;
                    for (String word : words) {
                        if (word.isEmpty()) continue;
                        paint.setColor((wordIndex % 2 == 0) ? c1 : c2);
                        canvas.drawText(word, x, y, paint);
                        x -= paint.measureText(word);
                        x -= paint.measureText(" ");
                        wordIndex++;
                    }
                }
                y += lineHeight;
            }

            resultBitmap = bmp;
            preview.setImageBitmap(bmp);
            Toast.makeText(this, "آماده شد!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    private List<String> wrapText(String text, Paint paint, float maxWidth) {
        List<String> result = new ArrayList<>();
        for (String para : text.split("\n")) {
            if (para.trim().isEmpty()) { result.add(""); continue; }
            String[] words = para.split(" ");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String test = line.length() == 0 ? word : line + " " + word;
                if (paint.measureText(test) <= maxWidth) line = new StringBuilder(test);
                else {
                    if (line.length() > 0) result.add(line.toString());
                    line = new StringBuilder(word);
                }
            }
            if (line.length() > 0) result.add(line.toString());
        }
        return result;
    }

    private void saveImage() {
        if (resultBitmap == null) {
            Toast.makeText(this, "اول متن را بسازید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String name = "Dastnevis_" + System.currentTimeMillis() + ".png";
            OutputStream out;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dastnevis");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                out = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Dastnevis");
                if (!dir.exists()) dir.mkdirs();
                out = new FileOutputStream(new File(dir, name));
            }
            resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            Toast.makeText(this, "در گالری ذخیره شد", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "خطا در ذخیره: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void shareImage() {
        if (resultBitmap == null) {
            Toast.makeText(this, "اول متن را بسازید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "Dastnevis_share_" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29)
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dastnevis");
            Uri shareUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            OutputStream os = getContentResolver().openOutputStream(shareUri);
            resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_STREAM, shareUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "اشتراک‌گذاری دست‌نویس"));
        } catch (Exception e) {
            Toast.makeText(this, "خطا در اشتراک: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // ─── UI helpers ────────────────────────────────────────
    private TextView sectionLabel(String t) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(14);
        v.setTextColor(Color.rgb(80, 90, 110));
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setPadding(0, dp(10), 0, dp(6));
        return v;
    }

    private LinearLayout makeChipRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private HorizontalScrollView wrapH(View v) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        hsv.addView(v);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(4);
        hsv.setLayoutParams(lp);
        return hsv;
    }

    private Button chip(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(13);
        b.setPadding(dp(14), dp(6), dp(14), dp(6));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(40));
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        styleChip(b, selected);
        return b;
    }

    private void styleChip(Button b, boolean selected) {
        if (selected) {
            b.setBackground(roundBg(Color.rgb(60, 90, 200), 20));
            b.setTextColor(Color.WHITE);
        } else {
            b.setBackground(roundBg(Color.WHITE, 20));
            b.setTextColor(Color.rgb(40, 50, 70));
        }
    }

    private void refreshChips(LinearLayout row, int selectedIdx) {
        for (int i = 0; i < row.getChildCount(); i++)
            styleChip((Button) row.getChildAt(i), i == selectedIdx);
    }

    private Button primaryBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setTextColor(Color.WHITE);
        b.setBackground(roundBg(Color.rgb(50, 90, 200), 14));
        return b;
    }

    private Button secondaryBtn(String t) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setTextColor(Color.rgb(40, 60, 120));
        b.setBackground(roundBg(Color.WHITE, 12));
        return b;
    }

    private GradientDrawable roundBg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private View space(int w) {
        View v = new View(this);
        v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1));
        return v;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
