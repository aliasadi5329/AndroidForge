package com.example.dastnevis;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final int REQ_PAPER = 1001, REQ_FONT = 1002, REQ_PERM = 1003;
    private static final String PREFS = "dastnevis_prefs";
    private static final String KEY_FONTS = "saved_fonts", KEY_PAPERS = "saved_papers";

    // One locked text layer on the paper
    static class TextLayer {
        String text;
        float topRatio;
        float sideRatio;
        float fontSizeScale;
        int colorIndex;
        boolean dual;
        int c1, c2;
        int[] multiColors;   // null = use dual/c1, otherwise cycle these
        boolean useCustomFont;
        int fontIndex;
        String fontId;
    }

    private final List<TextLayer> lockedLayers = new ArrayList<>();
    private TextLayer currentLayer = null; // being positioned (not yet locked)

    private EditText inputText;
    private ImageView preview;
    private LinearLayout colorRow, positionPanel, layersPanel;
    private TextView sizeLabel, statusLabel, paperInfo, fontInfo, posLabel, layersInfo;
    private SeekBar sizeSeek, topSeek, sideSeek;

    private int selectedColorIndex = 0;
    private int selectedPaper = 1;
    private int selectedFont = 1;
    private float fontSizeScale = 1.0f;
    private float topOffsetRatio = 0.08f;
    private float sideMarginRatio = 0.06f;
    private Bitmap resultBitmap;

    private boolean useCustomPaper = false, useCustomFont = false;
    private String selectedSavedPaperId = null, selectedSavedFontId = null;
    private final List<String> savedPaperIds = new ArrayList<>();
    private final List<String> savedFontIds = new ArrayList<>();

    private boolean useCustomDual = false;
    private int customColor1 = Color.rgb(120, 0, 160);
    private int customColor2 = Color.rgb(0, 0, 200);
    private final java.util.ArrayList<Integer> customMultiColors = new java.util.ArrayList<>();

    private final String[] colorNames = {
            "آبی", "مشکی", "قرمز", "سبز", "زرد", "بنفش", "نارنجی",
            "آبی+قرمز", "مشکی+آبی", "مشکی+قرمز", "ترکیب دلخواه"
    };
    private final int[] color1Arr = {
            Color.rgb(0, 0, 200), Color.BLACK, Color.rgb(200, 0, 0),
            Color.rgb(0, 140, 0), Color.rgb(180, 140, 0),
            Color.rgb(120, 0, 160), Color.rgb(220, 100, 0),
            Color.rgb(0, 0, 200), Color.BLACK, Color.BLACK, 0
    };
    private final int[] color2Arr = {
            0, 0, 0, 0, 0, 0, 0,
            Color.rgb(200, 0, 0), Color.rgb(0, 0, 200), Color.rgb(200, 0, 0), 0
    };
    private final boolean[] isDualArr = {
            false, false, false, false, false, false, false, true, true, true, true
    };
    private final int[] palette = {
            Color.rgb(0, 0, 200), Color.BLACK, Color.rgb(200, 0, 0),
            Color.rgb(0, 140, 0), Color.rgb(180, 140, 0), Color.rgb(120, 0, 160),
            Color.rgb(220, 100, 0), Color.rgb(0, 150, 200), Color.rgb(180, 0, 100),
            Color.rgb(100, 60, 20), Color.rgb(0, 100, 80), Color.GRAY
    };

    private File fontsDir, papersDir;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        getWindow().setStatusBarColor(Color.rgb(30, 40, 70));

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        fontsDir = new File(getFilesDir(), "custom_fonts");
        papersDir = new File(getFilesDir(), "custom_papers");
        if (!fontsDir.exists()) fontsDir.mkdirs();
        if (!papersDir.exists()) papersDir.mkdirs();
        loadSavedLists();

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(240, 242, 247));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setBackgroundColor(Color.rgb(30, 40, 70));
        header.setPadding(dp(20), dp(28), dp(20), dp(20));
        TextView title = new TextView(this);
        title.setText("✍️  دست‌نویس کلاسیک");
        title.setTextSize(22);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        header.addView(title);
        TextView sub = new TextView(this);
        sub.setText("هر متن را جدا بنویس، تنظیم کن، تثبیت کن");
        sub.setTextSize(12);
        sub.setTextColor(Color.rgb(180, 190, 210));
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(4), 0, 0);
        header.addView(sub);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(16), dp(16), dp(16), dp(16));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        content.addView(cardLabel("متن جدید"));
        inputText = new EditText(this);
        inputText.setHint("متن این لایه را بنویسید...");
        inputText.setMinLines(3);
        inputText.setMaxLines(6);
        inputText.setGravity(Gravity.TOP | Gravity.RIGHT);
        inputText.setTextSize(15);
        inputText.setPadding(dp(14), dp(12), dp(14), dp(12));
        inputText.setBackground(roundBg(Color.WHITE, 14));
        inputText.setTextColor(Color.rgb(30, 30, 30));
        content.addView(inputText, lp(-1, -2, 0, 0, 0, 14));

        content.addView(cardLabel("رنگ متن"));
        colorRow = makeChipRow();
        for (int i = 0; i < colorNames.length; i++) {
            final int idx = i;
            Button b = chip(colorNames[i], idx == selectedColorIndex);
            b.setOnClickListener(v -> {
                selectedColorIndex = idx;
                useCustomDual = (idx == colorNames.length - 1);
                refreshChips(colorRow, idx);
                if (useCustomDual) showCustomColorDialog();
                updateStatus();
            });
            colorRow.addView(b);
        }
        content.addView(wrapH(colorRow), lp(-1, -2, 0, 0, 0, 10));

        content.addView(cardLabel("کاغذ (برای کل صفحه مشترک)"));
        LinearLayout paperBtns = new LinearLayout(this);
        paperBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button btnPaper = menuBtn("📄  انتخاب کاغذ", Color.rgb(55, 100, 180));
        btnPaper.setOnClickListener(v -> showPaperMenu());
        Button btnMyPaper = menuBtn("📁  کاغذهای من", Color.rgb(70, 130, 90));
        btnMyPaper.setOnClickListener(v -> showMyPapersMenu());
        paperBtns.addView(btnPaper, new LinearLayout.LayoutParams(0, dp(46), 1));
        paperBtns.addView(space(8));
        paperBtns.addView(btnMyPaper, new LinearLayout.LayoutParams(0, dp(46), 1));
        content.addView(paperBtns, lp(-1, -2, 0, 0, 0, 4));
        paperInfo = infoText("کاغذ ۱");
        content.addView(paperInfo, lp(-1, -2, 0, 0, 0, 12));

        content.addView(cardLabel("فونت این لایه"));
        LinearLayout fontBtns = new LinearLayout(this);
        fontBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button btnFont = menuBtn("✏️  انتخاب فونت", Color.rgb(55, 100, 180));
        btnFont.setOnClickListener(v -> showFontMenu());
        Button btnMyFont = menuBtn("📁  فونت‌های من", Color.rgb(70, 130, 90));
        btnMyFont.setOnClickListener(v -> showMyFontsMenu());
        fontBtns.addView(btnFont, new LinearLayout.LayoutParams(0, dp(46), 1));
        fontBtns.addView(space(8));
        fontBtns.addView(btnMyFont, new LinearLayout.LayoutParams(0, dp(46), 1));
        content.addView(fontBtns, lp(-1, -2, 0, 0, 0, 4));
        fontInfo = infoText("فونت ۱");
        content.addView(fontInfo, lp(-1, -2, 0, 0, 0, 12));

        content.addView(cardLabel("اندازه فونت این لایه"));
        sizeLabel = new TextView(this);
        sizeLabel.setText("متوسط — ۱۰۰٪");
        sizeLabel.setTextSize(13);
        sizeLabel.setTextColor(Color.rgb(60, 70, 90));
        content.addView(sizeLabel);
        sizeSeek = new SeekBar(this);
        sizeSeek.setMax(18);
        sizeSeek.setProgress(6);
        sizeSeek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean u) {
                fontSizeScale = 0.7f + p * 0.05f;
                String l = fontSizeScale < 0.9f ? "کوچک" : fontSizeScale < 1.15f ? "متوسط" : fontSizeScale < 1.4f ? "بزرگ" : "خیلی بزرگ";
                sizeLabel.setText(l + " — " + String.format("%.0f", fontSizeScale * 100) + "٪");
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        content.addView(sizeSeek, lp(-1, -2, 0, 0, 0, 12));

        statusLabel = infoText("");
        content.addView(statusLabel);

        // Locked layers info
        layersPanel = new LinearLayout(this);
        layersPanel.setOrientation(LinearLayout.VERTICAL);
        layersPanel.setBackground(roundBg(Color.rgb(230, 245, 235), 12));
        layersPanel.setPadding(dp(12), dp(10), dp(12), dp(10));
        layersInfo = new TextView(this);
        layersInfo.setTextSize(13);
        layersInfo.setTextColor(Color.rgb(40, 90, 50));
        layersInfo.setTypeface(Typeface.DEFAULT_BOLD);
        layersPanel.addView(layersInfo);
        Button clearLayers = secondaryBtn("پاک کردن همه لایه‌های تثبیت‌شده");
        clearLayers.setOnClickListener(v -> {
            lockedLayers.clear();
            currentLayer = null;
            positionPanel.setVisibility(View.GONE);
            updateLayersInfo();
            redrawAll();
            Toast.makeText(this, "همه لایه‌ها پاک شد", Toast.LENGTH_SHORT).show();
        });
        layersPanel.addView(clearLayers, lp(-1, dp(42), 0, 8, 0, 0));
        content.addView(layersPanel, lp(-1, -2, 0, 0, 0, 12));
        updateLayersInfo();

        Button gen = primaryBtn("پیش‌نمایش این متن");
        gen.setOnClickListener(v -> previewCurrent());
        content.addView(gen, lp(-1, dp(50), 0, 4, 0, 8));

        Button lockBtn = menuBtn("📌  تثبیت این متن روی کاغذ", Color.rgb(180, 100, 40));
        lockBtn.setOnClickListener(v -> lockCurrent());
        content.addView(lockBtn, lp(-1, dp(50), 0, 0, 0, 14));

        // Position panel for CURRENT layer only
        positionPanel = new LinearLayout(this);
        positionPanel.setOrientation(LinearLayout.VERTICAL);
        positionPanel.setBackground(roundBg(Color.rgb(235, 240, 255), 14));
        positionPanel.setPadding(dp(14), dp(12), dp(14), dp(12));
        positionPanel.setVisibility(View.GONE);

        TextView posTitle = new TextView(this);
        posTitle.setText("📐 موقعیت همین متن (لایه فعلی)");
        posTitle.setTextSize(14);
        posTitle.setTypeface(Typeface.DEFAULT_BOLD);
        posTitle.setTextColor(Color.rgb(40, 50, 90));
        positionPanel.addView(posTitle);

        posLabel = new TextView(this);
        posLabel.setTextSize(12);
        posLabel.setTextColor(Color.rgb(70, 80, 110));
        posLabel.setPadding(0, dp(6), 0, dp(4));
        positionPanel.addView(posLabel);

        TextView topL = new TextView(this);
        topL.setText("فاصله از بالا");
        topL.setTextSize(12);
        topL.setTextColor(Color.rgb(80, 90, 110));
        positionPanel.addView(topL);
        topSeek = new SeekBar(this);
        topSeek.setMax(100);
        topSeek.setProgress(8);
        topSeek.setOnSeekBarChangeListener(simpleSeek(() -> {
            topOffsetRatio = topSeek.getProgress() / 100f;
            if (currentLayer != null) currentLayer.topRatio = topOffsetRatio;
            updatePosLabel();
            redrawAll();
        }));
        positionPanel.addView(topSeek);

        TextView sideL = new TextView(this);
        sideL.setText("فاصله از راست / چپ");
        sideL.setTextSize(12);
        sideL.setTextColor(Color.rgb(80, 90, 110));
        sideL.setPadding(0, dp(8), 0, 0);
        positionPanel.addView(sideL);
        sideSeek = new SeekBar(this);
        sideSeek.setMax(100);
        sideSeek.setProgress(6);
        sideSeek.setOnSeekBarChangeListener(simpleSeek(() -> {
            sideMarginRatio = sideSeek.getProgress() / 100f;
            if (currentLayer != null) currentLayer.sideRatio = sideMarginRatio;
            updatePosLabel();
            redrawAll();
        }));
        positionPanel.addView(sideSeek);
        content.addView(positionPanel, lp(-1, -2, 0, 0, 0, 12));

        preview = new ImageView(this);
        preview.setAdjustViewBounds(true);
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        preview.setBackground(roundBg(Color.WHITE, 12));
        preview.setPadding(dp(4), dp(4), dp(4), dp(4));
        content.addView(preview, lp(-1, -2, 0, 0, 0, 12));

        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        Button save = secondaryBtn("ذخیره در گالری");
        Button share = secondaryBtn("اشتراک‌گذاری");
        save.setOnClickListener(v -> saveImage());
        share.setOnClickListener(v -> shareImage());
        actions.addView(save, new LinearLayout.LayoutParams(0, dp(48), 1));
        actions.addView(space(8));
        actions.addView(share, new LinearLayout.LayoutParams(0, dp(48), 1));
        content.addView(actions, lp(-1, -2, 0, 0, 0, 16));

        // ─── Support section ───────────────────────────────
        LinearLayout support = new LinearLayout(this);
        support.setOrientation(LinearLayout.VERTICAL);
        support.setBackground(roundBg(Color.rgb(30, 40, 70), 16));
        support.setPadding(dp(18), dp(16), dp(18), dp(16));

        TextView supportTitle = new TextView(this);
        supportTitle.setText("💙  حمایت از من");
        supportTitle.setTextSize(16);
        supportTitle.setTypeface(Typeface.DEFAULT_BOLD);
        supportTitle.setTextColor(Color.WHITE);
        supportTitle.setGravity(Gravity.CENTER);
        support.addView(supportTitle);

        TextView supportSub = new TextView(this);
        supportSub.setText("اگر از برنامه خوشتان آمد، از من حمایت کنید");
        supportSub.setTextSize(12);
        supportSub.setTextColor(Color.rgb(180, 190, 210));
        supportSub.setGravity(Gravity.CENTER);
        supportSub.setPadding(0, dp(4), 0, dp(12));
        support.addView(supportSub);

        // Card number
        TextView cardLabel = new TextView(this);
        cardLabel.setText("شماره کارت جهت حمایت:");
        cardLabel.setTextSize(12);
        cardLabel.setTextColor(Color.rgb(160, 170, 190));
        cardLabel.setGravity(Gravity.CENTER);
        support.addView(cardLabel);

        TextView cardNum = new TextView(this);
        cardNum.setText("6037  7016  2255  1023");
        cardNum.setTextSize(18);
        cardNum.setTypeface(Typeface.MONOSPACE);
        cardNum.setTypeface(Typeface.DEFAULT_BOLD);
        cardNum.setTextColor(Color.rgb(255, 215, 100));
        cardNum.setGravity(Gravity.CENTER);
        cardNum.setPadding(0, dp(6), 0, dp(4));
        cardNum.setOnClickListener(v -> {
            android.content.ClipboardManager cm = (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(android.content.ClipData.newPlainText("card", "6037701622551023"));
            Toast.makeText(this, "شماره کارت کپی شد", Toast.LENGTH_SHORT).show();
        });
        support.addView(cardNum);

        TextView cardHint = new TextView(this);
        cardHint.setText("(برای کپی لمس کنید)");
        cardHint.setTextSize(11);
        cardHint.setTextColor(Color.rgb(140, 150, 170));
        cardHint.setGravity(Gravity.CENTER);
        cardHint.setPadding(0, 0, 0, dp(14));
        support.addView(cardHint);

        // Instagram
        TextView igLabel = new TextView(this);
        igLabel.setText("دنبال کردن در اینستاگرام:");
        igLabel.setTextSize(12);
        igLabel.setTextColor(Color.rgb(160, 170, 190));
        igLabel.setGravity(Gravity.CENTER);
        support.addView(igLabel);

        Button igBtn = new Button(this);
        igBtn.setText("📷  ali.classik97");
        igBtn.setAllCaps(false);
        igBtn.setTextSize(15);
        igBtn.setTypeface(Typeface.DEFAULT_BOLD);
        igBtn.setTextColor(Color.WHITE);
        igBtn.setBackground(roundBg(Color.rgb(193, 53, 132), 12));
        LinearLayout.LayoutParams igLp = new LinearLayout.LayoutParams(-1, dp(48));
        igLp.topMargin = dp(8);
        igBtn.setLayoutParams(igLp);
        igBtn.setOnClickListener(v -> openInstagram("ali.classik97"));
        support.addView(igBtn);

        content.addView(support, lp(-1, -2, 0, 8, 0, 28));

        setContentView(root);
        updateStatus();
        updatePosLabel();
    }

    private void updateLayersInfo() {
        int n = lockedLayers.size();
        if (n == 0) {
            layersInfo.setText("لایه تثبیت‌شده: ۰ — هنوز متنی قفل نشده");
        } else {
            layersInfo.setText("لایه تثبیت‌شده: " + n + " — متن‌های قبلی ثابت مانده‌اند");
        }
    }

    private void updatePosLabel() {
        posLabel.setText(String.format("بالا: %.0f٪   |   حاشیه: %.0f٪",
                topOffsetRatio * 100, sideMarginRatio * 100));
    }

    private SeekBar.OnSeekBarChangeListener simpleSeek(Runnable onChange) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) onChange.run();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        };
    }

    // ─── Layer logic ───────────────────────────────────────
    private TextLayer buildLayerFromUI(String text) {
        TextLayer L = new TextLayer();
        L.text = text;
        L.topRatio = topOffsetRatio;
        L.sideRatio = sideMarginRatio;
        L.fontSizeScale = fontSizeScale;
        L.colorIndex = selectedColorIndex;
        if (useCustomDual || selectedColorIndex == colorNames.length - 1) {
            L.dual = true;
            if (customMultiColors.size() >= 2) {
                L.multiColors = new int[customMultiColors.size()];
                for (int i = 0; i < customMultiColors.size(); i++)
                    L.multiColors[i] = customMultiColors.get(i);
                L.c1 = L.multiColors[0];
                L.c2 = L.multiColors[1];
            } else {
                L.multiColors = null;
                L.c1 = customColor1;
                L.c2 = customColor2;
            }
        } else {
            L.dual = isDualArr[selectedColorIndex];
            L.multiColors = null;
            L.c1 = color1Arr[selectedColorIndex];
            L.c2 = color2Arr[selectedColorIndex];
        }
        L.useCustomFont = useCustomFont;
        L.fontIndex = selectedFont;
        L.fontId = selectedSavedFontId;
        return L;
    }

    private void previewCurrent() {
        String text = inputText.getText().toString().trim();
        if (text.isEmpty()) {
            Toast.makeText(this, "متن این لایه را بنویسید", Toast.LENGTH_SHORT).show();
            return;
        }
        currentLayer = buildLayerFromUI(text);
        positionPanel.setVisibility(View.VISIBLE);
        // sync seekbars to layer
        topSeek.setProgress(Math.round(topOffsetRatio * 100));
        sideSeek.setProgress(Math.round(sideMarginRatio * 100));
        redrawAll();
        Toast.makeText(this, "پیش‌نمایش شد — موقعیت را تنظیم کنید، بعد تثبیت کنید", Toast.LENGTH_LONG).show();
    }

    private void lockCurrent() {
        if (currentLayer == null) {
            // try build from input
            String text = inputText.getText().toString().trim();
            if (text.isEmpty()) {
                Toast.makeText(this, "اول پیش‌نمایش بگیرید", Toast.LENGTH_SHORT).show();
                return;
            }
            currentLayer = buildLayerFromUI(text);
        }
        // update position from current seekbars
        currentLayer.topRatio = topOffsetRatio;
        currentLayer.sideRatio = sideMarginRatio;
        lockedLayers.add(currentLayer);
        currentLayer = null;
        inputText.setText("");
        positionPanel.setVisibility(View.GONE);
        updateLayersInfo();
        redrawAll();
        Toast.makeText(this, "متن تثبیت شد! حالا متن بعدی را بنویسید", Toast.LENGTH_LONG).show();
    }

    private void redrawAll() {
        try {
            Bitmap paper = loadPaper();
            if (paper == null) throw new Exception("کاغذ لود نشد");

            int maxW = 1200;
            if (paper.getWidth() > maxW) {
                float scale = maxW / (float) paper.getWidth();
                paper = Bitmap.createScaledBitmap(paper, maxW, (int) (paper.getHeight() * scale), true);
            }

            Bitmap bmp = paper.copy(Bitmap.Config.ARGB_8888, true);
            Canvas canvas = new Canvas(bmp);

            for (TextLayer L : lockedLayers) {
                drawLayer(canvas, bmp, L);
            }
            if (currentLayer != null) {
                drawLayer(canvas, bmp, currentLayer);
            }

            resultBitmap = bmp;
            preview.setImageBitmap(bmp);
        } catch (Exception e) {
            Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private Bitmap loadPaper() throws Exception {
        if (useCustomPaper && selectedSavedPaperId != null) {
            return BitmapFactory.decodeStream(new FileInputStream(new File(papersDir, selectedSavedPaperId)));
        }
        InputStream is = getAssets().open("papers/paper" + selectedPaper + ".jpg");
        Bitmap b = BitmapFactory.decodeStream(is);
        is.close();
        return b;
    }

    private void drawLayer(Canvas canvas, Bitmap bmp, TextLayer L) {
        Typeface tf;
        try {
            if (L.useCustomFont && L.fontId != null)
                tf = Typeface.createFromFile(new File(fontsDir, L.fontId));
            else
                tf = Typeface.createFromAsset(getAssets(), "fonts/font" + L.fontIndex + ".ttf");
        } catch (Exception e) {
            tf = Typeface.DEFAULT;
        }

        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setTypeface(tf);
        paint.setTextSize(bmp.getWidth() * 0.05f * L.fontSizeScale);
        paint.setTextAlign(Paint.Align.RIGHT);

        // side margin: keep at least 10% of width for text
        float sidePx = bmp.getWidth() * Math.min(L.sideRatio, 0.45f);
        float maxWidth = bmp.getWidth() - sidePx * 2;
        if (maxWidth < bmp.getWidth() * 0.1f) {
            maxWidth = bmp.getWidth() * 0.1f;
            sidePx = (bmp.getWidth() - maxWidth) / 2f;
        }
        float startX = bmp.getWidth() - sidePx;

        // top: 0% = near top, 100% = near bottom — still draw what fits
        float y = bmp.getHeight() * L.topRatio + paint.getTextSize() * 0.9f;
        if (y < paint.getTextSize()) y = paint.getTextSize();
        float lineHeight = paint.getTextSize() * 1.5f;
        float bottomLimit = bmp.getHeight() - 4;

        List<String> lines = wrapText(L.text, paint, maxWidth);
        int wordIndex = 0;
        for (String line : lines) {
            if (y > bottomLimit) break;
            if (!L.dual) {
                paint.setColor(L.c1);
                canvas.drawText(line, startX, y, paint);
            } else {
                String[] words = line.split(" ");
                float x = startX;
                int[] cols = (L.multiColors != null && L.multiColors.length > 0)
                        ? L.multiColors
                        : new int[]{L.c1, L.c2};
                for (String word : words) {
                    if (word.isEmpty()) continue;
                    paint.setColor(cols[wordIndex % cols.length]);
                    canvas.drawText(word, x, y, paint);
                    x -= paint.measureText(word);
                    x -= paint.measureText(" ");
                    wordIndex++;
                }
            }
            y += lineHeight;
        }
    }

    private List<String> wrapText(String text, Paint paint, float maxWidth) {
        List<String> result = new ArrayList<>();
        for (String para : text.split("\n")) {
            if (para.trim().isEmpty()) { result.add(""); continue; }
            String[] words = para.split(" ");
            StringBuilder line = new StringBuilder();
            for (String word : words) {
                String test = line.length() == 0 ? word : line + " " + word;
                if (paint.measureText(test) <= maxWidth) line = new StringBuilder(test);
                else {
                    if (line.length() > 0) result.add(line.toString());
                    line = new StringBuilder(word);
                }
            }
            if (line.length() > 0) result.add(line.toString());
        }
        return result;
    }

    // ─── Menus (same as before, shortened) ─────────────────
    private void showPaperMenu() {
        String[] items = new String[5];
        for (int i = 0; i < 5; i++) items[i] = "کاغذ " + (i + 1);
        new AlertDialog.Builder(this)
                .setTitle("📄 انتخاب کاغذ")
                .setItems(items, (d, which) -> {
                    selectedPaper = which + 1;
                    useCustomPaper = false;
                    selectedSavedPaperId = null;
                    paperInfo.setText("کاغذ " + selectedPaper);
                    updateStatus();
                    redrawAll();
                    try {
                        InputStream is = getAssets().open("papers/paper" + selectedPaper + ".jpg");
                        showThumbDialog("کاغذ " + selectedPaper, BitmapFactory.decodeStream(is));
                        is.close();
                    } catch (Exception ignored) {}
                })
                .setNegativeButton("بستن", null).show();
    }

    private void showMyPapersMenu() {
        if (savedPaperIds.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("📁 کاغذهای من")
                    .setMessage("هنوز کاغذی ذخیره نشده.")
                    .setPositiveButton("افزودن", (d, w) -> pickPaper())
                    .setNegativeButton("بستن", null).show();
            return;
        }
        String[] items = new String[savedPaperIds.size() + 1];
        for (int i = 0; i < savedPaperIds.size(); i++)
            items[i] = "📄  " + displayName(savedPaperIds.get(i));
        items[savedPaperIds.size()] = "➕  افزودن کاغذ جدید";
        new AlertDialog.Builder(this).setTitle("📁 کاغذهای من")
                .setItems(items, (d, which) -> {
                    if (which == savedPaperIds.size()) { pickPaper(); return; }
                    String id = savedPaperIds.get(which);
                    useCustomPaper = true;
                    selectedSavedPaperId = id;
                    paperInfo.setText(displayName(id));
                    updateStatus();
                    redrawAll();
                })
                .setNeutralButton("حذف…", (d, w) -> showDeletePaperDialog())
                .setNegativeButton("بستن", null).show();
    }

    private void showFontMenu() {
        String[] items = new String[9];
        for (int i = 0; i < 9; i++) items[i] = "فونت " + (i + 1);
        new AlertDialog.Builder(this).setTitle("✏️ انتخاب فونت")
                .setItems(items, (d, which) -> {
                    selectedFont = which + 1;
                    useCustomFont = false;
                    selectedSavedFontId = null;
                    fontInfo.setText("فونت " + selectedFont);
                    updateStatus();
                })
                .setNegativeButton("بستن", null).show();
    }

    private void showMyFontsMenu() {
        if (savedFontIds.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("📁 فونت‌های من")
                    .setMessage("هنوز فونتی ذخیره نشده.")
                    .setPositiveButton("افزودن", (d, w) -> pickFont())
                    .setNegativeButton("بستن", null).show();
            return;
        }
        String[] items = new String[savedFontIds.size() + 1];
        for (int i = 0; i < savedFontIds.size(); i++)
            items[i] = "✏️  " + displayName(savedFontIds.get(i));
        items[savedFontIds.size()] = "➕  افزودن فونت جدید";
        new AlertDialog.Builder(this).setTitle("📁 فونت‌های من")
                .setItems(items, (d, which) -> {
                    if (which == savedFontIds.size()) { pickFont(); return; }
                    String id = savedFontIds.get(which);
                    useCustomFont = true;
                    selectedSavedFontId = id;
                    fontInfo.setText(displayName(id));
                    updateStatus();
                })
                .setNeutralButton("حذف…", (d, w) -> showDeleteFontDialog())
                .setNegativeButton("بستن", null).show();
    }

    private void showDeletePaperDialog() {
        if (savedPaperIds.isEmpty()) return;
        String[] items = new String[savedPaperIds.size()];
        for (int i = 0; i < savedPaperIds.size(); i++) items[i] = displayName(savedPaperIds.get(i));
        new AlertDialog.Builder(this).setTitle("حذف کاغذ")
                .setItems(items, (d, which) -> {
                    String id = savedPaperIds.get(which);
                    new File(papersDir, id).delete();
                    savedPaperIds.remove(id);
                    if (id.equals(selectedSavedPaperId)) {
                        useCustomPaper = false; selectedSavedPaperId = null;
                        paperInfo.setText("کاغذ " + selectedPaper);
                    }
                    persistLists(); updateStatus();
                }).setNegativeButton("انصراف", null).show();
    }

    private void showDeleteFontDialog() {
        if (savedFontIds.isEmpty()) return;
        String[] items = new String[savedFontIds.size()];
        for (int i = 0; i < savedFontIds.size(); i++) items[i] = displayName(savedFontIds.get(i));
        new AlertDialog.Builder(this).setTitle("حذف فونت")
                .setItems(items, (d, which) -> {
                    String id = savedFontIds.get(which);
                    new File(fontsDir, id).delete();
                    savedFontIds.remove(id);
                    if (id.equals(selectedSavedFontId)) {
                        useCustomFont = false; selectedSavedFontId = null;
                        fontInfo.setText("فونت " + selectedFont);
                    }
                    persistLists(); updateStatus();
                }).setNegativeButton("انصراف", null).show();
    }

    private void showThumbDialog(String title, Bitmap bmp) {
        if (bmp == null) return;
        ImageView iv = new ImageView(this);
        iv.setAdjustViewBounds(true);
        iv.setMaxHeight(dp(280));
        iv.setImageBitmap(bmp);
        iv.setPadding(dp(12), dp(8), dp(12), dp(8));
        new AlertDialog.Builder(this).setTitle(title).setView(iv).setPositiveButton("باشه", null).show();
    }


    private void showCustomColorDialog() {
        // Step 1: choose how many colors
        String[] counts = new String[11];
        for (int i = 0; i < 11; i++) counts[i] = (i + 2) + " رنگ";
        new AlertDialog.Builder(this)
                .setTitle("🎨 تعداد رنگ ترکیب")
                .setItems(counts, (d, which) -> {
                    int count = which + 2; // 2..12
                    showMultiColorPicker(count);
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private void showMultiColorPicker(final int count) {
        final boolean[] selected = new boolean[palette.length];
        final java.util.ArrayList<Integer> chosen = new java.util.ArrayList<>();

        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(12), dp(16), dp(8));

        TextView info = new TextView(this);
        info.setText("تا " + count + " رنگ انتخاب کنید (به ترتیب لمس)");
        info.setTextSize(13);
        info.setTextColor(Color.rgb(60, 70, 90));
        info.setPadding(0, 0, 0, dp(10));
        box.addView(info);

        final TextView preview = new TextView(this);
        preview.setText("انتخاب‌شده: ۰ / " + count);
        preview.setTextSize(13);
        preview.setTypeface(Typeface.DEFAULT_BOLD);
        preview.setTextColor(Color.rgb(40, 60, 140));
        preview.setPadding(0, 0, 0, dp(10));
        box.addView(preview);

        // Grid of colors - 4 per row
        LinearLayout currentRow = null;
        for (int i = 0; i < palette.length; i++) {
            if (i % 4 == 0) {
                currentRow = new LinearLayout(this);
                currentRow.setOrientation(LinearLayout.HORIZONTAL);
                currentRow.setGravity(Gravity.CENTER);
                currentRow.setPadding(0, 0, 0, dp(8));
                box.addView(currentRow);
            }
            final int idx = i;
            final int col = palette[i];
            final Button b = colorDot(col, false);
            // larger
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(48), dp(48));
            lp.setMargins(dp(6), 0, dp(6), 0);
            b.setLayoutParams(lp);
            b.setOnClickListener(v -> {
                if (selected[idx]) {
                    // deselect
                    selected[idx] = false;
                    chosen.remove((Integer) col);
                    GradientDrawable d = new GradientDrawable();
                    d.setShape(GradientDrawable.OVAL);
                    d.setColor(col);
                    d.setStroke(dp(1), Color.LTGRAY);
                    b.setBackground(d);
                    b.setText("");
                } else {
                    if (chosen.size() >= count) {
                        Toast.makeText(this, "حداکثر " + count + " رنگ", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    selected[idx] = true;
                    chosen.add(col);
                    GradientDrawable d = new GradientDrawable();
                    d.setShape(GradientDrawable.OVAL);
                    d.setColor(col);
                    d.setStroke(dp(3), Color.rgb(40, 60, 140));
                    b.setBackground(d);
                    b.setText(String.valueOf(chosen.size()));
                    b.setTextColor(Color.WHITE);
                    b.setTextSize(12);
                    b.setGravity(Gravity.CENTER);
                }
                preview.setText("انتخاب‌شده: " + chosen.size() + " / " + count);
            });
            currentRow.addView(b);
        }

        TextView hint = new TextView(this);
        hint.setText("کلمات به ترتیب همین رنگ‌ها یکی‌درمیان نوشته می‌شوند");
        hint.setTextSize(11);
        hint.setTextColor(Color.rgb(100, 110, 130));
        hint.setPadding(0, dp(6), 0, 0);
        box.addView(hint);

        scroll.addView(box);

        new AlertDialog.Builder(this)
                .setTitle("انتخاب " + count + " رنگ")
                .setView(scroll)
                .setPositiveButton("تأیید", (d, w) -> {
                    if (chosen.size() < 2) {
                        Toast.makeText(this, "حداقل ۲ رنگ انتخاب کنید", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    customMultiColors.clear();
                    customMultiColors.addAll(chosen);
                    customColor1 = chosen.get(0);
                    customColor2 = chosen.get(1);
                    useCustomDual = true;
                    selectedColorIndex = colorNames.length - 1;
                    refreshChips(colorRow, selectedColorIndex);
                    updateStatus();
                    Toast.makeText(this, chosen.size() + " رنگ برای ترکیب ذخیره شد", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("انصراف", null)
                .show();
    }

    private Button colorDot(int color, boolean selected) {
        Button b = new Button(this);
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        d.setStroke(selected ? dp(3) : dp(1), selected ? Color.rgb(50, 90, 200) : Color.LTGRAY);
        b.setBackground(d);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(36), dp(36));
        lp.setMargins(0, 0, dp(8), 0);
        b.setLayoutParams(lp);
        b.setTag(color);
        return b;
    }

    private void highlightRow(LinearLayout row, View selected) {
        for (int i = 0; i < row.getChildCount(); i++) {
            View v = row.getChildAt(i);
            GradientDrawable d = new GradientDrawable();
            d.setShape(GradientDrawable.OVAL);
            d.setColor((Integer) v.getTag());
            d.setStroke(v == selected ? dp(3) : dp(1), v == selected ? Color.rgb(50, 90, 200) : Color.LTGRAY);
            v.setBackground(d);
        }
    }

    // ─── Persistence & pickers ─────────────────────────────
    private void loadSavedLists() {
        savedFontIds.clear(); savedPaperIds.clear();
        Set<String> fonts = prefs.getStringSet(KEY_FONTS, new HashSet<>());
        Set<String> papers = prefs.getStringSet(KEY_PAPERS, new HashSet<>());
        if (fonts != null) for (String id : fonts) if (new File(fontsDir, id).exists()) savedFontIds.add(id);
        if (papers != null) for (String id : papers) if (new File(papersDir, id).exists()) savedPaperIds.add(id);
    }

    private void persistLists() {
        prefs.edit().putStringSet(KEY_FONTS, new HashSet<>(savedFontIds))
                .putStringSet(KEY_PAPERS, new HashSet<>(savedPaperIds)).apply();
    }

    private String displayName(String id) {
        try {
            if (id.startsWith("font_")) return "فونت من " + id.replace("font_", "").replace(".ttf", "").replace(".otf", "");
            if (id.startsWith("paper_")) return "کاغذ من " + id.replace("paper_", "").replace(".jpg", "").replace(".png", "");
        } catch (Exception ignored) {}
        return id;
    }

    private void updateStatus() {
        String s = useCustomPaper ? "📄 " + displayName(selectedSavedPaperId) : "📄 کاغذ " + selectedPaper;
        s += useCustomFont ? "   ✏️ " + displayName(selectedSavedFontId) : "   ✏️ فونت " + selectedFont;
        if (useCustomDual) {
            int n = customMultiColors.size() >= 2 ? customMultiColors.size() : 2;
            s += "   🎨 ترکیب " + n + " رنگ";
        }
        statusLabel.setText(s);
    }

    private void pickPaper() {
        if (!ensurePermission()) return;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("image/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(i, "انتخاب کاغذ"), REQ_PAPER);
    }

    private void pickFont() {
        if (!ensurePermission()) return;
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"font/ttf", "font/otf", "application/x-font-ttf", "application/octet-stream"});
        startActivityForResult(Intent.createChooser(i, "انتخاب فونت"), REQ_FONT);
    }

    private boolean ensurePermission() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_PERM);
                return false;
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_PERM);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == REQ_PERM) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                Toast.makeText(this, "مجوز داده شد، دوباره انتخاب کنید", Toast.LENGTH_SHORT).show();
            else Toast.makeText(this, "برای انتخاب فایل به مجوز نیاز است", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_PAPER) {
                int next = savedPaperIds.size() + 1;
                String id = "paper_" + next + ".jpg";
                while (new File(papersDir, id).exists()) { next++; id = "paper_" + next + ".jpg"; }
                copyUriToFile(uri, new File(papersDir, id));
                savedPaperIds.add(id); persistLists();
                useCustomPaper = true; selectedSavedPaperId = id;
                paperInfo.setText(displayName(id)); updateStatus(); redrawAll();
                Toast.makeText(this, "کاغذ ذخیره شد", Toast.LENGTH_SHORT).show();
            } else if (requestCode == REQ_FONT) {
                int next = savedFontIds.size() + 1;
                String id = "font_" + next + ".ttf";
                while (new File(fontsDir, id).exists()) { next++; id = "font_" + next + ".ttf"; }
                File dest = new File(fontsDir, id);
                copyUriToFile(uri, dest);
                Typeface.createFromFile(dest);
                savedFontIds.add(id); persistLists();
                useCustomFont = true; selectedSavedFontId = id;
                fontInfo.setText(displayName(id)); updateStatus();
                Toast.makeText(this, "فونت ذخیره شد", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void copyUriToFile(Uri uri, File dest) throws Exception {
        InputStream is = getContentResolver().openInputStream(uri);
        FileOutputStream fos = new FileOutputStream(dest);
        byte[] buf = new byte[8192]; int n;
        while ((n = is.read(buf)) > 0) fos.write(buf, 0, n);
        fos.close(); is.close();
    }

    
    private void openInstagram(String username) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://instagram.com/_u/" + username));
            intent.setPackage("com.instagram.android");
            startActivity(intent);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/" + username)));
            } catch (Exception e2) {
                Toast.makeText(this, "نتوانست اینستاگرام را باز کند", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void saveImage() {
        if (resultBitmap == null) {
            Toast.makeText(this, "اول متن بسازید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            String name = "Dastnevis_" + System.currentTimeMillis() + ".png";
            OutputStream out;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dastnevis");
                Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                out = getContentResolver().openOutputStream(uri);
            } else {
                File dir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "Dastnevis");
                if (!dir.exists()) dir.mkdirs();
                out = new FileOutputStream(new File(dir, name));
            }
            resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            Toast.makeText(this, "در گالری ذخیره شد", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void shareImage() {
        if (resultBitmap == null) {
            Toast.makeText(this, "اول متن بسازید", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "Dastnevis_share_" + System.currentTimeMillis() + ".png");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            if (Build.VERSION.SDK_INT >= 29)
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Dastnevis");
            Uri shareUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            OutputStream os = getContentResolver().openOutputStream(shareUri);
            resultBitmap.compress(Bitmap.CompressFormat.PNG, 100, os);
            os.close();
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("image/png");
            intent.putExtra(Intent.EXTRA_STREAM, shareUri);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(intent, "اشتراک‌گذاری"));
        } catch (Exception e) {
            Toast.makeText(this, "خطا: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    // UI helpers
    private TextView cardLabel(String t) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(13); v.setTextColor(Color.rgb(80, 90, 120));
        v.setTypeface(Typeface.DEFAULT_BOLD); v.setPadding(0, 0, 0, dp(6));
        return v;
    }
    private TextView infoText(String t) {
        TextView v = new TextView(this);
        v.setText(t); v.setTextSize(12); v.setTextColor(Color.rgb(100, 110, 130));
        return v;
    }
    private Button menuBtn(String text, int color) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setTextColor(Color.WHITE);
        b.setBackground(roundBg(color, 12));
        return b;
    }
    private LinearLayout makeChipRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }
    private HorizontalScrollView wrapH(View v) {
        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false); hsv.addView(v);
        return hsv;
    }
    private Button chip(String text, boolean selected) {
        Button b = new Button(this);
        b.setText(text); b.setAllCaps(false); b.setTextSize(12);
        b.setPadding(dp(12), dp(4), dp(12), dp(4));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(38));
        lp.setMargins(0, 0, dp(6), 0); b.setLayoutParams(lp);
        styleChip(b, selected); return b;
    }
    private void styleChip(Button b, boolean selected) {
        if (selected) { b.setBackground(roundBg(Color.rgb(40, 60, 140), 18)); b.setTextColor(Color.WHITE); }
        else { b.setBackground(roundBg(Color.WHITE, 18)); b.setTextColor(Color.rgb(40, 50, 70)); }
    }
    private void refreshChips(LinearLayout row, int selectedIdx) {
        for (int i = 0; i < row.getChildCount(); i++) styleChip((Button) row.getChildAt(i), i == selectedIdx);
    }
    private Button primaryBtn(String t) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(16);
        b.setTypeface(Typeface.DEFAULT_BOLD); b.setTextColor(Color.WHITE);
        b.setBackground(roundBg(Color.rgb(40, 60, 140), 14)); return b;
    }
    private Button secondaryBtn(String t) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextSize(13);
        b.setTextColor(Color.rgb(40, 60, 120)); b.setBackground(roundBg(Color.WHITE, 12)); return b;
    }
    private GradientDrawable roundBg(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private View space(int w) {
        View v = new View(this); v.setLayoutParams(new LinearLayout.LayoutParams(dp(w), 1)); return v;
    }
    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b)); return p;
    }
    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }
}
