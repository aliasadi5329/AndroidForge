# Pro Soft Keyboard

A professional, feature-rich Android soft keyboard (IME) built with **Kotlin**.

## Features

- **English QWERTY** layout
- **Persian (فارسی)** layout with proper characters
- **Numbers** panel
- **Symbols** panel
- **Emoji** panel with popular emojis
- **Shift / Caps Lock** support
- **Language switch** (English ⇄ Persian)
- **Candidate / Suggestion bar** (basic dictionary for EN + FA)
- **Themes**: Dark, Light, Blue
- **Vibration** feedback (configurable)
- **Sound** feedback (configurable)
- **Long-press** alternatives for some keys
- Modern Material Design UI
- Settings activity for easy configuration

## How to enable

1. Install the APK
2. Open **Pro Keyboard** app → tap **Enable Pro Keyboard**
3. Turn on the keyboard in system settings
4. Tap **Select as Input Method** and choose **Pro Soft Keyboard**
5. Start typing in any text field!

## Project structure

```
ProKeyboard/
├── app/
│   ├── src/main/
│   │   ├── java/com/prokeyboard/
│   │   │   ├── SettingsActivity.kt
│   │   │   └── ime/
│   │   │       ├── ProKeyboardService.kt
│   │   │       └── KeyboardLayout.kt
│   │   ├── res/
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
├── settings.gradle
└── gradle.properties
```

## Build

```bash
./gradlew assembleDebug
```

APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

## Requirements

- minSdk 24 (Android 7.0+)
- targetSdk 34
- Kotlin + AndroidX

---
Made for AndroidForge
