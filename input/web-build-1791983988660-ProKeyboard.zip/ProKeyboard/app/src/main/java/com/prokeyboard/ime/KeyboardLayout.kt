package com.prokeyboard.ime

object KeyboardLayout {

    enum class Mode {
        LETTERS_EN, LETTERS_FA, NUMBERS, SYMBOLS, EMOJI
    }

    // English QWERTY
    val EN_ROW1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val EN_ROW2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
    val EN_ROW3 = listOf("⇧", "z", "x", "c", "v", "b", "n", "m", "⌫")

    // Persian (standard mobile layout approximation)
    val FA_ROW1 = listOf("ض", "ص", "ث", "ق", "ف", "غ", "ع", "ه", "خ", "ح", "ج", "چ")
    val FA_ROW2 = listOf("ش", "س", "ی", "ب", "ل", "ا", "ت", "ن", "م", "ک", "گ")
    val FA_ROW3 = listOf("⇧", "ظ", "ط", "ز", "ر", "ذ", "د", "پ", "و", "⌫")

    val NUM_ROW1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val NUM_ROW2 = listOf("-", "/", ":", ";", "(", ")", "\$", "&", "@", "\"")
    val NUM_ROW3 = listOf("#+=", ".", ",", "?", "!", "'", "⌫")

    val SYM_ROW1 = listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "=")
    val SYM_ROW2 = listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•")
    val SYM_ROW3 = listOf("123", ".", ",", "?", "!", "'", "⌫")

    // Common emojis
    val EMOJI_ROW1 = listOf("😀", "😂", "🥰", "😍", "😎", "🤔", "😢", "😡", "👍", "👎")
    val EMOJI_ROW2 = listOf("❤️", "🔥", "✨", "🎉", "🙏", "👏", "💪", "👀", "💯", "🚀")
    val EMOJI_ROW3 = listOf("ABC", "🌸", "🍕", "⚽", "🎵", "📱", "🌟", "💎", "⌫")

    val BOTTOM_EN = listOf("123", "🌐", " ", "😀", "↵")
    val BOTTOM_FA = listOf("123", "🌐", " ", "😀", "↵")
    val BOTTOM_NUM = listOf("ABC", "🌐", " ", "😀", "↵")
    val BOTTOM_SYM = listOf("ABC", "🌐", " ", "😀", "↵")
    val BOTTOM_EMOJI = listOf("ABC", "🌐", " ", ".", "↵")

    fun isSpecialKey(key: String): Boolean {
        return key in listOf("⇧", "⌫", "123", "#+=", "ABC", "🌐", "😀", "↵", " ")
    }

    fun isShiftKey(key: String) = key == "⇧"
    fun isBackspace(key: String) = key == "⌫"
    fun isEnter(key: String) = key == "↵"
    fun isSpace(key: String) = key == " "
    fun isLanguage(key: String) = key == "🌐"
    fun isNumbers(key: String) = key == "123"
    fun isSymbols(key: String) = key == "#+="
    fun isLetters(key: String) = key == "ABC"
    fun isEmoji(key: String) = key == "😀"
}
