package com.prokeyboard.ime

import android.content.Context
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.prokeyboard.R

class ProKeyboardService : InputMethodService() {

    private var keyboardView: View? = null
    private var keysContainer: LinearLayout? = null
    private var candidateBar: LinearLayout? = null

    private var currentMode = KeyboardLayout.Mode.LETTERS_EN
    private var isShifted = false
    private var isCapsLock = false
    private var isPersian = false

    private val simpleDictionary = listOf(
        "the", "be", "to", "of", "and", "a", "in", "that", "have", "I",
        "it", "for", "not", "on", "with", "he", "as", "you", "do", "at",
        "this", "but", "his", "by", "from", "they", "we", "say", "her", "she",
        "or", "an", "will", "my", "one", "all", "would", "there", "their", "what",
        "سلام", "خداحافظ", "ممنون", "لطفا", "بله", "خیر", "خوب", "بد", "امروز", "فردا",
        "من", "تو", "او", "ما", "شما", "آنها", "این", "آن", "کجا", "چطور"
    )

    private var currentWord = StringBuilder()

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null)
        keysContainer = keyboardView!!.findViewById(R.id.keys_container)
        candidateBar = keyboardView!!.findViewById(R.id.candidate_bar)
        applyTheme()
        buildKeyboard()
        return keyboardView!!
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        currentWord.clear()
        updateCandidates()
        applyTheme()
        buildKeyboard()
    }

    private fun applyTheme() {
        val prefs = getSharedPreferences("pro_keyboard_prefs", Context.MODE_PRIVATE)
        val theme = prefs.getString("theme", "dark") ?: "dark"
        val root = keyboardView?.findViewById<View>(R.id.keyboard_root) ?: return

        when (theme) {
            "light" -> {
                root.setBackgroundColor(ContextCompat.getColor(this, R.color.kb_bg_light))
            }
            "blue" -> {
                root.setBackgroundColor(ContextCompat.getColor(this, R.color.kb_bg_blue))
            }
            else -> {
                root.setBackgroundColor(ContextCompat.getColor(this, R.color.kb_bg_dark))
            }
        }
    }

    private fun buildKeyboard() {
        keysContainer?.removeAllViews()

        val rows = when (currentMode) {
            KeyboardLayout.Mode.LETTERS_EN -> listOf(
                KeyboardLayout.EN_ROW1,
                KeyboardLayout.EN_ROW2,
                KeyboardLayout.EN_ROW3,
                KeyboardLayout.BOTTOM_EN
            )
            KeyboardLayout.Mode.LETTERS_FA -> listOf(
                KeyboardLayout.FA_ROW1,
                KeyboardLayout.FA_ROW2,
                KeyboardLayout.FA_ROW3,
                KeyboardLayout.BOTTOM_FA
            )
            KeyboardLayout.Mode.NUMBERS -> listOf(
                KeyboardLayout.NUM_ROW1,
                KeyboardLayout.NUM_ROW2,
                KeyboardLayout.NUM_ROW3,
                KeyboardLayout.BOTTOM_NUM
            )
            KeyboardLayout.Mode.SYMBOLS -> listOf(
                KeyboardLayout.SYM_ROW1,
                KeyboardLayout.SYM_ROW2,
                KeyboardLayout.SYM_ROW3,
                KeyboardLayout.BOTTOM_SYM
            )
            KeyboardLayout.Mode.EMOJI -> listOf(
                KeyboardLayout.EMOJI_ROW1,
                KeyboardLayout.EMOJI_ROW2,
                KeyboardLayout.EMOJI_ROW3,
                KeyboardLayout.BOTTOM_EMOJI
            )
        }

        rows.forEach { rowKeys ->
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            rowKeys.forEach { keyLabel ->
                val btn = createKeyButton(keyLabel)
                rowLayout.addView(btn)
            }
            keysContainer?.addView(rowLayout)
        }
    }

    private fun createKeyButton(label: String): Button {
        val btn = Button(this)
        val displayLabel = when {
            label == "⇧" && isCapsLock -> "⇪"
            label == "⇧" && isShifted -> "⇧"
            isShifted || isCapsLock -> label.uppercase()
            else -> label
        }
        btn.text = displayLabel

        val isSpecial = KeyboardLayout.isSpecialKey(label)
        val isSpace = KeyboardLayout.isSpace(label)

        val lp = LinearLayout.LayoutParams(
            0,
            resources.getDimensionPixelSize(android.R.dimen.app_icon_size).coerceAtLeast(dp(48)),
            if (isSpace) 4f else if (isSpecial) 1.4f else 1f
        ).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        btn.layoutParams = lp
        btn.isAllCaps = false
        btn.textSize = if (label.length > 1 && !isEmojiChar(label)) 14f else 18f
        btn.minHeight = 0
        btn.minWidth = 0
        btn.setPadding(0, 0, 0, 0)

        val prefs = getSharedPreferences("pro_keyboard_prefs", Context.MODE_PRIVATE)
        val theme = prefs.getString("theme", "dark") ?: "dark"

        when {
            KeyboardLayout.isEnter(label) -> {
                btn.setBackgroundResource(R.drawable.key_accent_bg)
                btn.setTextColor(ContextCompat.getColor(this, R.color.white))
            }
            isSpecial -> {
                btn.setBackgroundResource(R.drawable.key_special_bg)
                btn.setTextColor(ContextCompat.getColor(this, R.color.white))
            }
            else -> {
                btn.setBackgroundResource(R.drawable.key_bg)
                btn.setTextColor(ContextCompat.getColor(this, R.color.white))
            }
        }

        // Light theme override for normal keys
        if (theme == "light" && !isSpecial && !KeyboardLayout.isEnter(label)) {
            btn.setBackgroundResource(R.drawable.key_bg) // still use dark style or adjust
            // For simplicity keep consistent; can enhance later
        }

        btn.setOnClickListener {
            onKeyClick(label)
        }

        btn.setOnLongClickListener {
            onKeyLongClick(label)
            true
        }

        return btn
    }

    private fun onKeyClick(key: String) {
        performFeedback()
        val ic: InputConnection = currentInputConnection ?: return

        when {
            KeyboardLayout.isShiftKey(key) -> {
                if (isShifted && !isCapsLock) {
                    isCapsLock = true
                    isShifted = true
                } else if (isCapsLock) {
                    isCapsLock = false
                    isShifted = false
                } else {
                    isShifted = true
                }
                buildKeyboard()
            }
            KeyboardLayout.isBackspace(key) -> {
                ic.deleteSurroundingText(1, 0)
                if (currentWord.isNotEmpty()) {
                    currentWord.deleteCharAt(currentWord.length - 1)
                }
                updateCandidates()
            }
            KeyboardLayout.isEnter(key) -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                when (action) {
                    EditorInfo.IME_ACTION_SEARCH,
                    EditorInfo.IME_ACTION_GO,
                    EditorInfo.IME_ACTION_SEND,
                    EditorInfo.IME_ACTION_DONE,
                    EditorInfo.IME_ACTION_NEXT -> {
                        ic.performEditorAction(action)
                    }
                    else -> {
                        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                    }
                }
                currentWord.clear()
                updateCandidates()
            }
            KeyboardLayout.isSpace(key) -> {
                ic.commitText(" ", 1)
                currentWord.clear()
                updateCandidates()
                if (isShifted && !isCapsLock) {
                    isShifted = false
                    buildKeyboard()
                }
            }
            KeyboardLayout.isLanguage(key) -> {
                isPersian = !isPersian
                currentMode = if (isPersian) KeyboardLayout.Mode.LETTERS_FA else KeyboardLayout.Mode.LETTERS_EN
                isShifted = false
                isCapsLock = false
                buildKeyboard()
            }
            KeyboardLayout.isNumbers(key) -> {
                currentMode = KeyboardLayout.Mode.NUMBERS
                buildKeyboard()
            }
            KeyboardLayout.isSymbols(key) -> {
                currentMode = KeyboardLayout.Mode.SYMBOLS
                buildKeyboard()
            }
            KeyboardLayout.isLetters(key) -> {
                currentMode = if (isPersian) KeyboardLayout.Mode.LETTERS_FA else KeyboardLayout.Mode.LETTERS_EN
                buildKeyboard()
            }
            KeyboardLayout.isEmoji(key) -> {
                currentMode = KeyboardLayout.Mode.EMOJI
                buildKeyboard()
            }
            else -> {
                var text = key
                if (currentMode == KeyboardLayout.Mode.LETTERS_EN || currentMode == KeyboardLayout.Mode.LETTERS_FA) {
                    if (isShifted || isCapsLock) {
                        text = key.uppercase()
                    }
                    if (isShifted && !isCapsLock) {
                        isShifted = false
                        buildKeyboard()
                    }
                }
                ic.commitText(text, 1)
                if (text.length == 1 && text[0].isLetter()) {
                    currentWord.append(text.lowercase())
                } else {
                    currentWord.clear()
                }
                updateCandidates()
            }
        }
    }

    private fun onKeyLongClick(key: String) {
        // Simple long-press alternatives
        val alternatives = mapOf(
            "a" to "àáâäæãåā",
            "e" to "èéêëēėę",
            "i" to "îïíīįì",
            "o" to "ôöòóœøōõ",
            "u" to "ûüùúū",
            "c" to "çćč",
            "n" to "ñń",
            "s" to "śš",
            "." to "…",
            "-" to "—–"
        )
        val alts = alternatives[key.lowercase()]
        if (alts != null && alts.isNotEmpty()) {
            val ic = currentInputConnection ?: return
            // For simplicity commit first alternative
            ic.commitText(alts[0].toString(), 1)
            performFeedback()
        }
    }

    private fun updateCandidates() {
        candidateBar?.removeAllViews()
        if (currentWord.isEmpty()) return

        val word = currentWord.toString()
        val matches = simpleDictionary.filter {
            it.startsWith(word, ignoreCase = true) && it != word
        }.take(5)

        matches.forEach { suggestion ->
            val tv = TextView(this).apply {
                text = suggestion
                setTextColor(ContextCompat.getColor(this@ProKeyboardService, R.color.white))
                textSize = 15f
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener {
                    val ic = currentInputConnection ?: return@setOnClickListener
                    // Replace current word
                    ic.deleteSurroundingText(currentWord.length, 0)
                    ic.commitText("$suggestion ", 1)
                    currentWord.clear()
                    updateCandidates()
                    performFeedback()
                }
            }
            candidateBar?.addView(tv)
        }
    }

    private fun performFeedback() {
        val prefs = getSharedPreferences("pro_keyboard_prefs", Context.MODE_PRIVATE)

        if (prefs.getBoolean("vibration", true)) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator.vibrate(
                        VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(20, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(20)
                    }
                }
            } catch (_: Exception) {}
        }

        if (prefs.getBoolean("sound", false)) {
            try {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.5f)
            } catch (_: Exception) {}
        }
    }

    private fun isEmojiChar(s: String): Boolean {
        if (s.isEmpty()) return false
        val code = s.codePointAt(0)
        return code > 0x1F300
    }

    private fun dp(value: Int): Int {
        return (value * resources.displayMetrics.density).toInt()
    }
}
