package com.prokeyboard

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import android.widget.RadioButton
import android.widget.RadioGroup
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("pro_keyboard_prefs", Context.MODE_PRIVATE)

        findViewById<MaterialButton>(R.id.btn_enable).setOnClickListener {
            startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
        }

        findViewById<MaterialButton>(R.id.btn_select).setOnClickListener {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showInputMethodPicker()
        }

        val themeGroup = findViewById<RadioGroup>(R.id.theme_group)
        when (prefs.getString("theme", "light")) {
            "light" -> themeGroup.check(R.id.theme_light)
            "blue" -> themeGroup.check(R.id.theme_blue)
            else -> themeGroup.check(R.id.theme_light)
        }

        themeGroup.setOnCheckedChangeListener { _, checkedId ->
            val theme = when (checkedId) {
                R.id.theme_light -> "light"
                R.id.theme_blue -> "blue"
                else -> "dark"
            }
            prefs.edit().putString("theme", theme).apply()
        }

        val vibSwitch = findViewById<SwitchMaterial>(R.id.switch_vibration)
        vibSwitch.isChecked = prefs.getBoolean("vibration", true)
        vibSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibration", isChecked).apply()
        }

        val soundSwitch = findViewById<SwitchMaterial>(R.id.switch_sound)
        soundSwitch.isChecked = prefs.getBoolean("sound", false)
        soundSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("sound", isChecked).apply()
        }

        val previewSwitch = findViewById<SwitchMaterial>(R.id.switch_preview)
        previewSwitch.isChecked = prefs.getBoolean("preview", true)
        previewSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("preview", isChecked).apply()
        }
    }
}
