package com.prokeyboard.ime

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.prokeyboard.R

class ProKeyboardService : InputMethodService() {

    private var keyboardView: View? = null
    private var keysContainer: LinearLayout? = null
    private var candidateBar: LinearLayout? = null

    private var currentMode = KeyboardLayout.Mode.LETTERS_FA
    private var isShifted = false
    private var isCapsLock = false
    private var isPersian = true
    private var emojiPage = 0

    private val simpleDictionary = listOf(
        "سلام", "خداحافظ", "ممنون", "لطفا", "بله", "خیر", "خوب", "بد", "امروز", "فردا",
        "من", "تو", "او", "ما", "شما", "آنها", "این", "آن", "کجا", "چطور", "چی", "چرا",
        "the", "be", "to", "of", "and", "a", "in", "that", "have", "I", "it", "for", "not",
        "on", "with", "he", "as", "you", "do", "at", "this", "but", "his", "by", "from"
    )

    private var currentWord = StringBuilder()
    private val recentClips = mutableListOf<String>()

    override fun onCreateInputView(): View {
        keyboardView = layoutInflater.inflate(R.layout.keyboard_view, null)
        keysContainer = keyboardView!!.findViewById(R.id.keys_container)
        candidateBar = keyboardView!!.findViewById(R.id.candidate_bar)
        applyTheme()
        buildKeyboard()
        return keyboardView!!
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        currentWord.clear()
        updateCandidates()
        applyTheme()
        buildKeyboard()
    }

    private fun applyTheme() {
        val prefs = getSharedPreferences("pro_keyboard_prefs", Context.MODE_PRIVATE)
        // Default to light to match the screenshot
        val theme = prefs.getString("theme", "light") ?: "light"
        val root = keyboardView?.findViewById<View>(R.id.keyboard_root) ?: return

        when (theme) {
            "dark" -> root.setBackgroundColor(0xFF1E1E1E.toInt())
            "blue" -> root.setBackgroundColor(0xFF0D47A1.toInt())
            else -> root.setBackgroundColor(0xFFE8E8E8.toInt()) // light gray like screenshot
        }
    }

    private fun buildKeyboard() {
        keysContainer?.removeAllViews()

        when (currentMode) {
            KeyboardLayout.Mode.LETTERS_FA -> buildPersianKeyboard()
            KeyboardLayout.Mode.LETTERS_EN -> buildEnglishKeyboard()
            KeyboardLayout.Mode.NUMBERS -> buildNumbersKeyboard()
            KeyboardLayout.Mode.SYMBOLS -> buildSymbolsKeyboard()
            KeyboardLayout.Mode.EMOJI -> buildEmojiKeyboard()
            KeyboardLayout.Mode.CLIPBOARD -> buildClipboardKeyboard()
        }
    }

    private fun buildPersianKeyboard() {
        // Numbers row (exactly like screenshot)
        addKeyRow(KeyboardLayout.FA_NUMBERS, isNumberRow = true)

        // Row 1
        addKeyRow(KeyboardLayout.FA_ROW1)

        // Row 2
        addKeyRow(KeyboardLayout.FA_ROW2)

        // Row 3 with Shift + letters + Backspace
        val row3 = mutableListOf("⇧")
        row3.addAll(KeyboardLayout.FA_ROW3)
        row3.add("⌫")
        addKeyRow(row3, isSpecialRow = true)

        // Bottom row: نماد | ABC | space | . | ↵   + clipboard & emoji
        addBottomRow(
            leftKeys = listOf("نماد", "ABC"),
            rightKeys = listOf("📋", "😀", ".", "↵")
        )
    }

    private fun buildEnglishKeyboard() {
        addKeyRow(KeyboardLayout.EN_ROW1)
        addKeyRow(KeyboardLayout.EN_ROW2)

        val row3 = mutableListOf("⇧")
        row3.addAll(KeyboardLayout.EN_ROW3)
        row3.add("⌫")
        addKeyRow(row3, isSpecialRow = true)

        addBottomRow(
            leftKeys = listOf("123", "🌐"),
            rightKeys = listOf("📋", "😀", ".", "↵")
        )
    }

    private fun buildNumbersKeyboard() {
        addKeyRow(KeyboardLayout.NUM_ROW1)
        addKeyRow(KeyboardLayout.NUM_ROW2)
        addKeyRow(KeyboardLayout.NUM_ROW3 + listOf("⌫"))

        addBottomRow(
            leftKeys = listOf("ABC", "نماد"),
            rightKeys = listOf("📋", "😀", ".", "↵")
        )
    }

    private fun buildSymbolsKeyboard() {
        addKeyRow(KeyboardLayout.SYM_ROW1)
        addKeyRow(KeyboardLayout.SYM_ROW2)
        addKeyRow(KeyboardLayout.SYM_ROW3 + listOf("⌫"))

        addBottomRow(
            leftKeys = listOf("ABC", "123"),
            rightKeys = listOf("📋", "😀", ".", "↵")
        )
    }

    private fun buildEmojiKeyboard() {
        val pageSize = 30
        val start = emojiPage * pageSize
        val end = minOf(start + pageSize, KeyboardLayout.EMOJIS.size)
        val pageEmojis = KeyboardLayout.EMOJIS.subList(start, end)

        // 6 columns
        var i = 0
        while (i < pageEmojis.size) {
            val row = pageEmojis.subList(i, minOf(i + 6, pageEmojis.size))
            addKeyRow(row, isEmojiRow = true)
            i += 6
        }

        // Navigation + back
        val nav = mutableListOf<String>()
        if (emojiPage > 0) nav.add("←")
        nav.add("ABC")
        if (end < KeyboardLayout.EMOJIS.size) nav.add("→")
        nav.add("⌫")
        addKeyRow(nav, isSpecialRow = true)
    }

    private fun buildClipboardKeyboard() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }

        val title = TextView(this).apply {
            text = "کلیپ‌بورد / Clipboard"
            textSize = 14f
            setTextColor(0xFF333333.toInt())
            setPadding(0, 0, 0, dp(8))
        }
        container.addView(title)

        // Current system clipboard
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = clipboard.primaryClip
        val clipText = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this).toString()
        } else ""

        if (clipText.isNotBlank()) {
            val btn = createActionButton("چسباندن: ${clipText.take(40)}${if (clipText.length > 40) "…" else ""}") {
                currentInputConnection?.commitText(clipText, 1)
                performFeedback()
            }
            container.addView(btn)
        } else {
            val empty = TextView(this).apply {
                text = "کلیپ‌بورد خالی است"
                textSize = 13f
                setTextColor(0xFF888888.toInt())
            }
            container.addView(empty)
        }

        // Recent internal clips
        recentClips.takeLast(5).reversed().forEach { text ->
            val btn = createActionButton(text.take(50)) {
                currentInputConnection?.commitText(text, 1)
                performFeedback()
            }
            container.addView(btn)
        }

        val backBtn = createActionButton("بازگشت به کیبورد") {
            currentMode = if (isPersian) KeyboardLayout.Mode.LETTERS_FA else KeyboardLayout.Mode.LETTERS_EN
            buildKeyboard()
        }
        container.addView(backBtn)

        keysContainer?.addView(container)
    }

    private fun createActionButton(text: String, onClick: () -> Unit): Button {
        return Button(this).apply {
            this.text = text
            textSize = 14f
            isAllCaps = false
            setBackgroundColor(0xFFFFFFFF.toInt())
            setTextColor(0xFF212121.toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(48)
            ).apply {
                setMargins(0, dp(4), 0, dp(4))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun addKeyRow(
        keys: List<String>,
        isNumberRow: Boolean = false,
        isSpecialRow: Boolean = false,
        isEmojiRow: Boolean = false
    ) {
        val rowLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            gravity = Gravity.CENTER
        }

        keys.forEach { keyLabel ->
            val btn = createKeyButton(keyLabel, isNumberRow, isSpecialRow, isEmojiRow)
            rowLayout.addView(btn)
        }
        keysContainer?.addView(rowLayout)
    }

    private fun addBottomRow(leftKeys: List<String>, rightKeys: List<String>) {
        val rowLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            gravity = Gravity.CENTER_VERTICAL
        }

        leftKeys.forEach { key ->
            rowLayout.addView(createKeyButton(key, isSpecialRow = true))
        }

        // Wide space bar
        val spaceBtn = createKeyButton(" ", isSpecialRow = true)
        val spaceLp = LinearLayout.LayoutParams(0, dp(52), 3.5f).apply {
            setMargins(dp(3), dp(4), dp(3), dp(4))
        }
        spaceBtn.layoutParams = spaceLp
        rowLayout.addView(spaceBtn)

        rightKeys.forEach { key ->
            rowLayout.addView(createKeyButton(key, isSpecialRow = true))
        }

        keysContainer?.addView(rowLayout)
    }

    private fun createKeyButton(
        label: String,
        isNumberRow: Boolean = false,
        isSpecialRow: Boolean = false,
        isEmojiRow: Boolean = false
    ): Button {
        val btn = Button(this)
        var display = label
        if ((isShifted || isCapsLock) && label.length == 1 && label[0].isLetter()) {
            display = label.uppercase()
        }
        if (label == "⇧" && isCapsLock) display = "⇪"

        btn.text = display
        btn.isAllCaps = false
        btn.minHeight = 0
        btn.minWidth = 0
        btn.setPadding(0, 0, 0, 0)

        val height = when {
            isEmojiRow -> dp(48)
            isNumberRow -> dp(44)
            else -> dp(52)
        }

        val weight = when {
            label == " " -> 3.5f
            KeyboardLayout.isSpecialKey(label) -> 1.3f
            isEmojiRow -> 1f
            label.length > 1 -> 1.2f
            else -> 1f
        }

        val lp = LinearLayout.LayoutParams(0, height, weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        btn.layoutParams = lp
        btn.textSize = when {
            isEmojiRow -> 22f
            label.length > 2 -> 13f
            KeyboardLayout.isSpecialKey(label) -> 15f
            else -> 18f
        }

        // Light theme style matching the screenshot (white keys, dark text)
        val prefs = getSharedPreferences("pro_keyboard_prefs", Context.MODE_PRIVATE)
        val theme = prefs.getString("theme", "light") ?: "light"

        when {
            KeyboardLayout.isEnter(label) -> {
                btn.setBackgroundResource(R.drawable.key_accent_bg)
                btn.setTextColor(0xFFFFFFFF.toInt())
            }
            isSpecialRow || KeyboardLayout.isSpecialKey(label) -> {
                if (theme == "light") {
                    btn.setBackgroundResource(R.drawable.key_special_bg_light)
                    btn.setTextColor(0xFF333333.toInt())
                } else {
                    btn.setBackgroundResource(R.drawable.key_special_bg)
                    btn.setTextColor(0xFFFFFFFF.toInt())
                }
            }
            else -> {
                if (theme == "light") {
                    btn.setBackgroundResource(R.drawable.key_bg_light)
                    btn.setTextColor(0xFF212121.toInt())
                } else {
                    btn.setBackgroundResource(R.drawable.key_bg)
                    btn.setTextColor(0xFFFFFFFF.toInt())
                }
            }
        }

        btn.setOnClickListener { onKeyClick(label) }
        btn.setOnLongClickListener {
            onKeyLongClick(label)
            true
        }
        return btn
    }

    private fun onKeyClick(key: String) {
        performFeedback()
        val ic: InputConnection = currentInputConnection ?: return

        when {
            key == "→" -> {
                emojiPage++
                buildKeyboard()
            }
            key == "←" -> {
                if (emojiPage > 0) emojiPage--
                buildKeyboard()
            }
            KeyboardLayout.isShiftKey(key) -> {
                if (isShifted && !isCapsLock) {
                    isCapsLock = true
                    isShifted = true
                } else if (isCapsLock) {
                    isCapsLock = false
                    isShifted = false
                } else {
                    isShifted = true
                }
                buildKeyboard()
            }
            KeyboardLayout.isBackspace(key) -> {
                ic.deleteSurroundingText(1, 0)
                if (currentWord.isNotEmpty()) currentWord.deleteCharAt(currentWord.length - 1)
                updateCandidates()
            }
            KeyboardLayout.isEnter(key) -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                when (action) {
                    EditorInfo.IME_ACTION_SEARCH, EditorInfo.IME_ACTION_GO,
                    EditorInfo.IME_ACTION_SEND, EditorInfo.IME_ACTION_DONE,
                    EditorInfo.IME_ACTION_NEXT -> ic.performEditorAction(action)
                    else -> {
                        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER))
                        ic.sendKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER))
                    }
                }
                currentWord.clear()
                updateCandidates()
            }
            KeyboardLayout.isSpace(key) -> {
                ic.commitText(" ", 1)
                // save to recent if meaningful
                if (currentWord.length > 1) {
                    val w = currentWord.toString()
                    if (!recentClips.contains(w)) {
                        recentClips.add(w)
                        if (recentClips.size > 20) recentClips.removeAt(0)
                    }
                }
                currentWord.clear()
                updateCandidates()
                if (isShifted && !isCapsLock) {
                    isShifted = false
                    buildKeyboard()
                }
            }
            KeyboardLayout.isLanguage(key) -> {
                isPersian = !isPersian
                currentMode = if (isPersian) KeyboardLayout.Mode.LETTERS_FA else KeyboardLayout.Mode.LETTERS_EN
                isShifted = false
                isCapsLock = false
                buildKeyboard()
            }
            KeyboardLayout.isNumbers(key) -> {
                currentMode = KeyboardLayout.Mode.NUMBERS
                buildKeyboard()
            }
            KeyboardLayout.isSymbols(key) -> {
                currentMode = KeyboardLayout.Mode.SYMBOLS
                buildKeyboard()
            }
            KeyboardLayout.isLetters(key) -> {
                currentMode = if (isPersian) KeyboardLayout.Mode.LETTERS_FA else KeyboardLayout.Mode.LETTERS_EN
                emojiPage = 0
                buildKeyboard()
            }
            KeyboardLayout.isEmoji(key) -> {
                currentMode = KeyboardLayout.Mode.EMOJI
                emojiPage = 0
                buildKeyboard()
            }
            KeyboardLayout.isClipboard(key) -> {
                currentMode = KeyboardLayout.Mode.CLIPBOARD
                buildKeyboard()
            }
            else -> {
                var text = key
                if ((currentMode == KeyboardLayout.Mode.LETTERS_EN || currentMode == KeyboardLayout.Mode.LETTERS_FA)
                    && (isShifted || isCapsLock) && text.length == 1
                ) {
                    text = text.uppercase()
                }
                if (isShifted && !isCapsLock) {
                    isShifted = false
                    buildKeyboard()
                }
                ic.commitText(text, 1)
                if (text.length == 1 && text[0].isLetter()) {
                    currentWord.append(text)
                } else {
                    currentWord.clear()
                }
                updateCandidates()
            }
        }
    }

    private fun onKeyLongClick(key: String) {
        // long press backspace = clear word / delete more
        if (KeyboardLayout.isBackspace(key)) {
            val ic = currentInputConnection ?: return
            ic.deleteSurroundingText(currentWord.length.coerceAtLeast(1), 0)
            currentWord.clear()
            updateCandidates()
            performFeedback()
        }
    }

    private fun updateCandidates() {
        candidateBar?.removeAllViews()
        if (currentWord.isEmpty()) return

        val word = currentWord.toString()
        val matches = simpleDictionary.filter {
            it.startsWith(word, ignoreCase = true) && !it.equals(word, ignoreCase = true)
        }.take(6)

        matches.forEach { suggestion ->
            val tv = TextView(this).apply {
                text = suggestion
                setTextColor(0xFF212121.toInt())
                textSize = 15f
                setPadding(dp(14), dp(8), dp(14), dp(8))
                setOnClickListener {
                    val ic = currentInputConnection ?: return@setOnClickListener
                    ic.deleteSurroundingText(currentWord.length, 0)
                    ic.commitText("$suggestion ", 1)
                    currentWord.clear()
                    updateCandidates()
                    performFeedback()
                }
            }
            candidateBar?.addView(tv)
        }
    }

    private fun performFeedback() {
        val prefs = getSharedPreferences("pro_keyboard_prefs", Context.MODE_PRIVATE)
        if (prefs.getBoolean("vibration", true)) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                    vm.defaultVibrator.vibrate(
                        VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(15, VibrationEffect.DEFAULT_AMPLITUDE))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(15)
                    }
                }
            } catch (_: Exception) {}
        }
        if (prefs.getBoolean("sound", false)) {
            try {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.4f)
            } catch (_: Exception) {}
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
