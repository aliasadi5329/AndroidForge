package com.example.dastnevis;

import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * موتور رندر دست‌خط واقع‌گرایانه
 *
 * چه کارهایی انجام می‌دهد:
 *  - تشخیص خودکار خطوط و حاشیه‌ی کاغذ و نشاندن متن دقیقاً روی خط‌ها
 *  - شکستن کلمه‌های فارسی به «پاره‌خط»ها (بعد از حروف غیرچسبان) و لرزش طبیعی هر پاره
 *  - شیب و موج طبیعی هر سطر، چرخش/اندازه/فاصله‌ی متغیر هر کلمه
 *  - فشار قلم متغیر، تغییر جزئی رنگ جوهر، لبه‌ی نرم و پخش‌شدگی جوهر
 *  - بافت جوهر (دانه‌دانه بودن خودکار) و ترکیب Multiply تا بافت کاغذ از زیر جوهر دیده شود
 *  - همه‌ی تصادفی‌ها با Seed ثابت هر لایه هستند؛ با جابه‌جایی لایه، شکل دست‌خط عوض نمی‌شود
 */
public final class HandwritingRenderer {

    private HandwritingRenderer() {}

    // ───────────────────────── Paper analysis ─────────────────────────

    /** اطلاعات خطوط و حاشیه‌های کاغذ. */
    public static final class PaperInfo {
        public boolean ruled = false;
        public float spacing = 0f;
        public float firstLine = 0f;
        public int count = 0;
        public float leftMargin = -1f;
        public float rightMargin = -1f;

        public float lineY(int i) { return firstLine + i * spacing; }
    }

    /** اندازه‌ی مناسب کاغذ برای خروجی تمیز (نه خیلی کوچک، نه سنگین). */
    public static Bitmap prepareCanvasPaper(Bitmap src) {
        int w = src.getWidth();
        int target;
        if (w > 1440) target = 1440;
        else target = Math.max(w, Math.min(1080, w * 2));
        Bitmap out = src;
        if (target != w) {
            float s = target / (float) w;
            out = Bitmap.createScaledBitmap(src, target, Math.max(1, Math.round(src.getHeight() * s)), true);
        }
        if (out.getConfig() != Bitmap.Config.ARGB_8888 || !out.isMutable()) {
            out = out.copy(Bitmap.Config.ARGB_8888, false);
        }
        return out;
    }

    /** پیدا کردن خطوط افقی منظم و خط‌های حاشیه‌ی عمودی. */
    public static PaperInfo analyzePaper(Bitmap bmp) {
        PaperInfo info = new PaperInfo();
        try {
            final int W = bmp.getWidth(), H = bmp.getHeight();
            if (W < 50 || H < 50) return info;
            int[] row = new int[W];

            // ---- horizontal ruled lines ----
            float[] r = new float[H];
            int x0 = (int) (W * 0.2f), x1 = (int) (W * 0.8f);
            for (int y = 0; y < H; y++) {
                bmp.getPixels(row, 0, W, 0, y, W, 1);
                long sum = 0;
                for (int x = x0; x < x1; x++) sum += lum(row[x]);
                r[y] = sum / (float) (x1 - x0);
            }
            int win = Math.max(9, H / 40) | 1;
            float[] d = new float[H];
            float[] sorted = new float[H];
            int half = win / 2;
            double run = 0;
            for (int i = -half; i <= half; i++) run += r[clampI(i, 0, H - 1)];
            for (int y = 0; y < H; y++) {
                float b = (float) (run / win);
                d[y] = b - r[y];
                sorted[y] = d[y];
                run += r[clampI(y + half + 1, 0, H - 1)] - r[clampI(y - half, 0, H - 1)];
            }
            java.util.Arrays.sort(sorted);
            float thr = Math.max(2f, sorted[(int) (H * 0.97f)] * 0.35f);

            List<Integer> peaks = new ArrayList<>();
            for (int y = 2; y < H - 2; y++) {
                float v = d[y];
                if (v > thr && v >= d[y - 1] && v >= d[y + 1] && v >= d[y - 2] && v >= d[y + 2]) {
                    if (!peaks.isEmpty() && y - peaks.get(peaks.size() - 1) < 4) {
                        if (v > d[peaks.get(peaks.size() - 1)]) peaks.set(peaks.size() - 1, y);
                    } else peaks.add(y);
                }
            }
            if (peaks.size() >= 6) {
                List<Float> gaps = new ArrayList<>();
                for (int i = 1; i < peaks.size(); i++) {
                    int g = peaks.get(i) - peaks.get(i - 1);
                    if (g >= H * 0.012f) gaps.add((float) g);
                }
                if (gaps.size() >= 4) {
                    java.util.Collections.sort(gaps);
                    float sp = gaps.get(gaps.size() / 2);
                    List<Integer> best = new ArrayList<>(), cur = new ArrayList<>();
                    cur.add(peaks.get(0));
                    for (int i = 1; i < peaks.size(); i++) {
                        int p = peaks.get(i);
                        float gap = p - cur.get(cur.size() - 1);
                        if (Math.abs(gap - sp) <= sp * 0.22f) cur.add(p);
                        else if (gap < sp * 0.78f) { /* noise between lines */ }
                        else {
                            if (cur.size() > best.size()) best = cur;
                            cur = new ArrayList<>();
                            cur.add(p);
                        }
                    }
                    if (cur.size() > best.size()) best = cur;
                    if (best.size() >= 5) {
                        // least-squares fit: y = first + i * spacing
                        int n = best.size();
                        double sx = 0, sy = 0, sxx = 0, sxy = 0;
                        for (int i = 0; i < n; i++) {
                            sx += i; sy += best.get(i); sxx += (double) i * i; sxy += (double) i * best.get(i);
                        }
                        double k = (n * sxy - sx * sy) / (n * sxx - sx * sx);
                        double c = (sy - k * sx) / n;
                        if (k > H * 0.012) {
                            info.ruled = true;
                            info.spacing = (float) k;
                            info.firstLine = (float) c;
                            info.count = n;
                        }
                    }
                }
            }

            // ---- vertical margin lines ----
            int ya = (int) (H * 0.25f), yb = (int) (H * 0.85f);
            float[] col = new float[W];
            int[] colPx = new int[yb - ya];
            for (int x = 0; x < W; x++) {
                bmp.getPixels(colPx, 0, 1, x, ya, 1, yb - ya);
                long s = 0;
                for (int v : colPx) s += lum(v);
                col[x] = s / (float) colPx.length;
            }
            float[] cs = col.clone();
            java.util.Arrays.sort(cs);
            float med = cs[W / 2];
            float bestL = -1, bestR = -1;
            for (int x = 0; x < W; x++) {
                if (med - col[x] > 8f) {
                    if (x < W * 0.3f) bestL = Math.max(bestL, x);
                    else if (x > W * 0.7f && bestR < 0) bestR = x;
                }
            }
            info.leftMargin = bestL;
            info.rightMargin = bestR;
        } catch (Throwable ignored) {
        }
        return info;
    }

    // ───────────────────────── Rendering ─────────────────────────

    public interface TypefaceProvider {
        Typeface get(MainActivity.TextLayer layer);
    }

    /** رندر کامل: کاغذ + همه‌ی لایه‌ها، خروجی یک Bitmap جدید. */
    public static Bitmap render(Bitmap paper, PaperInfo info, List<MainActivity.TextLayer> layers, TypefaceProvider tfp) {
        final int W = paper.getWidth(), H = paper.getHeight();
        Bitmap ink = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas ic = new Canvas(ink);
        float realismSum = 0f;
        long seedMix = 0x5DEECE66DL;
        for (MainActivity.TextLayer L : layers) {
            Typeface tf;
            try { tf = tfp.get(L); } catch (Throwable t) { tf = Typeface.DEFAULT; }
            if (tf == null) tf = Typeface.DEFAULT;
            drawLayerInk(ic, W, H, info, L, tf);
            realismSum += L.realism;
            seedMix = seedMix * 31 + L.seed;
        }
        float realism = layers.isEmpty() ? 0.6f : realismSum / layers.size();
        Bitmap out = paper.copy(Bitmap.Config.ARGB_8888, true);
        if (!layers.isEmpty()) compositeInk(out, ink, realism, (int) (seedMix ^ (seedMix >>> 32)));
        ink.recycle();
        return out;
    }

    // ---- layout model ----
    private static final class Piece {
        String s;
        float w, dy, scale, gap;
    }

    private static final class Word {
        final List<Piece> pieces = new ArrayList<>();
        float width, space, rot, dy, skew, press, colorK, size;
        int colorIndex;
    }

    private static final class Para {
        boolean rtl;
        final List<Word> words = new ArrayList<>();
    }

    private static void drawLayerInk(Canvas canvas, int W, int H, PaperInfo info, MainActivity.TextLayer L, Typeface tf) {
        final float R = clamp(L.realism, 0f, 1f);
        final Random rnd = new Random(L.seed);
        final boolean snap = L.snapToLines && info.ruled;

        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG | Paint.LINEAR_TEXT_FLAG);
        p.setTypeface(tf);
        p.setTextAlign(Paint.Align.LEFT);

        // ---- font size ----
        float size;
        if (snap) {
            p.setTextSize(100f);
            Rect rb = new Rect();
            String sample = "کلاس";
            p.getTextBounds(sample, 0, sample.length(), rb);
            float asc = -rb.top;
            if (asc < 20f) { // font without Persian glyphs
                p.getTextBounds("Hlbk", 0, 4, rb);
                asc = -rb.top;
            }
            asc = clamp(asc, 40f, 180f) / 100f;
            // tall letters (ک ل ا) reach ~78% of the gap to the next ruled line
            size = info.spacing * 0.78f * L.fontSizeScale / asc;
        } else {
            size = W * 0.05f * L.fontSizeScale;
        }
        p.setTextSize(size);
        final float spaceW = Math.max(size * 0.22f, p.measureText(" "));

        // writer's personal tendencies for this layer (consistent across lines)
        final float writerSlope = R * g(rnd) * 0.0025f;
        final float writerSkew = R * g(rnd) * 0.03f;
        final float writerScale = 1f + R * g(rnd) * 0.015f;

        // ---- tokenize + per-word randomness (independent of position) ----
        List<Para> paras = new ArrayList<>();
        int colorCounter = 0;
        for (String raw : L.text.split("\n", -1)) {
            Para para = new Para();
            para.rtl = isRtlParagraph(raw);
            for (String token : raw.trim().split("[ \\t\\u00A0]+")) {
                if (token.isEmpty()) continue;
                Word w = new Word();
                w.size = size * writerScale * (1f + R * g(rnd) * 0.022f);
                w.rot = R * g(rnd) * 0.9f;
                w.dy = R * g(rnd) * 0.03f * size;
                w.skew = writerSkew + R * g(rnd) * 0.03f;
                w.press = clamp(0.95f + R * g(rnd) * 0.04f, 0.8f, 1f);
                w.colorK = R * g(rnd) * 0.07f;
                w.space = spaceW * clamp(1f + R * g(rnd) * 0.2f, 0.65f, 1.6f);
                w.colorIndex = colorCounter++;

                List<String> parts = para.rtl && canSplit(token) ? splitPieces(token) : java.util.Collections.singletonList(token);
                float total = 0f;
                for (int i = 0; i < parts.size(); i++) {
                    Piece pc = new Piece();
                    pc.s = parts.get(i);
                    pc.scale = 1f + R * g(rnd) * 0.018f;
                    pc.dy = R * g(rnd) * 0.018f * size;
                    pc.gap = (i == parts.size() - 1) ? 0f : R * Math.abs(g(rnd)) * 0.014f * size - 0.002f * size;
                    p.setTextSize(w.size * pc.scale);
                    p.setTextSkewX(w.skew);
                    pc.w = p.measureText(pc.s);
                    total += pc.w + pc.gap;
                    w.pieces.add(pc);
                }
                w.width = total;
                para.words.add(w);
            }
            paras.add(para);
        }

        // ---- horizontal bounds ----
        float sidePx = W * Math.min(L.sideRatio, 0.45f);
        float right = W - sidePx, left = sidePx;
        if (L.snapToLines) {
            float pad = W * 0.014f;
            if (info.rightMargin > W * 0.6f && info.rightMargin - pad < right) right = info.rightMargin - pad;
            if (info.leftMargin > 0 && info.leftMargin < W * 0.4f && info.leftMargin + pad > left) left = info.leftMargin + pad;
        }
        if (right - left < W * 0.1f) {
            float c = (right + left) / 2f;
            left = c - W * 0.05f;
            right = c + W * 0.05f;
        }
        final float maxWidth = (right - left) - size * 0.15f;

        // ---- vertical layout ----
        int lineIndex;
        int step = 1;
        float y;
        float lineAdv;
        if (snap) {
            step = L.fontSizeScale >= 1.45f ? 2 : 1;
            float minY = H * L.topRatio + size * 0.75f;
            lineIndex = (int) Math.ceil((minY - info.firstLine) / info.spacing);
            if (lineIndex < 0) lineIndex = 0;
            lineAdv = info.spacing * step;
            y = info.lineY(lineIndex) - info.spacing * 0.11f;
        } else {
            lineIndex = 0;
            y = Math.max(size, H * L.topRatio + size * 0.9f);
            lineAdv = size * 1.5f;
        }
        final float bottomLimit = H - Math.max(4f, size * 0.25f);

        // ---- ink paints ----
        Paint core = new Paint(p);
        core.setStyle(Paint.Style.FILL_AND_STROKE);
        core.setStrokeJoin(Paint.Join.ROUND);
        core.setStrokeCap(Paint.Cap.ROUND);
        core.setMaskFilter(new BlurMaskFilter(Math.max(0.5f, size * 0.0055f), BlurMaskFilter.Blur.NORMAL));
        Paint bleed = new Paint(core);
        bleed.setMaskFilter(new BlurMaskFilter(Math.max(1.2f, size * 0.028f), BlurMaskFilter.Blur.NORMAL));

        int[] cols = (L.multiColors != null && L.multiColors.length > 0) ? L.multiColors
                : (L.dual ? new int[]{L.c1, L.c2} : new int[]{L.c1});

        int visualLine = 0;
        float drift = 0f;
        for (Para para : paras) {
            if (para.words.isEmpty()) { // empty line
                y += lineAdv;
                visualLine++;
                continue;
            }
            int i = 0;
            while (i < para.words.size()) {
                // greedy line fill
                int j = i;
                float used = 0f;
                while (j < para.words.size()) {
                    Word w = para.words.get(j);
                    float add = (j == i ? 0f : para.words.get(j - 1).space) + w.width;
                    if (j > i && used + add > maxWidth) break;
                    used += add;
                    j++;
                }
                if (y > bottomLimit) return;

                Random lr = new Random(L.seed * 1_000_003L + visualLine * 7919L + 17L);
                float slope = writerSlope + R * g(lr) * 0.0035f;
                float waveAmp = R * size * (0.012f + 0.012f * lr.nextFloat());
                float wavePh = lr.nextFloat() * 6.2832f;
                float waveK = 6.2832f / (W * (0.45f + 0.4f * lr.nextFloat()));
                drift = clamp(drift * 0.6f + R * g(lr) * size * 0.06f, -size * 0.18f, size * 0.18f);
                float lineDy = snap ? R * g(lr) * info.spacing * 0.025f : R * g(lr) * size * 0.04f;
                float baseY = y + lineDy;

                float cursor = para.rtl ? right + drift : left + drift;
                for (int k = i; k < j; k++) {
                    Word w = para.words.get(k);
                    float wLeft = para.rtl ? cursor - w.width : cursor;
                    float cx = wLeft + w.width / 2f;
                    float dist = para.rtl ? (right - cx) : (cx - left);
                    float by = baseY + w.dy + dist * slope + waveAmp * (float) Math.sin(cx * waveK + wavePh);
                    float slopeDeg = (float) Math.toDegrees(Math.atan(para.rtl ? -slope : slope));

                    int base = cols[w.colorIndex % cols.length];
                    int c = shade(base, w.colorK);
                    int aCore = Math.round(255 * clamp(w.press, 0f, 1f));

                    canvas.save();
                    canvas.rotate(w.rot + slopeDeg, cx, by);
                    // draw pieces in visual order
                    float px = para.rtl ? wLeft + w.width : wLeft;
                    for (Piece pc : w.pieces) {
                        float ts = w.size * pc.scale;
                        float x = para.rtl ? px - pc.w : px;
                        float yy = by + pc.dy;

                        bleed.setTextSize(ts);
                        bleed.setTextSkewX(w.skew);
                        bleed.setStrokeWidth(ts * 0.022f * w.press);
                        bleed.setColor(c);
                        bleed.setAlpha(Math.round(aCore * (0.10f + 0.10f * R)));
                        canvas.drawText(pc.s, x, yy, bleed);

                        core.setTextSize(ts);
                        core.setTextSkewX(w.skew);
                        core.setStrokeWidth(ts * (0.004f + 0.006f * w.press));
                        core.setColor(c);
                        core.setAlpha(aCore);
                        canvas.drawText(pc.s, x, yy, core);

                        px = para.rtl ? px - pc.w - pc.gap : px + pc.w + pc.gap;
                    }
                    canvas.restore();

                    cursor = para.rtl ? cursor - w.width - w.space : cursor + w.width + w.space;
                }

                y += lineAdv;
                visualLine++;
                i = j;
            }
        }
    }

    /** ترکیب لایه‌ی جوهر با کاغذ (Multiply) + بافت و دانه‌ی جوهر خودکار. */
    private static void compositeInk(Bitmap paper, Bitmap ink, float realism, int seed) {
        final int W = paper.getWidth(), H = paper.getHeight();
        final float grainAmt = 0.05f + 0.12f * realism;
        final float blotAmt = 0.04f + 0.12f * realism;
        final float cell = Math.max(6f, W / 60f);
        final float streakCellX = Math.max(3f, W / 300f) * 4f, streakCellY = Math.max(1.5f, W / 900f);
        int[] pp = new int[W], ip = new int[W];
        for (int y = 0; y < H; y++) {
            ink.getPixels(ip, 0, W, 0, y, W, 1);
            boolean any = false;
            for (int x = 0; x < W; x++) if ((ip[x] >>> 24) != 0) { any = true; break; }
            if (!any) continue;
            paper.getPixels(pp, 0, W, 0, y, W, 1);
            for (int x = 0; x < W; x++) {
                int ic = ip[x];
                int a = ic >>> 24;
                if (a == 0) continue;
                float af = a / 255f;
                float grain = hash01(x >> 1, y >> 1, seed);
                float blot = valueNoise(x / cell, y / cell, seed ^ 0x2545F491);
                float streak = valueNoise(x / streakCellX, y / streakCellY, seed ^ 0x6C8E9CF5);
                af *= 1f - grainAmt * grain * grain;
                af *= 1f - blotAmt * blot;
                af *= 1f - 0.12f * realism * Math.max(0f, streak - 0.55f) * 2.2f;
                if (af <= 0f) continue;
                if (af > 1f) af = 1f;

                int pc = pp[x];
                float ir = ((ic >> 16) & 255) / 255f, ig = ((ic >> 8) & 255) / 255f, ib = (ic & 255) / 255f;
                int pr = (pc >> 16) & 255, pg = (pc >> 8) & 255, pb = pc & 255;
                // multiply blend: paper * lerp(1, ink, alpha)
                int r = Math.round(pr * (1f - af + af * ir));
                int gch = Math.round(pg * (1f - af + af * ig));
                int b = Math.round(pb * (1f - af + af * ib));
                pp[x] = 0xFF000000 | (r << 16) | (gch << 8) | b;
            }
            paper.setPixels(pp, 0, W, 0, y, W, 1);
        }
    }

    // ───────────────────────── Persian helpers ─────────────────────────

    /** حروفی که به حرف بعدی نمی‌چسبند. */
    private static boolean isNonJoiner(char c) {
        switch (c) {
            case '\u0627': case '\u0622': case '\u0623': case '\u0625': case '\u0671':
            case '\u062F': case '\u0630': case '\u0631': case '\u0632': case '\u0698':
            case '\u0648': case '\u0624': case '\u0629': case '\u0621': case '\u06C0':
            case '\u200C':
                return true;
            default:
                return false;
        }
    }

    private static boolean isMark(char c) {
        return (c >= '\u064B' && c <= '\u065F') || c == '\u0670' || (c >= '\u06D6' && c <= '\u06ED');
    }

    private static boolean isArabicChar(char c) {
        return (c >= '\u0600' && c <= '\u06FF') || (c >= '\u0750' && c <= '\u077F')
                || (c >= '\uFB50' && c <= '\uFDFF') || (c >= '\uFE70' && c <= '\uFEFF');
    }

    private static boolean canSplit(String w) {
        boolean hasArabic = false;
        for (int i = 0; i < w.length(); i++) {
            char c = w.charAt(i);
            if (isArabicChar(c)) hasArabic = true;
            else if (Character.isLetter(c)) return false; // mixed latin: keep whole
        }
        return hasArabic && w.length() > 1;
    }

    /** تقسیم کلمه به پاره‌خط‌ها؛ شکل حروف دقیقاً مثل حالت کامل می‌ماند. */
    private static List<String> splitPieces(String w) {
        List<String> out = new ArrayList<>();
        int start = 0, i = 0, n = w.length();
        while (i < n) {
            char c = w.charAt(i);
            i++;
            if (isNonJoiner(c)) {
                while (i < n && isMark(w.charAt(i))) i++;
                // keep trailing punctuation glued to the last piece
                boolean restHasLetter = false;
                for (int k = i; k < n; k++) if (Character.isLetterOrDigit(w.charAt(k))) { restHasLetter = true; break; }
                if (!restHasLetter) break;
                out.add(w.substring(start, i));
                start = i;
            }
        }
        if (start < n) out.add(w.substring(start));
        if (out.isEmpty()) out.add(w);
        return out;
    }

    private static boolean isRtlParagraph(String s) {
        for (int i = 0; i < s.length(); i++) {
            byte d = Character.getDirectionality(s.charAt(i));
            if (d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC) return true;
            if (d == Character.DIRECTIONALITY_LEFT_TO_RIGHT) return false;
        }
        return true;
    }

    // ───────────────────────── math helpers ─────────────────────────

    private static float g(Random r) {
        return clamp((float) r.nextGaussian(), -2.2f, 2.2f) / 1.0f;
    }

    private static float clamp(float v, float a, float b) { return v < a ? a : (v > b ? b : v); }

    private static int clampI(int v, int a, int b) { return v < a ? a : (v > b ? b : v); }

    private static int lum(int c) {
        return (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
    }

    /** روشن/تیره کردن جزئی رنگ (k منفی = تیره‌تر). */
    private static int shade(int c, float k) {
        int r = Color.red(c), gg = Color.green(c), b = Color.blue(c);
        if (k >= 0) {
            r = Math.round(r + (255 - r) * k * 0.6f);
            gg = Math.round(gg + (255 - gg) * k * 0.6f);
            b = Math.round(b + (255 - b) * k * 0.6f);
        } else {
            float f = 1f + k;
            r = Math.round(r * f); gg = Math.round(gg * f); b = Math.round(b * f);
        }
        return Color.rgb(clampI(r, 0, 255), clampI(gg, 0, 255), clampI(b, 0, 255));
    }

    private static float hash01(int x, int y, int seed) {
        int h = seed ^ (x * 0x27d4eb2d) ^ (y * 0x165667b1);
        h ^= h >>> 15;
        h *= 0x2c1b3c6d;
        h ^= h >>> 12;
        h *= 0x297a2d39;
        h ^= h >>> 15;
        return (h & 0xFFFFFF) / (float) 0xFFFFFF;
    }

    private static float valueNoise(float x, float y, int seed) {
        int xi = (int) Math.floor(x), yi = (int) Math.floor(y);
        float fx = x - xi, fy = y - yi;
        fx = fx * fx * (3 - 2 * fx);
        fy = fy * fy * (3 - 2 * fy);
        float a = hash01(xi, yi, seed), b = hash01(xi + 1, yi, seed);
        float c = hash01(xi, yi + 1, seed), d = hash01(xi + 1, yi + 1, seed);
        return (a + (b - a) * fx) + ((c + (d - c) * fx) - (a + (b - a) * fx)) * fy;
    }
}
