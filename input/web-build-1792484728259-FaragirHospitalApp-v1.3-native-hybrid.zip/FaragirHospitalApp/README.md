# اپلیکیشن بیمارستان تخصصی فراگیر سلامت (نسخه ۱.۳ - هیبرید نیتیو)

## تغییرات نسخه ۱.۳

بخش‌های حیاتی به **نیتیو (Jetpack Compose)** تبدیل شدند:

- **نوبت‌دهی** → کاملاً نیتیو (Compose)
- **پیگیری نوبت** → کاملاً نیتیو
- **پنل مدیریت** → کاملاً نیتیو
- **صفحات اطلاعاتی** (خانه، بخش‌ها، پزشکان و...) → همچنان WebView از assets

## ساختار

- `ui/screens/AppointmentScreen.kt` — فرم نوبت‌دهی نیتیو
- `ui/screens/TrackScreen.kt` — پیگیری با کد
- `ui/screens/AdminScreen.kt` — ورود و مدیریت نوبت‌ها
- `ui/screens/WebContentScreen.kt` — نمایش صفحات HTML
- `data/AppointmentRepository.kt` — ارتباط با Firebase

## نیازمندی‌ها برای ساخت

1. فایل `google-services.json` را از Firebase Console دانلود و در پوشه `app/` قرار دهید.
2. در `build.gradle` ریشه، پلاگین گوگل سرویس را اضافه کنید (در صورت نیاز).

## ساخت APK

```bash
./gradlew assembleRelease
```

یا از Android Studio / AndroidForge استفاده کنید.

## نکات مهم

- قوانین Firestore همان `firestore.rules` قبلی است (حتماً Publish کنید).
- برای OTP پیامکی هنوز نیاز به سرویس ایرانی + بک‌اند دارید.
- Firebase باید در پروژه فعال باشد (Authentication + Firestore).
