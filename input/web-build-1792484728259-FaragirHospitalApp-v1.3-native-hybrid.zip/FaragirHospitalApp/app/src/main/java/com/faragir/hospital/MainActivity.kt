package com.faragir.hospital

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.faragir.hospital.ui.screens.AdminScreen
import com.faragir.hospital.ui.screens.AppointmentScreen
import com.faragir.hospital.ui.screens.TrackScreen
import com.faragir.hospital.ui.screens.WebContentScreen
import com.faragir.hospital.ui.theme.FaragirTheme
import com.google.firebase.FirebaseApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Firebase (make sure google-services.json is present or use default)
        try {
            FirebaseApp.initializeApp(this)
        } catch (_: Exception) { /* already initialized or missing config */ }

        enableEdgeToEdge()
        setContent {
            FaragirTheme {
                MainApp()
            }
        }
    }
}

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "خانه", Icons.Default.Home)
    object Appointment : Screen("appointment", "نوبت‌دهی", Icons.Default.CalendarMonth)
    object Track : Screen("track", "پیگیری", Icons.Default.Search)
    object Admin : Screen("admin", "مدیریت", Icons.Default.AdminPanelSettings)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainApp() {
    val navController = rememberNavController()
    val items = listOf(Screen.Home, Screen.Appointment, Screen.Track, Screen.Admin)

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                items.forEach { screen ->
                    NavigationBarItem(
                        icon = { Icon(screen.icon, contentDescription = screen.title) },
                        label = { Text(screen.title) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                WebContentScreen("index.html")
            }
            composable(Screen.Appointment.route) {
                AppointmentScreen()
            }
            composable(Screen.Track.route) {
                TrackScreen()
            }
            composable(Screen.Admin.route) {
                AdminScreen()
            }
        }
    }
}
