package com.faragir.hospital.data

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await
import java.security.SecureRandom

class AppointmentRepository {

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    private val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private val random = SecureRandom()

    fun generateTrackingCode(): String {
        val sb = StringBuilder(10)
        repeat(10) {
            sb.append(chars[random.nextInt(chars.length)])
        }
        return sb.toString()
    }

    suspend fun getTakenSlots(date: String): Set<String> {
        return try {
            val snapshot = db.collection("slots")
                .whereEqualTo("date", date)
                .get()
                .await()
            snapshot.documents.map { it.id }.toSet()
        } catch (e: Exception) {
            emptySet()
        }
    }

    suspend fun createAppointment(
        fullName: String,
        phone: String,
        nationalId: String,
        appointmentType: String,
        specialty: String,
        preferredDate: String,
        preferredDateLabel: String,
        preferredTime: String,
        notes: String
    ): Result<String> {
        return try {
            val code = generateTrackingCode()
            val slotId = "${preferredDate}_${preferredTime}_${specialty.ifEmpty { "general" }}"
            val batch = db.batch()

            // Slot
            val slotRef = db.collection("slots").document(slotId)
            batch.set(slotRef, mapOf(
                "date" to preferredDate,
                "time" to preferredTime,
                "spec" to specialty.ifEmpty { "general" },
                "createdAt" to FieldValue.serverTimestamp()
            ))

            // Appointment (private)
            val apptRef = db.collection("appointments").document(code)
            batch.set(apptRef, mapOf(
                "fullName" to fullName,
                "phone" to phone,
                "nationalId" to nationalId,
                "appointmentType" to appointmentType,
                "specialty" to specialty,
                "preferredDate" to preferredDate,
                "preferredDateLabel" to preferredDateLabel,
                "preferredTime" to preferredTime,
                "slotId" to slotId,
                "notes" to notes,
                "status" to "جدید",
                "createdAt" to FieldValue.serverTimestamp()
            ))

            // Public status
            val publicRef = db.collection("public_status").document(code)
            batch.set(publicRef, mapOf(
                "status" to "جدید",
                "preferredDateLabel" to preferredDateLabel,
                "preferredTime" to preferredTime,
                "createdAt" to FieldValue.serverTimestamp()
            ))

            batch.commit().await()
            Result.success(code)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun trackAppointment(code: String): Result<PublicStatus> {
        return try {
            val doc = db.collection("public_status").document(code.uppercase()).get().await()
            if (!doc.exists()) {
                Result.failure(Exception("کد پیگیری یافت نشد"))
            } else {
                val data = doc.data ?: emptyMap()
                Result.success(
                    PublicStatus(
                        status = data["status"] as? String ?: "نامشخص",
                        preferredDateLabel = data["preferredDateLabel"] as? String ?: "",
                        preferredTime = data["preferredTime"] as? String ?: ""
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun loginAdmin(email: String, password: String): Result<Unit> {
        return try {
            auth.signInWithEmailAndPassword(email, password).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun isAdminLoggedIn(): Boolean = auth.currentUser != null

    fun logout() {
        auth.signOut()
    }

    suspend fun getAllAppointments(): Result<List<Appointment>> {
        return try {
            val snapshot = db.collection("appointments")
                .orderBy("createdAt", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(100)
                .get()
                .await()

            val list = snapshot.documents.map { doc ->
                val data = doc.data ?: emptyMap()
                Appointment(
                    code = doc.id,
                    fullName = data["fullName"] as? String ?: "",
                    phone = data["phone"] as? String ?: "",
                    nationalId = data["nationalId"] as? String ?: "",
                    appointmentType = data["appointmentType"] as? String ?: "",
                    specialty = data["specialty"] as? String ?: "",
                    preferredDate = data["preferredDate"] as? String ?: "",
                    preferredDateLabel = data["preferredDateLabel"] as? String ?: "",
                    preferredTime = data["preferredTime"] as? String ?: "",
                    slotId = data["slotId"] as? String ?: "",
                    notes = data["notes"] as? String ?: "",
                    status = data["status"] as? String ?: "جدید"
                )
            }
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateStatus(code: String, newStatus: String): Result<Unit> {
        return try {
            val batch = db.batch()
            batch.update(db.collection("appointments").document(code), mapOf(
                "status" to newStatus,
                "updatedAt" to FieldValue.serverTimestamp()
            ))
            batch.update(db.collection("public_status").document(code), mapOf(
                "status" to newStatus
            ))
            batch.commit().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
