package com.faragir.hospital.data

import java.util.Calendar

/**
 * Simple Jalali (Persian) date helpers for the next 7 days.
 * For production a full library is better, but this is enough for week picker.
 */
object DateUtils {

    private val persianDays = arrayOf("شنبه", "یکشنبه", "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه")
    private val persianMonths = arrayOf(
        "فروردین", "اردیبهشت", "خرداد", "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر", "دی", "بهمن", "اسفند"
    )

    data class DayItem(
        val isoDate: String,          // 2026-10-20
        val label: String,            // دوشنبه ۲۰ مهر
        val dayOfWeek: String,
        val isFriday: Boolean
    )

    fun next7Days(): List<DayItem> {
        val result = mutableListOf<DayItem>()
        val cal = Calendar.getInstance()

        // Start from today
        for (i in 0 until 7) {
            if (i > 0) cal.add(Calendar.DAY_OF_MONTH, 1)

            val year = cal.get(Calendar.YEAR)
            val month = cal.get(Calendar.MONTH) + 1
            val day = cal.get(Calendar.DAY_OF_MONTH)
            val dow = cal.get(Calendar.DAY_OF_WEEK) // 1=Sunday ... 7=Saturday

            // Convert approximate to Jalali (simple algorithm for near dates)
            val j = gregorianToJalali(year, month, day)
            val jYear = j[0]
            val jMonth = j[1]
            val jDay = j[2]

            // Persian day of week: Saturday=0
            val persianDowIndex = (dow % 7) // rough mapping
            val dayName = when (dow) {
                Calendar.SATURDAY -> "شنبه"
                Calendar.SUNDAY -> "یکشنبه"
                Calendar.MONDAY -> "دوشنبه"
                Calendar.TUESDAY -> "سه‌شنبه"
                Calendar.WEDNESDAY -> "چهارشنبه"
                Calendar.THURSDAY -> "پنجشنبه"
                Calendar.FRIDAY -> "جمعه"
                else -> ""
            }

            val iso = String.format("%04d-%02d-%02d", year, month, day)
            val label = "$dayName ${toPersianNumber(jDay)} ${persianMonths[jMonth - 1]}"
            result.add(DayItem(iso, label, dayName, dow == Calendar.FRIDAY))
        }
        return result
    }

    fun toPersianNumber(n: Int): String {
        val persian = charArrayOf('۰','۱','۲','۳','۴','۵','۶','۷','۸','۹')
        return n.toString().map { if (it.isDigit()) persian[it - '0'] else it }.joinToString("")
    }

    fun toPersianTime(time: String): String {
        return time.map { if (it.isDigit()) "۰۱۲۳۴۵۶۷۸۹"[it - '0'] else it }.joinToString("")
    }

    // Simple Gregorian → Jalali (accurate enough for current years)
    private fun gregorianToJalali(gy: Int, gm: Int, gd: Int): IntArray {
        val g_d_m = intArrayOf(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334)
        var gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + (365 * gy) + ((gy2 + 3) / 4) - ((gy2 + 99) / 100) + ((gy2 + 399) / 400) + gd + g_d_m[gm - 1]
        var jy = -1595 + (33 * (days / 12053))
        days %= 12053
        jy += 4 * (days / 1461)
        days %= 1461
        if (days > 365) {
            jy += (days - 1) / 365
            days = (days - 1) % 365
        }
        val jm: Int
        val jd: Int
        if (days < 186) {
            jm = 1 + (days / 31)
            jd = 1 + (days % 31)
        } else {
            jm = 7 + ((days - 186) / 30)
            jd = 1 + ((days - 186) % 30)
        }
        return intArrayOf(jy, jm, jd)
    }
}
