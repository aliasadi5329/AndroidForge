package com.faragir.hospital.data

data class Appointment(
    val code: String = "",
    val fullName: String = "",
    val phone: String = "",
    val nationalId: String = "",
    val appointmentType: String = "",
    val specialty: String = "",
    val preferredDate: String = "",
    val preferredDateLabel: String = "",
    val preferredTime: String = "",
    val slotId: String = "",
    val notes: String = "",
    val status: String = "جدید",
    val createdAt: Long = 0L
)

data class PublicStatus(
    val status: String = "جدید",
    val preferredDateLabel: String = "",
    val preferredTime: String = ""
)

val appointmentTypes = listOf(
    "ویزیت متخصص",
    "رادیولوژی / سونوگرافی",
    "آزمایشگاه",
    "جراحی",
    "سایر"
)

val specialties = listOf(
    "جراحی عمومی",
    "زنان و زایمان",
    "قلب و عروق",
    "اطفال",
    "ارتوپدی",
    "داخلی",
    "چشم",
    "گوش و حلق و بینی",
    "پوست و مو",
    "سایر"
)

val timeSlots = listOf(
    "08:00", "09:00", "10:00", "11:00",
    "12:00", "13:00", "14:00", "15:00",
    "16:00", "17:00", "18:00"
)
