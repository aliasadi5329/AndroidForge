package com.faragir.hospital.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faragir.hospital.data.Appointment
import com.faragir.hospital.data.AppointmentRepository
import com.faragir.hospital.data.DateUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen() {
    val repo = remember { AppointmentRepository() }
    val scope = rememberCoroutineScope()

    var isLoggedIn by remember { mutableStateOf(repo.isAdminLoggedIn()) }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var loginError by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }

    var appointments by remember { mutableStateOf<List<Appointment>>(emptyList()) }
    var listError by remember { mutableStateOf<String?>(null) }

    fun loadAppointments() {
        scope.launch {
            isLoading = true
            val res = repo.getAllAppointments()
            isLoading = false
            res.onSuccess { appointments = it }
                .onFailure { listError = it.message }
        }
    }

    LaunchedEffect(isLoggedIn) {
        if (isLoggedIn) loadAppointments()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = { Text("پنل مدیریت نوبت‌ها", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = Color.White
            ),
            actions = {
                if (isLoggedIn) {
                    IconButton(onClick = { loadAppointments() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "بروزرسانی", tint = Color.White)
                    }
                    IconButton(onClick = {
                        repo.logout()
                        isLoggedIn = false
                        appointments = emptyList()
                    }) {
                        Icon(Icons.Default.ExitToApp, contentDescription = "خروج", tint = Color.White)
                    }
                }
            }
        )

        if (!isLoggedIn) {
            // Login form
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("ورود کارکنان", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(24.dp))

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("ایمیل") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("رمز عبور") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation()
                )
                Spacer(Modifier.height(16.dp))

                loginError?.let {
                    Text(it, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(8.dp))
                }

                Button(
                    onClick = {
                        loginError = null
                        isLoading = true
                        scope.launch {
                            val res = repo.loginAdmin(email.trim(), password)
                            isLoading = false
                            res.onSuccess { isLoggedIn = true }
                                .onFailure { loginError = "ورود ناموفق. ایمیل یا رمز اشتباه است." }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !isLoading
                ) {
                    if (isLoading) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    else Text("ورود")
                }
            }
        } else {
            // Appointments list
            if (isLoading && appointments.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            } else if (appointments.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("هیچ نوبتی ثبت نشده است", color = Color.Gray)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(appointments, key = { it.code }) { appt ->
                        AppointmentCard(appt, onStatusChange = { newStatus ->
                            scope.launch {
                                repo.updateStatus(appt.code, newStatus)
                                loadAppointments()
                            }
                        })
                    }
                }
            }
        }
    }
}

@Composable
private fun AppointmentCard(
    appt: Appointment,
    onStatusChange: (String) -> Unit
) {
    val statusOptions = listOf("جدید", "تأیید‌شده", "انجام‌شده", "لغو")
    var expanded by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(appt.fullName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                AssistChip(
                    onClick = { expanded = true },
                    label = { Text(appt.status, fontSize = 12.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = when (appt.status) {
                            "تأیید‌شده" -> Color(0xFFD1FAE5)
                            "لغو" -> Color(0xFFFEE2E2)
                            "انجام‌شده" -> Color(0xFFDBEAFE)
                            else -> Color(0xFFFEF3C7)
                        }
                    )
                )
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    statusOptions.forEach { s ->
                        DropdownMenuItem(
                            text = { Text(s) },
                            onClick = {
                                expanded = false
                                onStatusChange(s)
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("کد: ${appt.code}", color = Color.Gray, fontSize = 13.sp)
            Text("موبایل: ${appt.phone}", fontSize = 13.sp)
            if (appt.specialty.isNotEmpty()) Text("تخصص: ${appt.specialty}", fontSize = 13.sp)
            Text(
                "${appt.preferredDateLabel} — ${DateUtils.toPersianTime(appt.preferredTime)}",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.primary
            )
            if (appt.notes.isNotEmpty()) {
                Text("توضیح: ${appt.notes}", fontSize = 12.sp, color = Color.Gray)
            }
        }
    }
}
