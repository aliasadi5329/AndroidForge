package com.faragir.hospital.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faragir.hospital.data.AppointmentRepository
import com.faragir.hospital.data.DateUtils
import com.faragir.hospital.data.appointmentTypes
import com.faragir.hospital.data.specialties
import com.faragir.hospital.data.timeSlots
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppointmentScreen(
    onBack: () -> Unit = {}
) {
    val repo = remember { AppointmentRepository() }
    val scope = rememberCoroutineScope()
    val scroll = rememberScrollState()

    var fullName by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var nationalId by remember { mutableStateOf("") }
    var appointmentType by remember { mutableStateOf("") }
    var specialty by remember { mutableStateOf("") }
    var selectedDay by remember { mutableStateOf<DateUtils.DayItem?>(null) }
    var selectedTime by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    var takenSlots by remember { mutableStateOf<Set<String>>(emptySet()) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    var successCode by remember { mutableStateOf<String?>(null) }

    val days = remember { DateUtils.next7Days() }

    // Load taken slots when day or specialty changes
    LaunchedEffect(selectedDay, specialty) {
        selectedDay?.let { day ->
            takenSlots = repo.getTakenSlots(day.isoDate)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top bar
        TopAppBar(
            title = { Text("دریافت نوبت آنلاین", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = Color.White
            )
        )

        if (successCode != null) {
            // Success view
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = Color(0xFF059669),
                    modifier = Modifier.size(80.dp)
                )
                Spacer(Modifier.height(16.dp))
                Text("نوبت شما با موفقیت ثبت شد", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Text("کد پیگیری:", color = Color.Gray)
                Text(
                    successCode!!,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    letterSpacing = 3.sp
                )
                Spacer(Modifier.height(8.dp))
                selectedDay?.let {
                    Text("${it.label} — ساعت ${DateUtils.toPersianTime(selectedTime)}")
                }
                Spacer(Modifier.height(24.dp))
                Button(
                    onClick = {
                        successCode = null
                        fullName = ""; phone = ""; nationalId = ""
                        appointmentType = ""; specialty = ""
                        selectedDay = null; selectedTime = ""; notes = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("ثبت نوبت جدید")
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scroll)
                    .padding(16.dp)
            ) {
                // Name
                OutlinedTextField(
                    value = fullName,
                    onValueChange = { fullName = it },
                    label = { Text("نام و نام خانوادگی *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(Modifier.height(12.dp))

                // Phone
                OutlinedTextField(
                    value = phone,
                    onValueChange = { if (it.length <= 11) phone = it.filter { c -> c.isDigit() } },
                    label = { Text("شماره موبایل *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    placeholder = { Text("0912xxxxxxx") }
                )
                Spacer(Modifier.height(12.dp))

                // National ID
                OutlinedTextField(
                    value = nationalId,
                    onValueChange = { if (it.length <= 10) nationalId = it.filter { c -> c.isDigit() } },
                    label = { Text("کد ملی") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                Spacer(Modifier.height(12.dp))

                // Appointment Type
                var typeExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = typeExpanded, onExpandedChange = { typeExpanded = it }) {
                    OutlinedTextField(
                        value = appointmentType,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("نوع نوبت *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(typeExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = typeExpanded, onDismissRequest = { typeExpanded = false }) {
                        appointmentTypes.forEach { type ->
                            DropdownMenuItem(
                                text = { Text(type) },
                                onClick = {
                                    appointmentType = type
                                    typeExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))

                // Specialty
                var specExpanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = specExpanded, onExpandedChange = { specExpanded = it }) {
                    OutlinedTextField(
                        value = specialty,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("تخصص مورد نظر") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(specExpanded) },
                        modifier = Modifier.fillMaxWidth().menuAnchor()
                    )
                    ExposedDropdownMenu(expanded = specExpanded, onDismissRequest = { specExpanded = false }) {
                        specialties.forEach { s ->
                            DropdownMenuItem(
                                text = { Text(s) },
                                onClick = {
                                    specialty = s
                                    specExpanded = false
                                }
                            )
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))

                // Day picker
                Text("انتخاب روز *", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    days.forEach { day ->
                        val isSelected = selectedDay?.isoDate == day.isoDate
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(12.dp))
                                .border(
                                    width = 2.dp,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else Color(0xFFE2E8F0),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .background(if (isSelected) Color(0xFFECFDF5) else Color.White)
                                .clickable {
                                    selectedDay = day
                                    selectedTime = ""
                                }
                                .padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                day.dayOfWeek,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                day.label.substringAfter(" "),
                                fontSize = 10.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
                Spacer(Modifier.height(20.dp))

                // Time picker
                Text("انتخاب ساعت *", fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Two rows of times would be better, but simple flow
                }
                // Better: use Flow-like with wrap
                val chunked = timeSlots.chunked(4)
                chunked.forEach { rowTimes ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        rowTimes.forEach { time ->
                            val slotKey = selectedDay?.let { "${it.isoDate}_${time}_${specialty.ifEmpty { "general" }}" } ?: ""
                            val isTaken = takenSlots.contains(slotKey)
                            val isSelected = selectedTime == time
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(
                                        2.dp,
                                        when {
                                            isSelected -> MaterialTheme.colorScheme.primary
                                            isTaken -> Color.LightGray
                                            else -> Color(0xFFE2E8F0)
                                        },
                                        RoundedCornerShape(10.dp)
                                    )
                                    .background(
                                        when {
                                            isSelected -> MaterialTheme.colorScheme.primary
                                            isTaken -> Color(0xFFF1F5F9)
                                            else -> Color.White
                                        }
                                    )
                                    .clickable(enabled = !isTaken && selectedDay != null) {
                                        selectedTime = time
                                    }
                                    .padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    DateUtils.toPersianTime(time),
                                    color = when {
                                        isSelected -> Color.White
                                        isTaken -> Color.Gray
                                        else -> Color(0xFF334155)
                                    },
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 14.sp
                                )
                            }
                        }
                        // Fill remaining space if less than 4
                        repeat(4 - rowTimes.size) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                if (selectedDay != null && selectedTime.isNotEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDFA))
                    ) {
                        Text(
                            "نوبت انتخابی: ${selectedDay!!.label} — ساعت ${DateUtils.toPersianTime(selectedTime)}",
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("توضیحات (اختیاری)") },
                    modifier = Modifier.fillMaxWidth().height(100.dp),
                    maxLines = 4
                )

                Spacer(Modifier.height(16.dp))

                errorMsg?.let {
                    Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(bottom = 8.dp))
                }

                Button(
                    onClick = {
                        errorMsg = null
                        when {
                            fullName.trim().length < 3 -> errorMsg = "نام را کامل وارد کنید"
                            !phone.matches(Regex("09[0-9]{9}")) -> errorMsg = "شماره موبایل معتبر نیست"
                            appointmentType.isEmpty() -> errorMsg = "نوع نوبت را انتخاب کنید"
                            selectedDay == null || selectedTime.isEmpty() -> errorMsg = "روز و ساعت را انتخاب کنید"
                            else -> {
                                isLoading = true
                                scope.launch {
                                    val result = repo.createAppointment(
                                        fullName = fullName.trim(),
                                        phone = phone,
                                        nationalId = nationalId,
                                        appointmentType = appointmentType,
                                        specialty = specialty,
                                        preferredDate = selectedDay!!.isoDate,
                                        preferredDateLabel = selectedDay!!.label,
                                        preferredTime = selectedTime,
                                        notes = notes.trim()
                                    )
                                    isLoading = false
                                    result.onSuccess { code ->
                                        successCode = code
                                    }.onFailure { e ->
                                        errorMsg = "خطا در ثبت نوبت: ${e.message ?: "دوباره تلاش کنید"}"
                                    }
                                }
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(52.dp),
                    enabled = !isLoading,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                    } else {
                        Text("ثبت درخواست نوبت", fontSize = 16.sp)
                    }
                }

                Spacer(Modifier.height(32.dp))
            }
        }
    }
}
