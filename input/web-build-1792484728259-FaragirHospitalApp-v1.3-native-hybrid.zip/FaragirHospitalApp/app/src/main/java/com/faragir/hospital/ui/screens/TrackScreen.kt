package com.faragir.hospital.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.faragir.hospital.data.AppointmentRepository
import com.faragir.hospital.data.DateUtils
import com.faragir.hospital.data.PublicStatus
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackScreen() {
    val repo = remember { AppointmentRepository() }
    val scope = rememberCoroutineScope()

    var code by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }
    var result by remember { mutableStateOf<PublicStatus?>(null) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        TopAppBar(
            title = { Text("پیگیری نوبت", fontWeight = FontWeight.Bold) },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.primary,
                titleContentColor = Color.White
            )
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                "کد پیگیری ۱۰ کاراکتری خود را وارد کنید",
                color = Color.Gray,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))

            OutlinedTextField(
                value = code,
                onValueChange = {
                    if (it.length <= 10) code = it.uppercase().filter { c -> c.isLetterOrDigit() }
                },
                label = { Text("کد پیگیری") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii),
                textStyle = LocalTextStyle.current.copy(
                    textAlign = TextAlign.Center,
                    letterSpacing = 4.sp,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    errorMsg = null
                    result = null
                    if (code.length != 10) {
                        errorMsg = "کد پیگیری باید ۱۰ کاراکتر باشد"
                        return@Button
                    }
                    isLoading = true
                    scope.launch {
                        val res = repo.trackAppointment(code)
                        isLoading = false
                        res.onSuccess { result = it }
                            .onFailure { errorMsg = it.message ?: "خطا در دریافت اطلاعات" }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled = !isLoading,
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                } else {
                    Icon(Icons.Default.Search, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text("پیگیری نوبت")
                }
            }

            Spacer(Modifier.height(24.dp))

            errorMsg?.let {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(it, color = Color(0xFF991B1B), modifier = Modifier.padding(16.dp))
                }
            }

            result?.let { status ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFECFDF5)),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("وضعیت نوبت", color = Color.Gray)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            status.status,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (status.status) {
                                "تأیید‌شده" -> Color(0xFF059669)
                                "لغو" -> Color(0xFFDC2626)
                                "انجام‌شده" -> Color(0xFF2563EB)
                                else -> MaterialTheme.colorScheme.primary
                            }
                        )
                        if (status.preferredDateLabel.isNotEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            Text("${status.preferredDateLabel}")
                            Text("ساعت ${DateUtils.toPersianTime(status.preferredTime)}")
                        }
                    }
                }
            }
        }
    }
}
