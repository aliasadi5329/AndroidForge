(function () {
  'use strict';

  let allAppointments = [];
  let currentDetailId = null;

  const $ = (id) => document.getElementById(id);

  // ---------- Auth ----------
  function showLogin() {
    $('loginPage').style.display = 'block';
    $('adminPage').style.display = 'none';
  }

  function showAdmin(user) {
    $('loginPage').style.display = 'none';
    $('adminPage').style.display = 'block';
    $('adminEmail').textContent = user.email || '';
    loadAppointments();
  }

  async function isAdmin(uid) {
    try {
      const doc = await window.db.collection('admins').doc(uid).get();
      return doc.exists;
    } catch (e) {
      console.error(e);
      return false;
    }
  }

  window.auth.onAuthStateChanged(async (user) => {
    if (user) {
      const ok = await isAdmin(user.uid);
      if (ok) {
        showAdmin(user);
      } else {
        await window.auth.signOut();
        showLogin();
        $('loginError').textContent = 'شما دسترسی مدیریت ندارید.';
      }
    } else {
      showLogin();
    }
  });

  $('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = $('email').value.trim();
    const password = $('password').value;
    const btn = $('loginBtn');
    const err = $('loginError');
    err.textContent = '';
    btn.disabled = true;
    btn.textContent = 'در حال ورود...';

    try {
      await window.auth.signInWithEmailAndPassword(email, password);
      // onAuthStateChanged handles the rest
    } catch (ex) {
      err.textContent = 'ایمیل یا رمز عبور اشتباه است.';
      btn.disabled = false;
      btn.textContent = 'ورود به پنل';
    }
  });

  $('logoutBtn').addEventListener('click', () => {
    window.auth.signOut();
  });

  // ---------- Load & Render ----------
  async function loadAppointments() {
    $('loading').style.display = 'block';
    $('emptyMsg').style.display = 'none';
    $('appointmentsList').innerHTML = '';

    try {
      const snap = await window.db.collection('appointments')
        .orderBy('createdAt', 'desc')
        .limit(200)
        .get();

      allAppointments = snap.docs.map((doc) => {
        const d = doc.data();
        return {
          id: doc.id,
          fullName: d.fullName || '',
          phone: d.phone || '',
          nationalId: d.nationalId || '',
          appointmentType: d.appointmentType || '',
          specialty: d.specialty || '',
          preferredDate: d.preferredDate || '',
          preferredDateLabel: d.preferredDateLabel || '',
          preferredTime: d.preferredTime || '',
          slotId: d.slotId || '',
          notes: d.notes || '',
          status: d.status || 'جدید',
          createdAt: d.createdAt
        };
      });

      fillSpecialtyFilter();
      applyFilters();
      updateStats();
    } catch (e) {
      console.error(e);
      $('loading').textContent = 'خطا در بارگذاری داده‌ها. قوانین Firestore را بررسی کنید.';
    } finally {
      $('loading').style.display = 'none';
    }
  }

  function fillSpecialtyFilter() {
    const specs = [...new Set(allAppointments.map(a => a.specialty).filter(Boolean))];
    const sel = $('filterSpecialty');
    const current = sel.value;
    sel.innerHTML = '<option value="">همه تخصص‌ها</option>';
    specs.sort().forEach(s => {
      const opt = document.createElement('option');
      opt.value = s;
      opt.textContent = s;
      sel.appendChild(opt);
    });
    sel.value = current;
  }

  function updateStats() {
    $('statTotal').textContent = allAppointments.length;
    $('statNew').textContent = allAppointments.filter(a => a.status === 'جدید').length;
    $('statConfirmed').textContent = allAppointments.filter(a => a.status === 'تأیید‌شده').length;
    $('statDone').textContent = allAppointments.filter(a => a.status === 'انجام‌شده').length;
    $('statCancel').textContent = allAppointments.filter(a => a.status === 'لغو').length;
  }

  function applyFilters() {
    const q = ($('searchInput').value || '').trim().toLowerCase();
    const status = $('filterStatus').value;
    const specialty = $('filterSpecialty').value;
    const date = $('filterDate').value;

    let list = allAppointments.filter(a => {
      if (status && a.status !== status) return false;
      if (specialty && a.specialty !== specialty) return false;
      if (date && a.preferredDate !== date) return false;
      if (q) {
        const hay = (a.fullName + ' ' + a.phone + ' ' + a.id + ' ' + a.nationalId).toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    renderList(list);
  }

  function badgeClass(status) {
    if (status === 'تأیید‌شده') return 'badge-confirmed';
    if (status === 'انجام‌شده') return 'badge-done';
    if (status === 'لغو') return 'badge-cancel';
    return 'badge-new';
  }

  function renderList(list) {
    const container = $('appointmentsList');
    container.innerHTML = '';

    if (list.length === 0) {
      $('emptyMsg').style.display = 'block';
      return;
    }
    $('emptyMsg').style.display = 'none';

    list.forEach(a => {
      const card = document.createElement('div');
      card.className = 'appt-card';
      card.innerHTML = `
        <div class="appt-top">
          <div class="appt-name">${escapeHtml(a.fullName)}</div>
          <span class="badge ${badgeClass(a.status)}">${escapeHtml(a.status)}</span>
        </div>
        <div class="appt-info">
          <div><span>کد:</span> ${escapeHtml(a.id)}</div>
          <div><span>موبایل:</span> ${escapeHtml(a.phone)}</div>
          <div><span>نوع:</span> ${escapeHtml(a.appointmentType)} ${a.specialty ? '— ' + escapeHtml(a.specialty) : ''}</div>
          <div><span>زمان:</span> ${escapeHtml(a.preferredDateLabel || a.preferredDate)} — ${escapeHtml(a.preferredTime)}</div>
        </div>
        <div class="appt-actions">
          <select class="status-select" data-id="${a.id}">
            <option value="جدید" ${a.status === 'جدید' ? 'selected' : ''}>جدید</option>
            <option value="تأیید‌شده" ${a.status === 'تأیید‌شده' ? 'selected' : ''}>تأیید‌شده</option>
            <option value="انجام‌شده" ${a.status === 'انجام‌شده' ? 'selected' : ''}>انجام‌شده</option>
            <option value="لغو" ${a.status === 'لغو' ? 'selected' : ''}>لغو</option>
          </select>
          <button class="btn btn-outline btn-sm detail-btn" data-id="${a.id}">جزئیات</button>
        </div>
      `;
      container.appendChild(card);
    });

    // Status change
    container.querySelectorAll('.status-select').forEach(sel => {
      sel.addEventListener('change', async function () {
        const id = this.dataset.id;
        const newStatus = this.value;
        this.disabled = true;
        try {
          await updateStatus(id, newStatus);
          const item = allAppointments.find(x => x.id === id);
          if (item) item.status = newStatus;
          updateStats();
          applyFilters();
        } catch (e) {
          alert('خطا در تغییر وضعیت: ' + (e.message || e));
          loadAppointments();
        }
      });
    });

    // Detail buttons
    container.querySelectorAll('.detail-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        openDetail(btn.dataset.id);
      });
    });
  }

  // ---------- Status & Delete ----------
  async function updateStatus(code, newStatus) {
    const batch = window.db.batch();
    batch.update(window.db.collection('appointments').doc(code), {
      status: newStatus,
      updatedAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    batch.update(window.db.collection('public_status').doc(code), {
      status: newStatus
    });
    await batch.commit();
  }

  async function deleteAppointment(code) {
    const appt = allAppointments.find(a => a.id === code);
    const batch = window.db.batch();
    batch.delete(window.db.collection('appointments').doc(code));
    batch.delete(window.db.collection('public_status').doc(code));
    if (appt && appt.slotId) {
      batch.delete(window.db.collection('slots').doc(appt.slotId));
    }
    await batch.commit();
  }

  // ---------- Detail Modal ----------
  function openDetail(id) {
    const a = allAppointments.find(x => x.id === id);
    if (!a) return;
    currentDetailId = id;

    $('detailBody').innerHTML = `
      <div class="detail-row"><span class="label">کد پیگیری</span><span class="value">${escapeHtml(a.id)}</span></div>
      <div class="detail-row"><span class="label">نام</span><span class="value">${escapeHtml(a.fullName)}</span></div>
      <div class="detail-row"><span class="label">موبایل</span><span class="value">${escapeHtml(a.phone)}</span></div>
      <div class="detail-row"><span class="label">کد ملی</span><span class="value">${escapeHtml(a.nationalId || '—')}</span></div>
      <div class="detail-row"><span class="label">نوع نوبت</span><span class="value">${escapeHtml(a.appointmentType)}</span></div>
      <div class="detail-row"><span class="label">تخصص</span><span class="value">${escapeHtml(a.specialty || '—')}</span></div>
      <div class="detail-row"><span class="label">تاریخ</span><span class="value">${escapeHtml(a.preferredDateLabel || a.preferredDate)}</span></div>
      <div class="detail-row"><span class="label">ساعت</span><span class="value">${escapeHtml(a.preferredTime)}</span></div>
      <div class="detail-row"><span class="label">وضعیت</span><span class="value">${escapeHtml(a.status)}</span></div>
      <div class="detail-row"><span class="label">توضیحات</span><span class="value">${escapeHtml(a.notes || '—')}</span></div>
    `;
    $('detailModal').style.display = 'flex';
  }

  function closeModal() {
    $('detailModal').style.display = 'none';
    currentDetailId = null;
  }

  $('closeModal').addEventListener('click', closeModal);
  $('closeModal2').addEventListener('click', closeModal);
  $('detailModal').addEventListener('click', (e) => {
    if (e.target === $('detailModal')) closeModal();
  });

  $('deleteApptBtn').addEventListener('click', async () => {
    if (!currentDetailId) return;
    if (!confirm('آیا از حذف این نوبت مطمئن هستید؟ این عمل قابل برگشت نیست.')) return;

    try {
      await deleteAppointment(currentDetailId);
      allAppointments = allAppointments.filter(a => a.id !== currentDetailId);
      closeModal();
      updateStats();
      applyFilters();
    } catch (e) {
      alert('خطا در حذف: ' + (e.message || e));
    }
  });

  // ---------- Filters events ----------
  $('searchInput').addEventListener('input', applyFilters);
  $('filterStatus').addEventListener('change', applyFilters);
  $('filterSpecialty').addEventListener('change', applyFilters);
  $('filterDate').addEventListener('change', applyFilters);
  $('clearFilters').addEventListener('click', () => {
    $('searchInput').value = '';
    $('filterStatus').value = '';
    $('filterSpecialty').value = '';
    $('filterDate').value = '';
    applyFilters();
  });
  $('refreshBtn').addEventListener('click', loadAppointments);

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
})();
