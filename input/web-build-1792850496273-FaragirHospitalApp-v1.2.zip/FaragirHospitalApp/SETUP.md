# راه‌اندازی امنیتی (۱۰ دقیقه)

## ۱. قوانین دیتابیس (مهم‌ترین مرحله)
1. Firebase Console ← پروژه faragir-appointment-app ← Firestore Database ← تب **Rules**
2. محتوای فایل `firestore.rules` را کامل جایگزین و **Publish** کنید. (حالت test mode حذف می‌شود)

## ۲. ساخت حساب مدیر
1. Authentication ← Sign-in method ← **Email/Password** را فعال کنید.
2. Users ← Add user: ایمیل و رمز قوی (حداقل ۱۲ کاراکتر) برای هر کارمند.
3. UID کاربر را کپی کنید. Firestore ← Start collection با نام `admins` ← Document ID = همان UID (محتوای دلخواه، مثلاً `role: "admin"`).
4. حتماً پنل را از آدرس `admin.html` داخل اپ تست کنید.

## ۳. محافظت بیشتر در برابر ثبت نوبت جعلی (اختیاری، بعد از تست)
- Google Cloud Console ← APIs & Services ← Credentials ← کلید API را محدود کنید (API restrictions: فقط Firestore و Identity Toolkit).
- App Check هنوز در کد فعال نشده است. **تا زمانی که در کد اضافه نشده، Enforce نکنید**، وگرنه ثبت نوبت از کار می‌افتد.

## ۴. ساخت اپ
- اپ اکنون از آدرس امن `https://appassets.androidplatform.net` اجرا می‌شود (نه file://) و دسترسی به فایل‌های گوشی بسته است.
- ساخت APK مثل قبل با AndroidForge یا `./gradlew assembleRelease` انجام می‌شود.

## محدودیت‌های شناخته‌شده
- تأیید پیامکی موبایل نیاز به سرویس پیامک ایرانی (مثل کاوه‌نگار/ملی‌پیامک) و یک سرور دارد و در این نسخه نیست؛ فعلاً جلوگیری از اسپم با قفل ساعت، فیلد تله، فاصله بین ثبت‌ها و App Check است.
- ظرفیت هر ساعت برای هر تخصص یک نوبت است؛ برای ظرفیت به‌ازای هر پزشک باید فهرست پزشکان اضافه شود.
- Firebase سرورش خارج از ایران است؛ برای استفاده واقعی، با مسئول IT درباره میزبانی داخلی (و اتصال به HIS) هماهنگ کنید.
