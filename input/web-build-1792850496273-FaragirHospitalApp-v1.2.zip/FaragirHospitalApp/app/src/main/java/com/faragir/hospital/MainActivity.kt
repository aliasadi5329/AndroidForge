package com.faragir.hospital

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ProgressBar
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader
import java.net.HttpURLConnection
import java.net.URL

/**
 * نمایش سایت بیمارستان از داخل assets از طریق آدرس امن HTTPS مجازی
 * (به‌جای file://) تا دسترسی به فایل‌های دستگاه بسته بماند.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var progress: ProgressBar

    private val assetLoader by lazy {
        WebViewAssetLoader.Builder()
            .setDomain(APP_HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        webView = WebView(this)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(webView, FrameLayout.LayoutParams(-1, -1))
        root.addView(progress, FrameLayout.LayoutParams(-1, 8))
        setContentView(root)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // دسترسی به فایل‌های دستگاه بسته است
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            loadWithOverviewMode = true
            useWideViewPort = true
            builtInZoomControls = false
            displayZoomControls = false
            setSupportZoom(false)
            setGeolocationEnabled(false)
            cacheMode = WebSettings.LOAD_DEFAULT
            userAgentString = "$userAgentString FaragirApp/${BuildConfigVersion.NAME}"
        }

        webView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val uri = request.url
                val scheme = uri.scheme ?: return true
                // صفحات داخلی اپ
                if (scheme == "https" && uri.host == APP_HOST) return false
                // تصاویر سرور بیمارستان داخل خود اپ لود شوند
                if (scheme == "https" && uri.host == IMAGE_HOST && isImageUrl(uri.toString())) return false
                // تماس و ایمیل
                if (scheme == "tel" || scheme == "mailto") {
                    openExternal(uri); return true
                }
                // فقط HTTPS در مرورگر بیرونی باز شود؛ بقیه (http, file, intent, ...) مسدود
                if (scheme == "https") openExternal(uri)
                return true
            }

            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
                assetLoader.shouldInterceptRequest(request.url)?.let { return it }
                val url = request.url.toString()
                if (request.url.host == IMAGE_HOST && isImageUrl(url)) return fetchImageWithHeaders(url)
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                progress.visibility = View.VISIBLE
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                progress.visibility = View.GONE
            }

            override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                // فقط خطای صفحه اصلی؛ خطای تصاویر/اسکریپت‌های جانبی نادیده گرفته می‌شود
                if (request.isForMainFrame) {
                    view.loadUrl("$APP_ORIGIN/assets/offline.html")
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress.progress = newProgress
                progress.visibility = if (newProgress in 1..99) View.VISIBLE else View.GONE
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) webView.goBack() else finish()
            }
        })

        if (savedInstanceState != null) webView.restoreState(savedInstanceState)
        else webView.loadUrl("$APP_ORIGIN/assets/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onDestroy() {
        // جلوگیری از نشت حافظه
        (webView.parent as? FrameLayout)?.removeView(webView)
        webView.destroy()
        super.onDestroy()
    }

    private fun openExternal(uri: Uri) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
        } catch (_: Exception) { /* برنامه‌ای برای باز کردن وجود ندارد */ }
    }

    private fun isImageUrl(url: String): Boolean {
        val l = url.lowercase().substringBefore('?')
        return l.endsWith(".jpg") || l.endsWith(".jpeg") || l.endsWith(".png") ||
            l.endsWith(".webp") || l.endsWith(".gif") || l.contains("/cms/")
    }

    @Suppress("unused")
    private fun isOnline(): Boolean {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun fetchImageWithHeaders(imageUrl: String): WebResourceResponse? = try {
        val c = URL(imageUrl).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 15000
        c.instanceFollowRedirects = true
        c.setRequestProperty("Referer", "https://faragirsalamat.ir/")
        c.setRequestProperty("Accept", "image/avif,image/webp,image/apng,image/*,*/*;q=0.8")
        c.connect()
        val mime = when {
            imageUrl.contains(".webp", true) -> "image/webp"
            imageUrl.contains(".png", true) -> "image/png"
            imageUrl.contains(".gif", true) -> "image/gif"
            else -> "image/jpeg"
        }
        if (c.responseCode in 200..299) WebResourceResponse(mime, null, c.inputStream) else null
    } catch (_: Exception) {
        null
    }

    companion object {
        private const val APP_HOST = "appassets.androidplatform.net"
        private const val APP_ORIGIN = "https://$APP_HOST"
        private const val IMAGE_HOST = "assets.faragirsalamat.ir"
    }
}

private object BuildConfigVersion { const val NAME = "1.2" }
