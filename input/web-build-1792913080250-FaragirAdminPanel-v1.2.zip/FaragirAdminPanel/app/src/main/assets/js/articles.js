(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  let unsub = null, editId = null, cache = {};

  function say(cls, text) { const m = $('artMsg'); m.className = 'art-msg ' + cls; m.textContent = text; }
  function resetForm() {
    editId = null; $('artForm').reset(); $('artPublished').checked = true;
    $('artFormTitle').textContent = 'مقاله جدید'; $('artCancel').style.display = 'none';
  }
  function dateFa(ts) {
    try { return (ts && ts.toDate ? ts.toDate() : new Date()).toLocaleDateString('fa-IR'); } catch (_) { return ''; }
  }

  function tab(which) {
    const arts = which === 'arts';
    $('apptsView').style.display = arts ? 'none' : 'block';
    $('artsView').style.display = arts ? 'block' : 'none';
    $('tabAppts').classList.toggle('active', !arts);
    $('tabArts').classList.toggle('active', arts);
  }
  $('tabAppts').addEventListener('click', () => tab('appts'));
  $('tabArts').addEventListener('click', () => tab('arts'));

  function listen() {
    if (unsub) unsub();
    unsub = window.db.collection('articles').orderBy('createdAt', 'desc').limit(100).onSnapshot((snap) => {
      const list = $('artList'); list.innerHTML = ''; cache = {};
      $('artEmpty').style.display = snap.size ? 'none' : 'block';
      snap.forEach((d) => {
        const a = d.data(); cache[d.id] = a;
        const card = document.createElement('div'); card.className = 'appt-card';
        const top = document.createElement('div'); top.className = 'appt-top';
        const name = document.createElement('div'); name.className = 'appt-name'; name.textContent = a.title;
        const badge = document.createElement('span');
        badge.className = 'badge ' + (a.published ? 'badge-confirmed' : 'badge-new');
        badge.textContent = a.published ? 'منتشرشده' : 'پیش‌نویس';
        top.appendChild(name); top.appendChild(badge);
        const info = document.createElement('div'); info.className = 'appt-info';
        info.textContent = dateFa(a.createdAt) + (a.summary ? ' — ' + a.summary : '');
        const act = document.createElement('div'); act.className = 'appt-actions';
        [['ویرایش', 'btn-outline', () => edit(d.id)], ['حذف', 'btn-danger', () => del(d.id)]].forEach((x) => {
          const b = document.createElement('button'); b.className = 'btn btn-sm ' + x[1]; b.textContent = x[0];
          b.addEventListener('click', x[2]); act.appendChild(b);
        });
        card.appendChild(top); card.appendChild(info); card.appendChild(act); list.appendChild(card);
      });
    }, (e) => { console.error(e); say('err', 'خطا در بارگذاری مقالات. قوانین Firestore را بررسی کنید.'); });
  }

  function edit(id) {
    const a = cache[id]; if (!a) return;
    editId = id; $('artTitle').value = a.title; $('artSummary').value = a.summary || ''; $('artBody').value = a.body || '';
    $('artPublished').checked = !!a.published; $('artFormTitle').textContent = 'ویرایش مقاله';
    $('artCancel').style.display = 'block'; window.scrollTo(0, 0);
  }
  async function del(id) {
    if (!confirm('این مقاله حذف شود؟ قابل برگشت نیست.')) return;
    try { await window.db.collection('articles').doc(id).delete(); if (editId === id) resetForm(); }
    catch (e) { console.error(e); alert('خطا در حذف مقاله'); }
  }

  $('artCancel').addEventListener('click', resetForm);
  $('artForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('artSave'); btn.disabled = true; $('artMsg').className = 'art-msg';
    const ts = firebase.firestore.FieldValue.serverTimestamp();
    const data = {
      title: $('artTitle').value.trim(), summary: $('artSummary').value.trim(),
      body: $('artBody').value.trim(), published: $('artPublished').checked, updatedAt: ts
    };
    try {
      if (editId) await window.db.collection('articles').doc(editId).update(data);
      else { data.createdAt = ts; await window.db.collection('articles').add(data); }
      say('ok', data.published ? 'ذخیره شد و همین حالا در اپ بیمارستان دیده می‌شود.' : 'به‌عنوان پیش‌نویس ذخیره شد.');
      resetForm();
    } catch (err) { console.error(err); say('err', 'خطا در ذخیره مقاله. اینترنت را بررسی کنید.'); }
    finally { btn.disabled = false; }
  });

  document.addEventListener('admin-ready', () => { tab('appts'); listen(); });
  // اگر ورود قبل از بارگذاری این فایل انجام شده بود
  if ($('adminPage').style.display === 'block') { tab('appts'); listen(); }
  document.addEventListener('admin-out', () => { if (unsub) { unsub(); unsub = null; } resetForm(); });
})();
