package com.faragir.hospital

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * هر ~۱۵ دقیقه سند عمومی meta/latest را می‌خواند؛ اگر مقاله تازه‌ای منتشر شده باشد اعلان نشان می‌دهد.
 * نیازی به سرویس‌های گوگل (FCM) ندارد.
 */
class ArticleCheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        return try {
            val c = URL(META_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 15000
            val prefs = applicationContext.getSharedPreferences("articles", Context.MODE_PRIVATE)
            val code = c.responseCode
            if (code == 404) {
                // هنوز مقاله‌ای منتشر نشده؛ هر مقاله بعدی «جدید» حساب می‌شود
                if (prefs.getLong("lastTs", -1L) == -1L) prefs.edit().putLong("lastTs", 0L).apply()
                return Result.success()
            }
            if (code !in 200..299) return Result.retry()
            val body = c.inputStream.bufferedReader().use { it.readText() }
            val f = JSONObject(body).getJSONObject("fields")
            val id = f.getJSONObject("articleId").getString("stringValue")
            val title = f.getJSONObject("title").getString("stringValue")
            val ts = f.getJSONObject("ts").getString("integerValue").toLong()
            val last = prefs.getLong("lastTs", -1L)
            if (last == -1L) {
                // اولین اجرا: مقالات موجود را اعلان نکن
                prefs.edit().putLong("lastTs", ts).apply()
            } else if (ts > last) {
                showNotification(id, title)
                prefs.edit().putLong("lastTs", ts).apply()
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    private fun showNotification(articleId: String, title: String) {
        val ctx = applicationContext
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "مقالات جدید", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val intent = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("articleId", articleId)
        }
        val pi = PendingIntent.getActivity(
            ctx, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_notify_chat)
            .setContentTitle("مقاله جدید در فراگیر سلامت")
            .setContentText(title)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .build()
        nm.notify(1001, n)
    }

    companion object {
        const val CHANNEL = "new_articles"
        const val META_URL =
            "https://firestore.googleapis.com/v1/projects/faragir-appointment-app/databases/(default)/documents/meta/latest?key=AIzaSyAUL-TMPS1YwH8U2SVu4GjQg59Smn2YzCk"
    }
}
