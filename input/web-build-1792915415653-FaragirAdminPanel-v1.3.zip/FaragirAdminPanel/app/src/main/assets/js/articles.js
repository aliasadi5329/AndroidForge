(function () {
  'use strict';
  const $ = (id) => document.getElementById(id);
  let unsub = null, editId = null, cache = {}, images = [];
  const MAX_IMG = 3, MAX_LEN = 200000; // طول رشته هر عکس (تقریباً ۱۵۰ کیلوبایت)


  function renderThumbs() {
    const box = $('artThumbs'); box.innerHTML = '';
    images.forEach((src, i) => {
      const w = document.createElement('div'); w.className = 'thumb';
      const im = document.createElement('img'); im.src = src; im.alt = '';
      const x = document.createElement('button'); x.type = 'button'; x.textContent = '×';
      x.addEventListener('click', () => { images.splice(i, 1); renderThumbs(); });
      w.appendChild(im); w.appendChild(x); box.appendChild(w);
    });
  }
  // کوچک‌کردن عکس در خود دستگاه تا به سقف حجم برسد (بدون نیاز به Firebase Storage)
  function compress(file) {
    return new Promise((resolve, reject) => {
      const img = new Image(), url = URL.createObjectURL(file);
      img.onload = () => {
        URL.revokeObjectURL(url);
        let scale = Math.min(1, 1000 / Math.max(img.width, img.height));
        for (let tries = 0; tries < 8; tries++) {
          const w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
          const cv = document.createElement('canvas'); cv.width = w; cv.height = h;
          const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, w, h); ctx.drawImage(img, 0, 0, w, h);
          for (let q = 0.8; q >= 0.4; q -= 0.1) {
            const d = cv.toDataURL('image/jpeg', q);
            if (d.length <= MAX_LEN) return resolve(d);
          }
          scale *= 0.8;
        }
        reject(new Error('too-big'));
      };
      img.onerror = () => reject(new Error('bad-image'));
      img.src = url;
    });
  }
  $('artFiles').addEventListener('change', async (e) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    for (const f of files) {
      if (images.length >= MAX_IMG) { say('err', 'حداکثر ۳ عکس مجاز است.'); break; }
      try { images.push(await compress(f)); renderThumbs(); }
      catch (_) { say('err', 'این عکس قابل پردازش نبود.'); }
    }
  });

  function say(cls, text) { const m = $('artMsg'); m.className = 'art-msg ' + cls; m.textContent = text; }
  function resetForm() {
    editId = null; images = []; renderThumbs(); $('artForm').reset(); $('artPublished').checked = true;
    $('artFormTitle').textContent = 'مقاله جدید'; $('artCancel').style.display = 'none';
  }
  function dateFa(ts) {
    try { return (ts && ts.toDate ? ts.toDate() : new Date()).toLocaleDateString('fa-IR'); } catch (_) { return ''; }
  }

  function tab(which) {
    const arts = which === 'arts';
    $('apptsView').style.display = arts ? 'none' : 'block';
    $('artsView').style.display = arts ? 'block' : 'none';
    $('tabAppts').classList.toggle('active', !arts);
    $('tabArts').classList.toggle('active', arts);
  }
  $('tabAppts').addEventListener('click', () => tab('appts'));
  $('tabArts').addEventListener('click', () => tab('arts'));

  function listen() {
    if (unsub) unsub();
    unsub = window.db.collection('articles').orderBy('createdAt', 'desc').limit(100).onSnapshot((snap) => {
      const list = $('artList'); list.innerHTML = ''; cache = {};
      $('artEmpty').style.display = snap.size ? 'none' : 'block';
      snap.forEach((d) => {
        const a = d.data(); cache[d.id] = a;
        const card = document.createElement('div'); card.className = 'appt-card';
        const top = document.createElement('div'); top.className = 'appt-top';
        const name = document.createElement('div'); name.className = 'appt-name'; name.textContent = a.title;
        const badge = document.createElement('span');
        badge.className = 'badge ' + (a.published ? 'badge-confirmed' : 'badge-new');
        badge.textContent = a.published ? 'منتشرشده' : 'پیش‌نویس';
        top.appendChild(name); top.appendChild(badge);
        const info = document.createElement('div'); info.className = 'appt-info';
        info.textContent = dateFa(a.createdAt) + (a.summary ? ' — ' + a.summary : '');
        const act = document.createElement('div'); act.className = 'appt-actions';
        [['ویرایش', 'btn-outline', () => edit(d.id)], ['حذف', 'btn-danger', () => del(d.id)]].forEach((x) => {
          const b = document.createElement('button'); b.className = 'btn btn-sm ' + x[1]; b.textContent = x[0];
          b.addEventListener('click', x[2]); act.appendChild(b);
        });
        card.appendChild(top); card.appendChild(info); card.appendChild(act); list.appendChild(card);
      });
    }, (e) => { console.error(e); say('err', 'خطا در بارگذاری مقالات. قوانین Firestore را بررسی کنید.'); });
  }

  function edit(id) {
    const a = cache[id]; if (!a) return;
    editId = id; $('artTitle').value = a.title; $('artSummary').value = a.summary || ''; $('artBody').value = a.body || '';
    $('artPublished').checked = !!a.published; images = Array.isArray(a.images) ? a.images.slice() : []; renderThumbs(); $('artVideo').value = a.videoUrl || ''; $('artFormTitle').textContent = 'ویرایش مقاله';
    $('artCancel').style.display = 'block'; window.scrollTo(0, 0);
  }
  async function del(id) {
    if (!confirm('این مقاله حذف شود؟ قابل برگشت نیست.')) return;
    try { await window.db.collection('articles').doc(id).delete(); if (editId === id) resetForm(); }
    catch (e) { console.error(e); alert('خطا در حذف مقاله'); }
  }

  $('artCancel').addEventListener('click', resetForm);
  $('artForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = $('artSave'); btn.disabled = true; $('artMsg').className = 'art-msg';
    const ts = firebase.firestore.FieldValue.serverTimestamp();
    const video = $('artVideo').value.trim();
    if (video && !/^https:\/\//i.test(video)) { say('err', 'لینک ویدیو باید با https شروع شود.'); btn.disabled = false; return; }
    const data = {
      title: $('artTitle').value.trim(), summary: $('artSummary').value.trim(),
      body: $('artBody').value.trim(), published: $('artPublished').checked,
      images: images, videoUrl: video, updatedAt: ts
    };
    try {
      const col = window.db.collection('articles');
      const wasPublished = editId && cache[editId] && cache[editId].published;
      const batch = window.db.batch();
      let id = editId;
      if (editId) batch.update(col.doc(editId), data);
      else { data.createdAt = ts; const ref = col.doc(); id = ref.id; batch.set(ref, data); }
      // مقاله تازه منتشرشده → «آخرین مقاله» به‌روز شود (برای نشان «جدید» و اعلان اپ)
      if (data.published && !wasPublished) {
        batch.set(window.db.collection('meta').doc('latest'), { articleId: id, title: data.title, ts: Date.now() });
      }
      await batch.commit();
      say('ok', data.published ? 'ذخیره شد و همین حالا در اپ بیمارستان دیده می‌شود.' : 'به‌عنوان پیش‌نویس ذخیره شد.');
      resetForm();
    } catch (err) { console.error(err); say('err', 'خطا در ذخیره مقاله. اینترنت را بررسی کنید.'); }
    finally { btn.disabled = false; }
  });

  document.addEventListener('admin-ready', () => { tab('appts'); listen(); });
  // اگر ورود قبل از بارگذاری این فایل انجام شده بود
  if ($('adminPage').style.display === 'block') { tab('appts'); listen(); }
  document.addEventListener('admin-out', () => { if (unsub) { unsub(); unsub = null; } resetForm(); });
})();
