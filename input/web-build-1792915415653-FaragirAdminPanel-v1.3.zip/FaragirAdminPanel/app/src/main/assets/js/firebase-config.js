// تنظیمات Firebase پروژه faragir-appointment-app
const firebaseConfig = {
  apiKey: "AIzaSyAUL-TMPS1YwH8U2SVu4GjQg59Smn2YzCk",
  authDomain: "faragir-appointment-app.firebaseapp.com",
  projectId: "faragir-appointment-app",
  storageBucket: "faragir-appointment-app.firebasestorage.app",
  messagingSenderId: "367980306885",
  appId: "1:367980306885:web:177742f8a06b8c8ac5abac",
  measurementId: "G-B5D8V0T1XP"
};

try {
  if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }
  window.db = firebase.firestore();
  window.auth = firebase.auth();
} catch (e) {
  console.error('Firebase init error:', e);
  window.db = null;
  window.auth = null;
}
