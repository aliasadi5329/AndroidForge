// کمک‌کننده‌های مقالات زنده (بدون HTML خام؛ همه متن‌ها با textContent نمایش داده می‌شوند)
var Articles = (function () {
  function dateFa(ts) {
    var d = ts && ts.toDate ? ts.toDate() : new Date();
    var m = ['','فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور','مهر','آبان','آذر','دی','بهمن','اسفند'];
    var j = Jalali.toJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
    return Validators.toFa(j.jd) + ' ' + m[j.jm] + ' ' + Validators.toFa(j.jy);
  }
  function millis(a) { return a.createdAt && a.createdAt.toMillis ? a.createdAt.toMillis() : Date.now(); }
  // فقط مقالات منتشرشده؛ به‌روزرسانی لحظه‌ای با onSnapshot
  function listen(limit, cb, errCb) {
    return window.db.collection('articles').where('published', '==', true).limit(limit || 50)
      .onSnapshot(function (snap) {
        var arr = snap.docs.map(function (d) { var x = d.data(); x.id = d.id; return x; });
        arr.sort(function (a, b) { return millis(b) - millis(a); });
        cb(arr);
      }, errCb || function (e) { console.error(e); });
  }
  // فقط تصویر داده‌ای (data:image) مجاز است؛ هر چیز دیگر نادیده گرفته می‌شود
  function safeImg(s) { return typeof s === 'string' && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+\/=]+$/.test(s) ? s : null; }
  function isDirectVideo(u) { return /^https:\/\/.+\.(mp4|webm)(\?.*)?$/i.test(u || ''); }
  function isHttps(u) { return /^https:\/\//i.test(u || ''); }
  return { dateFa: dateFa, listen: listen, safeImg: safeImg, isDirectVideo: isDirectVideo, isHttps: isHttps };
})();
