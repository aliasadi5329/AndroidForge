/* booking-api.js — لایه داده سامانه نوبت‌دهی روی Firebase (Firestore + Auth)
 * همه تصمیم‌های نهایی (ظرفیت، تکرار، مالکیت) در قوانین سمت سرور (server/firestore.rules) اجرا می‌شود.
 * این فایل فقط درخواست‌ها را می‌سازد و پیام‌های فارسی مناسب برمی‌گرداند.
 */
var BookingAPI = (function () {
  'use strict';
  var C = window.BookingCore;
  var DEFAULT_CONFIG = {
    maxActivePerPatientPerDay: 2,
    cancelDeadlineMinutes: 120,
    admissionLeadMinutes: 30,
    defaultCapacity: 10,
    bookingWindowDays: 60,
    hospitalName: 'بیمارستان تخصصی فاطمه‌الزهرا (س)',
    brandName: 'فراگیر سلامت',
    slogan: 'نبض زندگی در قلب کویر',
    showSlogan: true,
    defaultLocation: 'ساختمان درمانگاه، طبقه همکف',
    receptionPhone: '۰۳۴-۴۱۴۲۸۰۰۰'
  };
  // ثبت خدمات: برای فعال‌سازی یک خدمت در آینده، در config/services مقدار آن را true کنید و برای آن بازه زمانی بسازید.
  var SERVICES = [
    { id: 'clinic', title: 'درمانگاه', icon: '🩺', active: true },
    { id: 'sono', title: 'سونوگرافی', icon: '🫄', active: false },
    { id: 'imaging', title: 'تصویربرداری', icon: '🩻', active: false },
    { id: 'lab', title: 'آزمایشگاه', icon: '🧪', active: false },
    { id: 'physio', title: 'فیزیوتراپی', icon: '🦵', active: false },
    { id: 'health', title: 'ارتقای سلامت', icon: '💚', active: false }
  ];
  var TIMEOUT_MS = 15000;

  function BErr(code, message, extra) { var e = new Error(message); e.bcode = code; if (extra) e.extra = extra; return e; }
  function db() { if (!window.db || !window.firebase) throw BErr('offline', 'اتصال به سرور برقرار نیست. اینترنت خود را بررسی کنید و دوباره تلاش کنید.'); return window.db; }
  function ts() { return firebase.firestore.FieldValue.serverTimestamp(); }
  function inc(n) { return firebase.firestore.FieldValue.increment(n); }
  function withTimeout(p, ms) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { rej(BErr('timeout', 'پاسخی از سرور دریافت نشد. اتصال اینترنت را بررسی کنید.')); }, ms || TIMEOUT_MS);
      p.then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
    });
  }
  function friendly(err) {
    if (err && err.bcode) return err;
    var c = err && err.code;
    if (c === 'unavailable' || c === 'deadline-exceeded' || (typeof navigator !== 'undefined' && navigator.onLine === false))
      return BErr('offline', 'ارتباط با سرور برقرار نیست. اینترنت خود را بررسی کنید و دوباره تلاش کنید.');
    if (c === 'permission-denied') return BErr('denied', 'سرور این درخواست را نپذیرفت.');
    if (c === 'unauthenticated') return BErr('auth', 'نشست شما منقضی شده است. صفحه را دوباره باز کنید.');
    if (c === 'not-found') return BErr('notfound', 'اطلاعات مورد نظر پیدا نشد.');
    if (c === 'auth/operation-not-allowed' || c === 'auth/admin-restricted-operation')
      return BErr('auth-setup', 'ورود ناشناس در تنظیمات Firebase فعال نشده است (به راهنمای راه‌اندازی مراجعه کنید).');
    if (c === 'auth/network-request-failed') return BErr('offline', 'ارتباط با سرور برقرار نیست.');
    return BErr('unknown', 'خطای غیرمنتظره رخ داد. لطفاً دوباره تلاش کنید.');
  }

  // ---------- احراز هویت: حساب ناشناس پایدار برای هر نصب اپ ----------
  var userP = null;
  function ensureUser() {
    if (userP) return userP;
    userP = new Promise(function (resolve, reject) {
      if (!window.auth) return reject(BErr('offline', 'اتصال به سرویس برقرار نیست. اینترنت خود را بررسی کنید.'));
      var off = window.auth.onAuthStateChanged(function (u) {
        off();
        if (u) return resolve(u);
        window.auth.signInAnonymously().then(function (c) { resolve(c.user); }, function (e) { reject(friendly(e)); });
      }, function (e) { reject(friendly(e)); });
    });
    userP.catch(function () { userP = null; });
    return withTimeout(userP);
  }

  // ---------- تنظیمات و خدمات ----------
  var cfgCache = null;
  function getConfig() {
    if (cfgCache) return Promise.resolve(cfgCache);
    return withTimeout(db().collection('config').doc('booking').get()).then(function (s) {
      var c = Object.assign({}, DEFAULT_CONFIG, s.exists ? s.data() : {});
      c._exists = s.exists; cfgCache = c; return c;
    }).catch(function (e) { throw friendly(e); });
  }
  function getServices() {
    var list = SERVICES.map(function (s) { return Object.assign({}, s); });
    if (!window.db) return Promise.resolve(list);
    return withTimeout(db().collection('config').doc('services').get(), 8000).then(function (s) {
      var o = s.exists ? s.data() : {};
      list.forEach(function (x) { if (typeof o[x.id] === 'boolean') x.active = o[x.id]; });
      return list;
    }).catch(function () { return list; });
  }

  // ---------- پزشکان و بازه‌ها ----------
  function listDoctors() {
    return withTimeout(db().collection('doctors').where('active', '==', true).get()).then(function (snap) {
      var out = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; out.push(x); });
      out.sort(function (a, b) { return (a.order || 0) - (b.order || 0) || String(a.name).localeCompare(b.name, 'fa'); });
      return out;
    }).catch(function (e) { throw friendly(e); });
  }
  function mapSlots(snap) {
    var out = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; out.push(x); });
    out.sort(function (a, b) { return a.date < b.date ? -1 : a.date > b.date ? 1 : (a.start < b.start ? -1 : 1); });
    return out;
  }
  /** شنود لحظه‌ای بازه‌ها در یک بازه تاریخ (ظرفیت باقی‌مانده بلافاصله به‌روز می‌شود) */
  function watchSlots(fromIso, toIso, service, onData, onError) {
    try {
      return db().collection('timeSlots').where('date', '>=', fromIso).where('date', '<=', toIso)
        .onSnapshot({ includeMetadataChanges: false }, function (snap) {
          onData(mapSlots(snap).filter(function (s) { return s.service === service && s.active; }), snap.metadata.fromCache);
        }, function (e) { onError(friendly(e)); });
    } catch (e) { onError(friendly(e)); return function () {}; }
  }
  /** خواندن تازه از سرور (نه حافظه نهان) */
  function getSlotFresh(id) {
    return withTimeout(db().collection('timeSlots').doc(id).get({ source: 'server' })).then(function (s) {
      if (!s.exists) throw BErr('notfound', 'این بازه زمانی دیگر وجود ندارد.');
      var x = s.data(); x.id = s.id; return x;
    }).catch(function (e) { throw friendly(e); });
  }

  // ---------- پروفایل‌ها ----------
  function profilesCol(u) { return db().collection('users').doc(u.uid).collection('profiles'); }
  function listProfiles() {
    return ensureUser().then(function (u) { return withTimeout(profilesCol(u).get()); }).then(function (snap) {
      var out = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; out.push(x); });
      out.sort(function (a, b) { return (a.relation === 'self' ? 0 : 1) - (b.relation === 'self' ? 0 : 1) || (a.createdAt && b.createdAt ? a.createdAt.toMillis() - b.createdAt.toMillis() : 0); });
      return out;
    }).catch(function (e) { throw friendly(e); });
  }
  function saveProfile(input, id) {
    var v = C.validateProfile(input);
    if (!v.ok) return Promise.reject(BErr('invalid', 'اطلاعات فرم را اصلاح کنید.', v.errors));
    return ensureUser().then(function (u) {
      var col = profilesCol(u);
      var data = { fullName: v.value.fullName, nationalId: v.value.nationalId, fatherName: v.value.fatherName,
        mobile: v.value.mobile, relation: v.value.relation, updatedAt: ts() };
      return withTimeout(col.get()).then(function (snap) {
        var dup = null, selfOther = null;
        snap.forEach(function (d) {
          if (d.id !== id && d.data().nationalId === data.nationalId) dup = d;
          if (d.id !== id && d.data().relation === 'self') selfOther = d;
        });
        if (dup) throw BErr('dup-profile', 'پروفایلی با این کد ملی قبلاً در حساب شما ثبت شده است. همان را انتخاب یا ویرایش کنید.');
        if (data.relation === 'self' && selfOther) throw BErr('dup-self', 'پروفایل «خودم» قبلاً ثبت شده است. برای این فرد گزینه «فرد دیگر» را انتخاب کنید.');
        if (snap.size >= 10 && !id) throw BErr('limit', 'حداکثر ۱۰ پروفایل برای هر حساب قابل ثبت است.');
        var ref = id ? col.doc(id) : col.doc();
        if (!id) data.createdAt = ts();
        return withTimeout(id ? ref.update(data) : ref.set(data)).then(function () { data.id = ref.id; return data; });
      });
    }).catch(function (e) { throw friendly(e); });
  }
  function deleteProfile(id) {
    return ensureUser().then(function (u) { return withTimeout(profilesCol(u).doc(id).delete()); }).catch(function (e) { throw friendly(e); });
  }

  // ---------- رمزنگاری ----------
  function sha256hex(s) {
    var bytes = new TextEncoder().encode(s);
    return crypto.subtle.digest('SHA-256', bytes).then(function (buf) {
      return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    });
  }

  // ---------- نوبت‌ها ----------
  function getBooking(code) {
    return ensureUser().then(function () { return withTimeout(db().collection('bookings').doc(code).get({ source: 'server' })); })
      .then(function (s) { if (!s.exists) return null; var x = s.data(); x.id = s.id; return x; })
      .catch(function (e) { throw friendly(e); });
  }
  function myBookings() {
    return ensureUser().then(function (u) {
      return withTimeout(db().collection('bookings').where('uid', '==', u.uid).get({ source: 'server' }));
    }).then(function (snap) {
      var out = []; snap.forEach(function (d) { var x = d.data(); x.id = d.id; out.push(x); });
      out.sort(function (a, b) { return b.startAt.toMillis() - a.startAt.toMillis(); });
      return out;
    }).catch(function (e) { throw friendly(e); });
  }

  /**
   * ثبت نوبت — یک «نوشتن دسته‌ای اتمیک» (batch) شامل ۵ سند.
   * قوانین سرور همه را با هم می‌سنجند؛ یا همه ثبت می‌شوند یا هیچ‌کدام.
   * code (شماره پیگیری) پیش از اولین تلاش ساخته و برای تلاش‌های مجدد همان درخواست حفظ می‌شود ⇒ تکرارناپذیر.
   */
  function createBooking(opts) {
    var code = opts.code, slotId = opts.slotId, profileId = opts.profileId;
    var u, slot, prof, lockId, dayKey;
    return ensureUser().then(function (user) {
      u = user;
      // ۰) تکرارپذیری: اگر این شماره قبلاً با موفقیت ثبت شده، همان را برگردان
      return getBooking(code).catch(function (e) { if (e && e.bcode === 'denied') throw BErr('code-collision', 'retry'); throw e; });
    }).then(function (existing) {
      if (existing) {
        if (existing.slotId === slotId && existing.profileId === profileId) return { booking: existing, replay: true };
        throw BErr('code-collision', 'retry');
      }
      // ۱) خواندن تازه بازه و پروفایل از سرور
      return Promise.all([getSlotFresh(slotId), withTimeout(profilesCol(u).doc(profileId).get({ source: 'server' })), getConfig(), myBookings()])
        .then(function (r) {
          slot = r[0];
          if (!r[1].exists) throw BErr('noprofile', 'پروفایل بیمار پیدا نشد. دوباره انتخاب کنید.');
          prof = r[1].data();
          var cfg = r[2], mine = r[3];
          var v = C.validateProfile(prof);
          if (!v.ok) throw BErr('invalid', 'اطلاعات پروفایل بیمار ناقص یا نامعتبر است. آن را ویرایش کنید.');
          // ۲) بررسی‌های پیش از ارسال (برای پیام دقیق؛ حکم نهایی با سرور)
          var st = C.slotState(slot);
          if (st === 'full') throw BErr('full', 'ظرفیت این بازه زمانی تکمیل شده است. لطفاً زمان دیگری انتخاب کنید.');
          if (st === 'past') throw BErr('past', 'زمان این نوبت گذشته است. لطفاً زمان دیگری انتخاب کنید.');
          if (st !== 'open') throw BErr('inactive', 'این بازه زمانی در حال حاضر فعال نیست.');
          var active = mine.filter(function (b) { return (b.status === 'booked' || b.status === 'confirmed') && b.nationalId === prof.nationalId; });
          if (active.some(function (b) { return b.slotId === slotId; }))
            throw BErr('duplicate', 'برای این بیمار در همین بازه زمانی، نوبت فعال ثبت شده است.');
          if (active.filter(function (b) { return b.date === slot.date; }).length >= cfg.maxActivePerPatientPerDay)
            throw BErr('daylimit', 'سقف تعداد نوبت فعال این بیمار در این روز (' + C.toFa(cfg.maxActivePerPatientPerDay) + ' نوبت) تکمیل شده است.');
          return Promise.all([sha256hex(slotId + '|' + prof.nationalId), sha256hex(slot.date + '|' + prof.nationalId)]);
        });
    }).then(function (r) {
      if (r && r.booking) return r;
      lockId = r[0]; dayKey = r[1];
      var d = db(), b = d.batch();
      var booking = {
        uid: u.uid, profileId: profileId, patientName: prof.fullName, nationalId: prof.nationalId,
        fatherName: prof.fatherName || '', mobile: prof.mobile, relation: prof.relation,
        slotId: slotId, doctorId: slot.doctorId, doctorName: slot.doctorName, specialty: slot.specialty,
        service: slot.service, date: slot.date, start: slot.start, end: slot.end, startAt: slot.startAt, endAt: slot.endAt,
        location: slot.location, status: 'booked', lockId: lockId, dayKey: dayKey,
        requestId: opts.requestId, createdAt: ts(), source: 'android-app'
      };
      b.update(d.collection('timeSlots').doc(slotId), { booked: inc(1), lastBookingId: code });
      b.set(d.collection('bookings').doc(code), booking);
      b.set(d.collection('bookingLocks').doc(lockId), { bookingId: code, uid: u.uid, createdAt: ts() });
      b.set(d.collection('patientDays').doc(dayKey), { count: inc(1), lastBookingId: code }, { merge: true });
      b.set(d.collection('public_status').doc(code), { kind: 'clinic', status: 'booked', date: slot.date, start: slot.start, end: slot.end, createdAt: ts() });
      return withTimeout(b.commit(), 20000).then(function () { return getBooking(code); }).then(function (saved) {
        if (!saved) throw BErr('unknown', 'ثبت نوبت تأیید نشد. از «نوبت‌های من» وضعیت را بررسی کنید.');
        return { booking: saved, replay: false };
      }, function (e) {
        // پاسخ گم‌شده یا ارسال دوباره: اگر سند با همین شماره ثبت شده، موفق است
        return getBooking(code).catch(function () { return null; }).then(function (saved) {
          if (saved) return { booking: saved, replay: true };
          if (e && e.code === 'permission-denied') {
            // دلیل رد را با خواندن دوباره ظرفیت مشخص می‌کنیم
            return getSlotFresh(slotId).then(function (s2) {
              logEvent('booking_denied', slotId);
              var st = C.slotState(s2);
              if (st === 'full') throw BErr('full', 'متأسفانه در فاصله انتخاب تا تأیید، ظرفیت این بازه تکمیل شد. لطفاً زمان دیگری انتخاب کنید.');
              if (st === 'past') throw BErr('past', 'زمان این نوبت گذشته است.');
              throw BErr('denied', 'ثبت نوبت پذیرفته نشد. ممکن است برای این بیمار در این بازه یا این روز نوبت فعال وجود داشته باشد (از حساب یا دستگاه دیگر).');
            });
          }
          throw friendly(e);
        });
      });
    }).catch(function (e) { throw friendly(e); });
  }

  /** لغو نوبت توسط بیمار — اتمیک: وضعیت + آزادسازی ظرفیت + آزادسازی قفل + شمارنده روزانه */
  function cancelBooking(code, by) {
    return Promise.all([getBooking(code), getConfig()]).then(function (r) {
      var bk = r[0], cfg = r[1];
      if (!bk) throw BErr('notfound', 'نوبت پیدا نشد.');
      if (by !== 'admin') {
        var cc = C.canCancel(bk, cfg.cancelDeadlineMinutes);
        if (!cc.ok) throw BErr('deadline', cc.reason);
      }
      var d = db(), b = d.batch();
      b.update(d.collection('bookings').doc(code), { status: 'cancelled', cancelledAt: ts(), cancelledBy: by === 'admin' ? 'admin' : 'patient' });
      b.update(d.collection('timeSlots').doc(bk.slotId), { booked: inc(-1), lastCancelId: code });
      b.delete(d.collection('bookingLocks').doc(bk.lockId));
      b.set(d.collection('patientDays').doc(bk.dayKey), { count: inc(-1), lastCancelId: code }, { merge: true });
      b.update(d.collection('public_status').doc(code), { status: 'cancelled' });
      return withTimeout(b.commit(), 20000).then(function () { return getBooking(code); });
    }).catch(function (e) {
      if (e && e.code === 'permission-denied') return Promise.reject(BErr('denied', 'لغو این نوبت مجاز نیست (ممکن است مهلت لغو گذشته باشد یا وضعیت نوبت تغییر کرده باشد).'));
      return Promise.reject(friendly(e));
    });
  }

  /** ثبت رخداد امنیتی بدون اطلاعات شخصی (فقط نوع رخداد و شناسه فنی) */
  function logEvent(type, ref) {
    try {
      if (!window.db || !window.auth || !window.auth.currentUser) return;
      db().collection('securityEvents').add({ type: String(type).slice(0, 40), uid: window.auth.currentUser.uid, at: ts(), ref: String(ref || '').slice(0, 40), app: '1.5' })
        .catch(function () {});
    } catch (e) {}
  }

  return {
    SERVICES: SERVICES, DEFAULT_CONFIG: DEFAULT_CONFIG, BErr: BErr, friendly: friendly,
    ensureUser: ensureUser, getConfig: getConfig, getServices: getServices,
    listDoctors: listDoctors, watchSlots: watchSlots, getSlotFresh: getSlotFresh,
    listProfiles: listProfiles, saveProfile: saveProfile, deleteProfile: deleteProfile,
    getBooking: getBooking, myBookings: myBookings, createBooking: createBooking, cancelBooking: cancelBooking,
    logEvent: logEvent, sha256hex: sha256hex
  };
})();
