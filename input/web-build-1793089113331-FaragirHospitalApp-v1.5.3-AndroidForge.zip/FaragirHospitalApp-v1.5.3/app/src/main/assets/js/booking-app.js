/* booking-app.js — جریان کاری نوبت‌دهی (مسیریابی hash، صفحه‌ها، رویدادها) */
(function () {
  'use strict';
  var C = window.BookingCore, API = window.BookingAPI, RC = window.BookingReceipt;
  var root = document.getElementById('bkApp');
  var S = { cfg: null, doctors: null, doctorMap: {}, slots: [], slotsErr: null, slotsLoaded: false, unsub: null,
    pageStart: 0, selDate: null, q: '', spec: '', onlyFree: false, submitting: false };
  var PAGE = 14;

  // ---------- ابزارها ----------
  function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }
  function $(sel) { return root.querySelector(sel); }
  function ss(k, v) { try { if (v === undefined) return JSON.parse(sessionStorage.getItem('bk.' + k) || 'null'); if (v === null) sessionStorage.removeItem('bk.' + k); else sessionStorage.setItem('bk.' + k, JSON.stringify(v)); } catch (e) { return null; } }
  function go(h, replace) { if (replace) location.replace(h); else location.hash = h; }
  function toast(t) { var el = document.createElement('div'); el.className = 'bk-toast'; el.textContent = t; document.body.appendChild(el); setTimeout(function () { el.remove(); }, 3200); }
  function capClass(n) { return n <= 0 ? 'full' : n <= 3 ? 'low' : 'ok'; }
  function capText(n) { return n <= 0 ? 'ظرفیت تکمیل شده است' : 'ظرفیت باقی‌مانده: ' + C.toFa(n) + ' نفر'; }
  function hero(title, sub, back, step) {
    var steps = step ? '<div class="bk-steps">' + [1, 2, 3, 4].map(function (i) { return '<span class="' + (i <= step ? 'on' : '') + '"></span>'; }).join('') + '</div>' : '';
    return '<div class="bk-net" id="bkNet">اتصال اینترنت برقرار نیست</div><div class="bk-hero"><div class="bk-hero-row">' +
      (back ? '<button class="bk-back" data-back="' + esc(back) + '" aria-label="بازگشت">→</button>' : '') +
      '<div><h2>' + esc(title) + '</h2>' + (sub ? '<p>' + esc(sub) + '</p>' : '') + '</div></div>' + steps + '</div>';
  }
  function errBox(e, retry) {
    return '<div class="bk-alert err">' + esc(e.message || e) + (retry ? '<br><button class="bk-btn outline" data-retry>تلاش دوباره</button>' : '') + '</div>';
  }
  function skel(n) { var s = ''; for (var i = 0; i < (n || 3); i++) s += '<div class="bk-skel"></div>'; return s; }
  function updateNet() { var n = document.getElementById('bkNet'); if (n) n.classList.toggle('show', navigator.onLine === false); }
  window.addEventListener('online', updateNet); window.addEventListener('offline', updateNet);
  function cfg() { return S.cfg || API.DEFAULT_CONFIG; }
  function loadCfg() { return API.getConfig().then(function (c) { S.cfg = c; return c; }); }
  function slotById(id) { for (var i = 0; i < S.slots.length; i++) if (S.slots[i].id === id) return S.slots[i]; return null; }
  function avatar(doc) {
    var url = doc && doc.photoUrl && /^https:\/\//.test(doc.photoUrl) ? doc.photoUrl : null;
    return '<div class="bk-avatar">' + (url ? '<img src="' + esc(url) + '" alt="" loading="lazy" onerror="this.remove()">' : '') + (url ? '' : esc(C.initials(doc.name || doc.doctorName || ''))) + '</div>';
  }

  // ---------- شنود بازه‌ها ----------
  function startSlots() {
    if (S.unsub) return;
    var from = C.todayIso(), to = C.addDaysIso(from, (cfg().bookingWindowDays || 60) - 1);
    S.unsub = API.watchSlots(from, to, 'clinic', function (list) {
      S.slots = list; S.slotsLoaded = true; S.slotsErr = null; rerenderLive();
    }, function (e) { S.slotsErr = e; S.slotsLoaded = true; rerenderLive(); });
  }
  function stopSlots() { if (S.unsub) { S.unsub(); S.unsub = null; S.slotsLoaded = false; } }
  var liveRenderer = null;
  function rerenderLive() { if (liveRenderer) liveRenderer(); }

  // ---------- ۱) صفحه اصلی خدمات ----------
  function viewHome() {
    root.innerHTML = hero('نوبت‌دهی اینترنتی', 'خدمت مورد نظر خود را انتخاب کنید.') +
      '<div class="bk-services" id="svc">' + skel(2) + '</div>' +
      '<div class="bk-quick"><a href="#/mine">📋 نوبت‌های من</a><a href="track.html">🔎 پیگیری با شماره</a></div>';
    API.getServices().then(function (list) {
      $('#svc').innerHTML = list.map(function (s) {
        return '<button class="bk-service ' + (s.active ? 'active' : 'soon') + '" ' + (s.active ? 'data-svc="' + s.id + '"' : 'aria-disabled="true" data-soon="' + esc(s.title) + '"') + '>' +
          (s.active ? '<span class="bk-badge-on">فعال</span>' : '<span class="bk-badge-soon">به‌زودی</span>') +
          '<span class="ic">' + s.icon + '</span><span class="nm">' + esc(s.title) + '</span></button>';
      }).join('');
    });
  }

  // ---------- ۲) درمانگاه: جست‌وجو، تاریخ‌ها، پزشکان ----------
  function viewClinic() {
    root.innerHTML = hero('درمانگاه', 'روز مورد نظر خود را انتخاب کنید و نوبت را برگزینید.', '#/', 1) +
      '<div class="bk-search"><div class="box"><span class="mag">🔍</span><input id="q" type="search" placeholder="پزشک، تخصص، تجهیز یا خدمت" value="' + esc(S.q) + '" autocomplete="off"></div>' +
      '<button class="bk-filter-btn" id="fbtn" aria-label="فیلتر">⚙︎</button></div><div class="bk-chips-active" id="fchips"></div>' +
      '<div class="bk-dates-head"><b>تاریخ‌های دارای نوبت</b><div class="bk-pager"><button id="pprev" aria-label="قبلی">›</button><button id="pnext" aria-label="بعدی">‹</button></div></div>' +
      '<div class="bk-dates" id="dates"></div><div id="docs">' + skel(3) + '</div>';
    var q = $('#q'), t = null;
    q.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { S.q = q.value; renderDocs(); }, 150); });
    Promise.all([loadCfg(), S.doctors ? Promise.resolve(S.doctors) : API.listDoctors()]).then(function (r) {
      S.doctors = r[1]; S.doctorMap = {}; r[1].forEach(function (d) { S.doctorMap[d.id] = d; });
      startSlots(); liveRenderer = function () { renderDates(); renderDocs(); }; rerenderLive();
    }).catch(function (e) { $('#docs').innerHTML = errBox(e, true); });
    updateNet();
  }
  function doctorFor(s) { return S.doctorMap[s.doctorId] || { id: s.doctorId, name: s.doctorName, specialty: s.specialty }; }
  function visibleSlots() {
    var docs = C.filterDoctors(S.doctors || [], S.q, S.spec), ids = {};
    docs.forEach(function (d) { ids[d.id] = 1; });
    return S.slots.filter(function (s) { return ids[s.doctorId] && C.slotState(s) !== 'past' && (!S.onlyFree || C.remaining(s) > 0); });
  }
  function renderDates() {
    var el = $('#dates'); if (!el) return;
    var today = C.todayIso(), total = cfg().bookingWindowDays || 60, vis = visibleSlots(), byDate = {};
    vis.forEach(function (s) { var x = byDate[s.date] || (byDate[s.date] = { n: 0, free: 0 }); x.n++; x.free += C.remaining(s); });
    // اولین تاریخ دارای نوبت به‌صورت پیش‌فرض انتخاب می‌شود
    if (!S.selDate || !byDate[S.selDate]) {
      var keys = Object.keys(byDate).sort(); S.selDate = keys.length ? keys[0] : null;
      if (S.selDate) S.pageStart = Math.floor((daysBetween(today, S.selDate)) / PAGE) * PAGE;
    }
    var html = '';
    for (var i = S.pageStart; i < Math.min(S.pageStart + PAGE, total); i++) {
      var iso = C.addDaysIso(today, i), info = byDate[iso], c = C.dayChip(iso);
      html += '<button class="bk-date' + (iso === S.selDate ? ' sel' : '') + '" data-date="' + iso + '"' + (info ? '' : ' disabled') +
        ' aria-label="' + esc(C.formatJalaliLong(iso)) + '"><div class="wd">' + c.weekday + '</div><div class="dd">' + c.day + '</div><div class="mm">' + c.month + '</div>' +
        '<div class="cnt">' + (info ? (info.free > 0 ? C.toFa(info.free) + ' خالی' : 'تکمیل') : 'بدون نوبت') + '</div></button>';
    }
    el.innerHTML = html;
    $('#pprev').disabled = S.pageStart <= 0; $('#pnext').disabled = S.pageStart + PAGE >= total;
    var sel = el.querySelector('.sel'); if (sel && sel.scrollIntoView) sel.scrollIntoView({ inline: 'center', block: 'nearest' });
    var chips = '';
    if (S.spec) chips += '<button class="bk-chip" data-clear="spec">' + esc(S.spec) + ' ✕</button>';
    if (S.onlyFree) chips += '<button class="bk-chip" data-clear="free">فقط دارای ظرفیت ✕</button>';
    $('#fchips').innerHTML = chips; $('#fbtn').classList.toggle('on', !!(S.spec || S.onlyFree));
  }
  function daysBetween(a, b) { var A = C.parseIso(a), B = C.parseIso(b); return Math.round((Date.UTC(B.y, B.m - 1, B.d) - Date.UTC(A.y, A.m - 1, A.d)) / 864e5); }
  function renderDocs() {
    var el = $('#docs'); if (!el) return;
    if (S.slotsErr) { el.innerHTML = errBox(S.slotsErr, true); return; }
    if (!S.slotsLoaded || !S.doctors) { el.innerHTML = skel(3); return; }
    if (!S.doctors.length || !S.slots.length) { el.innerHTML = '<div class="bk-empty"><div class="e">🗓️</div>در حال حاضر برنامه نوبت‌دهی فعالی برای درمانگاه ثبت نشده است.<br>لطفاً بعداً دوباره سر بزنید یا با تلفن ' + esc(cfg().receptionPhone) + ' تماس بگیرید.</div>'; return; }
    var vis = visibleSlots();
    if (!S.selDate) {
      el.innerHTML = '<div class="bk-empty"><div class="e">🔍</div>' + (S.q || S.spec || S.onlyFree ? 'نتیجه‌ای با این جست‌وجو یا فیلتر پیدا نشد.' : 'نوبت خالی در روزهای آینده وجود ندارد.') + '</div>'; return;
    }
    var groups = {}, order = [];
    vis.filter(function (s) { return s.date === S.selDate; }).forEach(function (s) { if (!groups[s.doctorId]) { groups[s.doctorId] = []; order.push(s.doctorId); } groups[s.doctorId].push(s); });
    var html = '<div class="bk-selected-date">📅 ' + esc(C.formatJalaliLong(S.selDate)) + '</div>';
    order.forEach(function (did) {
      var list = groups[did], d = doctorFor(list[0]);
      var free = list.reduce(function (a, s) { return a + C.remaining(s); }, 0);
      var time = list.length === 1 ? C.faTime(list[0].start) + ' تا ' + C.faTime(list[0].end)
        : C.faTime(list[0].start) + ' تا ' + C.faTime(list[list.length - 1].end) + ' (' + C.toFa(list.length) + ' بازه)';
      html += '<div class="bk-card"><div class="bk-doc">' + avatar(d) + '<div class="bk-doc-info"><h3>' + esc(d.name) + '</h3><div class="sp">' + esc(d.specialty) + '</div>' +
        '<div class="bk-meta"><div><span class="k">روز و تاریخ:</span><b>' + esc(C.formatJalaliLong(S.selDate)) + '</b></div>' +
        '<div><span class="k">ساعت:</span><b>' + time + '</b></div>' +
        '<div><span class="k">ظرفیت:</span><b class="bk-cap ' + capClass(free) + '">' + capText(free) + '</b></div></div></div></div>' +
        '<div class="bk-doc-actions"><button class="bk-btn ' + (free > 0 ? 'primary' : 'outline') + ' block" data-times="' + esc(did) + '">مشاهده زمان‌ها</button></div></div>';
    });
    if (!order.length) {
      // شاید پزشک جست‌وجوشده در روز دیگری نوبت داشته باشد
      var other = vis[0];
      html += '<div class="bk-empty">برای این روز نتیجه‌ای نیست.' + (other ? '<br><button class="bk-btn ghost" data-date="' + other.date + '" style="margin-top:10px">نزدیک‌ترین نوبت: ' + esc(C.formatJalaliLong(other.date)) + '</button>' : '') + '</div>';
    }
    el.innerHTML = html;
  }
  function openFilter() {
    var specs = {}; (S.doctors || []).forEach(function (d) { specs[d.specialty] = 1; });
    var bg = document.createElement('div'); bg.className = 'bk-sheet-bg';
    bg.innerHTML = '<div class="bk-sheet" role="dialog" aria-label="فیلتر"><div class="grip"></div><h3>فیلتر پزشکان</h3><b style="font-size:.9rem">تخصص</b><div class="bk-opt-list" style="margin-top:8px">' +
      '<button class="bk-opt' + (!S.spec ? ' on' : '') + '" data-spec="">همه تخصص‌ها</button>' +
      Object.keys(specs).sort(function (a, b) { return a.localeCompare(b, 'fa'); }).map(function (s) { return '<button class="bk-opt' + (S.spec === s ? ' on' : '') + '" data-spec="' + esc(s) + '">' + esc(s) + '</button>'; }).join('') +
      '</div><label class="bk-switch">فقط پزشکانی که ظرفیت خالی دارند<input type="checkbox" id="fFree"' + (S.onlyFree ? ' checked' : '') + '></label>' +
      '<div class="bk-btn-row" style="margin-top:8px"><button class="bk-btn primary" id="fApply">اعمال فیلتر</button><button class="bk-btn outline" id="fReset">حذف فیلترها</button></div></div>';
    document.body.appendChild(bg);
    var spec = S.spec;
    bg.addEventListener('click', function (e) {
      if (e.target === bg) bg.remove();
      var o = e.target.closest('[data-spec]'); if (o) { spec = o.dataset.spec; bg.querySelectorAll('.bk-opt').forEach(function (x) { x.classList.toggle('on', x === o); }); }
      if (e.target.id === 'fApply') { S.spec = spec; S.onlyFree = bg.querySelector('#fFree').checked; S.selDate = null; bg.remove(); rerenderLive(); }
      if (e.target.id === 'fReset') { S.spec = ''; S.onlyFree = false; S.selDate = null; bg.remove(); rerenderLive(); }
    });
  }

  // ---------- ۳) زمان‌های یک پزشک در یک روز ----------
  function viewTimes(did, date) {
    root.innerHTML = hero('انتخاب زمان نوبت', C.formatJalaliLong(date), '#/clinic', 2) + '<div id="tm">' + skel(2) + '</div>';
    Promise.all([loadCfg(), S.doctors ? Promise.resolve(S.doctors) : API.listDoctors()]).then(function (r) {
      S.doctors = r[1]; S.doctorMap = {}; r[1].forEach(function (d) { S.doctorMap[d.id] = d; });
      startSlots();
      liveRenderer = function () {
        var el = $('#tm'); if (!el) return;
        if (S.slotsErr) { el.innerHTML = errBox(S.slotsErr, true); return; }
        if (!S.slotsLoaded) return;
        var list = S.slots.filter(function (s) { return s.doctorId === did && s.date === date; });
        var d = S.doctorMap[did] || (list[0] ? doctorFor(list[0]) : null);
        if (!d || !list.length) { el.innerHTML = '<div class="bk-empty"><div class="e">🗓️</div>برای این پزشک در این روز زمان نوبتی وجود ندارد.<br><a class="bk-btn outline" href="#/clinic" style="margin-top:10px">بازگشت به فهرست پزشکان</a></div>'; return; }
        var html = '<div class="bk-card"><div class="bk-doc">' + avatar(d) + '<div class="bk-doc-info"><h3>' + esc(d.name) + '</h3><div class="sp">' + esc(d.specialty) + '</div></div></div></div><div class="bk-title">زمان‌های قابل انتخاب</div>';
        list.forEach(function (s) {
          var st = C.slotState(s), rem = C.remaining(s), pct = s.capacity ? Math.round((s.booked / s.capacity) * 100) : 100;
          html += '<div class="bk-card bk-slot' + (st !== 'open' ? ' full' : '') + '"><div style="flex:1"><div class="t">از ساعت ' + C.faTime(s.start) + ' تا ' + C.faTime(s.end) + '</div>' +
            '<div class="d">' + esc(C.formatJalaliLong(s.date)) + '</div><div class="bk-cap ' + capClass(rem) + '" style="margin-top:6px;font-size:.88rem">ظرفیت باقی‌مانده: ' + C.toFa(rem) + ' نفر</div>' +
            '<div class="bk-bar"><i style="width:' + pct + '%"></i></div></div>' +
            (st === 'open' ? '<button class="bk-btn primary" data-pick="' + esc(s.id) + '">انتخاب</button>'
              : st === 'full' ? '<span class="bk-full-tag">ظرفیت تکمیل شده است</span>' : '<span class="bk-past-tag">' + (st === 'past' ? 'گذشته' : 'غیرفعال') + '</span>') + '</div>';
        });
        el.innerHTML = html;
      };
      rerenderLive();
    }).catch(function (e) { $('#tm').innerHTML = errBox(e, true); });
  }

  // ---------- ۴) انتخاب پروفایل بیمار ----------
  function selSummary() {
    var sel = ss('sel'); if (!sel) return '';
    return '<div class="bk-alert info">نوبت انتخابی: <b>' + esc(sel.doctorName) + '</b> — ' + esc(C.formatJalaliLong(sel.date)) + '، ساعت ' + C.faTime(sel.start) + ' تا ' + C.faTime(sel.end) + '</div>';
  }
  function viewPatient() {
    if (!ss('sel')) return go('#/clinic', true);
    root.innerHTML = hero('انتخاب بیمار', 'نوبت برای چه کسی ثبت شود؟', '#/times/' + ss('sel').doctorId + '/' + ss('sel').date, 3) + selSummary() + '<div id="pl">' + skel(2) + '</div>';
    API.listProfiles().then(function (list) {
      if (!list.length) return go('#/patient/new', true);
      var cur = ss('profileId');
      $('#pl').innerHTML = list.map(function (p) {
        return '<div class="bk-card bk-profile' + (p.id === cur ? ' sel' : '') + '"><div class="pi">' + (p.relation === 'self' ? '🙂' : '👤') + '</div>' +
          '<div class="pinfo"><b>' + esc(p.fullName) + (p.relation === 'self' ? '<span class="bk-tag-self">خودم</span>' : '<span class="bk-tag-other">فرد دیگر</span>') + '</b>' +
          '<small>کد ملی: ' + C.maskNationalId(p.nationalId) + '</small></div>' +
          '<button class="bk-icon-btn" data-edit="' + esc(p.id) + '" aria-label="ویرایش">✎</button>' +
          '<button class="bk-btn primary" data-choose="' + esc(p.id) + '">انتخاب</button></div>';
      }).join('') + '<button class="bk-add" data-add>＋ افزودن فرد دیگر</button>';
    }).catch(function (e) { $('#pl').innerHTML = errBox(e, true); });
  }

  // ---------- ۵) فرم اطلاعات بیمار ----------
  function viewProfileForm(id, back) {
    var flowBack = back || (ss('sel') ? '#/patient' : '#/mine');
    root.innerHTML = hero(id ? 'ویرایش اطلاعات بیمار' : 'ثبت اطلاعات بیمار', 'فیلدهای ستاره‌دار الزامی هستند.', flowBack, ss('sel') ? 3 : 0) + selSummary() +
      '<div class="bk-card"><form id="pf" novalidate>' +
      '<div class="bk-field"><label>این پروفایل برای</label><div class="bk-seg"><label><input type="radio" name="relation" value="self"><span>خودم</span></label><label><input type="radio" name="relation" value="other"><span>فرد دیگر</span></label></div></div>' +
      field('fullName', 'نام و نام خانوادگی', true, 'text', 'مثال: علی احمدی', 'name') +
      field('nationalId', 'کد ملی', true, 'tel', '۱۰ رقم بدون خط تیره', 'off', 'numeric', 10) +
      field('fatherName', 'نام پدر', false, 'text', '', 'off') +
      field('mobile', 'شماره تلفن همراه', true, 'tel', '۰۹۱۲۳۴۵۶۷۸۹', 'tel', 'numeric', 13) +
      '<div class="bk-alert info" style="font-size:.8rem">🔒 اطلاعات بیمار فقط در حساب همین اپ ذخیره می‌شود و برای سایر کاربران قابل مشاهده نیست. کد ملی در فهرست‌ها و رسید به‌صورت پوشیده نمایش داده می‌شود.</div>' +
      '<div id="pfMsg"></div><button class="bk-btn primary block" id="pfSave" type="submit">' + (ss('sel') ? 'ذخیره و ادامه' : 'ذخیره اطلاعات') + '</button>' +
      (id ? '<button class="bk-btn danger block" type="button" id="pfDel" style="margin-top:10px">حذف این پروفایل</button>' : '') + '</form></div>';
    var form = $('#pf');
    function setRel(v) { form.querySelectorAll('input[name=relation]').forEach(function (r) { r.checked = r.value === v; }); }
    API.listProfiles().then(function (list) {
      var p = id ? list.filter(function (x) { return x.id === id; })[0] : null;
      var hasSelf = list.some(function (x) { return x.relation === 'self' && x.id !== id; });
      if (id && !p) { $('#pfMsg').innerHTML = errBox({ message: 'این پروفایل پیدا نشد.' }); return; }
      if (p) { ['fullName', 'nationalId', 'fatherName', 'mobile'].forEach(function (k) { form[k].value = k === 'nationalId' || k === 'mobile' ? C.toFa(p[k] || '') : (p[k] || ''); }); setRel(p.relation); }
      else setRel(hasSelf || list.length ? 'other' : 'self');
      if (hasSelf) { var s = form.querySelector('input[value=self]'); s.disabled = true; s.parentNode.style.opacity = .45; s.parentNode.title = 'پروفایل «خودم» قبلاً ثبت شده است'; }
    }).catch(function (e) { $('#pfMsg').innerHTML = errBox(e); setRel('self'); });
    form.addEventListener('input', function (e) { var f = e.target.closest('.bk-field'); if (f) f.classList.remove('err'); });
    form.addEventListener('focusout', function (e) {
      var n = e.target.name; if (!n || n === 'relation') return;
      var v = C.validateProfile(read()); var f = form.querySelector('[data-f=' + n + ']');
      if (e.target.value && v.errors[n]) { f.classList.add('err'); f.querySelector('.msg').textContent = v.errors[n]; }
    });
    function read() { var r = form.querySelector('input[name=relation]:checked'); return { fullName: form.fullName.value, nationalId: form.nationalId.value, fatherName: form.fatherName.value, mobile: form.mobile.value, relation: r ? r.value : 'other' }; }
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var v = C.validateProfile(read());
      form.querySelectorAll('.bk-field').forEach(function (f) { f.classList.remove('err'); });
      if (!v.ok) {
        Object.keys(v.errors).forEach(function (k) { var f = form.querySelector('[data-f=' + k + ']'); if (f) { f.classList.add('err'); f.querySelector('.msg').textContent = v.errors[k]; } });
        var first = form.querySelector('.bk-field.err input'); if (first) first.focus();
        $('#pfMsg').innerHTML = '<div class="bk-alert err">لطفاً خطاهای فرم را اصلاح کنید.</div>'; return;
      }
      var btn = $('#pfSave'); btn.disabled = true; btn.innerHTML = '<span class="bk-spinner"></span> در حال ذخیره...';
      API.saveProfile(v.value, id).then(function (saved) {
        toast('اطلاعات بیمار ذخیره شد');
        if (ss('sel')) { ss('profileId', saved.id); ss('pending', null); go('#/confirm', true); }
        else go('#/mine', true);
      }).catch(function (err) {
        if (err.extra) Object.keys(err.extra).forEach(function (k) { var f = form.querySelector('[data-f=' + k + ']'); if (f) { f.classList.add('err'); f.querySelector('.msg').textContent = err.extra[k]; } });
        $('#pfMsg').innerHTML = errBox(err);
      }).then(function () { btn.disabled = false; btn.textContent = ss('sel') ? 'ذخیره و ادامه' : 'ذخیره اطلاعات'; });
    });
    var del = $('#pfDel');
    if (del) del.addEventListener('click', function () {
      confirmSheet('حذف پروفایل', 'این پروفایل از حساب شما حذف شود؟ نوبت‌های ثبت‌شده قبلی حذف نمی‌شوند.', 'حذف', function () {
        return API.deleteProfile(id).then(function () { if (ss('profileId') === id) ss('profileId', null); toast('پروفایل حذف شد'); go(ss('sel') ? '#/patient' : '#/', true); });
      });
    });
  }
  function field(name, label, req, type, ph, ac, im, max) {
    return '<div class="bk-field" data-f="' + name + '"><label for="f_' + name + '">' + label + ' ' + (req ? '<span class="req">*</span>' : '<span class="opt">(اختیاری)</span>') + '</label>' +
      '<input id="f_' + name + '" name="' + name + '" type="' + type + '" placeholder="' + esc(ph) + '" autocomplete="' + ac + '"' + (im ? ' inputmode="' + im + '" class="bk-ltr"' : '') + (max ? ' maxlength="' + max + '"' : ' maxlength="60"') + '>' +
      '<div class="msg"></div></div>';
  }

  // ---------- ۶) تأیید نهایی ----------
  function viewConfirm() {
    var sel = ss('sel'), pid = ss('profileId');
    if (!sel) return go('#/clinic', true);
    if (!pid) return go('#/patient', true);
    root.innerHTML = hero('تأیید نهایی', 'اطلاعات را بررسی و سپس نوبت را ثبت کنید.', '#/patient', 4) + '<div id="cf">' + skel(2) + '</div>';
    Promise.all([loadCfg(), API.getSlotFresh(sel.slotId), API.listProfiles()]).then(function (r) {
      var c = r[0], slot = r[1], prof = r[2].filter(function (p) { return p.id === pid; })[0];
      if (!prof) { ss('profileId', null); return go('#/patient', true); }
      var st = C.slotState(slot), rem = C.remaining(slot), w = C.admissionWindow(slot.start, slot.end, c.admissionLeadMinutes);
      var warn = st === 'full' ? '<div class="bk-alert err">ظرفیت این بازه تکمیل شده است. لطفاً زمان دیگری انتخاب کنید.<br><a class="bk-btn outline" href="#/times/' + esc(slot.doctorId) + '/' + slot.date + '">انتخاب زمان دیگر</a></div>'
        : st !== 'open' ? '<div class="bk-alert err">این بازه زمانی دیگر قابل رزرو نیست.<br><a class="bk-btn outline" href="#/clinic">انتخاب زمان دیگر</a></div>' : '';
      if (!c._exists) warn += '<div class="bk-alert warn">تنظیمات سامانه هنوز توسط مدیر ثبت نشده است؛ ثبت نوبت تا تکمیل تنظیمات ممکن است انجام نشود.</div>';
      $('#cf').innerHTML = warn + '<div class="bk-card"><div class="bk-sum">' +
        sumRow('نام بیمار', prof.fullName + (prof.relation === 'self' ? ' (خودم)' : '')) + sumRow('کد ملی', C.maskNationalId(prof.nationalId)) +
        sumRow('تلفن همراه', C.maskMobile(prof.mobile)) + sumRow('پزشک', slot.doctorName) + sumRow('تخصص', slot.specialty) +
        sumRow('تاریخ نوبت', C.formatJalaliLong(slot.date)) + sumRow('ساعت نوبت', 'از ' + C.faTime(slot.start) + ' تا ' + C.faTime(slot.end)) +
        sumRow('بازه تقریبی پذیرش', 'از ' + C.faTime(w.from) + ' تا ' + C.faTime(w.to)) + sumRow('محل مراجعه', slot.location || c.defaultLocation) +
        '<div><span>ظرفیت باقی‌مانده</span><b class="bk-cap ' + capClass(rem) + '">' + C.toFa(rem) + ' نفر</b></div></div></div>' +
        '<div class="bk-alert info" style="font-size:.84rem">📌 اطلاعات ضروری پذیرش: همراه داشتن کارت شناسایی معتبر (کارت ملی) الزامی است. لطفاً در بازه پذیرش اعلام‌شده به ' + esc(slot.location || c.defaultLocation) + ' مراجعه کنید.</div>' +
        '<div id="cfMsg"></div><button class="bk-btn primary block" id="cfGo"' + (st !== 'open' ? ' disabled' : '') + '>تأیید و ثبت نوبت</button>' +
        '<div class="bk-btn-row" style="margin-top:10px"><a class="bk-btn outline" href="#/patient/edit/' + esc(prof.id) + '/confirm">ویرایش اطلاعات بیمار</a><a class="bk-btn outline" href="#/patient">تغییر بیمار</a></div>';
      $('#cfGo').addEventListener('click', function () { submit(slot, prof); });
    }).catch(function (e) { $('#cf').innerHTML = errBox(e, true); });
  }
  function sumRow(k, v) { return '<div><span>' + esc(k) + '</span><b>' + esc(v) + '</b></div>'; }
  function submit(slot, prof) {
    if (S.submitting) return; // جلوگیری از چندبار فشردن
    S.submitting = true;
    var btn = $('#cfGo'); btn.disabled = true; btn.innerHTML = '<span class="bk-spinner"></span> در حال ثبت نوبت...';
    $('#cfMsg').innerHTML = '';
    // شناسه یکتای درخواست: برای تلاش‌های مجدد همین انتخاب ثابت می‌ماند ⇒ ارسال تکراری نوبت دوم نمی‌سازد
    var p = ss('pending');
    if (!p || p.slotId !== slot.id || p.profileId !== prof.id) { p = { code: C.randomCode(10), requestId: C.randomCode(16) + Date.now().toString(36), slotId: slot.id, profileId: prof.id }; ss('pending', p); }
    function attempt(tries) {
      return API.createBooking({ code: p.code, requestId: p.requestId, slotId: slot.id, profileId: prof.id }).catch(function (e) {
        if (e.bcode === 'code-collision' && tries < 3) { p.code = C.randomCode(10); ss('pending', p); return attempt(tries + 1); }
        throw e;
      });
    }
    attempt(0).then(function (res) {
      ss('pending', null); ss('sel', null); ss('lastCode', res.booking.id);
      go('#/receipt/' + res.booking.id + '/new', true);
    }).catch(function (e) {
      var back = (e.bcode === 'full' || e.bcode === 'past' || e.bcode === 'inactive' || e.bcode === 'notfound');
      if (back || e.bcode === 'duplicate' || e.bcode === 'daylimit' || e.bcode === 'denied') ss('pending', null);
      $('#cfMsg').innerHTML = '<div class="bk-alert err">' + esc(e.message) +
        (back ? '<br><a class="bk-btn outline" href="#/times/' + esc(slot.doctorId) + '/' + slot.date + '">انتخاب زمان دیگر</a>' : '') +
        (e.bcode === 'offline' || e.bcode === 'timeout' ? '<br>با تلاش دوباره، همان درخواست ارسال می‌شود و نوبت تکراری ثبت نخواهد شد.' : '') + '</div>';
      btn.disabled = back; btn.textContent = 'تأیید و ثبت نوبت';
    }).then(function () { S.submitting = false; });
  }

  // ---------- ۷) رسید و جزئیات نوبت ----------
  function viewReceipt(code, isNew) {
    root.innerHTML = hero(isNew ? 'ثبت موفق نوبت' : 'جزئیات نوبت', null, isNew ? '#/' : '#/mine') + '<div id="rc">' + skel(3) + '</div>';
    if (!C.isTrackingCode(code)) { $('#rc').innerHTML = errBox({ message: 'شماره پیگیری نامعتبر است.' }); return; }
    Promise.all([loadCfg(), API.getBooking(code)]).then(function (r) {
      var c = r[0], b = r[1];
      if (!b) { $('#rc').innerHTML = '<div class="bk-empty"><div class="e">🔎</div>نوبتی با این شماره در حساب شما پیدا نشد.<br><a href="track.html" class="bk-btn outline" style="margin-top:10px">پیگیری عمومی با شماره</a></div>'; return; }
      var st = C.displayStatus(b), cc = C.canCancel(b, c.cancelDeadlineMinutes);
      $('#rc').innerHTML = (isNew && b.status === 'booked' ? '<div class="bk-success"><div class="tick">✓</div><h3>نوبت شما با موفقیت ثبت شد.</h3></div>' : '') +
        RC.html(b, c) +
        '<div class="bk-receipt-actions"><button class="bk-btn primary" data-save>⬇️ ذخیره رسید</button><button class="bk-btn outline" data-share>📤 اشتراک‌گذاری رسید</button>' +
        '<a class="bk-btn outline" href="#/mine">📋 نوبت‌های من</a><a class="bk-btn outline" href="#/">🏠 بازگشت به صفحه اصلی</a></div>' +
        ((b.status === 'booked' || b.status === 'confirmed') && st !== 'expired'
          ? (cc.ok ? '<button class="bk-btn danger block" data-cancel="' + esc(b.id) + '" style="margin-top:12px">لغو نوبت</button>'
            : '<div class="bk-alert warn" style="margin-top:12px">' + esc(cc.reason) + ' برای هماهنگی با ' + esc(c.receptionPhone) + ' تماس بگیرید.</div>') : '');
      S.lastReceipt = { b: b, c: c };
    }).catch(function (e) { $('#rc').innerHTML = errBox(e, true); });
  }
  var inApp = /FaragirApp|; wv\)/.test(navigator.userAgent) || location.protocol === 'https:' && location.host === 'appassets.androidplatform.net';
  function saveReceipt() {
    var x = S.lastReceipt; if (!x) return;
    RC.canvas(x.b, x.c).then(function (cv) {
      var url = cv.toDataURL('image/png'), name = 'receipt-' + x.b.id + '.png';
      if (window.FaragirNative && typeof window.FaragirNative.saveImage === 'function') { // پل بومی (در صورت افزوده‌شدن به اپ)
        window.FaragirNative.saveImage(url.split(',')[1], name); toast('رسید در گالری ذخیره شد'); return;
      }
      if (!inApp) { var a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove(); return; }
      var bg = document.createElement('div'); bg.className = 'bk-sheet-bg';
      bg.innerHTML = '<div class="bk-sheet"><div class="grip"></div><h3>تصویر رسید</h3><img class="bk-img-view" src="' + url + '" alt="رسید نوبت">' +
        '<div class="bk-alert info" style="font-size:.84rem">برای نگه‌داشتن رسید در گالری، از همین صفحه اسکرین‌شات بگیرید. شماره پیگیری <b dir="ltr">' + esc(x.b.id) + '</b> را هم یادداشت کنید.</div>' +
        '<button class="bk-btn outline block" data-close>بستن</button></div>';
      document.body.appendChild(bg);
      bg.addEventListener('click', function (e) { if (e.target === bg || e.target.hasAttribute('data-close')) bg.remove(); });
    });
  }
  function shareReceipt() {
    var x = S.lastReceipt; if (!x) return;
    var text = RC.shareText(x.b, x.c);
    if (window.FaragirNative && typeof window.FaragirNative.shareText === 'function') { window.FaragirNative.shareText(text); return; }
    if (navigator.share) { navigator.share({ title: 'رسید نوبت', text: text }).catch(function () {}); return; }
    copy(text).then(function () { toast('متن رسید کپی شد؛ آن را در پیام‌رسان دلخواه بچسبانید.'); }, function () { toast('اشتراک‌گذاری در این دستگاه پشتیبانی نمی‌شود.'); });
  }
  function copy(t) {
    if (navigator.clipboard && navigator.clipboard.writeText) return navigator.clipboard.writeText(t);
    return new Promise(function (res, rej) { var ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); ta.remove(); ok ? res() : rej(); });
  }

  // ---------- ۸) نوبت‌های من ----------
  var mineTab = 'all';
  function viewMine() {
    root.innerHTML = hero('نوبت‌های من', 'آخرین وضعیت نوبت‌های ثبت‌شده در این حساب', '#/') +
      '<div class="bk-tabs" id="tabs"></div><div id="ml">' + skel(3) + '</div><div class="bk-quick"><a href="#/clinic">＋ نوبت جدید</a><a href="#/profiles">👥 پروفایل‌ها</a></div>';
    Promise.all([loadCfg(), API.myBookings()]).then(function (r) {
      var list = r[1];
      var tabs = [['all', 'همه'], ['booked', 'ثبت‌شده'], ['confirmed', 'تأییدشده'], ['cancelled', 'لغوشده'], ['done', 'انجام‌شده'], ['expired', 'منقضی‌شده']];
      function draw() {
        $('#tabs').innerHTML = tabs.map(function (t) { return '<button data-tab="' + t[0] + '" class="' + (mineTab === t[0] ? 'on' : '') + '">' + t[1] + '</button>'; }).join('');
        var rows = list.filter(function (b) { return mineTab === 'all' || C.displayStatus(b) === mineTab; });
        $('#ml').innerHTML = rows.length ? rows.map(function (b) {
          var st = C.displayStatus(b);
          return '<div class="bk-card"><div class="bk-appt-head"><span class="bk-status ' + C.STATUS[st].cls + '">' + C.STATUS[st].fa + '</span><span class="code">' + esc(b.id) + '</span></div>' +
            '<div class="bk-meta"><div><span class="k">بیمار:</span><b>' + esc(b.patientName) + '</b></div><div><span class="k">پزشک:</span><b>' + esc(b.doctorName) + ' — ' + esc(b.specialty) + '</b></div>' +
            '<div><span class="k">تاریخ:</span><b>' + esc(C.formatJalaliLong(b.date)) + '</b></div><div><span class="k">ساعت:</span><b>' + C.faTime(b.start) + ' تا ' + C.faTime(b.end) + '</b></div></div>' +
            '<div class="bk-doc-actions"><a class="bk-btn outline block" href="#/receipt/' + esc(b.id) + '">جزئیات و رسید</a></div></div>';
        }).join('') : '<div class="bk-empty"><div class="e">📭</div>' + (list.length ? 'نوبتی با این وضعیت ندارید.' : 'هنوز نوبتی در این حساب ثبت نشده است.') + '</div>';
      }
      $('#tabs').addEventListener('click', function (e) { var b = e.target.closest('[data-tab]'); if (b) { mineTab = b.dataset.tab; draw(); } });
      draw();
    }).catch(function (e) { $('#ml').innerHTML = errBox(e, true); });
  }
  function viewProfiles() {
    root.innerHTML = hero('پروفایل‌های بیمار', 'مدیریت اطلاعات ذخیره‌شده', '#/mine') + '<div id="pl">' + skel(2) + '</div>';
    API.listProfiles().then(function (list) {
      $('#pl').innerHTML = (list.length ? list.map(function (p) {
        return '<div class="bk-card bk-profile"><div class="pi">' + (p.relation === 'self' ? '🙂' : '👤') + '</div><div class="pinfo"><b>' + esc(p.fullName) + (p.relation === 'self' ? '<span class="bk-tag-self">خودم</span>' : '') + '</b><small>کد ملی: ' + C.maskNationalId(p.nationalId) + '</small></div>' +
          '<a class="bk-btn outline" href="#/patient/edit/' + esc(p.id) + '/profiles">ویرایش</a></div>';
      }).join('') : '<div class="bk-empty">پروفایلی ثبت نشده است.</div>') + '<a class="bk-add" style="display:block;text-align:center;text-decoration:none" href="#/patient/new/profiles">＋ افزودن پروفایل</a>';
    }).catch(function (e) { $('#pl').innerHTML = errBox(e, true); });
  }

  function confirmSheet(title, text, okLabel, onOk) {
    var bg = document.createElement('div'); bg.className = 'bk-sheet-bg center';
    bg.innerHTML = '<div class="bk-sheet center" role="alertdialog"><h3>' + esc(title) + '</h3><p style="line-height:2;font-size:.92rem;margin:0 0 14px">' + esc(text) + '</p><div id="csMsg"></div>' +
      '<div class="bk-btn-row"><button class="bk-btn danger" data-ok>' + esc(okLabel) + '</button><button class="bk-btn outline" data-no>انصراف</button></div></div>';
    document.body.appendChild(bg);
    bg.addEventListener('click', function (e) {
      if (e.target === bg || e.target.hasAttribute('data-no')) bg.remove();
      if (e.target.hasAttribute('data-ok')) {
        var b = e.target; b.disabled = true; b.innerHTML = '<span class="bk-spinner" style="border-top-color:#c62828"></span>';
        Promise.resolve(onOk()).then(function () { bg.remove(); }, function (err) { bg.querySelector('#csMsg').innerHTML = errBox(err); b.disabled = false; b.textContent = okLabel; });
      }
    });
  }

  // ---------- رویدادهای سراسری ----------
  root.addEventListener('click', function (e) {
    var t = e.target.closest('button, a'); if (!t) return;
    if (t.dataset.back) { e.preventDefault(); go(t.dataset.back); }
    else if (t.dataset.svc) { go('#/' + t.dataset.svc); }
    else if (t.hasAttribute('data-soon')) { toast('نوبت‌دهی «' + t.dataset.soon + '» به‌زودی فعال می‌شود.'); }
    else if (t.id === 'fbtn') openFilter();
    else if (t.dataset.clear) { if (t.dataset.clear === 'spec') S.spec = ''; else S.onlyFree = false; S.selDate = null; rerenderLive(); }
    else if (t.id === 'pprev') { S.pageStart = Math.max(0, S.pageStart - PAGE); renderDates(); }
    else if (t.id === 'pnext') { S.pageStart += PAGE; renderDates(); }
    else if (t.dataset.date) { S.selDate = t.dataset.date; S.pageStart = Math.floor(daysBetween(C.todayIso(), S.selDate) / PAGE) * PAGE; rerenderLive(); }
    else if (t.dataset.times) { go('#/times/' + t.dataset.times + '/' + S.selDate); }
    else if (t.dataset.pick) {
      var s = slotById(t.dataset.pick); if (!s || C.slotState(s) !== 'open') { toast('این زمان دیگر قابل انتخاب نیست.'); return; }
      ss('sel', { slotId: s.id, doctorId: s.doctorId, doctorName: s.doctorName, date: s.date, start: s.start, end: s.end }); ss('pending', null);
      go('#/patient');
    }
    else if (t.dataset.choose) { ss('profileId', t.dataset.choose); ss('pending', null); go('#/confirm'); }
    else if (t.dataset.edit) { go('#/patient/edit/' + t.dataset.edit); }
    else if (t.hasAttribute('data-add')) { go('#/patient/new'); }
    else if (t.hasAttribute('data-retry')) { route(); }
    else if (t.hasAttribute('data-save')) saveReceipt();
    else if (t.hasAttribute('data-share')) shareReceipt();
    else if (t.dataset.cancel) {
      var code = t.dataset.cancel;
      confirmSheet('لغو نوبت', 'آیا از لغو این نوبت مطمئن هستید؟ پس از لغو، این زمان برای سایر بیماران آزاد می‌شود و قابل بازگشت نیست.', 'بله، لغو شود', function () {
        return API.cancelBooking(code, 'patient').then(function () { toast('نوبت لغو شد'); viewReceipt(code, false); });
      });
    }
  });

  // ---------- مسیریابی ----------
  function route() {
    liveRenderer = null;
    var h = (location.hash || '#/').slice(1).split('/').filter(Boolean);
    window.scrollTo(0, 0);
    if (h[0] !== 'clinic' && h[0] !== 'times') stopSlots();
    if (!h.length) return viewHome();
    switch (h[0]) {
      case 'clinic': return viewClinic();
      case 'times': return viewTimes(decodeURIComponent(h[1] || ''), h[2] || '');
      case 'patient':
        if (h[1] === 'new') return viewProfileForm(null, h[2] ? '#/' + h[2] : null);
        if (h[1] === 'edit') return viewProfileForm(decodeURIComponent(h[2] || ''), h[3] ? '#/' + h[3] : null);
        return viewPatient();
      case 'confirm': return viewConfirm();
      case 'receipt': return viewReceipt(h[1], h[2] === 'new');
      case 'mine': return viewMine();
      case 'profiles': return viewProfiles();
      default:
        // سرویس‌های غیرفعال قابل ورود نیستند
        return API.getServices().then(function (list) {
          var s = list.filter(function (x) { return x.id === h[0]; })[0];
          if (s && !s.active) toast('نوبت‌دهی «' + s.title + '» به‌زودی فعال می‌شود.');
          go('#/', true);
        });
    }
  }
  window.addEventListener('hashchange', route);
  // نشست ناشناس را از ابتدا آماده می‌کنیم (پروفایل‌ها و نوبت‌ها به همین حساب تعلق دارند)
  if (window.auth) API.ensureUser().catch(function (e) { console.warn('auth', e && e.bcode); });
  route();
})();
