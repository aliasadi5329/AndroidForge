/* booking-core.js — منطق خالص سامانه نوبت‌دهی (بدون وابستگی به DOM یا Firebase)
 * قابل اجرا در مرورگر/WebView و Node (برای تست خودکار).
 * قرارداد داده:
 *   - تاریخ ذخیره‌شده: رشته میلادی ISO «YYYY-MM-DD» به وقت تهران
 *   - ساعت ذخیره‌شده: «HH:MM» (۲۴ ساعته، ارقام لاتین) به وقت رسمی تهران
 *   - لحظه دقیق شروع: Timestamp (UTC) در فیلد startAt
 *   - نمایش به کاربر: همیشه شمسی و با ارقام فارسی
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.BookingCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  var TZ = 'Asia/Tehran';
  var FA = '۰۱۲۳۴۵۶۷۸۹', AR = '٠١٢٣٤٥٦٧٨٩';
  var WEEKDAYS = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];
  var MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];

  // ---------- ارقام و متن ----------
  function toEn(s) {
    return String(s == null ? '' : s).replace(/[۰-۹٠-٩]/g, function (c) {
      var i = FA.indexOf(c); if (i < 0) i = AR.indexOf(c); return String(i);
    });
  }
  function toFa(s) { return String(s == null ? '' : s).replace(/[0-9]/g, function (d) { return FA[+d]; }); }
  /** یکسان‌سازی برای جست‌وجو: ی/ک عربی، نیم‌فاصله، اعراب، فاصله‌های اضافه */
  function normalizeText(s) {
    return toEn(String(s || ''))
      .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/[ةۀ]/g, 'ه').replace(/[أإآ]/g, 'ا')
      .replace(/[\u064B-\u0652\u0670]/g, '')
      .replace(/[\u200c\u200f\u200e]/g, ' ')
      .replace(/\s+/g, ' ').trim().toLowerCase();
  }
  function cleanName(s) { return String(s || '').replace(/[يى]/g, 'ی').replace(/ك/g, 'ک').replace(/\s+/g, ' ').trim(); }

  // ---------- اعتبارسنجی ----------
  /** الگوریتم رسمی رقم کنترل کد ملی اشخاص حقیقی ایران */
  function isValidNationalId(input) {
    var code = toEn(input).replace(/[\s-]/g, '');
    if (!/^\d{10}$/.test(code)) return false;
    if (/^(\d)\1{9}$/.test(code)) return false;
    var sum = 0;
    for (var i = 0; i < 9; i++) sum += (+code[i]) * (10 - i);
    var r = sum % 11, c = +code[9];
    return r < 2 ? c === r : c === 11 - r;
  }
  function normalizeNationalId(input) { return toEn(input).replace(/[\s-]/g, ''); }
  /** موبایل ایران: 09xxxxxxxxx؛ پیش‌شماره‌های +98 / 0098 / 98 به 0 تبدیل می‌شوند */
  function normalizeMobile(input) {
    var m = toEn(input).replace(/[\s\-()]/g, '');
    if (/^\+98/.test(m)) m = '0' + m.slice(3);
    else if (/^0098/.test(m)) m = '0' + m.slice(4);
    else if (/^98\d{10}$/.test(m)) m = '0' + m.slice(2);
    else if (/^9\d{9}$/.test(m)) m = '0' + m;
    return m;
  }
  function isValidMobile(input) { return /^09\d{9}$/.test(normalizeMobile(input)); }

  /** اعتبارسنجی فرم پروفایل؛ خروجی: { ok, errors:{field:msg}, value } */
  function validateProfile(p) {
    var errors = {};
    var fullName = cleanName(p.fullName);
    var nationalId = normalizeNationalId(p.nationalId);
    var mobile = normalizeMobile(p.mobile);
    var fatherName = cleanName(p.fatherName);
    if (!fullName) errors.fullName = 'وارد کردن نام و نام خانوادگی الزامی است.';
    else if (fullName.length < 5 || fullName.indexOf(' ') < 0) errors.fullName = 'نام و نام خانوادگی را کامل (با فاصله بین نام و نام خانوادگی) وارد کنید.';
    else if (fullName.length > 60) errors.fullName = 'نام و نام خانوادگی حداکثر ۶۰ حرف می‌تواند باشد.';
    else if (!/^[\u0600-\u06FF\u200c a-zA-Z.'-]+$/.test(fullName)) errors.fullName = 'نام فقط می‌تواند شامل حروف باشد.';
    if (!nationalId) errors.nationalId = 'وارد کردن کد ملی الزامی است.';
    else if (!/^\d{10}$/.test(nationalId)) errors.nationalId = 'کد ملی باید دقیقاً ۱۰ رقم باشد.';
    else if (!isValidNationalId(nationalId)) errors.nationalId = 'کد ملی وارد شده معتبر نیست.';
    if (!toEn(p.mobile || '').trim()) errors.mobile = 'وارد کردن شماره تلفن همراه الزامی است.';
    else if (!isValidMobile(mobile)) errors.mobile = 'شماره همراه معتبر نیست (نمونه: ۰۹۱۲۳۴۵۶۷۸۹).';
    if (fatherName && (fatherName.length > 40 || !/^[\u0600-\u06FF\u200c a-zA-Z]+$/.test(fatherName))) errors.fatherName = 'نام پدر فقط می‌تواند شامل حروف باشد (حداکثر ۴۰ حرف).';
    var relation = p.relation === 'self' ? 'self' : 'other';
    return { ok: Object.keys(errors).length === 0, errors: errors,
      value: { fullName: fullName, nationalId: nationalId, mobile: mobile, fatherName: fatherName, relation: relation } };
  }

  // ---------- حریم خصوصی ----------
  /** کد ملی پوشیده: فقط ۳ رقم اول و ۲ رقم آخر */
  function maskNationalId(n) {
    n = normalizeNationalId(n);
    if (n.length !== 10) return '—';
    return toFa(n.slice(0, 3)) + '•••••' + toFa(n.slice(8));
  }
  function maskMobile(m) {
    m = normalizeMobile(m);
    if (m.length !== 11) return '—';
    return toFa(m.slice(0, 4)) + '•••' + toFa(m.slice(7));
  }

  // ---------- زمان و تقویم (منطقه زمانی رسمی: Asia/Tehran) ----------
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  var hasIntlPersian = (function () {
    try {
      var s = new Intl.DateTimeFormat('fa-IR-u-ca-persian', { timeZone: 'UTC', year: 'numeric' }).format(new Date(Date.UTC(2026, 9, 25)));
      return /۱۴۰۵/.test(s);
    } catch (e) { return false; }
  })();

  /** اجزای تاریخ/ساعت دیواری تهران برای یک لحظه */
  function tehranParts(date) {
    var d = date instanceof Date ? date : new Date(date);
    try {
      var f = new Intl.DateTimeFormat('en-US', { timeZone: TZ, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' });
      var o = {}; f.formatToParts(d).forEach(function (p) { o[p.type] = p.value; });
      return { y: +o.year, m: +o.month, d: +o.day, h: +o.hour % 24, mi: +o.minute, s: +o.second };
    } catch (e) { // بدون پشتیبانی منطقه زمانی: ایران از ۱۴۰۱ ساعت تابستانی ندارد (UTC+03:30)
      var t = new Date(d.getTime() + 210 * 60000);
      return { y: t.getUTCFullYear(), m: t.getUTCMonth() + 1, d: t.getUTCDate(), h: t.getUTCHours(), mi: t.getUTCMinutes(), s: t.getUTCSeconds() };
    }
  }
  function todayIso(now) { var p = tehranParts(now || new Date()); return p.y + '-' + pad(p.m) + '-' + pad(p.d); }
  function parseIso(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || ''); if (!m) return null;
    return { y: +m[1], m: +m[2], d: +m[3] };
  }
  function addDaysIso(iso, n) {
    var p = parseIso(iso); var t = new Date(Date.UTC(p.y, p.m - 1, p.d + n, 12));
    return t.getUTCFullYear() + '-' + pad(t.getUTCMonth() + 1) + '-' + pad(t.getUTCDate());
  }
  function weekdayIndex(iso) { var p = parseIso(iso); return new Date(Date.UTC(p.y, p.m - 1, p.d, 12)).getUTCDay(); } // 0=یکشنبه
  /** لحظه UTC برای «تاریخ + ساعت» دیواری تهران (با محاسبه اختلاف واقعی همان تاریخ) */
  function tehranToUtc(iso, hhmm) {
    var p = parseIso(iso), t = /^(\d{2}):(\d{2})$/.exec(hhmm);
    var guess = Date.UTC(p.y, p.m - 1, p.d, +t[1], +t[2]) - 210 * 60000;
    for (var k = 0; k < 2; k++) {
      var w = tehranParts(new Date(guess));
      var wallMs = Date.UTC(w.y, w.m - 1, w.d, w.h, w.mi);
      var wantMs = Date.UTC(p.y, p.m - 1, p.d, +t[1], +t[2]);
      guess += wantMs - wallMs;
    }
    return new Date(guess);
  }

  // تبدیل میلادی↔شمسی (الگوریتم حسابی رایج؛ با ICU مرورگر در تست‌ها مقایسه شده)
  function g2j(gy, gm, gd) {
    var g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334], jy, jm, jd, days;
    var gy2 = gm > 2 ? gy + 1 : gy;
    days = 355666 + 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) + Math.floor((gy2 + 399) / 400) + gd + g_d_m[gm - 1];
    jy = -1595 + 33 * Math.floor(days / 12053); days %= 12053;
    jy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { jy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    if (days < 186) { jm = 1 + Math.floor(days / 31); jd = 1 + (days % 31); }
    else { jm = 7 + Math.floor((days - 186) / 30); jd = 1 + ((days - 186) % 30); }
    return { jy: jy, jm: jm, jd: jd };
  }
  function j2g(jy, jm, jd) {
    var gy, gm, gd, days;
    jy += 1595;
    days = -355668 + 365 * jy + Math.floor(jy / 33) * 8 + Math.floor(((jy % 33) + 3) / 4) + jd + (jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    gy = 400 * Math.floor(days / 146097); days %= 146097;
    if (days > 36524) { gy += 100 * Math.floor(--days / 36524); days %= 36524; if (days >= 365) days++; }
    gy += 4 * Math.floor(days / 1461); days %= 1461;
    if (days > 365) { gy += Math.floor((days - 1) / 365); days = (days - 1) % 365; }
    gd = days + 1;
    var sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) gd -= sal_a[gm];
    return { gy: gy, gm: gm, gd: gd };
  }
  /** ورودی شمسی «۱۴۰۵/۰۸/۰۷» → ISO میلادی؛ نامعتبر → null */
  function jalaliToIso(str) {
    var m = /^(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})$/.exec(toEn(String(str || '').trim()));
    if (!m) return null;
    var jy = +m[1], jm = +m[2], jd = +m[3];
    if (jm < 1 || jm > 12 || jd < 1 || jd > (jm <= 6 ? 31 : 30)) return null;
    var g = j2g(jy, jm, jd);
    var iso = g.gy + '-' + pad(g.gm) + '-' + pad(g.gd);
    var back = isoToJalali(iso);
    return (back.jy === jy && back.jm === jm && back.jd === jd) ? iso : null; // رد ۳۰ اسفند در سال غیرکبیسه
  }
  function isoToJalali(iso) { var p = parseIso(iso); return g2j(p.y, p.m, p.d); }

  /** «پنج‌شنبه، ۷ آبان ۱۴۰۵» از تاریخ ISO */
  function formatJalaliLong(iso) {
    var p = parseIso(iso); if (!p) return '';
    var wd = WEEKDAYS[weekdayIndex(iso)];
    if (hasIntlPersian) {
      var dt = new Date(Date.UTC(p.y, p.m - 1, p.d, 12));
      var o = {};
      new Intl.DateTimeFormat('fa-IR-u-ca-persian-nu-arabext', { timeZone: 'UTC', day: 'numeric', month: 'long', year: 'numeric' })
        .formatToParts(dt).forEach(function (x) { o[x.type] = x.value; });
      if (o.day && o.month && o.year) return wd + '، ' + toFa(toEn(o.day)) + ' ' + o.month + ' ' + toFa(toEn(o.year).replace(/\D/g, ''));
    }
    var j = isoToJalali(iso);
    return wd + '، ' + toFa(j.jd) + ' ' + MONTHS[j.jm - 1] + ' ' + toFa(j.jy);
  }
  function formatJalaliShort(iso) { var j = isoToJalali(iso); return toFa(j.jy + '/' + pad(j.jm) + '/' + pad(j.jd)); }
  function dayChip(iso) { var j = isoToJalali(iso); return { weekday: WEEKDAYS[weekdayIndex(iso)], day: toFa(j.jd), month: MONTHS[j.jm - 1], year: toFa(j.jy) }; }
  function faTime(hhmm) { return toFa(hhmm || ''); }
  function minutesOf(hhmm) { var t = /^(\d{2}):(\d{2})$/.exec(hhmm || ''); return t ? (+t[1]) * 60 + (+t[2]) : NaN; }
  function hhmmOf(min) { min = ((min % 1440) + 1440) % 1440; return pad(Math.floor(min / 60)) + ':' + pad(min % 60); }
  function isValidHHMM(s) { return /^([01]\d|2[0-3]):[0-5]\d$/.test(s || ''); }
  /** بازه تقریبی پذیرش: از (شروع − leadMinutes) تا پایان بازه نوبت؛ از داده واقعی همان نوبت */
  function admissionWindow(start, end, leadMinutes) {
    var lead = typeof leadMinutes === 'number' && leadMinutes >= 0 ? leadMinutes : 30;
    return { from: hhmmOf(minutesOf(start) - lead), to: end };
  }
  function formatDateTimeFa(date) {
    var p = tehranParts(date);
    var iso = p.y + '-' + pad(p.m) + '-' + pad(p.d);
    return formatJalaliShort(iso) + ' ساعت ' + toFa(pad(p.h) + ':' + pad(p.mi));
  }

  // ---------- ظرفیت و وضعیت ----------
  function remaining(slot) { return Math.max(0, (slot.capacity | 0) - (slot.booked | 0)); }
  /** وضعیت قابل رزرو بودن یک بازه از دید رابط کاربری (حکم نهایی با قوانین سرور است) */
  function slotState(slot, nowMs) {
    var now = nowMs == null ? Date.now() : nowMs;
    var startMs = slot.startAt && slot.startAt.toMillis ? slot.startAt.toMillis() : +new Date(slot.startAt);
    if (!slot.active) return 'inactive';
    if (!(startMs > now)) return 'past';
    if (remaining(slot) <= 0) return 'full';
    return 'open';
  }
  var STATUS = {
    booked: { fa: 'ثبت‌شده', cls: 'st-booked' },
    confirmed: { fa: 'تأییدشده', cls: 'st-confirmed' },
    cancelled: { fa: 'لغوشده', cls: 'st-cancelled' },
    done: { fa: 'انجام‌شده', cls: 'st-done' },
    expired: { fa: 'منقضی‌شده', cls: 'st-expired' }
  };
  /** وضعیت نمایشی: نوبت فعالی که زمانش گذشته «منقضی‌شده» نمایش داده می‌شود */
  function displayStatus(b, nowMs) {
    var now = nowMs == null ? Date.now() : nowMs;
    var endMs = b.endAt && b.endAt.toMillis ? b.endAt.toMillis() : (b.endAt ? +new Date(b.endAt) : NaN);
    if ((b.status === 'booked' || b.status === 'confirmed') && endMs && endMs < now) return 'expired';
    return b.status;
  }
  function canCancel(b, cancelDeadlineMinutes, nowMs) {
    var now = nowMs == null ? Date.now() : nowMs;
    if (b.status !== 'booked' && b.status !== 'confirmed') return { ok: false, reason: 'این نوبت قابل لغو نیست.' };
    var startMs = b.startAt && b.startAt.toMillis ? b.startAt.toMillis() : +new Date(b.startAt);
    var dl = (cancelDeadlineMinutes == null ? 120 : cancelDeadlineMinutes) * 60000;
    if (startMs - dl < now) return { ok: false, reason: 'مهلت لغو این نوبت (' + toFa(Math.round(dl / 60000)) + ' دقیقه پیش از شروع) به پایان رسیده است.' };
    return { ok: true };
  }

  // ---------- شناسه‌ها ----------
  var CODE_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // بدون O/0/I/1
  function randomCode(len, rnd) {
    len = len || 10;
    var arr = new Uint32Array(len);
    (rnd || (typeof crypto !== 'undefined' && crypto.getRandomValues ? crypto.getRandomValues.bind(crypto) : null))(arr);
    var out = ''; for (var i = 0; i < len; i++) out += CODE_CHARS[arr[i] % CODE_CHARS.length];
    return out;
  }
  function isTrackingCode(s) { return /^[A-HJ-NP-Z2-9]{10}$/.test(s || ''); }
  function slotIdFor(doctorId, iso, start) { return doctorId + '_' + iso.replace(/-/g, '') + '_' + start.replace(':', ''); }

  // ---------- پزشکان: جست‌وجو و فیلتر ----------
  function filterDoctors(doctors, query, specialty) {
    var q = normalizeText(query), tokens = q ? q.split(' ') : [];
    return doctors.filter(function (d) {
      if (specialty && d.specialty !== specialty) return false;
      if (!tokens.length) return true;
      var hay = normalizeText([d.name, d.specialty, (d.services || []).join(' '), (d.tags || []).join(' ')].join(' '));
      return tokens.every(function (t) { return hay.indexOf(t) >= 0; });
    });
  }
  function initials(name) {
    var n = cleanName(name).replace(/^دکتر\s+/, '').split(' ');
    return (n[0] ? n[0][0] : '') + (n.length > 1 && n[n.length - 1] ? '‌' + n[n.length - 1][0] : '');
  }

  return {
    TZ: TZ, WEEKDAYS: WEEKDAYS, MONTHS: MONTHS, STATUS: STATUS,
    toEn: toEn, toFa: toFa, normalizeText: normalizeText, cleanName: cleanName,
    isValidNationalId: isValidNationalId, normalizeNationalId: normalizeNationalId,
    normalizeMobile: normalizeMobile, isValidMobile: isValidMobile, validateProfile: validateProfile,
    maskNationalId: maskNationalId, maskMobile: maskMobile,
    tehranParts: tehranParts, todayIso: todayIso, parseIso: parseIso, addDaysIso: addDaysIso, weekdayIndex: weekdayIndex,
    tehranToUtc: tehranToUtc, g2j: g2j, j2g: j2g, jalaliToIso: jalaliToIso, isoToJalali: isoToJalali,
    formatJalaliLong: formatJalaliLong, formatJalaliShort: formatJalaliShort, dayChip: dayChip, faTime: faTime,
    minutesOf: minutesOf, hhmmOf: hhmmOf, isValidHHMM: isValidHHMM, admissionWindow: admissionWindow, formatDateTimeFa: formatDateTimeFa,
    remaining: remaining, slotState: slotState, displayStatus: displayStatus, canCancel: canCancel,
    randomCode: randomCode, isTrackingCode: isTrackingCode, slotIdFor: slotIdFor,
    filterDoctors: filterDoctors, initials: initials, hasIntlPersian: hasIntlPersian
  };
});
