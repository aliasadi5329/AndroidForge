/* booking-receipt.js — رسید نوبت: نمایش HTML، تصویر (Canvas)، متن اشتراک‌گذاری */
var BookingReceipt = (function () {
  'use strict';
  var C = window.BookingCore;
  function esc(s) { var d = document.createElement('div'); d.textContent = s == null ? '' : String(s); return d.innerHTML; }

  function notes(b, cfg) {
    var w = C.admissionWindow(b.start, b.end, cfg.admissionLeadMinutes);
    return [
      'جهت انجام پذیرش، در بازه زمانی اعلام‌شده برای نوبت خود (' + formatWindow(w) + ') به بخش درمانگاه مراجعه فرمایید.',
      'خدمت‌رسانی بر اساس زمان پذیرش بیماران انجام می‌شود. در صورت عدم مراجعه به‌موقع در زمان پذیرش تعیین‌شده، نوبت شما ممکن است با تأخیر مواجه شود یا مطابق مقررات مرکز لغو گردد.',
      'به همراه داشتن کارت شناسایی معتبر الزامی است.',
      'زمان نوبت تقریبی است و ممکن است به دلیل شلوغی درمانگاه یا نیاز به پذیرش بیماران اورژانسی با تأخیر مواجه شود.',
      'این نوبت برای بیمار ثبت‌شده صادر شده است و انتقال آن به شخص دیگر مجاز نیست.',
      'برای لغو نوبت، در صورت امکان تا ' + C.toFa(Math.round(cfg.cancelDeadlineMinutes / 60 * 10) / 10) + ' ساعت پیش از زمان نوبت اقدام کنید. مقررات نهایی لغو مطابق سیاست مصوب بیمارستان اجرا می‌شود.',
      'از بخش «نوبت‌های من» می‌توانید آخرین وضعیت نوبت خود را مشاهده کنید.'
    ];
  }
  function formatWindow(w) { return 'از ساعت ' + C.faTime(w.from) + ' تا ' + C.faTime(w.to); }

  function rows(b, cfg) {
    var st = C.displayStatus(b), w = C.admissionWindow(b.start, b.end, cfg.admissionLeadMinutes);
    var chip = C.dayChip(b.date);
    return [
      ['نام و نام خانوادگی بیمار', b.patientName],
      ['کد ملی', C.maskNationalId(b.nationalId)],
      ['نام پزشک', b.doctorName],
      ['تخصص', b.specialty],
      ['روز هفته', chip.weekday],
      ['تاریخ مراجعه', C.formatJalaliLong(b.date).split('، ')[1] + ' (' + C.formatJalaliShort(b.date) + ')'],
      ['ساعت نوبت', 'از ' + C.faTime(b.start) + ' تا ' + C.faTime(b.end)],
      ['بازه تقریبی پذیرش', formatWindow(w)],
      ['محل مراجعه', b.location || cfg.defaultLocation],
      ['وضعیت نوبت', { status: st }],
      ['تاریخ ثبت', b.createdAt && b.createdAt.toDate ? C.formatDateTimeFa(b.createdAt.toDate()) : '—']
    ];
  }

  function html(b, cfg) {
    var r = rows(b, cfg).map(function (x) {
      var v = x[1] && x[1].status ? '<span class="bk-status ' + C.STATUS[x[1].status].cls + '">' + C.STATUS[x[1].status].fa + '</span>' : esc(x[1]);
      return '<div class="bk-rc-row"><span>' + esc(x[0]) + '</span><b>' + v + '</b></div>';
    }).join('');
    var n = notes(b, cfg).map(function (t) { return '<li>' + esc(t) + '</li>'; }).join('');
    var foot = cfg.showSlogan ? '<div class="bk-rc-foot"><b>«' + esc(cfg.slogan) + '»</b><br>' + esc(cfg.hospitalName) + ' | ' + esc(cfg.brandName) + '</div>'
      : '<div class="bk-rc-foot">' + esc(cfg.hospitalName) + '</div>';
    return '<div class="bk-receipt" id="bkReceipt">' +
      '<div class="bk-rc-head"><img src="images/logo.png" alt=""><div><div class="h1">' + esc(cfg.hospitalName) + '</div><div class="h2">' + esc(cfg.brandName) + ' — سامانه نوبت‌دهی درمانگاه</div></div></div>' +
      '<div class="bk-rc-title">رسید نوبت</div>' +
      '<div class="bk-rc-code"><small>شماره پیگیری</small><strong>' + esc(b.id) + '</strong></div>' +
      '<div class="bk-rc-body">' + r + '</div>' +
      '<div class="bk-note"><h4>⚠️ توجه</h4><ul>' + n + '</ul></div>' + foot + '</div>';
  }

  function shareText(b, cfg) {
    return 'رسید نوبت — ' + cfg.hospitalName + '\n' +
      'شماره پیگیری: ' + b.id + '\n' +
      'بیمار: ' + b.patientName + '\n' +
      'پزشک: ' + b.doctorName + ' (' + b.specialty + ')\n' +
      'تاریخ: ' + C.formatJalaliLong(b.date) + '\n' +
      'ساعت: ' + C.faTime(b.start) + ' تا ' + C.faTime(b.end) + '\n' +
      'محل: ' + (b.location || cfg.defaultLocation) + '\n' +
      'وضعیت: ' + C.STATUS[C.displayStatus(b)].fa;
  }

  // ---------- تصویر رسید با Canvas ----------
  function loadImg(src) { return new Promise(function (res) { var i = new Image(); i.onload = function () { res(i); }; i.onerror = function () { res(null); }; i.src = src; }); }
  function wrap(ctx, text, maxW) {
    var words = text.split(' '), lines = [], line = '';
    words.forEach(function (w) { var t = line ? line + ' ' + w : w; if (ctx.measureText(t).width > maxW && line) { lines.push(line); line = w; } else line = t; });
    if (line) lines.push(line); return lines;
  }
  function roundRect(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

  function canvas(b, cfg) {
    var W = 1080, P = 60, F = "'Vazirmatn', Tahoma, sans-serif";
    var fontsReady = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
    return Promise.all([loadImg('images/logo.png'), fontsReady]).then(function (r) {
      var logo = r[0];
      var cv = document.createElement('canvas'), ctx = cv.getContext('2d');
      ctx.font = '30px ' + F;
      var noteLines = []; notes(b, cfg).forEach(function (t) { wrap(ctx, '• ' + t, W - 2 * P - 60).forEach(function (l) { noteLines.push(l); }); });
      var R = rows(b, cfg), H = 220 + 90 + 150 + R.length * 70 + 100 + noteLines.length * 46 + 200;
      cv.width = W; cv.height = H; ctx = cv.getContext('2d'); ctx.direction = 'rtl';
      ctx.fillStyle = '#f3f8f8'; ctx.fillRect(0, 0, W, H);
      ctx.fillStyle = '#fff'; roundRect(ctx, 24, 24, W - 48, H - 48, 36); ctx.fill();
      // سربرگ
      ctx.save(); roundRect(ctx, 24, 24, W - 48, 200, 36); ctx.clip();
      var g = ctx.createLinearGradient(0, 0, W, 220); g.addColorStop(0, '#0b9e98'); g.addColorStop(1, '#08736f');
      ctx.fillStyle = g; ctx.fillRect(24, 24, W - 48, 200); ctx.restore();
      if (logo) { ctx.fillStyle = '#fff'; roundRect(ctx, W - P - 130, 58, 130, 130, 24); ctx.fill(); ctx.drawImage(logo, W - P - 122, 66, 114, 114); }
      ctx.fillStyle = '#fff'; ctx.textAlign = 'right';
      ctx.font = 'bold 44px ' + F; ctx.fillText(cfg.hospitalName, W - P - 160, 115);
      ctx.font = '30px ' + F; ctx.fillText(cfg.brandName + ' — سامانه نوبت‌دهی درمانگاه', W - P - 160, 165);
      var y = 300;
      ctx.textAlign = 'center'; ctx.fillStyle = '#08736f'; ctx.font = 'bold 46px ' + F; ctx.fillText('رسید نوبت', W / 2, y);
      ctx.setLineDash([12, 10]); ctx.strokeStyle = '#cfe5e4'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(P, y + 34); ctx.lineTo(W - P, y + 34); ctx.stroke(); ctx.setLineDash([]);
      y += 100; ctx.fillStyle = '#6b7a88'; ctx.font = '28px ' + F; ctx.fillText('شماره پیگیری', W / 2, y);
      ctx.fillStyle = '#e6f6f5'; roundRect(ctx, W / 2 - 220, y + 18, 440, 76, 18); ctx.fill();
      ctx.fillStyle = '#08736f'; ctx.font = 'bold 50px ' + F; ctx.direction = 'ltr'; ctx.fillText(b.id.split('').join(' '), W / 2, y + 74); ctx.direction = 'rtl';
      y += 150;
      R.forEach(function (row) {
        ctx.textAlign = 'right'; ctx.fillStyle = '#6b7a88'; ctx.font = '30px ' + F; ctx.fillText(row[0], W - P, y);
        var v = row[1] && row[1].status ? C.STATUS[row[1].status].fa : String(row[1]);
        ctx.textAlign = 'left'; ctx.fillStyle = '#1f2d3a'; ctx.font = 'bold 31px ' + F;
        var maxV = W - 2 * P - ctx.measureText(row[0]).width - 40;
        while (ctx.measureText(v).width > maxV && v.length > 4) v = v.slice(0, -2);
        ctx.fillText(v, P, y);
        ctx.strokeStyle = '#eef3f3'; ctx.lineWidth = 2; ctx.beginPath(); ctx.moveTo(P, y + 24); ctx.lineTo(W - P, y + 24); ctx.stroke();
        y += 70;
      });
      y += 20;
      var boxH = noteLines.length * 46 + 90;
      ctx.fillStyle = '#fffaf0'; roundRect(ctx, P, y, W - 2 * P, boxH, 24); ctx.fill();
      ctx.strokeStyle = '#f0d9a8'; ctx.lineWidth = 3; roundRect(ctx, P, y, W - 2 * P, boxH, 24); ctx.stroke();
      ctx.textAlign = 'right'; ctx.fillStyle = '#b26a00'; ctx.font = 'bold 34px ' + F; ctx.fillText('توجه', W - P - 30, y + 54);
      ctx.fillStyle = '#5b4a2a'; ctx.font = '30px ' + F;
      noteLines.forEach(function (l, i) { ctx.fillText(l, W - P - 30, y + 104 + i * 46); });
      y += boxH + 70;
      ctx.textAlign = 'center'; ctx.fillStyle = '#08736f';
      if (cfg.showSlogan) { ctx.font = 'bold 34px ' + F; ctx.fillText('«' + cfg.slogan + '»', W / 2, y); ctx.font = '28px ' + F; ctx.fillText(cfg.hospitalName + ' | ' + cfg.brandName, W / 2, y + 48); }
      else { ctx.font = '28px ' + F; ctx.fillText(cfg.hospitalName, W / 2, y); }
      return cv;
    });
  }

  return { html: html, canvas: canvas, shareText: shareText, notes: notes };
})();
