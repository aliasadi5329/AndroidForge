// Mobile Menu Toggle
const menuToggle = document.getElementById('menuToggle');
const mainNav = document.getElementById('mainNav');

if (menuToggle && mainNav) {
  menuToggle.addEventListener('click', () => {
    mainNav.classList.toggle('open');
  });
}

// Dropdown menus - toggle open/close properly
document.querySelectorAll('.nav-item > a').forEach(link => {
  link.addEventListener('click', function (e) {
    e.preventDefault();
    e.stopPropagation();
    const parent = this.parentElement;
    const isOpen = parent.classList.contains('open');

    // Close all other dropdowns
    document.querySelectorAll('.nav-item.open').forEach(item => {
      if (item !== parent) item.classList.remove('open');
    });

    // Toggle current
    if (isOpen) {
      parent.classList.remove('open');
    } else {
      parent.classList.add('open');
    }
  });
});

// Close dropdown when clicking outside
document.addEventListener('click', (e) => {
  if (!e.target.closest('.nav-item')) {
    document.querySelectorAll('.nav-item.open').forEach(item => {
      item.classList.remove('open');
    });
  }
});

// Hero Slider (homepage)
const slides = document.querySelectorAll('.hero-slider .slide');
const dots = document.querySelectorAll('.hero-dots .dot');
let currentSlide = 0;

function showSlide(index) {
  slides.forEach((slide, i) => {
    slide.classList.toggle('active', i === index);
  });
  dots.forEach((dot, i) => {
    dot.classList.toggle('active', i === index);
  });
  currentSlide = index;
}

if (dots.length > 0 && slides.length > 0) {
  dots.forEach(dot => {
    dot.addEventListener('click', () => {
      showSlide(parseInt(dot.dataset.slide));
    });
  });
  setInterval(() => {
    showSlide((currentSlide + 1) % slides.length);
  }, 5000);
}

// Ward image slider
(function initWardSlider() {
  const gallery = document.querySelector('.ward-gallery');
  if (!gallery) return;

  const images = Array.from(gallery.querySelectorAll('img'));
  if (images.length < 2) return;

  // Build slider structure
  gallery.classList.add('ward-slider');
  gallery.innerHTML = '';

  const track = document.createElement('div');
  track.className = 'ward-slider-track';

  images.forEach((img, i) => {
    const slide = document.createElement('div');
    slide.className = 'ward-slide' + (i === 0 ? ' active' : '');
    slide.appendChild(img.cloneNode(true));
    track.appendChild(slide);
  });
  gallery.appendChild(track);

  // Dots
  const dotsWrap = document.createElement('div');
  dotsWrap.className = 'ward-slider-dots';
  images.forEach((_, i) => {
    const d = document.createElement('span');
    d.className = 'ward-dot' + (i === 0 ? ' active' : '');
    d.dataset.index = i;
    dotsWrap.appendChild(d);
  });
  gallery.appendChild(dotsWrap);

  // Arrows
  const prevBtn = document.createElement('button');
  prevBtn.className = 'ward-slider-btn prev';
  prevBtn.innerHTML = '‹';
  prevBtn.type = 'button';
  const nextBtn = document.createElement('button');
  nextBtn.className = 'ward-slider-btn next';
  nextBtn.innerHTML = '›';
  nextBtn.type = 'button';
  gallery.appendChild(prevBtn);
  gallery.appendChild(nextBtn);

  let current = 0;
  const slideEls = track.querySelectorAll('.ward-slide');
  const dotEls = dotsWrap.querySelectorAll('.ward-dot');

  function goTo(index) {
    current = (index + slideEls.length) % slideEls.length;
    slideEls.forEach((s, i) => s.classList.toggle('active', i === current));
    dotEls.forEach((d, i) => d.classList.toggle('active', i === current));
  }

  prevBtn.addEventListener('click', () => goTo(current - 1));
  nextBtn.addEventListener('click', () => goTo(current + 1));
  dotEls.forEach(d => {
    d.addEventListener('click', () => goTo(parseInt(d.dataset.index)));
  });

  // Auto play
  setInterval(() => goTo(current + 1), 4000);
})();

// فرم‌های دارای id (نوبت، پیگیری، ورود مدیر) هندلر اختصاصی خودشان را دارند.
// فرم‌های تماس/استخدام هنوز به سروری وصل نیستند؛ به‌جای نمایش پیام موفقیت جعلی، صادقانه راهنمایی می‌کنیم.
document.querySelectorAll('form').forEach(form => {
  if (form.id) return;
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    alert('ارسال آنلاین این فرم هنوز فعال نیست. لطفاً با تلفن گویا ۰۳۴-۴۱۴۲۸۰۰۰ تماس بگیرید.');
  });
});


// ===== لینک ثابت «مقالات» در همه صفحات + نشان «جدید» =====
(function () {
  var META = 'https://firestore.googleapis.com/v1/projects/faragir-appointment-app/databases/(default)/documents/meta/latest?key=AIzaSyAUL-TMPS1YwH8U2SVu4GjQg59Smn2YzCk';
  var pre = location.pathname.indexOf('/wards/') >= 0 ? '../' : '';
  var cont = document.querySelector('.header-main .container');
  var badge = null;
  if (cont && !cont.querySelector('.art-link')) {
    var a = document.createElement('a');
    a.className = 'art-link'; a.href = pre + 'articles.html';
    a.appendChild(document.createTextNode('📰 مقالات'));
    badge = document.createElement('span'); badge.className = 'art-badge'; badge.textContent = 'جدید'; badge.style.display = 'none';
    a.appendChild(badge);
    cont.insertBefore(a, document.getElementById('menuToggle'));
  }
  var metaP = fetch(META).then(function (r) { return r.ok ? r.json() : null; }).catch(function () { return null; });
  function tsOf(j) { try { return parseInt(j.fields.ts.integerValue, 10) || 0; } catch (e) { return 0; } }
  function seen() { try { return parseInt(localStorage.getItem('lastSeenArticleTs') || '0', 10); } catch (e) { return 0; } }
  metaP.then(function (j) { if (j && badge && tsOf(j) > seen()) badge.style.display = 'inline-block'; });
  // صفحه مقالات صدا می‌زند: همه مقالات تا این لحظه دیده شد
  window.markArticlesSeen = function () {
    metaP.then(function (j) { if (!j) return; try { localStorage.setItem('lastSeenArticleTs', String(tsOf(j))); } catch (e) {} if (badge) badge.style.display = 'none'; });
  };
})();
