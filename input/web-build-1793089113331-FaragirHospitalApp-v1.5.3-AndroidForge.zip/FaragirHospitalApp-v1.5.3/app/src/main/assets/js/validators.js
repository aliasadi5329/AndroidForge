// اعتبارسنجی ورودی‌ها
var Validators = (function () {
  var FA = '۰۱۲۳۴۵۶۷۸۹', AR = '٠١٢٣٤٥٦٧٨٩';
  function toEn(s) {
    return String(s || '').replace(/[۰-۹٠-٩]/g, function (c) {
      var i = FA.indexOf(c); if (i < 0) i = AR.indexOf(c); return String(i);
    });
  }
  function toFa(s) { return String(s).replace(/[0-9]/g, function (d) { return FA[d]; }); }
  function isMobile(s) { return /^09\d{9}$/.test(s); }
  // الگوریتم رسمی صحت کد ملی ایران
  function isNationalId(code) {
    if (!/^\d{10}$/.test(code)) return false;
    if (/^(\d)\1{9}$/.test(code)) return false;
    var sum = 0;
    for (var i = 0; i < 9; i++) sum += parseInt(code[i], 10) * (10 - i);
    var r = sum % 11, c = parseInt(code[9], 10);
    return (r < 2 && c === r) || (r >= 2 && c === 11 - r);
  }
  return { toEn: toEn, toFa: toFa, isMobile: isMobile, isNationalId: isNationalId };
})();
