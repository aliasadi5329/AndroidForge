# چت ساده - پیام‌رسان شیک با Firebase

یک اپلیکیشن چت بسیار ساده و مدرن که فقط با وارد کردن **نام** و **نام خانوادگی** وارد چت می‌شوید.

## ویژگی‌ها
- طراحی شیک و تاریک (Dark Mode)
- ورود فقط با نام و فامیل (بدون نیاز به ایمیل یا پسورد)
- چت گروهی real-time با Firebase Realtime Database
- ذخیره نام کاربر در localStorage
- رابط کاربری کاملاً فارسی و راست‌چین
- آماده تبدیل به اپلیکیشن اندروید

---

## مراحل راه‌اندازی Firebase

### ۱. ساخت پروژه Firebase
1. برو به [Firebase Console](https://console.firebase.google.com/)
2. روی **Add project** کلیک کن و یک پروژه جدید بساز
3. Google Analytics را می‌توانی غیرفعال کنی

### ۲. فعال کردن Realtime Database
1. از منوی سمت چپ **Build → Realtime Database** را انتخاب کن
2. روی **Create Database** کلیک کن
3. مکان را انتخاب کن (مثلاً `europe-west1` یا نزدیک‌ترین)
4. در حالت **test mode** شروع کن (بعداً قوانین را تغییر می‌دهیم)

### ۳. تنظیم قوانین امنیتی (مهم)
در تب **Rules** این قوانین را بگذار:

```json
{
  "rules": {
    "messages": {
      ".read": true,
      ".write": true,
      ".indexOn": ["timestamp"]
    }
  }
}
```

> **توجه:** این قوانین برای تست و استفاده شخصی است. برای پروژه واقعی باید احراز هویت اضافه کنید.

### ۴. گرفتن تنظیمات وب
1. در صفحه اصلی پروژه روی آیکون **Web** (</>) کلیک کن
2. یک اپ ثبت کن (نام دلخواه)
3. تنظیمات `firebaseConfig` را کپی کن

### ۵. قرار دادن تنظیمات در کد
فایل `app.js` را باز کن و قسمت `firebaseConfig` را با اطلاعات خودت عوض کن:

```js
const firebaseConfig = {
  apiKey: "AIza...",
  authDomain: "project-id.firebaseapp.com",
  databaseURL: "https://project-id-default-rtdb.firebaseio.com",
  projectId: "project-id",
  storageBucket: "project-id.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
};
```

---

## تست کردن

می‌توانی فایل‌ها را مستقیماً با یک سرور محلی تست کنی:

```bash
# اگر Python داری
python -m http.server 8080

# یا با Node
npx serve .
```

سپس در مرورگر برو به `http://localhost:8080`

---

## تبدیل به اپلیکیشن اندروید

### روش پیشنهادی (ساده‌ترین):
1. فایل‌ها را روی یک هاست رایگان آپلود کن (مثل Firebase Hosting، Netlify، GitHub Pages، یا حتی یک هاست معمولی)
2. لینک سایت را در یکی از سایت‌های تبدیل وب به اپ وارد کن:
   - [WebToApp](https://www.webtoapp.app/)
   - [Webium](https://webiumapp.com/)
   - یا اپ‌های موبایل مثل WebApp / Website to App

### روش دیگر (AndroidForge):
اگر از سایت AndroidForge استفاده می‌کنی، این پروژه وب است. می‌توانی آن را داخل یک WebView ساده قرار دهی یا از ابزارهای تبدیل ZIP به APK استفاده کنی.

### Firebase Hosting (پیشنهادی برای هاست رایگان):
```bash
npm install -g firebase-tools
firebase login
firebase init hosting
# پوشه public را روی همین پوشه تنظیم کن
firebase deploy
```

---

## ساختار فایل‌ها

```
chat-app/
├── index.html      # صفحه اصلی
├── styles.css      # استایل‌های شیک
├── app.js          # منطق چت + Firebase
└── README.md       # همین فایل
```

---

## نکات مهم
- برای استفاده واقعی حتماً قوانین Firebase را محدود کنید و احراز هویت اضافه کنید.
- پیام‌ها در Realtime Database ذخیره می‌شوند و real-time هستند.
- حداکثر ۱۰۰ پیام آخر نمایش داده می‌شود.
- نام کاربر در مرورگر ذخیره می‌شود و با بستن اپ پاک نمی‌شود (مگر خروج بزنید).

موفق باشی! 🚀
