# چت ساده - پروژه اندروید (WebView + Firebase)

این پروژه آماده آپلود در **AndroidForge** است.

## قبل از بیلد (خیلی مهم)

1. فایل `app/src/main/assets/www/app.js` را باز کن
2. قسمت `firebaseConfig` را با تنظیمات واقعی پروژه Firebase خودت عوض کن

```js
const firebaseConfig = {
  apiKey: "....",
  authDomain: "....",
  databaseURL: "....",
  projectId: "....",
  storageBucket: "....",
  messagingSenderId: "....",
  appId: "...."
};
```

3. مطمئن شو Realtime Database را در Firebase فعال کرده‌ای و قوانین را باز گذاشته‌ای.

## آپلود در AndroidForge

کل پوشه را زیپ کن و در سایت AndroidForge آپلود کن.
سایت خودش با Gradle بیلد می‌گیرد و APK می‌دهد.
