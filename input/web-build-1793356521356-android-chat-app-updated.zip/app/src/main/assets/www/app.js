// ============================================
// تنظیمات Firebase - این قسمت را با اطلاعات پروژه خودتان عوض کنید
// ============================================
const firebaseConfig = {
  apiKey: "AIzaSyBWkd5Zi_1Pb9zThRGun69VcOwYaNyDckw",
  authDomain: "sample-firebase-ai-app-f211a.firebaseapp.com",
  databaseURL: "https://sample-firebase-ai-app-f211a-default-rtdb.firebaseio.com",
  projectId: "sample-firebase-ai-app-f211a",
  storageBucket: "sample-firebase-ai-app-f211a.firebasestorage.app",
  messagingSenderId: "689511797055",
  appId: "1:689511797055:web:5269152f011d284962438a"
};

// مقداردهی اولیه Firebase
firebase.initializeApp(firebaseConfig);
const db = firebase.database();
const messagesRef = db.ref('messages');
const presenceRef = db.ref('presence');

// عناصر DOM
const loginScreen = document.getElementById('login-screen');
const chatScreen = document.getElementById('chat-screen');
const loginForm = document.getElementById('login-form');
const firstNameInput = document.getElementById('first-name');
const lastNameInput = document.getElementById('last-name');
const messagesContainer = document.getElementById('messages');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');
const sendBtn = document.getElementById('send-btn');
const logoutBtn = document.getElementById('logout-btn');
const onlineCountEl = document.getElementById('online-count');
const replyBar = document.getElementById('reply-bar');
const replyToNameEl = document.getElementById('reply-to-name');
const replyToTextEl = document.getElementById('reply-to-text');
const cancelReplyBtn = document.getElementById('cancel-reply-btn');

let currentUser = null;
let messagesListener = null;
let presenceListener = null;
let myPresenceRef = null;
let replyToMessage = null; // { id, name, text }

// بررسی ورود قبلی
const savedUser = localStorage.getItem('chatUser');
if (savedUser) {
  currentUser = JSON.parse(savedUser);
  showChat();
}

// فرم ورود
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const firstName = firstNameInput.value.trim();
  const lastName = lastNameInput.value.trim();

  if (!firstName || !lastName) return;

  currentUser = {
    firstName,
    lastName,
    fullName: `${firstName} ${lastName}`,
    id: Date.now().toString(36) + Math.random().toString(36).substr(2, 5)
  };

  localStorage.setItem('chatUser', JSON.stringify(currentUser));
  showChat();
});

// خروج
logoutBtn.addEventListener('click', () => {
  if (confirm('آیا می‌خواهید خارج شوید؟')) {
    stopPresence();
    localStorage.removeItem('chatUser');
    currentUser = null;
    if (messagesListener) {
      messagesRef.off('child_added', messagesListener);
      messagesListener = null;
    }
    if (presenceListener) {
      presenceRef.off('value', presenceListener);
      presenceListener = null;
    }
    messagesContainer.innerHTML = '';
    cancelReply();
    chatScreen.classList.remove('active');
    loginScreen.classList.add('active');
    firstNameInput.value = '';
    lastNameInput.value = '';
    onlineCountEl.textContent = 'در حال بارگذاری...';
  }
});

// نمایش صفحه چت
function showChat() {
  loginScreen.classList.remove('active');
  chatScreen.classList.add('active');
  loadMessages();
  setupPresence();
  messageInput.focus();
}

// ==================== حضور آنلاین ====================
function setupPresence() {
  if (!currentUser) return;

  const connectedRef = db.ref('.info/connected');
  connectedRef.on('value', (snap) => {
    if (snap.val() === true) {
      myPresenceRef = presenceRef.child(currentUser.id);
      myPresenceRef.set({
        name: currentUser.fullName,
        lastSeen: firebase.database.ServerValue.TIMESTAMP
      });
      myPresenceRef.onDisconnect().remove();
    }
  });

  // گوش دادن به تعداد آنلاین‌ها
  if (presenceListener) {
    presenceRef.off('value', presenceListener);
  }
  presenceListener = presenceRef.on('value', (snapshot) => {
    const count = snapshot.numChildren();
    if (count === 0) {
      onlineCountEl.textContent = 'هیچ‌کس آنلاین نیست';
    } else if (count === 1) {
      onlineCountEl.textContent = '۱ نفر آنلاین';
    } else {
      onlineCountEl.textContent = `${toPersianNum(count)} نفر آنلاین`;
    }
  });
}

function stopPresence() {
  if (myPresenceRef) {
    myPresenceRef.remove();
    myPresenceRef = null;
  }
}

function toPersianNum(n) {
  const persian = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(n).replace(/\d/g, (d) => persian[d]);
}

// ==================== پیام‌ها ====================
function loadMessages() {
  messagesContainer.innerHTML = '<div class="loading">در حال بارگذاری پیام‌ها...</div>';

  messagesRef.limitToLast(100).once('value', (snapshot) => {
    messagesContainer.innerHTML = '';
    if (!snapshot.exists()) {
      messagesContainer.innerHTML = `
        <div class="empty-state">
          <span>💬</span>
          <p>هنوز پیامی نیست<br>اولین پیام را بفرستید!</p>
        </div>
      `;
    } else {
      snapshot.forEach((child) => {
        appendMessage(child.val(), child.key);
      });
      scrollToBottom();
    }

    if (messagesListener) {
      messagesRef.off('child_added', messagesListener);
    }
    messagesListener = messagesRef.limitToLast(100).on('child_added', (snapshot) => {
      if (document.querySelector(`[data-id="${snapshot.key}"]`)) return;

      const empty = messagesContainer.querySelector('.empty-state');
      if (empty) empty.remove();
      const loading = messagesContainer.querySelector('.loading');
      if (loading) loading.remove();

      appendMessage(snapshot.val(), snapshot.key);
      scrollToBottom();
    });
  });
}

function appendMessage(msg, id) {
  const isMe = msg.userId === currentUser.id;
  const time = formatTime(msg.timestamp);

  const div = document.createElement('div');
  div.className = `message ${isMe ? 'me' : 'other'}`;
  div.dataset.id = id;

  let replyHtml = '';
  if (msg.replyTo) {
    replyHtml = `
      <div class="reply-preview" data-reply-id="${escapeHtml(msg.replyTo.id || '')}">
        <span class="reply-preview-name">${escapeHtml(msg.replyTo.name || '')}</span>
        <span class="reply-preview-text">${escapeHtml(msg.replyTo.text || '')}</span>
      </div>
    `;
  }

  div.innerHTML = `
    <div class="message-meta">
      <span class="message-name">${escapeHtml(msg.name)}</span>
      <span class="message-time">${time}</span>
    </div>
    <div class="message-bubble">
      ${replyHtml}
      ${escapeHtml(msg.text)}
    </div>
    <div class="message-actions">
      <button type="button" class="btn-reply" data-id="${id}" data-name="${escapeHtml(msg.name)}" data-text="${escapeHtml(msg.text)}">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <polyline points="9 17 4 12 9 7"></polyline>
          <path d="M20 18v-2a4 4 0 0 0-4-4H4"></path>
        </svg>
        پاسخ
      </button>
    </div>
  `;

  // کلیک روی دکمه پاسخ
  const replyBtn = div.querySelector('.btn-reply');
  replyBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    setReplyTo({
      id,
      name: msg.name,
      text: msg.text
    });
  });

  // کلیک روی پیش‌نمایش ریپلای برای اسکرول به پیام اصلی
  const replyPreview = div.querySelector('.reply-preview');
  if (replyPreview) {
    replyPreview.addEventListener('click', () => {
      const targetId = replyPreview.dataset.replyId;
      if (targetId) {
        const target = document.querySelector(`[data-id="${targetId}"]`);
        if (target) {
          target.scrollIntoView({ behavior: 'smooth', block: 'center' });
          target.classList.add('highlight');
          setTimeout(() => target.classList.remove('highlight'), 1500);
        }
      }
    });
  }

  // در موبایل با لمس طولانی یا کلیک، دکمه‌ها را نشان بده
  div.addEventListener('click', () => {
    document.querySelectorAll('.message.show-actions').forEach((m) => {
      if (m !== div) m.classList.remove('show-actions');
    });
    div.classList.toggle('show-actions');
  });

  messagesContainer.appendChild(div);
}

// ==================== ریپلای ====================
function setReplyTo(msg) {
  replyToMessage = msg;
  replyToNameEl.textContent = msg.name;
  const shortText = msg.text.length > 40 ? msg.text.slice(0, 40) + '…' : msg.text;
  replyToTextEl.textContent = shortText;
  replyBar.classList.remove('hidden');
  messageInput.focus();
}

function cancelReply() {
  replyToMessage = null;
  replyBar.classList.add('hidden');
  replyToNameEl.textContent = '';
  replyToTextEl.textContent = '';
}

cancelReplyBtn.addEventListener('click', cancelReply);

// ارسال پیام
messageForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const text = messageInput.value.trim();
  if (!text || !currentUser) return;

  sendBtn.disabled = true;

  const message = {
    text,
    name: currentUser.fullName,
    userId: currentUser.id,
    timestamp: firebase.database.ServerValue.TIMESTAMP
  };

  if (replyToMessage) {
    message.replyTo = {
      id: replyToMessage.id,
      name: replyToMessage.name,
      text: replyToMessage.text.length > 80
        ? replyToMessage.text.slice(0, 80) + '…'
        : replyToMessage.text
    };
  }

  messagesRef.push(message)
    .then(() => {
      messageInput.value = '';
      sendBtn.disabled = true;
      cancelReply();
      messageInput.focus();
    })
    .catch((err) => {
      console.error('خطا در ارسال:', err);
      alert('خطا در ارسال پیام. اتصال اینترنت و تنظیمات Firebase را بررسی کنید.');
      sendBtn.disabled = false;
    });
});

// فعال/غیرفعال کردن دکمه ارسال
messageInput.addEventListener('input', () => {
  sendBtn.disabled = messageInput.value.trim().length === 0;
});

// اسکرول به پایین
function scrollToBottom() {
  requestAnimationFrame(() => {
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
  });
}

// فرمت زمان
function formatTime(timestamp) {
  if (!timestamp) return '';
  const date = new Date(timestamp);
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();

  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');

  if (isToday) {
    return `${hours}:${minutes}`;
  }
  return `${date.getDate()}/${date.getMonth() + 1} ${hours}:${minutes}`;
}

// جلوگیری از XSS
function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// پشتیبانی از Enter برای ارسال
messageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    if (!sendBtn.disabled) {
      messageForm.dispatchEvent(new Event('submit'));
    }
  }
});

// پاک کردن حضور هنگام بستن صفحه
window.addEventListener('beforeunload', () => {
  stopPresence();
});
