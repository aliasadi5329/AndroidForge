import { useState, useEffect, useMemo } from 'react';
import {
  Download,
  FileArchive,
  CheckCircle2,
  Code2,
  Smartphone,
  Settings2,
  Copy,
  Check,
  Sparkles,
  FolderTree,
  ShieldCheck,
  Cpu,
  Layers,
  ExternalLink,
  RefreshCw,
  FileCode,
  HelpCircle,
} from 'lucide-react';
import {
  DEFAULT_PROJECT_CONFIG,
  ProjectConfig,
  ProjectFile,
  THEME_PRESETS,
  generateProjectFiles,
} from './data/kotlinProjectTemplate';
import {
  createKotlinProjectZipBlob,
  triggerBlobDownload,
} from './utils/zipBuilder';
import { AndroidNotepadSimulator } from './components/AndroidNotepadSimulator';

export function App() {
  const [config, setConfig] = useState<ProjectConfig>(DEFAULT_PROJECT_CONFIG);
  const [wrapInFolder, setWrapInFolder] = useState<boolean>(true);
  const [selectedFileIndex, setSelectedFileIndex] = useState<number>(7); // Default to MainActivity.kt
  const [customOverrides, setCustomOverrides] = useState<Record<string, string>>({});
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<boolean>(false);
  const [zipStats, setZipStats] = useState<{ fileCount: number; sizeKB: string }>({
    fileCount: 21,
    sizeKB: '14.8',
  });
  const [copiedFile, setCopiedFile] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'overview' | 'code' | 'guide'>('overview');

  // Generate files from current config + any manual code edits
  const projectFiles: ProjectFile[] = useMemo(() => {
    const baseFiles = generateProjectFiles(config);
    return baseFiles.map((file) => {
      if (customOverrides[file.path] !== undefined) {
        return { ...file, content: customOverrides[file.path] };
      }
      return file;
    });
  }, [config, customOverrides]);

  // Keep selected file valid
  const activeFile = projectFiles[selectedFileIndex] || projectFiles[0];

  // Calculate real ZIP size whenever files change
  useEffect(() => {
    let mounted = true;
    createKotlinProjectZipBlob(config, projectFiles, wrapInFolder).then((res) => {
      if (mounted) {
        setZipStats({ fileCount: res.fileCount, sizeKB: res.sizeKB });
      }
    });
    return () => {
      mounted = false;
    };
  }, [config, projectFiles, wrapInFolder]);

  const handleDownloadZip = async (folderMode = wrapInFolder) => {
    setIsDownloading(true);
    try {
      const { blob } = await createKotlinProjectZipBlob(
        config,
        projectFiles,
        folderMode
      );
      const safeName =
        config.packageName.split('.').pop() || 'SimpleNotepad';
      const filename = `${safeName}-Kotlin-AndroidForge.zip`;
      triggerBlobDownload(blob, filename);
      setDownloadSuccess(true);
      setTimeout(() => setDownloadSuccess(false), 4000);
    } finally {
      setIsDownloading(false);
    }
  };

  const handleCopyCode = () => {
    if (!activeFile) return;
    navigator.clipboard.writeText(activeFile.content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  const handleResetConfig = () => {
    setConfig(DEFAULT_PROJECT_CONFIG);
    setCustomOverrides({});
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col" dir="rtl">
      {/* Top Banner */}
      <header className="border-b border-slate-800/80 bg-slate-900/70 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-lg shadow-emerald-500/20">
              <FileArchive className="w-6 h-6 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-extrabold text-base sm:text-lg text-white">
                  پروژه دفترچه یادداشت کاتلین (Kotlin Notepad)
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-500/15 text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" />
                  آماده برای AndroidForge
                </span>
              </div>
              <p className="text-xs text-slate-400">
                سورس کامل اندروید استودیو و Gradle • بدون خطای کامپایل • خروجی مستقیم فایل ZIP
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={() => handleDownloadZip(wrapInFolder)}
              disabled={isDownloading}
              className="flex items-center gap-2 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-extrabold text-xs sm:text-sm px-4 sm:px-5 py-2.5 rounded-xl shadow-lg shadow-emerald-500/25 active:scale-95 transition cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>دانلود فوری فایل ZIP</span>
              <span className="bg-slate-950/20 px-2 py-0.5 rounded-md text-[11px] font-mono">
                {zipStats.sizeKB} KB
              </span>
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-8">
        {/* HERO DOWNLOAD CARD - Immediate Primary Action */}
        <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/60 border border-emerald-500/30 p-6 sm:p-8 shadow-2xl">
          <div className="absolute -top-24 -left-24 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-8 space-y-4">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                <Sparkles className="w-3.5 h-3.5" />
                <span>تست‌شده و بهینه‌شده ویژه تبدیل به APK در سایت AndroidForge</span>
              </div>

              <h2 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                فایل ZIP پروژه دفترچه یادداشت ساده با زبان{' '}
                <span className="text-emerald-400">Kotlin</span> آماده دانلود است!
              </h2>

              <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
                این فایل فشرده شامل تمامی فایل‌های استاندارد یک پروژه اندروید کاتلین (
                <code className="text-emerald-300 bg-slate-800/80 px-1.5 py-0.5 rounded text-xs">
                  settings.gradle
                </code>
                ،{' '}
                <code className="text-emerald-300 bg-slate-800/80 px-1.5 py-0.5 rounded text-xs">
                  build.gradle
                </code>
                ،{' '}
                <code className="text-emerald-300 bg-slate-800/80 px-1.5 py-0.5 rounded text-xs">
                  AndroidManifest.xml
                </code>
                ، کلاس‌های کاتلین دیتابیس SQLite و رابط کاربری XML) است. کافیست فایل ZIP زیر را دانلود کرده و مستقیماً در{' '}
                <strong className="text-white">AndroidForge</strong> آپلود کنید تا فایل نصبی{' '}
                <strong className="text-emerald-400">.apk</strong> را تحویل بگیرید.
              </p>

              {/* Technical Spec Pills */}
              <div className="flex flex-wrap gap-2 pt-1">
                <span className="px-3 py-1 rounded-lg bg-slate-800/90 border border-slate-700 text-xs text-slate-200 flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                  Kotlin 1.9.22
                </span>
                <span className="px-3 py-1 rounded-lg bg-slate-800/90 border border-slate-700 text-xs text-slate-200 flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" />
                  AGP 8.2.2 / Gradle 8.2
                </span>
                <span className="px-3 py-1 rounded-lg bg-slate-800/90 border border-slate-700 text-xs text-slate-200 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                  MinSDK {config.minSdk} / TargetSDK {config.targetSdk}
                </span>
                <span className="px-3 py-1 rounded-lg bg-slate-800/90 border border-slate-700 text-xs text-slate-200 flex items-center gap-1.5">
                  <FolderTree className="w-3.5 h-3.5 text-purple-400" />
                  {zipStats.fileCount} فایل استاندارد
                </span>
              </div>
            </div>

            {/* Download Action Box */}
            <div className="lg:col-span-4 bg-slate-950/80 border border-slate-800 rounded-2xl p-5 flex flex-col gap-3.5 shadow-inner">
              <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2.5">
                <span>نام فایل خروجی:</span>
                <span className="font-mono text-emerald-400 font-semibold truncate max-w-[180px]" dir="ltr">
                  SimpleNotepad-Kotlin.zip
                </span>
              </div>

              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={wrapInFolder}
                  onChange={(e) => setWrapInFolder(e.target.checked)}
                  className="rounded accent-emerald-500 w-4 h-4"
                />
                <span>قرار دادن فایل‌ها داخل پوشه اصلی SimpleNotepad/</span>
              </label>

              <button
                onClick={() => handleDownloadZip(wrapInFolder)}
                disabled={isDownloading}
                className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm sm:text-base shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2.5 active:scale-[0.99] transition cursor-pointer"
              >
                <Download className="w-5 h-5" />
                <span>دانلود فایل ZIP پروژه کاتلین</span>
              </button>

              <button
                onClick={() => handleDownloadZip(false)}
                disabled={isDownloading}
                className="w-full py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700 flex items-center justify-center gap-1.5 transition cursor-pointer"
              >
                <FileArchive className="w-3.5 h-3.5 text-emerald-400" />
                <span>دانلود ZIP بدون پوشه میانی (مستقیم در Root)</span>
              </button>

              {downloadSuccess && (
                <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 rounded-lg py-2 px-3 animate-pulse">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>فایل ZIP با موفقیت دانلود شد! آماده آپلود در AndroidForge</span>
                </div>
              )}
            </div>
          </div>
        </section>

        {/* Navigation Tabs */}
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>پیش‌نمایش زنده و شخصی‌سازی برنامه</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeTab === 'code'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>مشاهده و ویرایش کدهای کاتلین ({projectFiles.length} فایل)</span>
          </button>

          <button
            onClick={() => setActiveTab('guide')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer ${
              activeTab === 'guide'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
            }`}
          >
            <HelpCircle className="w-4 h-4" />
            <span>راهنمای تبدیل به APK در AndroidForge</span>
          </button>
        </div>

        {/* TAB 1: OVERVIEW (SIMULATOR + CUSTOMIZER) */}
        {activeTab === 'overview' && (
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left/Right Column: Customizer & Features */}
            <div className="lg:col-span-7 space-y-6">
              {/* Customizer Card */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3.5">
                  <div className="flex items-center gap-2.5">
                    <Settings2 className="w-5 h-5 text-emerald-400" />
                    <h3 className="font-bold text-base sm:text-lg text-white">
                      شخصی‌سازی مشخصات APK قبل از دانلود ZIP
                    </h3>
                  </div>
                  <button
                    type="button"
                    onClick={handleResetConfig}
                    className="text-xs text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>بازنشانی پیش‌فرض</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">
                      نام برنامه (نمایش زیر آیکون گوشی):
                    </label>
                    <input
                      type="text"
                      value={config.appName}
                      onChange={(e) =>
                        setConfig((prev) => ({ ...prev, appName: e.target.value }))
                      }
                      placeholder="دفترچه یادداشت من"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">
                      شناسه پکیج (Package Name):
                    </label>
                    <input
                      type="text"
                      dir="ltr"
                      value={config.packageName}
                      onChange={(e) =>
                        setConfig((prev) => ({
                          ...prev,
                          packageName: e.target.value,
                        }))
                      }
                      placeholder="com.example.simplenotepad"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-sm font-mono text-emerald-300 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                {/* Theme Presets */}
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-2">
                    رنگ اصلی برنامه (Theme Color):
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                    {THEME_PRESETS.map((preset) => {
                      const isSelected = config.primaryColor === preset.primaryColor;
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() =>
                            setConfig((prev) => ({
                              ...prev,
                              primaryColor: preset.primaryColor,
                              primaryDarkColor: preset.primaryDarkColor,
                              accentColor: preset.accentColor,
                            }))
                          }
                          className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                            isSelected
                              ? 'bg-slate-800 border-emerald-500 text-white shadow-sm'
                              : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:border-slate-700'
                          }`}
                        >
                          <span
                            className="w-4 h-4 rounded-full shrink-0"
                            style={{ backgroundColor: preset.primaryColor }}
                          />
                          <span className="truncate">{preset.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* SDK & Starter Notes Options */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-slate-300 mb-1.5">
                      حداقل نسخه اندروید (Min SDK):
                    </label>
                    <select
                      value={config.minSdk}
                      onChange={(e) =>
                        setConfig((prev) => ({
                          ...prev,
                          minSdk: Number(e.target.value),
                        }))
                      }
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
                    >
                      <option value={21}>Android 5.0 (API 21)</option>
                      <option value={24}>Android 7.0 (API 24 - پیشنهادی)</option>
                      <option value={26}>Android 8.0 (API 26)</option>
                    </select>
                  </div>

                  <div className="flex items-end pb-1">
                    <label className="flex items-center gap-2.5 text-xs text-slate-300 cursor-pointer select-none bg-slate-950/70 border border-slate-800 px-3.5 py-2.5 rounded-xl w-full">
                      <input
                        type="checkbox"
                        checked={config.includeSampleNotes}
                        onChange={(e) =>
                          setConfig((prev) => ({
                            ...prev,
                            includeSampleNotes: e.target.checked,
                          }))
                        }
                        className="rounded accent-emerald-500 w-4 h-4"
                      />
                      <span>درج ۲ یادداشت راهنمای اولیه در دیتابیس SQLite</span>
                    </label>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
                  <span className="text-xs text-slate-400">
                    هر تغییری که بدهید بلافاصله در کدهای کاتلین و فایل ZIP اعمال می‌شود.
                  </span>
                  <button
                    type="button"
                    onClick={() => handleDownloadZip(wrapInFolder)}
                    className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs px-4 py-2.5 rounded-xl transition cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>دانلود ZIP با این تنظیمات</span>
                  </button>
                </div>
              </div>

              {/* Why this project works 100% on AndroidForge */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
                <h3 className="font-bold text-base text-white flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-400" />
                  <span>چرا این فایل ZIP بدون هیچ خطایی در AndroidForge به APK تبدیل می‌شود؟</span>
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>هماهنگ با اسکریپت تشخیص AndroidForge</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      شامل فایل‌های استاندارد <code className="text-slate-200">settings.gradle</code> و{' '}
                      <code className="text-slate-200">build.gradle</code> با پلاگین رسمی کاتلین و AGP 8.2.2.
                    </p>
                  </div>

                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>دیتابیس SQLite بومی بدون خطای KAPT</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      به‌جای کتابخانه‌های سنگین که در بیلدهای ابری خطا می‌دهند، از{' '}
                      <code className="text-slate-200">SQLiteOpenHelper</code> استاندارد خود اندروید استفاده شده است.
                    </p>
                  </div>

                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>آیکون وکتوری داخلی (VectorDrawable)</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      تمام آیکون‌ها و پس‌زمینه‌ها با کد XML ساخته شده‌اند تا خطای AAPT2 یا فایل تصویری خراب رخ ندهد.
                    </p>
                  </div>

                  <div className="bg-slate-950/70 border border-slate-800/80 rounded-xl p-3.5 space-y-1">
                    <div className="font-bold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>پشتیبانی کامل از فارسی و راست‌چین</span>
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      دارای قابلیت افزودن، ویرایش، حذف، سنجاق کردن (Pin)، رنگ‌بندی کارت‌ها، جستجو و اشتراک‌گذاری یادداشت.
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Simulator Column */}
            <div className="lg:col-span-5 flex flex-col items-center">
              <AndroidNotepadSimulator config={config} />
            </div>
          </section>
        )}

        {/* TAB 2: SOURCE CODE EXPLORER & EDITOR */}
        {activeTab === 'code' && (
          <section className="grid grid-cols-1 lg:grid-cols-12 gap-6 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            {/* File Tree Sidebar */}
            <div className="lg:col-span-4 border-b lg:border-b-0 lg:border-l border-slate-800 bg-slate-950/60 p-4 flex flex-col max-h-[680px]">
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <FolderTree className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-xs sm:text-sm text-white">
                    فایل‌های داخل بسته ZIP ({projectFiles.length})
                  </span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">
                  {zipStats.sizeKB} KB
                </span>
              </div>

              <div className="flex-1 overflow-y-auto space-y-1 pl-1">
                {projectFiles.map((file, idx) => {
                  const isSelected = idx === selectedFileIndex;
                  const isKotlin = file.language === 'kotlin';
                  return (
                    <button
                      key={file.path}
                      onClick={() => setSelectedFileIndex(idx)}
                      className={`w-full text-right px-3 py-2.5 rounded-xl flex items-center justify-between gap-2 transition cursor-pointer ${
                        isSelected
                          ? 'bg-emerald-500/15 border border-emerald-500/40 text-emerald-300'
                          : 'hover:bg-slate-800/70 text-slate-300 border border-transparent'
                      }`}
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-1.5">
                          <FileCode
                            className={`w-4 h-4 shrink-0 ${
                              isKotlin
                                ? 'text-purple-400'
                                : file.language === 'xml'
                                ? 'text-amber-400'
                                : 'text-cyan-400'
                            }`}
                          />
                          <span className="font-mono text-xs font-semibold truncate" dir="ltr">
                            {file.name}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate mt-0.5">
                          {file.description}
                        </p>
                      </div>
                      <span
                        className={`text-[10px] font-mono px-1.5 py-0.5 rounded uppercase shrink-0 ${
                          isKotlin
                            ? 'bg-purple-500/20 text-purple-300'
                            : file.language === 'xml'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {file.language}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Code Content Area */}
            <div className="lg:col-span-8 flex flex-col max-h-[680px]">
              <div className="p-4 border-b border-slate-800 bg-slate-900 flex flex-wrap items-center justify-between gap-3">
                <div>
                  <div className="font-mono text-xs sm:text-sm font-bold text-emerald-400" dir="ltr">
                    {wrapInFolder ? `SimpleNotepad/${activeFile.path}` : activeFile.path}
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{activeFile.description}</p>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleCopyCode}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition cursor-pointer"
                  >
                    {copiedFile ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-400">کپی شد</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>کپی کد</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => handleDownloadZip(wrapInFolder)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>دانلود کل پروژه (ZIP)</span>
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-auto bg-[#0B1120] p-4" dir="ltr">
                <textarea
                  value={activeFile.content}
                  onChange={(e) =>
                    setCustomOverrides((prev) => ({
                      ...prev,
                      [activeFile.path]: e.target.value,
                    }))
                  }
                  spellCheck={false}
                  className="w-full h-[540px] bg-transparent text-slate-200 font-mono text-xs sm:text-[13px] leading-relaxed focus:outline-none resize-none"
                />
              </div>
            </div>
          </section>
        )}

        {/* TAB 3: ANDROIDFORGE STEP-BY-STEP GUIDE */}
        {activeTab === 'guide' && (
          <section className="bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-8 space-y-6">
            <div className="border-b border-slate-800 pb-4">
              <h3 className="text-lg sm:text-xl font-black text-white flex items-center gap-2.5">
                <ExternalLink className="w-5 h-5 text-emerald-400" />
                <span>مراحل تبدیل فایل ZIP به APK در AndroidForge</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                پروژه شما دقیقاً مطابق ساختار مورد نیاز سیستم بیلد خودکار AndroidForge آماده شده است.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 font-black flex items-center justify-center text-base">
                  ۱
                </div>
                <h4 className="font-bold text-white text-sm sm:text-base">
                  دانلود فایل ZIP از همین صفحه
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  روی دکمه سبز رنگ <strong className="text-slate-200">«دانلود فایل ZIP پروژه کاتلین»</strong> در بالای صفحه کلیک کنید تا فایل{' '}
                  <code className="text-emerald-300">SimpleNotepad-Kotlin-AndroidForge.zip</code> در گوشی یا کامپیوتر شما ذخیره شود.
                </p>
              </div>

              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 font-black flex items-center justify-center text-base">
                  ۲
                </div>
                <h4 className="font-bold text-white text-sm sm:text-base">
                  آپلود فایل ZIP در AndroidForge
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  وارد سایت یا مخزن <strong className="text-slate-200">AndroidForge</strong> خود شوید. فایل ZIP دانلودشده را در پوشه{' '}
                  <code className="text-emerald-300">input/</code> قرار دهید یا در بخش انتخاب فایل ZIP آپلود نمایید (نیازی به استخراج کردن فایل ZIP نیست).
                </p>
              </div>

              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 space-y-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 font-black flex items-center justify-center text-base">
                  ۳
                </div>
                <h4 className="font-bold text-white text-sm sm:text-base">
                  اجرای Build و دریافت APK
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed">
                  ورک‌فلوی <strong className="text-slate-200">Build Android APK</strong> را اجرا کنید. سیستم به صورت خودکار پروژه{' '}
                  <code className="text-emerald-300">Gradle (Kotlin)</code> را تشخیص داده و پس از حدود ۱ تا ۲ دقیقه فایل{' '}
                  <strong className="text-emerald-400">.apk</strong> آماده نصب روی گوشی را به شما تحویل می‌دهد.
                </p>
              </div>
            </div>

            <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
              <div className="space-y-1">
                <h4 className="font-bold text-sm sm:text-base text-emerald-300">
                  آماده دریافت فایل ZIP هستید؟
                </h4>
                <p className="text-xs text-slate-300">
                  همین حالا فایل فشرده را دانلود کنید و در AndroidForge به APK تبدیل نمایید.
                </p>
              </div>
              <button
                onClick={() => handleDownloadZip(wrapInFolder)}
                className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-xs sm:text-sm px-5 py-3 rounded-xl shadow-lg transition cursor-pointer"
              >
                <Download className="w-4 h-4" />
                <span>دانلود فایل ZIP پروژه کاتلین</span>
              </button>
            </div>
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-900 bg-slate-950 py-5 px-4 text-center text-xs text-slate-500">
        ساخته‌شده با زبان کاتلین (Kotlin 1.9.22) و استاندارد Gradle 8.2 • آماده کامپایل مستقیم به APK در AndroidForge
      </footer>
    </div>
  );
}
export default App;
