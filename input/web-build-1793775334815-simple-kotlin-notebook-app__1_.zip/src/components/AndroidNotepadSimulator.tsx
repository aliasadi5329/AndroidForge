import React, { useState, useMemo } from 'react';
import {
  Plus,
  Search,
  Trash2,
  Share2,
  Pin,
  X,
  Check,
  Wifi,
  BatteryCharging,
  Signal,
} from 'lucide-react';
import { ProjectConfig } from '../data/kotlinProjectTemplate';

export interface SimNote {
  id: number;
  title: string;
  content: string;
  createdAt: string;
  colorIndex: number;
  isPinned: boolean;
}

const CARD_COLORS = [
  { index: 0, label: 'سفید', hex: '#FFFFFF', border: '#E2E8F0' },
  { index: 1, label: 'زرد', hex: '#FEF3C7', border: '#FDE68A' },
  { index: 2, label: 'سبز', hex: '#D1FAE5', border: '#A7F3D0' },
  { index: 3, label: 'آبی', hex: '#DBEAFE', border: '#BFDBFE' },
  { index: 4, label: 'صورتی', hex: '#FCE7F3', border: '#FBCFE8' },
];

interface AndroidNotepadSimulatorProps {
  config: ProjectConfig;
}

export const AndroidNotepadSimulator: React.FC<AndroidNotepadSimulatorProps> = ({ config }) => {
  const [notes, setNotes] = useState<SimNote[]>([
    {
      id: 1,
      title: 'خوش آمدید به دفترچه یادداشت!',
      content:
        'این برنامه با زبان کاتلین (Kotlin) ساخته شده است. برای افزودن یادداشت جدید روی دکمه + پایین صفحه بزنید.',
      createdAt: '1404/02/15 - 10:30',
      colorIndex: 0,
      isPinned: true,
    },
    {
      id: 2,
      title: 'لیست خرید روزانه',
      content: '۱. نان تازه و پنیر\n۲. میوه و سبزیجات\n۳. شیر و قهوه',
      createdAt: '1404/02/15 - 11:15',
      colorIndex: 1,
      isPinned: false,
    },
    {
      id: 3,
      title: 'کارهای مهم هفته',
      content: 'تبدیل فایل ZIP پروژه کاتلین به APK در سایت AndroidForge و نصب روی گوشی اندروید.',
      createdAt: '1404/02/15 - 14:20',
      colorIndex: 2,
      isPinned: false,
    },
  ]);

  const [searchQuery, setSearchQuery] = useState('');
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<SimNote | null>(null);
  const [titleInput, setTitleInput] = useState('');
  const [contentInput, setContentInput] = useState('');
  const [selectedColor, setSelectedColor] = useState(0);
  const [isPinnedInput, setIsPinnedInput] = useState(false);
  const [deleteConfirmNote, setDeleteConfirmNote] = useState<SimNote | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((prev) => (prev === msg ? null : prev));
    }, 2400);
  };

  const filteredNotes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = notes.filter((n) => {
      if (!q) return true;
      return (
        n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q)
      );
    });
    return [...list].sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
      return b.id - a.id;
    });
  }, [notes, searchQuery]);

  const openAddDialog = () => {
    setEditingNote(null);
    setTitleInput('');
    setContentInput('');
    setSelectedColor(0);
    setIsPinnedInput(false);
    setDialogOpen(true);
  };

  const openEditDialog = (note: SimNote) => {
    setEditingNote(note);
    setTitleInput(note.title);
    setContentInput(note.content);
    setSelectedColor(note.colorIndex);
    setIsPinnedInput(note.isPinned);
    setDialogOpen(true);
  };

  const handleSaveNote = () => {
    if (!titleInput.trim() && !contentInput.trim()) {
      showToast('لطفاً عنوان یا متن یادداشت را وارد کنید');
      return;
    }

    const finalTitle = titleInput.trim() || 'یادداشت بدون عنوان';
    const now = new Date();
    const timeStr = `1404/02/15 - ${String(now.getHours()).padStart(2, '0')}:${String(
      now.getMinutes()
    ).padStart(2, '0')}`;

    if (editingNote) {
      setNotes((prev) =>
        prev.map((item) =>
          item.id === editingNote.id
            ? {
                ...item,
                title: finalTitle,
                content: contentInput.trim(),
                createdAt: timeStr,
                colorIndex: selectedColor,
                isPinned: isPinnedInput,
              }
            : item
        )
      );
      showToast('یادداشت بروزرسانی شد');
    } else {
      const newNote: SimNote = {
        id: Date.now(),
        title: finalTitle,
        content: contentInput.trim(),
        createdAt: timeStr,
        colorIndex: selectedColor,
        isPinned: isPinnedInput,
      };
      setNotes((prev) => [newNote, ...prev]);
      showToast('یادداشت با موفقیت ذخیره شد');
    }
    setDialogOpen(false);
  };

  const handleTogglePin = (note: SimNote, e: React.MouseEvent) => {
    e.stopPropagation();
    setNotes((prev) =>
      prev.map((n) => (n.id === note.id ? { ...n, isPinned: !n.isPinned } : n))
    );
    showToast(note.isPinned ? 'سنجاق برداشته شد' : 'یادداشت سنجاق شد 📌');
  };

  const handleShareNote = (note: SimNote, e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.clipboard) {
      navigator.clipboard.writeText(`${note.title}\n\n${note.content}`);
    }
    showToast(`«${note.title}» برای اشتراک‌گذاری کپی شد`);
  };

  const confirmDelete = () => {
    if (!deleteConfirmNote) return;
    setNotes((prev) => prev.filter((n) => n.id !== deleteConfirmNote.id));
    setDeleteConfirmNote(null);
    showToast('یادداشت حذف شد');
  };

  return (
    <div className="flex flex-col items-center">
      {/* Phone Frame */}
      <div className="relative w-[330px] sm:w-[350px] h-[660px] rounded-[42px] bg-slate-900 p-3 shadow-2xl border-4 border-slate-700/80 ring-1 ring-white/10">
        {/* Speaker Notch */}
        <div className="absolute top-5 left-1/2 -translate-x-1/2 z-30 w-24 h-5 bg-slate-950 rounded-full flex items-center justify-center gap-2">
          <div className="w-2 h-2 rounded-full bg-slate-800" />
          <div className="w-10 h-1 rounded-full bg-slate-800" />
        </div>

        {/* Screen Content */}
        <div
          className="relative w-full h-full rounded-[32px] overflow-hidden flex flex-col bg-[#F8FAFC] text-slate-900 select-none"
          dir="rtl"
        >
          {/* Android Status Bar */}
          <div
            className="pt-2 pb-1.5 px-5 flex items-center justify-between text-white text-[11px] font-medium"
            style={{ backgroundColor: config.primaryDarkColor }}
          >
            <span>12:45</span>
            <div className="flex items-center gap-1.5">
              <Signal className="w-3 h-3" />
              <Wifi className="w-3 h-3" />
              <BatteryCharging className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* App Header (activity_main.xml headerContainer) */}
          <div
            className="px-4 pt-3 pb-3.5 shadow-md transition-colors"
            style={{ backgroundColor: config.primaryColor }}
          >
            <div className="flex items-center justify-between">
              <h3 className="text-white font-bold text-lg truncate max-w-[200px]">
                {config.appName || 'دفترچه یادداشت من'}
              </h3>
              <span
                className="bg-white px-2.5 py-0.5 rounded-xl text-xs font-bold shadow-xs"
                style={{ color: config.primaryDarkColor }}
              >
                {filteredNotes.length} یادداشت
              </span>
            </div>

            {/* Search Input (etSearch) */}
            <div className="mt-3 relative">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="جستجو در عنوان یا متن یادداشت‌ها..."
                className="w-full h-10 bg-white rounded-xl pr-3.5 pl-9 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none shadow-inner"
              />
              {searchQuery ? (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
                >
                  <X className="w-4 h-4" />
                </button>
              ) : (
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              )}
            </div>
          </div>

          {/* Notes RecyclerView (rvNotes) */}
          <div className="flex-1 overflow-y-auto p-3 space-y-2.5 pb-20">
            {filteredNotes.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6">
                <div className="text-4xl mb-2">📝</div>
                <p className="text-slate-700 font-bold text-sm">
                  هنوز هیچ یادداشتی ثبت نشده است
                </p>
                <p className="text-slate-500 text-xs mt-1 leading-relaxed">
                  برای نوشتن اولین یادداشت، روی دکمه + پایین صفحه بزنید
                </p>
              </div>
            ) : (
              filteredNotes.map((note) => {
                const colorObj =
                  CARD_COLORS.find((c) => c.index === note.colorIndex) ||
                  CARD_COLORS[0];
                return (
                  <div
                    key={note.id}
                    onClick={() => openEditDialog(note)}
                    style={{
                      backgroundColor: colorObj.hex,
                      borderColor: colorObj.border,
                    }}
                    className="rounded-2xl p-3.5 shadow-xs border cursor-pointer transition-transform active:scale-[0.99] hover:shadow-md"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="font-bold text-slate-900 text-sm truncate">
                        {note.title}
                      </h4>
                      {note.isPinned && (
                        <span
                          className="shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-lg bg-white/80 border border-slate-200"
                          style={{ color: config.primaryDarkColor }}
                        >
                          📌 سنجاق‌شده
                        </span>
                      )}
                    </div>

                    <p className="text-slate-700 text-xs mt-1.5 whitespace-pre-line line-clamp-3 leading-relaxed">
                      {note.content}
                    </p>

                    <div className="mt-3 pt-2 border-t border-black/5 flex items-center justify-between">
                      <span className="text-[10px] text-slate-500 font-mono">
                        {note.createdAt}
                      </span>

                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={(e) => handleTogglePin(note, e)}
                          title="سنجاق کردن"
                          className={`p-1.5 rounded-lg hover:bg-black/5 transition ${
                            note.isPinned ? 'text-amber-600' : 'text-slate-400'
                          }`}
                        >
                          <Pin className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => handleShareNote(note, e)}
                          title="اشتراک‌گذاری"
                          className="p-1.5 rounded-lg text-slate-500 hover:bg-black/5 transition"
                        >
                          <Share2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setDeleteConfirmNote(note);
                          }}
                          title="حذف یادداشت"
                          className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* FloatingActionButton (fabAddNote) */}
          <button
            type="button"
            onClick={openAddDialog}
            style={{ backgroundColor: config.primaryColor }}
            className="absolute bottom-6 left-5 w-13 h-13 rounded-full text-white shadow-lg flex items-center justify-center hover:brightness-110 active:scale-95 transition z-10 cursor-pointer"
            title="افزودن یادداشت جدید"
          >
            <Plus className="w-6 h-6" />
          </button>

          {/* Add / Edit Dialog (dialog_note.xml simulation) */}
          {dialogOpen && (
            <div className="absolute inset-0 bg-black/50 z-20 flex items-center justify-center p-4 animate-fade-in">
              <div className="bg-white w-full rounded-2xl p-4 shadow-xl border border-slate-100">
                <div className="flex items-center justify-between mb-3">
                  <h4
                    className="font-bold text-base"
                    style={{ color: config.primaryDarkColor }}
                  >
                    {editingNote ? 'ویرایش یادداشت' : 'یادداشت جدید'}
                  </h4>
                  <button
                    type="button"
                    onClick={() => setDialogOpen(false)}
                    className="text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <input
                  type="text"
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  placeholder="عنوان یادداشت..."
                  className="w-full bg-slate-100 border border-slate-200 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500"
                />

                <textarea
                  rows={4}
                  value={contentInput}
                  onChange={(e) => setContentInput(e.target.value)}
                  placeholder="متن یادداشت خود را اینجا بنویسید..."
                  className="w-full mt-2.5 bg-slate-100 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 placeholder:text-slate-400 focus:outline-none focus:border-emerald-500 resize-none"
                />

                <div className="mt-2.5">
                  <span className="block text-[11px] font-bold text-slate-600 mb-1.5">
                    رنگ پس‌زمینه کارت:
                  </span>
                  <div className="flex items-center gap-2">
                    {CARD_COLORS.map((c) => (
                      <button
                        key={c.index}
                        type="button"
                        onClick={() => setSelectedColor(c.index)}
                        style={{ backgroundColor: c.hex }}
                        className={`w-7 h-7 rounded-full border-2 flex items-center justify-center transition ${
                          selectedColor === c.index
                            ? 'border-slate-900 scale-110'
                            : 'border-slate-300'
                        }`}
                        title={c.label}
                      >
                        {selectedColor === c.index && (
                          <Check className="w-3.5 h-3.5 text-slate-800" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <label className="mt-3 flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isPinnedInput}
                    onChange={(e) => setIsPinnedInput(e.target.checked)}
                    className="rounded accent-emerald-600"
                  />
                  <span>سنجاق کردن در بالای لیست (📌)</span>
                </label>

                <div className="mt-4 flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setDialogOpen(false)}
                    className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 hover:bg-slate-100"
                  >
                    انصراف
                  </button>
                  <button
                    type="button"
                    onClick={handleSaveNote}
                    style={{ backgroundColor: config.primaryColor }}
                    className="px-4 py-1.5 rounded-lg text-xs font-bold text-white shadow-xs hover:brightness-110"
                  >
                    ذخیره
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Delete Confirmation AlertDialog */}
          {deleteConfirmNote && (
            <div className="absolute inset-0 bg-black/50 z-20 flex items-center justify-center p-5">
              <div className="bg-white w-full rounded-2xl p-4 shadow-xl">
                <h5 className="font-bold text-sm text-slate-900">حذف یادداشت</h5>
                <p className="text-xs text-slate-600 mt-1.5 leading-relaxed">
                  آیا مطمئن هستید که می‌خواهید «{deleteConfirmNote.title}» را حذف کنید؟
                </p>
                <div className="mt-4 flex items-center justify-end gap-2">
                  <button
                    type="button"
                    onClick={() => setDeleteConfirmNote(null)}
                    className="px-3 py-1.5 rounded-lg text-xs text-slate-600 hover:bg-slate-100"
                  >
                    لغو
                  </button>
                  <button
                    type="button"
                    onClick={confirmDelete}
                    className="px-3.5 py-1.5 rounded-lg text-xs font-bold bg-rose-600 text-white hover:bg-rose-500"
                  >
                    حذف
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Android Toast Notification */}
          {toastMessage && (
            <div className="absolute bottom-14 left-1/2 -translate-x-1/2 z-30 bg-slate-900/90 text-white text-[11px] px-3.5 py-2 rounded-full shadow-lg whitespace-nowrap">
              {toastMessage}
            </div>
          )}

          {/* Android Navigation Bar */}
          <div className="h-5 bg-slate-900 flex items-center justify-center">
            <div className="w-24 h-1 rounded-full bg-slate-500" />
          </div>
        </div>
      </div>
      <p className="text-xs text-slate-400 mt-3 text-center">
        پیش‌نمایش زنده اپلیکیشن کاتلین (روی دکمه <span className="text-emerald-400 font-bold">+</span> یا کارت‌ها کلیک کنید)
      </p>
    </div>
  );
};
