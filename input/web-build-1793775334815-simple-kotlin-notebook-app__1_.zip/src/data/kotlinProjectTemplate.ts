export interface ProjectConfig {
  appName: string;
  packageName: string;
  primaryColor: string;
  primaryDarkColor: string;
  accentColor: string;
  minSdk: number;
  targetSdk: number;
  includeSampleNotes: boolean;
}

export interface ProjectFile {
  path: string;
  name: string;
  folder: string;
  language: 'kotlin' | 'xml' | 'groovy' | 'properties' | 'markdown';
  description: string;
  content: string;
}

export const DEFAULT_PROJECT_CONFIG: ProjectConfig = {
  appName: 'دفترچه یادداشت من',
  packageName: 'com.example.simplenotepad',
  primaryColor: '#10B981',
  primaryDarkColor: '#059669',
  accentColor: '#F59E0B',
  minSdk: 24,
  targetSdk: 34,
  includeSampleNotes: true,
};

export const THEME_PRESETS = [
  {
    id: 'emerald',
    name: 'سبز زمردی (پیش‌فرض)',
    primaryColor: '#10B981',
    primaryDarkColor: '#059669',
    accentColor: '#F59E0B',
  },
  {
    id: 'indigo',
    name: 'آبی نیلی مدرن',
    primaryColor: '#4F46E5',
    primaryDarkColor: '#3730A3',
    accentColor: '#06B6D4',
  },
  {
    id: 'amber',
    name: 'کهربایی گرم (کلاسیک)',
    primaryColor: '#D97706',
    primaryDarkColor: '#B45309',
    accentColor: '#10B981',
  },
  {
    id: 'rose',
    name: 'سرخابی یاقوتی',
    primaryColor: '#E11D48',
    primaryDarkColor: '#BE123C',
    accentColor: '#8B5CF6',
  },
  {
    id: 'sky',
    name: 'آبی آسمانی',
    primaryColor: '#0284C7',
    primaryDarkColor: '#0369A1',
    accentColor: '#F59E0B',
  },
];

function escapeXml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, "\\'");
}

export function generateProjectFiles(config: ProjectConfig): ProjectFile[] {
  const safePackage =
    config.packageName
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_.]/g, '') || 'com.example.simplenotepad';

  const packagePath = safePackage.replace(/\./g, '/');
  const safeAppName = escapeXml(config.appName.trim() || 'دفترچه یادداشت من');

  const settingsGradle = `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "SimpleNotepad"
include ':app'
`;

  const rootBuildGradle = `// Top-level build file for SimpleNotepad (Kotlin) - Compatible with AndroidForge
buildscript {
    ext.kotlin_version = '1.9.22'
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        classpath 'com.android.tools.build:gradle:8.2.2'
        classpath "org.jetbrains.kotlin:kotlin-gradle-plugin:\$kotlin_version"
    }
}

task clean(type: Delete) {
    delete rootProject.buildDir
}
`;

  const gradleProperties = `# Project-wide Gradle settings optimized for AndroidForge CI builds
org.gradle.jvmargs=-Xmx3072m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.enableJetifier=true
kotlin.code.style=official
android.nonTransitiveRClass=false
`;

  const gradleWrapperProperties = `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.2-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
`;

  const appBuildGradle = `plugins {
    id 'com.android.application'
    id 'org.jetbrains.kotlin.android'
}

android {
    namespace '${safePackage}'
    compileSdk ${config.targetSdk}

    defaultConfig {
        applicationId "${safePackage}"
        minSdk ${config.minSdk}
        targetSdk ${config.targetSdk}
        versionCode 1
        versionName "1.0.0"
        vectorDrawables.useSupportLibrary = true
    }

    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
        }
        debug {
            minifyEnabled false
        }
    }

    compileOptions {
        sourceCompatibility JavaVersion.VERSION_17
        targetCompatibility JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = '17'
    }
}

dependencies {
    implementation 'androidx.core:core-ktx:1.12.0'
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'com.google.android.material:material:1.11.0'
    implementation 'androidx.recyclerview:recyclerview:1.3.2'
    implementation 'androidx.cardview:cardview:1.0.0'
}
`;

  const proguardRules = `# Add project specific ProGuard rules here.
-keep class ${safePackage}.** { *; }
`;

  const androidManifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android">

    <application
        android:allowBackup="true"
        android:icon="@drawable/ic_app_logo"
        android:roundIcon="@drawable/ic_app_logo"
        android:label="@string/app_name"
        android:supportsRtl="true"
        android:theme="@style/Theme.SimpleNotepad">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:windowSoftInputMode="adjustResize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

    </application>

</manifest>
`;

  const noteKt = `package ${safePackage}

/**
 * مدل داده یادداشت (Note Data Class)
 */
data class Note(
    val id: Long = 0,
    val title: String,
    val content: String,
    val createdAt: String,
    val colorIndex: Int = 0,
    val isPinned: Boolean = false
)
`;

  const noteDatabaseHelperKt = `package ${safePackage}

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * کلاس مدیریت پایگاه داده SQLite برای ذخیره دائمی یادداشت‌ها در گوشی
 */
class NoteDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "simple_notepad.db"
        private const val DATABASE_VERSION = 1

        private const val TABLE_NOTES = "notes"
        private const val COL_ID = "id"
        private const val COL_TITLE = "title"
        private const val COL_CONTENT = "content"
        private const val COL_CREATED_AT = "created_at"
        private const val COL_COLOR_INDEX = "color_index"
        private const val COL_IS_PINNED = "is_pinned"
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = """
            CREATE TABLE \$TABLE_NOTES (
                \$COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                \$COL_TITLE TEXT NOT NULL,
                \$COL_CONTENT TEXT NOT NULL,
                \$COL_CREATED_AT TEXT NOT NULL,
                \$COL_COLOR_INDEX INTEGER DEFAULT 0,
                \$COL_IS_PINNED INTEGER DEFAULT 0
            )
        """.trimIndent()
        db.execSQL(createTableQuery)
${
  config.includeSampleNotes
    ? `
        // درج چند یادداشت نمونه اولیه برای شروع کار
        val now = getCurrentTimestamp()
        insertSample(
            db,
            "خوش آمدید به دفترچه یادداشت!",
            "این برنامه با زبان کاتلین (Kotlin) ساخته شده است. برای افزودن یادداشت جدید روی دکمه + پایین صفحه بزنید.",
            now,
            0,
            1
        )
        insertSample(
            db,
            "لیست خرید روزانه",
            "۱. نان تازه و پنیر\\n۲. میوه و سبزیجات\\n۳. شیر و قهوه",
            now,
            1,
            0
        )`
    : ''
}
    }

    private fun insertSample(
        db: SQLiteDatabase,
        title: String,
        content: String,
        createdAt: String,
        colorIndex: Int,
        isPinned: Int
    ) {
        val values = ContentValues().apply {
            put(COL_TITLE, title)
            put(COL_CONTENT, content)
            put(COL_CREATED_AT, createdAt)
            put(COL_COLOR_INDEX, colorIndex)
            put(COL_IS_PINNED, isPinned)
        }
        db.insert(TABLE_NOTES, null, values)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS \$TABLE_NOTES")
        onCreate(db)
    }

    fun getCurrentTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy/MM/dd - HH:mm", Locale.getDefault())
        return sdf.format(Date())
    }

    fun insertNote(note: Note): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_TITLE, note.title)
            put(COL_CONTENT, note.content)
            put(COL_CREATED_AT, note.createdAt)
            put(COL_COLOR_INDEX, note.colorIndex)
            put(COL_IS_PINNED, if (note.isPinned) 1 else 0)
        }
        val id = db.insert(TABLE_NOTES, null, values)
        db.close()
        return id
    }

    fun updateNote(note: Note): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(COL_TITLE, note.title)
            put(COL_CONTENT, note.content)
            put(COL_CREATED_AT, note.createdAt)
            put(COL_COLOR_INDEX, note.colorIndex)
            put(COL_IS_PINNED, if (note.isPinned) 1 else 0)
        }
        val rows = db.update(
            TABLE_NOTES,
            values,
            "\$COL_ID = ?",
            arrayOf(note.id.toString())
        )
        db.close()
        return rows
    }

    fun deleteNote(id: Long): Int {
        val db = writableDatabase
        val rows = db.delete(TABLE_NOTES, "\$COL_ID = ?", arrayOf(id.toString()))
        db.close()
        return rows
    }

    fun getAllNotes(searchQuery: String = ""): List<Note> {
        val notes = mutableListOf<Note>()
        val db = readableDatabase

        val selection: String?
        val selectionArgs: Array<String>?

        if (searchQuery.isBlank()) {
            selection = null
            selectionArgs = null
        } else {
            selection = "\$COL_TITLE LIKE ? OR \$COL_CONTENT LIKE ?"
            val pattern = "%\${searchQuery.trim()}%"
            selectionArgs = arrayOf(pattern, pattern)
        }

        val cursor = db.query(
            TABLE_NOTES,
            null,
            selection,
            selectionArgs,
            null,
            null,
            "\$COL_IS_PINNED DESC, \$COL_ID DESC"
        )

        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val id = it.getLong(it.getColumnIndexOrThrow(COL_ID))
                    val title = it.getString(it.getColumnIndexOrThrow(COL_TITLE))
                    val content = it.getString(it.getColumnIndexOrThrow(COL_CONTENT))
                    val createdAt = it.getString(it.getColumnIndexOrThrow(COL_CREATED_AT))
                    val colorIndex = it.getInt(it.getColumnIndexOrThrow(COL_COLOR_INDEX))
                    val isPinned = it.getInt(it.getColumnIndexOrThrow(COL_IS_PINNED)) == 1

                    notes.add(
                        Note(
                            id = id,
                            title = title,
                            content = content,
                            createdAt = createdAt,
                            colorIndex = colorIndex,
                            isPinned = isPinned
                        )
                    )
                } while (it.moveToNext())
            }
        }
        db.close()
        return notes
    }
}
`;

  const noteAdapterKt = `package ${safePackage}

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView

/**
 * آداپتور RecyclerView برای نمایش کارت‌های یادداشت
 */
class NoteAdapter(
    private var notes: List<Note>,
    private val onNoteClick: (Note) -> Unit,
    private val onDeleteClick: (Note) -> Unit,
    private val onShareClick: (Note) -> Unit,
    private val onPinToggle: (Note) -> Unit
) : RecyclerView.Adapter<NoteAdapter.NoteViewHolder>() {

    private val cardColors = listOf(
        "#FFFFFF", // سفید ساده
        "#FEF3C7", // زرد ملایم
        "#D1FAE5", // سبز نعنایی
        "#DBEAFE", // آبی آسمانی ملایم
        "#FCE7F3"  // صورتی پاستلی
    )

    inner class NoteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardNote: CardView = itemView.findViewById(R.id.cardNote)
        val tvTitle: TextView = itemView.findViewById(R.id.tvNoteTitle)
        val tvContent: TextView = itemView.findViewById(R.id.tvNoteContent)
        val tvDate: TextView = itemView.findViewById(R.id.tvNoteDate)
        val tvPinnedBadge: TextView = itemView.findViewById(R.id.tvPinnedBadge)
        val btnPin: ImageButton = itemView.findViewById(R.id.btnPinNote)
        val btnShare: ImageButton = itemView.findViewById(R.id.btnShareNote)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDeleteNote)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_note, parent, false)
        return NoteViewHolder(view)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val note = notes[position]
        holder.tvTitle.text = note.title.ifBlank { "بدون عنوان" }
        holder.tvContent.text = note.content
        holder.tvDate.text = note.createdAt

        val colorHex = cardColors.getOrElse(note.colorIndex) { "#FFFFFF" }
        holder.cardNote.setCardBackgroundColor(Color.parseColor(colorHex))

        holder.tvPinnedBadge.visibility = if (note.isPinned) View.VISIBLE else View.GONE
        holder.btnPin.alpha = if (note.isPinned) 1.0f else 0.45f

        holder.itemView.setOnClickListener { onNoteClick(note) }
        holder.btnDelete.setOnClickListener { onDeleteClick(note) }
        holder.btnShare.setOnClickListener { onShareClick(note) }
        holder.btnPin.setOnClickListener { onPinToggle(note) }
    }

    override fun getItemCount(): Int = notes.size

    fun updateList(newNotes: List<Note>) {
        notes = newNotes
        notifyDataSetChanged()
    }
}
`;

  const mainActivityKt = `package ${safePackage}

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

/**
 * صفحه اصلی برنامه دفترچه یادداشت کاتلین
 */
class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: NoteDatabaseHelper
    private lateinit var noteAdapter: NoteAdapter
    private lateinit var rvNotes: RecyclerView
    private lateinit var layoutEmptyState: LinearLayout
    private lateinit var etSearch: EditText
    private lateinit var tvNotesCount: TextView
    private lateinit var fabAddNote: FloatingActionButton

    private var currentSearchQuery: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = NoteDatabaseHelper(this)

        rvNotes = findViewById(R.id.rvNotes)
        layoutEmptyState = findViewById(R.id.layoutEmptyState)
        etSearch = findViewById(R.id.etSearch)
        tvNotesCount = findViewById(R.id.tvNotesCount)
        fabAddNote = findViewById(R.id.fabAddNote)

        setupRecyclerView()
        setupSearchBar()

        fabAddNote.setOnClickListener {
            showNoteDialog(null)
        }

        loadNotes()
    }

    private fun setupRecyclerView() {
        noteAdapter = NoteAdapter(
            notes = emptyList(),
            onNoteClick = { note -> showNoteDialog(note) },
            onDeleteClick = { note -> confirmDeleteNote(note) },
            onShareClick = { note -> shareNote(note) },
            onPinToggle = { note -> togglePin(note) }
        )
        rvNotes.layoutManager = LinearLayoutManager(this)
        rvNotes.adapter = noteAdapter
    }

    private fun setupSearchBar() {
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                currentSearchQuery = s?.toString() ?: ""
                loadNotes()
            }
            override fun afterTextChanged(s: Editable?) {}
        })
    }

    private fun loadNotes() {
        val list = dbHelper.getAllNotes(currentSearchQuery)
        noteAdapter.updateList(list)

        tvNotesCount.text = "\${list.size} یادداشت"
        if (list.isEmpty()) {
            rvNotes.visibility = View.GONE
            layoutEmptyState.visibility = View.VISIBLE
        } else {
            rvNotes.visibility = View.VISIBLE
            layoutEmptyState.visibility = View.GONE
        }
    }

    private fun showNoteDialog(existingNote: Note?) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_note, null)
        val tvDialogHeader = dialogView.findViewById<TextView>(R.id.tvDialogHeader)
        val etTitle = dialogView.findViewById<EditText>(R.id.etNoteTitle)
        val etContent = dialogView.findViewById<EditText>(R.id.etNoteContent)
        val rgColors = dialogView.findViewById<RadioGroup>(R.id.rgNoteColors)
        val cbPin = dialogView.findViewById<CheckBox>(R.id.cbPinNote)

        val isEditing = existingNote != null
        tvDialogHeader.text = if (isEditing) "ویرایش یادداشت" else "یادداشت جدید"

        if (existingNote != null) {
            etTitle.setText(existingNote.title)
            etContent.setText(existingNote.content)
            cbPin.isChecked = existingNote.isPinned
            val radioId = when (existingNote.colorIndex) {
                1 -> R.id.rbColorYellow
                2 -> R.id.rbColorGreen
                3 -> R.id.rbColorBlue
                4 -> R.id.rbColorPink
                else -> R.id.rbColorWhite
            }
            rgColors.check(radioId)
        }

        AlertDialog.Builder(this)
            .setView(dialogView)
            .setPositiveButton("ذخیره") { _, _ ->
                val title = etTitle.text.toString().trim()
                val content = etContent.text.toString().trim()

                if (title.isEmpty() && content.isEmpty()) {
                    Toast.makeText(this, "لطفاً عنوان یا متن یادداشت را وارد کنید", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                val selectedColorIndex = when (rgColors.checkedRadioButtonId) {
                    R.id.rbColorYellow -> 1
                    R.id.rbColorGreen -> 2
                    R.id.rbColorBlue -> 3
                    R.id.rbColorPink -> 4
                    else -> 0
                }

                val finalTitle = if (title.isEmpty()) "یادداشت بدون عنوان" else title
                val now = dbHelper.getCurrentTimestamp()

                if (existingNote == null) {
                    dbHelper.insertNote(
                        Note(
                            title = finalTitle,
                            content = content,
                            createdAt = now,
                            colorIndex = selectedColorIndex,
                            isPinned = cbPin.isChecked
                        )
                    )
                    Toast.makeText(this, "یادداشت با موفقیت ذخیره شد", Toast.LENGTH_SHORT).show()
                } else {
                    dbHelper.updateNote(
                        existingNote.copy(
                            title = finalTitle,
                            content = content,
                            createdAt = now,
                            colorIndex = selectedColorIndex,
                            isPinned = cbPin.isChecked
                        )
                    )
                    Toast.makeText(this, "یادداشت بروزرسانی شد", Toast.LENGTH_SHORT).show()
                }
                loadNotes()
            }
            .setNegativeButton("انصراف", null)
            .show()
    }

    private fun togglePin(note: Note) {
        val updated = note.copy(isPinned = !note.isPinned)
        dbHelper.updateNote(updated)
        loadNotes()
    }

    private fun confirmDeleteNote(note: Note) {
        AlertDialog.Builder(this)
            .setTitle("حذف یادداشت")
            .setMessage("آیا مطمئن هستید که می‌خواهید «\${note.title}» را حذف کنید؟")
            .setPositiveButton("حذف") { _, _ ->
                dbHelper.deleteNote(note.id)
                loadNotes()
                Toast.makeText(this, "یادداشت حذف شد", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("لغو", null)
            .show()
    }

    private fun shareNote(note: Note) {
        val shareText = "\${note.title}\\n\\n\${note.content}"
        val sendIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        startActivity(Intent.createChooser(sendIntent, "اشتراک‌گذاری یادداشت با..."))
    }
}
`;

  const activityMainXml = `<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="@color/bg_screen"
    android:layoutDirection="rtl">

    <!-- نوار بالایی برنامه -->
    <LinearLayout
        android:id="@+id/headerContainer"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:background="@color/primary"
        android:orientation="vertical"
        android:paddingStart="20dp"
        android:paddingTop="20dp"
        android:paddingEnd="20dp"
        android:paddingBottom="18dp"
        android:elevation="4dp">

        <RelativeLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content">

            <TextView
                android:id="@+id/tvAppTitle"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_alignParentStart="true"
                android:text="@string/app_name"
                android:textColor="@android:color/white"
                android:textSize="22sp"
                android:textStyle="bold" />

            <TextView
                android:id="@+id/tvNotesCount"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_alignParentEnd="true"
                android:layout_centerVertical="true"
                android:background="@drawable/bg_search_box"
                android:paddingStart="12dp"
                android:paddingTop="4dp"
                android:paddingEnd="12dp"
                android:paddingBottom="4dp"
                android:text="0 یادداشت"
                android:textColor="@color/primary_dark"
                android:textSize="13sp"
                android:textStyle="bold" />
        </RelativeLayout>

        <!-- کادر جستجوی سریع -->
        <EditText
            android:id="@+id/etSearch"
            android:layout_width="match_parent"
            android:layout_height="46dp"
            android:layout_marginTop="14dp"
            android:background="@drawable/bg_search_box"
            android:hint="جستجو در عنوان یا متن یادداشت‌ها..."
            android:imeOptions="actionSearch"
            android:inputType="text"
            android:maxLines="1"
            android:paddingStart="16dp"
            android:paddingEnd="16dp"
            android:textColor="#1E293B"
            android:textColorHint="#64748B"
            android:textSize="14sp" />

    </LinearLayout>

    <!-- لیست یادداشت‌ها -->
    <androidx.recyclerview.widget.RecyclerView
        android:id="@+id/rvNotes"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:layout_below="@id/headerContainer"
        android:clipToPadding="false"
        android:paddingStart="14dp"
        android:paddingTop="12dp"
        android:paddingEnd="14dp"
        android:paddingBottom="88dp" />

    <!-- وضعیت خالی بودن لیست -->
    <LinearLayout
        android:id="@+id/layoutEmptyState"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_centerInParent="true"
        android:gravity="center"
        android:orientation="vertical"
        android:padding="28dp"
        android:visibility="gone">

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:text="📝"
            android:textSize="48sp" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:text="هنوز هیچ یادداشتی ثبت نشده است"
            android:textColor="#334155"
            android:textSize="17sp"
            android:textStyle="bold" />

        <TextView
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_marginTop="6dp"
            android:gravity="center"
            android:text="برای نوشتن اولین یادداشت، روی دکمه + پایین صفحه بزنید"
            android:textColor="#64748B"
            android:textSize="14sp" />

    </LinearLayout>

    <!-- دکمه شناور افزودن یادداشت جدید -->
    <com.google.android.material.floatingactionbutton.FloatingActionButton
        android:id="@+id/fabAddNote"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:layout_alignParentEnd="true"
        android:layout_alignParentBottom="true"
        android:layout_margin="22dp"
        android:contentDescription="افزودن یادداشت جدید"
        android:src="@android:drawable/ic_input_add"
        app:backgroundTint="@color/primary"
        app:tint="@android:color/white" />

</RelativeLayout>
`;

  const itemNoteXml = `<?xml version="1.0" encoding="utf-8"?>
<androidx.cardview.widget.CardView xmlns:android="http://schemas.android.com/apk/res/android"
    xmlns:app="http://schemas.android.com/apk/res-auto"
    android:id="@+id/cardNote"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layout_marginBottom="12dp"
    android:clickable="true"
    android:focusable="true"
    android:foreground="?android:attr/selectableItemBackground"
    android:layoutDirection="rtl"
    app:cardBackgroundColor="@android:color/white"
    app:cardCornerRadius="14dp"
    app:cardElevation="2dp">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="16dp">

        <!-- ردیف عنوان و نشان سنجاق -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:gravity="center_vertical"
            android:orientation="horizontal">

            <TextView
                android:id="@+id/tvNoteTitle"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:ellipsize="end"
                android:maxLines="1"
                android:text="عنوان یادداشت"
                android:textColor="#0F172A"
                android:textSize="17sp"
                android:textStyle="bold" />

            <TextView
                android:id="@+id/tvPinnedBadge"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginStart="8dp"
                android:background="@drawable/bg_note_card"
                android:paddingStart="8dp"
                android:paddingTop="2dp"
                android:paddingEnd="8dp"
                android:paddingBottom="2dp"
                android:text="📌 سنجاق‌شده"
                android:textColor="@color/primary_dark"
                android:textSize="11sp"
                android:textStyle="bold"
                android:visibility="gone" />
        </LinearLayout>

        <!-- متن یادداشت -->
        <TextView
            android:id="@+id/tvNoteContent"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:ellipsize="end"
            android:lineSpacingExtra="4dp"
            android:maxLines="4"
            android:text="متن یادداشت در این بخش قرار می‌گیرد..."
            android:textColor="#334155"
            android:textSize="14sp" />

        <!-- ردیف پایین: تاریخ و دکمه‌های عملیات -->
        <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:gravity="center_vertical"
            android:orientation="horizontal">

            <TextView
                android:id="@+id/tvNoteDate"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:layout_weight="1"
                android:text="1403/01/01 - 12:00"
                android:textColor="#64748B"
                android:textSize="12sp" />

            <ImageButton
                android:id="@+id/btnPinNote"
                android:layout_width="36dp"
                android:layout_height="36dp"
                android:background="?attr/selectableItemBackgroundBorderless"
                android:contentDescription="سنجاق کردن"
                android:src="@android:drawable/btn_star_big_on" />

            <ImageButton
                android:id="@+id/btnShareNote"
                android:layout_width="36dp"
                android:layout_height="36dp"
                android:layout_marginStart="4dp"
                android:background="?attr/selectableItemBackgroundBorderless"
                android:contentDescription="اشتراک‌گذاری"
                android:src="@android:drawable/ic_menu_share" />

            <ImageButton
                android:id="@+id/btnDeleteNote"
                android:layout_width="36dp"
                android:layout_height="36dp"
                android:layout_marginStart="4dp"
                android:background="?attr/selectableItemBackgroundBorderless"
                android:contentDescription="حذف یادداشت"
                android:src="@android:drawable/ic_menu_delete" />

        </LinearLayout>

    </LinearLayout>

</androidx.cardview.widget.CardView>
`;

  const dialogNoteXml = `<?xml version="1.0" encoding="utf-8"?>
<ScrollView xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="wrap_content"
    android:layoutDirection="rtl">

    <LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:padding="20dp">

        <TextView
            android:id="@+id/tvDialogHeader"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:text="یادداشت جدید"
            android:textColor="@color/primary_dark"
            android:textSize="19sp"
            android:textStyle="bold" />

        <EditText
            android:id="@+id/etNoteTitle"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="14dp"
            android:background="@drawable/bg_note_card"
            android:hint="عنوان یادداشت..."
            android:inputType="textCapSentences"
            android:maxLines="1"
            android:padding="12dp"
            android:textColor="#0F172A"
            android:textSize="16sp"
            android:textStyle="bold" />

        <EditText
            android:id="@+id/etNoteContent"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="12dp"
            android:background="@drawable/bg_note_card"
            android:gravity="top|start"
            android:hint="متن یادداشت خود را اینجا بنویسید..."
            android:inputType="textMultiLine|textCapSentences"
            android:minLines="5"
            android:padding="12dp"
            android:textColor="#1E293B"
            android:textSize="15sp" />

        <TextView
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="14dp"
            android:text="رنگ پس‌زمینه کارت:"
            android:textColor="#475569"
            android:textSize="13sp"
            android:textStyle="bold" />

        <RadioGroup
            android:id="@+id/rgNoteColors"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="6dp"
            android:orientation="horizontal">

            <RadioButton
                android:id="@+id/rbColorWhite"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:checked="true"
                android:text="سفید"
                android:textSize="12sp" />

            <RadioButton
                android:id="@+id/rbColorYellow"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginStart="6dp"
                android:text="زرد"
                android:textSize="12sp" />

            <RadioButton
                android:id="@+id/rbColorGreen"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginStart="6dp"
                android:text="سبز"
                android:textSize="12sp" />

            <RadioButton
                android:id="@+id/rbColorBlue"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginStart="6dp"
                android:text="آبی"
                android:textSize="12sp" />

            <RadioButton
                android:id="@+id/rbColorPink"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                android:layout_marginStart="6dp"
                android:text="صورتی"
                android:textSize="12sp" />
        </RadioGroup>

        <CheckBox
            android:id="@+id/cbPinNote"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:layout_marginTop="8dp"
            android:text="سنجاق کردن در بالای لیست (📌)"
            android:textColor="#1E293B"
            android:textSize="14sp" />

    </LinearLayout>
</ScrollView>
`;

  const icAppLogoXml = `<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android"
    android:width="108dp"
    android:height="108dp"
    android:viewportWidth="108"
    android:viewportHeight="108">
    <path
        android:fillColor="${config.primaryColor}"
        android:pathData="M0,0h108v108h-108z" />
    <path
        android:fillColor="#FFFFFF"
        android:pathData="M30,24h48c3.3,0 6,2.7 6,6v48c0,3.3 -2.7,6 -6,6H30c-3.3,0 -6,-2.7 -6,-6V30c0,-3.3 2.7,-6 6,-6z" />
    <path
        android:fillColor="${config.primaryDarkColor}"
        android:pathData="M36,38h36v4H36zM36,50h36v4H36zM36,62h24v4H36z" />
</vector>
`;

  const bgSearchBoxXml = `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#FFFFFF" />
    <corners android:radius="12dp" />
</shape>
`;

  const bgNoteCardXml = `<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android"
    android:shape="rectangle">
    <solid android:color="#F1F5F9" />
    <corners android:radius="10dp" />
    <stroke
        android:width="1dp"
        android:color="#CBD5E1" />
</shape>
`;

  const stringsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">${safeAppName}</string>
</resources>
`;

  const colorsXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">${config.primaryColor}</color>
    <color name="primary_dark">${config.primaryDarkColor}</color>
    <color name="accent">${config.accentColor}</color>
    <color name="bg_screen">#F8FAFC</color>
</resources>
`;

  const themesXml = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.SimpleNotepad" parent="Theme.MaterialComponents.Light.NoActionBar">
        <item name="colorPrimary">@color/primary</item>
        <item name="colorPrimaryVariant">@color/primary_dark</item>
        <item name="colorSecondary">@color/accent</item>
        <item name="android:statusBarColor">@color/primary_dark</item>
    </style>
</resources>
`;

  const readmeMd = `# ${config.appName} (Simple Notepad - Kotlin Android)

پروژه کامل و استاندارد **دفترچه یادداشت اندروید با زبان کاتلین (Kotlin)**، آماده برای تبدیل مستقیم به فایل نصبی **APK** در سرویس **AndroidForge** یا باز کردن در **Android Studio**.

## ویژگی‌های برنامه
- **نوشته‌شده ۱۰۰٪ با زبان Kotlin**
- **ذخیره‌سازی دائمی با SQLite داخلی اندروید** (بدون وابستگی‌های پیچیده که باعث خطای بیلد شوند)
- **افزودن، ویرایش، حذف، سنجاق کردن (Pin) و اشتراک‌گذاری یادداشت‌ها**
- **انتخاب رنگ کارت برای هر یادداشت** (سفید، زرد، سبز، آبی، صورتی)
- **جستجوی لحظه‌ای (Live Search)** در عنوان و متن یادداشت‌ها
- **رابط کاربری راست‌چین (RTL) و فارسی**

## نحوه تبدیل به APK در AndroidForge
1. فایل ZIP این پروژه را مستقیماً در **AndroidForge** آپلود کنید (در پوشه \`input/\` یا بخش آپلود فایل ZIP).
2. ورک‌فلوی \`Build Android APK\` را اجرا کنید.
3. سیستم به صورت خودکار پروژه \`Gradle (Kotlin)\` را شناسایی کرده و فایل \`APK\` آماده نصب را تحویل می‌دهد.

## مشخصات فنی پروژه
- **Package Name:** \`${safePackage}\`
- **Min SDK:** \`${config.minSdk}\` (Android 7.0+)
- **Compile / Target SDK:** \`${config.targetSdk}\` (Android 14)
- **Android Gradle Plugin (AGP):** \`8.2.2\`
- **Kotlin Version:** \`1.9.22\`
- **Java / JVM Target:** \`17\`
`;

  return [
    {
      path: 'settings.gradle',
      name: 'settings.gradle',
      folder: 'Root',
      language: 'groovy',
      description: 'تنظیمات ماژول‌ها و مخازن Gradle برای شناسایی خودکار در AndroidForge',
      content: settingsGradle,
    },
    {
      path: 'build.gradle',
      name: 'build.gradle',
      folder: 'Root',
      language: 'groovy',
      description: 'فایل بیلد اصلی پروژه با پلاگین Kotlin 1.9.22 و AGP 8.2.2',
      content: rootBuildGradle,
    },
    {
      path: 'gradle.properties',
      name: 'gradle.properties',
      folder: 'Root',
      language: 'properties',
      description: 'تنظیمات حافظه JVM و فعال‌سازی AndroidX برای کامپایل سریع',
      content: gradleProperties,
    },
    {
      path: 'gradle/wrapper/gradle-wrapper.properties',
      name: 'gradle-wrapper.properties',
      folder: 'gradle/wrapper',
      language: 'properties',
      description: 'مشخص‌کننده نسخه Gradle 8.2 هماهنگ با AndroidForge',
      content: gradleWrapperProperties,
    },
    {
      path: 'app/build.gradle',
      name: 'build.gradle (app)',
      folder: 'app',
      language: 'groovy',
      description: 'تنظیمات ماژول اپلیکیشن، نسخه SDK و کتابخانه‌های Material و RecyclerView',
      content: appBuildGradle,
    },
    {
      path: 'app/proguard-rules.pro',
      name: 'proguard-rules.pro',
      folder: 'app',
      language: 'properties',
      description: 'قوانین ProGuard برای نسخه Release',
      content: proguardRules,
    },
    {
      path: 'app/src/main/AndroidManifest.xml',
      name: 'AndroidManifest.xml',
      folder: 'app/src/main',
      language: 'xml',
      description: 'مانیفست برنامه با پشتیبانی کامل از راست‌چین (RTL) و اکتیویتی اصلی',
      content: androidManifest,
    },
    {
      path: `app/src/main/java/${packagePath}/MainActivity.kt`,
      name: 'MainActivity.kt',
      folder: `app/src/main/java/${packagePath}`,
      language: 'kotlin',
      description: 'اکتیویتی اصلی کاتلین: مدیریت صفحه، جستجو، دیالوگ ثبت/ویرایش و اشتراک‌گذاری',
      content: mainActivityKt,
    },
    {
      path: `app/src/main/java/${packagePath}/Note.kt`,
      name: 'Note.kt',
      folder: `app/src/main/java/${packagePath}`,
      language: 'kotlin',
      description: 'کلاس مدل داده (Data Class) یادداشت در کاتلین',
      content: noteKt,
    },
    {
      path: `app/src/main/java/${packagePath}/NoteDatabaseHelper.kt`,
      name: 'NoteDatabaseHelper.kt',
      folder: `app/src/main/java/${packagePath}`,
      language: 'kotlin',
      description: 'پایگاه داده SQLite برای ذخیره، ویرایش، حذف و جستجوی یادداشت‌ها',
      content: noteDatabaseHelperKt,
    },
    {
      path: `app/src/main/java/${packagePath}/NoteAdapter.kt`,
      name: 'NoteAdapter.kt',
      folder: `app/src/main/java/${packagePath}`,
      language: 'kotlin',
      description: 'آداپتور RecyclerView برای نمایش کارت‌های رنگی یادداشت',
      content: noteAdapterKt,
    },
    {
      path: 'app/src/main/res/layout/activity_main.xml',
      name: 'activity_main.xml',
      folder: 'app/src/main/res/layout',
      language: 'xml',
      description: 'رابط کاربری صفحه اصلی شامل هدر، کادر جستجو، لیست و دکمه شناور +',
      content: activityMainXml,
    },
    {
      path: 'app/src/main/res/layout/item_note.xml',
      name: 'item_note.xml',
      folder: 'app/src/main/res/layout',
      language: 'xml',
      description: 'طراحی کارت هر یادداشت با دکمه‌های سنجاق، اشتراک‌گذاری و حذف',
      content: itemNoteXml,
    },
    {
      path: 'app/src/main/res/layout/dialog_note.xml',
      name: 'dialog_note.xml',
      folder: 'app/src/main/res/layout',
      language: 'xml',
      description: 'پنجره دیالوگ افزودن و ویرایش یادداشت به همراه انتخاب رنگ',
      content: dialogNoteXml,
    },
    {
      path: 'app/src/main/res/drawable/ic_app_logo.xml',
      name: 'ic_app_logo.xml',
      folder: 'app/src/main/res/drawable',
      language: 'xml',
      description: 'آیکون وکتوری اپلیکیشن (بدون نیاز به فایل‌های PNG خارجی)',
      content: icAppLogoXml,
    },
    {
      path: 'app/src/main/res/drawable/bg_search_box.xml',
      name: 'bg_search_box.xml',
      folder: 'app/src/main/res/drawable',
      language: 'xml',
      description: 'پس‌زمینه گرد کادر جستجو',
      content: bgSearchBoxXml,
    },
    {
      path: 'app/src/main/res/drawable/bg_note_card.xml',
      name: 'bg_note_card.xml',
      folder: 'app/src/main/res/drawable',
      language: 'xml',
      description: 'کادر دور فیلدهای ورودی دیالوگ یادداشت',
      content: bgNoteCardXml,
    },
    {
      path: 'app/src/main/res/values/strings.xml',
      name: 'strings.xml',
      folder: 'app/src/main/res/values',
      language: 'xml',
      description: 'فایل رشته‌های متنی و نام اپلیکیشن',
      content: stringsXml,
    },
    {
      path: 'app/src/main/res/values/colors.xml',
      name: 'colors.xml',
      folder: 'app/src/main/res/values',
      language: 'xml',
      description: 'پالت رنگ‌های اصلی برنامه',
      content: colorsXml,
    },
    {
      path: 'app/src/main/res/values/themes.xml',
      name: 'themes.xml',
      folder: 'app/src/main/res/values',
      language: 'xml',
      description: 'تم MaterialComponents بدون اکشن‌بار پیش‌فرض',
      content: themesXml,
    },
    {
      path: 'README.md',
      name: 'README.md',
      folder: 'Root',
      language: 'markdown',
      description: 'راهنمای پروژه و دستورالعمل ساخت APK در AndroidForge',
      content: readmeMd,
    },
  ];
}
