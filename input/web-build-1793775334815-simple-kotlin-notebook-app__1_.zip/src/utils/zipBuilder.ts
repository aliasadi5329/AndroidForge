import JSZip from 'jszip';
import { ProjectConfig, ProjectFile, generateProjectFiles } from '../data/kotlinProjectTemplate';

export async function createKotlinProjectZipBlob(
  config: ProjectConfig,
  customFiles?: ProjectFile[],
  wrapInRootFolder = true
): Promise<{ blob: Blob; fileCount: number; sizeKB: string }> {
  const zip = new JSZip();
  const files = customFiles ?? generateProjectFiles(config);
  const rootPrefix = wrapInRootFolder ? 'SimpleNotepad/' : '';

  for (const file of files) {
    zip.file(`${rootPrefix}${file.path}`, file.content);
  }

  const blob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const sizeKB = (blob.size / 1024).toFixed(1);

  return {
    blob,
    fileCount: files.length,
    sizeKB,
  };
}

export function triggerBlobDownload(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
