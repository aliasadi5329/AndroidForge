package com.dubfa.app

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.BufferedReader
import java.io.InputStreamReader

private val Navy = Color(0xFF0B1020)
private val Panel = Color(0xFF171F33)
private val Purple = Color(0xFF9B7BFF)
private val Cyan = Color(0xFF55D6D0)
private val Muted = Color(0xFF9AA6BF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DubfaApp() }
    }
}

@Composable
private fun DubfaApp() {
    val context = LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoName by remember { mutableStateOf("هنوز فیلمی انتخاب نشده") }
    var subtitleUri by remember { mutableStateOf<Uri?>(null) }
    var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
    var subtitleLines by remember { mutableStateOf<List<String>>(emptyList()) }
    var subtitleCount by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf("برای شروع، فیلم و زیرنویس فارسی را انتخاب کن.") }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            videoName = uri.lastPathSegment?.substringAfterLast('/') ?: "فایل ویدیویی انتخاب شد"
            message = "فیلم انتخاب شد. حالا زیرنویس فارسی را انتخاب کن."
        }
    }

    val subtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            subtitleUri = uri
            subtitleName = uri.lastPathSegment?.substringAfterLast('/') ?: "فایل زیرنویس انتخاب شد"
            try {
                context.contentResolver.openInputStream(uri)?.use { stream ->
                    val text = BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                    val blocks = text.replace("\r\n", "\n").split(Regex("\n\\s*\n"))
                    val parsed = blocks.mapNotNull { block ->
                        val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
                        val textLines = lines.dropWhile {
                            it.matches(Regex("\\d+")) || it.contains("-->")
                        }
                        textLines.takeIf { it.isNotEmpty() }?.joinToString(" ")
                    }
                    subtitleCount = parsed.size
                    subtitleLines = parsed.take(8)
                    message = if (parsed.isNotEmpty()) {
                        "زیرنویس با موفقیت خوانده شد؛ $subtitleCount بخش متنی پیدا شد."
                    } else {
                        "فایل باز شد، اما متن قابل‌خواندن پیدا نشد. فایل SRT استاندارد را امتحان کن."
                    }
                }
            } catch (e: Exception) {
                message = "خواندن زیرنویس ناموفق بود. لطفاً فایل SRT با کدگذاری UTF-8 انتخاب کن."
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Navy,
            surface = Panel,
            primary = Purple,
            secondary = Cyan,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Navy) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFF17132D), Navy))),
                contentPadding = PaddingValues(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = Purple.copy(alpha = 0.18f), shape = RoundedCornerShape(16.dp)) {
                            Icon(Icons.Default.AutoAwesome, null, tint = Purple, modifier = Modifier.padding(14.dp).size(28.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("DUBFA", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
                            Text("دوبله هوشمند فارسی", color = Muted, fontSize = 13.sp)
                        }
                        Spacer(Modifier.weight(1f))
                        Surface(color = Color(0xFF203A3A), shape = RoundedCornerShape(50)) {
                            Text("نسخه ۰٫۱", color = Cyan, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth().background(
                            Brush.linearGradient(listOf(Color(0xFF30265A), Color(0xFF182A43))),
                            RoundedCornerShape(24.dp)
                        ).padding(20.dp),
                        horizontalAlignment = Alignment.Start
                    ) {
                        Text("فیلمت را فارسی بشنو!", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("فیلم و زیرنویس را وارد کن تا زیرساخت دوبله هوشمند آماده شود.", color = Color(0xFFD1D7E8), fontSize = 13.sp, lineHeight = 21.sp)
                    }
                }
                item {
                    FileCard(
                        title = "۱. انتخاب فیلم",
                        detail = videoName,
                        icon = { Icon(Icons.Default.Movie, null, tint = Purple, modifier = Modifier.size(25.dp)) },
                        buttonText = "انتخاب فایل ویدیو",
                        onClick = { videoPicker.launch(arrayOf("video/*")) }
                    )
                }
                item {
                    FileCard(
                        title = "۲. انتخاب زیرنویس فارسی",
                        detail = subtitleName,
                        icon = { Icon(Icons.Default.Subtitles, null, tint = Cyan, modifier = Modifier.size(25.dp)) },
                        buttonText = "انتخاب فایل SRT",
                        onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*")) }
                    )
                }
                item {
                    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp)) {
                        Text("وضعیت پروژه", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(message, color = Muted, fontSize = 13.sp, lineHeight = 20.sp)
                        if (subtitleCount > 0) {
                            Spacer(Modifier.height(10.dp))
                            Text("تعداد بخش‌های شناسایی‌شده: $subtitleCount", color = Cyan, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                if (subtitleLines.isNotEmpty()) {
                    item {
                        Text("پیش‌نمایش زیرنویس", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                    items(subtitleLines) { line ->
                        Text(
                            line,
                            modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(13.dp),
                            color = Color(0xFFE5E9F4),
                            textAlign = TextAlign.Right,
                            fontSize = 13.sp
                        )
                    }
                }
                item {
                    Button(
                        onClick = {
                            message = when {
                                videoUri == null -> "ابتدا فایل فیلم را انتخاب کن."
                                subtitleUri == null -> "حالا فایل زیرنویس فارسی را انتخاب کن."
                                subtitleCount == 0 -> "زیرنویس انتخاب شده، اما متن قابل‌پردازش ندارد."
                                else -> "عالی! فایل‌ها آماده‌اند. موتور تولید صدای فارسی در مرحله بعد اضافه می‌شود."
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(54.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Purple)
                    ) {
                        Text("بررسی فایل‌های انتخاب‌شده", fontWeight = FontWeight.Bold)
                    }
                }
                item {
                    Text(
                        "در نسخه بعد: تولید صدای طبیعی فارسی، هماهنگ‌سازی دیالوگ‌ها و پخش فیلم دوبله‌شده",
                        color = Muted,
                        fontSize = 11.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 18.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FileCard(
    title: String,
    detail: String,
    icon: @Composable () -> Unit,
    buttonText: String,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            icon()
            Spacer(Modifier.width(10.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
        Spacer(Modifier.height(10.dp))
        Text(detail, color = Muted, fontSize = 12.sp, maxLines = 2)
        Spacer(Modifier.height(14.dp))
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(13.dp)
        ) {
            Icon(Icons.Default.FolderOpen, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(buttonText)
        }
    }
}
