package com.dubfa.app

import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
 private var tts: TextToSpeech? = null
 private var ready = false
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  tts = TextToSpeech(this) { status -> ready = status == TextToSpeech.SUCCESS }
  setContent { Screen() }
 }
 @Composable fun Screen() {
  var video by remember { mutableStateOf<Uri?>(null) }
  var cues by remember { mutableStateOf(listOf<Cue>()) }
  var subtitle by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
  var status by remember { mutableStateOf("ویدئو و زیرنویس را انتخاب کن.") }
  var player by remember { mutableStateOf<ExoPlayer?>(null) }
  val videoPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
   if (u != null) { video = u; status = "ویدئو انتخاب شد." }
  }
  val srtPick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
   if (u != null) {
    val raw = contentResolver.openInputStream(u)?.use { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() }.orEmpty()
    cues = parseSrt(raw); subtitle = u.lastPathSegment ?: "subtitle.srt"
    status = "زیرنویس پاک‌سازی و خوانده شد: ${cues.size} بخش."
   }
  }
  DisposableEffect(video) {
   val p = video?.let { uri -> ExoPlayer.Builder(this@MainActivity).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare() } }
   player = p
   onDispose { p?.release(); if (player === p) player = null }
  }
  MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF9B7BFF), secondary = Color(0xFF54D1CC))) {
   Column(Modifier.fillMaxSize().background(Color(0xFF101126)).verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text("DUBFA", style = MaterialTheme.typography.headlineLarge, color = Color.White)
    Text("نسخه ۰٫۲ | پخش ویدئو و پاک‌سازی زیرنویس", color = Color.LightGray)
    Button(onClick = { videoPick.launch("video/*") }, modifier = Modifier.fillMaxWidth()) { Text("انتخاب فایل ویدئو") }
    Text(video?.lastPathSegment ?: "هنوز ویدئویی انتخاب نشده", color = Color.LightGray)
    if (player != null) AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().height(220.dp))
    OutlinedButton(onClick = { srtPick.launch(arrayOf("text/*", "application/x-subrip")) }, modifier = Modifier.fillMaxWidth()) { Text("انتخاب زیرنویس SRT") }
    Text(subtitle, color = Color.LightGray)
    Card { Column(Modifier.padding(14.dp)) {
     Text("وضعیت پروژه", style = MaterialTheme.typography.titleMedium)
     Text(status)
     Text("تعداد بخش‌های شناسایی‌شده: ${cues.size}", color = Color(0xFF54D1CC))
     Text("دوبله زمان‌بندی‌شده و خروجی MP4 در مرحله بعد اضافه می‌شود.", color = Color(0xFFFFD27D))
    } }
    Text("پیش‌نمایش زیرنویس پاک‌سازی‌شده", style = MaterialTheme.typography.titleLarge, color = Color.White)
    cues.take(15).forEachIndexed { i, cue ->
     Card { Column(Modifier.padding(12.dp)) {
      Text("${i+1} | ${cue.start/1000}s - ${cue.end/1000}s", color = Color(0xFF54D1CC))
      Text(cue.text)
      TextButton(onClick = {
       val lang = tts?.setLanguage(Locale("fa", "IR"))
       if (!ready || lang == TextToSpeech.LANG_MISSING_DATA || lang == TextToSpeech.LANG_NOT_SUPPORTED) status = "موتور گفتار گوشی فارسی را پشتیبانی نمی‌کند یا صدای فارسی نصب نیست."
       else { tts?.speak(cue.text, TextToSpeech.QUEUE_FLUSH, null, "dubfa_$i"); status = "درخواست خواندن جمله به موتور گفتار ارسال شد." }
      }) { Text("آزمایش خواندن این جمله") }
     } }
    }
   }
  }
 }
 override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
}

private fun parseSrt(raw: String): List<Cue> {
 val blocks = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r','\n').split(Regex("\n\\s*\n"))
 val regex = Regex("(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{3})\\s*-->\\s*(\\d{2}):(\\d{2}):(\\d{2})[,\\.](\\d{3})")
 return blocks.mapNotNull { block ->
  val lines = block.lines()
  val idx = lines.indexOfFirst { regex.containsMatchIn(it) }
  if (idx < 0) return@mapNotNull null
  val m = regex.find(lines[idx]) ?: return@mapNotNull null
  val n = m.groupValues.drop(1).map { it.toLong() }
  fun toMs(h:Long, mi:Long, s:Long, ms:Long) = ((h*3600+mi*60+s)*1000)+ms
  val text = lines.drop(idx+1).joinToString(" ")
   .replace(Regex("<[^>]*>"), "").replace(Regex("\\{\\\\[^}]*}"), "")
   .replace("&nbsp;"," ").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">")
   .replace(Regex("\\s+")," ").trim()
  if (text.isBlank()) null else Cue(toMs(n[0],n[1],n[2],n[3]),toMs(n[4],n[5],n[6],n[7]),text)
 }
}
