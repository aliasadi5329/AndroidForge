package com.dubfa.app

import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
        }
        setContent { DubfaScreen() }
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf(listOf<Cue>()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember { mutableStateOf("ویدئو و زیرنویس فارسی را انتخاب کن.") }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }

        val videoPick = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                videoUri = uri
                status = "ویدئو انتخاب شد. حالا زیرنویس را انتخاب کن."
            }
        }

        val srtPick = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                val raw = contentResolver.openInputStream(uri)?.use { stream ->
                    BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).readText()
                }.orEmpty()
                cues = parseSrt(raw)
                subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                status = if (cues.isNotEmpty()) {
                    "زیرنویس خوانده شد: ${cues.size} بخش پیدا شد."
                } else {
                    "فایل باز شد اما بخش قابل‌خواندن پیدا نشد. SRT استاندارد امتحان کن."
                }
            }
        }

        DisposableEffect(videoUri) {
            val p = videoUri?.let { uri ->
                ExoPlayer.Builder(this@MainActivity).build().apply {
                    setMediaItem(MediaItem.fromUri(uri))
                    prepare()
                }
            }
            player = p
            onDispose {
                p?.release()
                if (player === p) player = null
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0B1020))
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "DUBFA",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color(0xFF9B7BFF)
                )
                Text(
                    "دوبله هوشمند فارسی — نسخه ۰٫۳",
                    color = Color(0xFF9AA6BF),
                    style = MaterialTheme.typography.bodyMedium
                )

                OutlinedButton(
                    onClick = { videoPick.launch("video/*") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("۱. انتخاب ویدئو")
                }

                if (player != null) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply { this.player = player }
                        },
                        update = { view -> view.player = player },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                    )
                }

                OutlinedButton(
                    onClick = {
                        srtPick.launch(arrayOf("application/x-subrip", "text/*", "*/*"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("۲. انتخاب زیرنویس SRT")
                }

                Text(subtitleName, color = Color(0xFF9AA6BF))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                        Text(status, color = Color(0xFFD1D7E8))
                        Text(
                            "تعداد بخش‌ها: ${cues.size}",
                            color = Color(0xFF55D6D0)
                        )
                        Text(
                            "دوبله خودکار کامل و خروجی MP4 در مرحله بعد اضافه می‌شود.",
                            color = Color(0xFFFFD27D),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (cues.isNotEmpty()) {
                    Text(
                        "پیش‌نمایش زیرنویس",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    cues.take(15).forEachIndexed { index, cue ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    "${index + 1} | ${cue.start / 1000}s – ${cue.end / 1000}s",
                                    color = Color(0xFF55D6D0),
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(cue.text, color = Color.White)
                                TextButton(
                                    onClick = {
                                        val result = tts?.setLanguage(Locale("fa", "IR"))
                                        if (!ttsReady ||
                                            result == TextToSpeech.LANG_MISSING_DATA ||
                                            result == TextToSpeech.LANG_NOT_SUPPORTED
                                        ) {
                                            status = "موتور گفتار گوشی فارسی را پشتیبانی نمی‌کند یا صدای فارسی نصب نیست."
                                        } else {
                                            tts?.speak(
                                                cue.text,
                                                TextToSpeech.QUEUE_FLUSH,
                                                null,
                                                "dubfa_$index"
                                            )
                                            status = "درخواست خواندن جمله ارسال شد."
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("آزمایش خواندن این جمله")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private fun parseSrt(raw: String): List<Cue> {
    val blocks = raw
        .removePrefix("\uFEFF")
        .replace("\r\n", "\n")
        .replace('\r', '\n')
        .split(Regex("\n\\s*\n"))

    val timeRegex = Regex(
        "(\\d{2}):(\\d{2}):(\\d{2})[,.](\\d{3})\\s*-->\\s*(\\d{2}):(\\d{2}):(\\d{2})[,.](\\d{3})"
    )

    return blocks.mapNotNull { block ->
        val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val timeLineIndex = lines.indexOfFirst { timeRegex.containsMatchIn(it) }
        if (timeLineIndex < 0) return@mapNotNull null

        val match = timeRegex.find(lines[timeLineIndex]) ?: return@mapNotNull null
        val parts = match.groupValues.drop(1).map { it.toLong() }

        fun toMs(h: Long, m: Long, s: Long, ms: Long): Long =
            ((h * 3600 + m * 60 + s) * 1000) + ms

        val text = lines
            .drop(timeLineIndex + 1)
            .joinToString(" ")
            .replace(Regex("<[^>]*>"), "")
            .replace(Regex("\\{\\\\[^}]*}"), "")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace(Regex("\\s+"), " ")
            .trim()

        if (text.isBlank()) null
        else Cue(
            start = toMs(parts[0], parts[1], parts[2], parts[3]),
            end = toMs(parts[4], parts[5], parts[6], parts[7]),
            text = text
        )
    }
}
