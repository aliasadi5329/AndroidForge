package com.dubfa.app

import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { result ->
            ttsReady = result == TextToSpeech.SUCCESS
        }
        setContent { DubfaScreen() }
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember { mutableStateOf("ویدئو و زیرنویس فارسی را انتخاب کن.") }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }

        val videoPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                videoUri = uri
                status = "ویدئو انتخاب شد. حالا زیرنویس را انتخاب کن."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: throw IllegalStateException("فایل قابل خواندن نیست")
                    val parsed = parseSrtRobust(raw)
                    cues = parsed
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    status = if (parsed.isEmpty()) {
                        "فایل باز شد، اما بخش زمان‌بندی‌شده‌ای پیدا نشد. فرمت فایل را بررسی کن."
                    } else {
                        "زیرنویس با موفقیت خوانده شد: ${parsed.size} بخش."
                    }
                } catch (e: Exception) {
                    status = "خواندن زیرنویس ناموفق بود: ${e.message ?: "خطای ناشناخته"}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            val p = videoUri?.let { uri ->
                ExoPlayer.Builder(this@MainActivity).build().apply {
                    setMediaItem(MediaItem.fromUri(uri))
                    prepare()
                }
            }
            player = p
            onDispose {
                p?.release()
                if (player === p) player = null
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0B1020))
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "DUBFA",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color(0xFF9B7BFF)
                )
                Text(
                    "دوبله هوشمند فارسی — نسخه ۰٫۴",
                    color = Color(0xFF9AA6BF),
                    style = MaterialTheme.typography.bodyMedium
                )

                OutlinedButton(
                    onClick = { videoPicker.launch("video/*") },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("۱. انتخاب ویدئو")
                }

                if (player != null) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply { this.player = player }
                        },
                        update = { view -> view.player = player },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                    )
                }

                OutlinedButton(
                    onClick = {
                        subtitlePicker.launch(
                            arrayOf("application/x-subrip", "text/*", "*/*")
                        )
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("۲. انتخاب زیرنویس SRT")
                }

                Text(subtitleName, color = Color(0xFF9AA6BF))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                        Text(status, color = Color(0xFFD1D7E8))
                        Text(
                            "تعداد بخش‌ها: ${cues.size}",
                            color = Color(0xFF55D6D0)
                        )
                        Text(
                            "دوبله خودکار کامل و خروجی MP4 در مرحله بعد اضافه می‌شود.",
                            color = Color(0xFFFFD27D),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (cues.isNotEmpty()) {
                    Text(
                        "پیش‌نمایش زیرنویس",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    cues.take(20).forEachIndexed { index, cue ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    "${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}",
                                    color = Color(0xFF55D6D0),
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(cue.text, color = Color.White)
                                TextButton(
                                    onClick = {
                                        val languageResult = tts?.setLanguage(Locale("fa", "IR"))
                                        if (!ttsReady ||
                                            languageResult == TextToSpeech.LANG_MISSING_DATA ||
                                            languageResult == TextToSpeech.LANG_NOT_SUPPORTED
                                        ) {
                                            status = "موتور گفتار گوشی فارسی را پشتیبانی نمی‌کند یا صدای فارسی نصب نیست."
                                        } else {
                                            tts?.speak(
                                                cue.text,
                                                TextToSpeech.QUEUE_FLUSH,
                                                null,
                                                "dubfa_$index"
                                            )
                                            status = "درخواست خواندن جمله ارسال شد."
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("آزمایش خواندن این جمله")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

/**
 * SRT parser tolerant of:
 * - UTF-8 BOM
 * - blank first line
 * - CRLF / LF
 * - HTML font/color tags
 * - RTL/LTR direction marks
 */
private fun parseSrtRobust(source: String): List<Cue> {
    val text = source
        .removePrefix("\uFEFF")
        .replace("\u0000", "")
        .replace("\r\n", "\n")
        .replace('\r', '\n')

    val timePattern = Regex(
        """^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$"""
    )
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0

    fun millis(h: Long, m: Long, s: Long, ms: Long): Long =
        (((h * 60 + m) * 60 + s) * 1000) + ms

    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) {
            i++
            continue
        }

        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) {
            i++
            continue
        }

        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++

        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) {
                textLines.add(line)
            }
            i++
        }

        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .replace(Regex("""\{\\[^}]*}"""), "")
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ")
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ")
            .trim()

        if (cleaned.isNotBlank() && end >= start) {
            output.add(Cue(start, end, cleaned))
        }
    }
    return output
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return "%02d:%02d:%02d".format(h, m, s)
}
