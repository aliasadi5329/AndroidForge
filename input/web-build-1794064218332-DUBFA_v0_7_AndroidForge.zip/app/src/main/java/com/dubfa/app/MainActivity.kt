package com.dubfa.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var ttsEngineName: String = "نامشخص"
    private var ttsLangInfo: String = "در حال بررسی..."
    private val mainHandler = Handler(Looper.getMainLooper())

    private val preferredEngines = listOf(
        "org.woheller69.ttsengine",
        "com.lookbe.tobesaid",
        "com.google.android.tts",
        "com.samsung.SMT"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initTts()
        setContent { DubfaScreen() }
    }

    private fun initTts(forceEngine: String? = null) {
        tts?.stop()
        tts?.shutdown()
        ttsReady = false

        val listener = TextToSpeech.OnInitListener { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                ttsEngineName = tts?.defaultEngine ?: forceEngine ?: "default"
                ttsLangInfo = applyBestPersianLocale()
                tts?.setSpeechRate(1.0f)
                tts?.setPitch(1.0f)
            } else {
                ttsLangInfo = "موتور گفتار راه‌اندازی نشد"
            }
        }

        tts = if (forceEngine != null) {
            try {
                TextToSpeech(this, listener, forceEngine)
            } catch (_: Exception) {
                TextToSpeech(this, listener)
            }
        } else {
            val engines = try {
                val probe = TextToSpeech(this, null)
                val list = probe.engines.map { it.name }
                probe.shutdown()
                list
            } catch (_: Exception) {
                emptyList()
            }
            val chosen = preferredEngines.firstOrNull { it in engines }
            if (chosen != null) {
                try {
                    TextToSpeech(this, listener, chosen)
                } catch (_: Exception) {
                    TextToSpeech(this, listener)
                }
            } else {
                TextToSpeech(this, listener)
            }
        }
    }

    private fun applyBestPersianLocale(): String {
        val engine = tts ?: return "TTS خالی است"

        val candidates = listOf(
            Locale("fa", "IR"),
            Locale("fa"),
            Locale.forLanguageTag("fa-IR"),
            Locale.forLanguageTag("fa")
        )

        for (loc in candidates) {
            val available = engine.isLanguageAvailable(loc)
            if (available != TextToSpeech.LANG_NOT_SUPPORTED) {
                val setResult = engine.setLanguage(loc)
                if (setResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                    pickPersianVoice(engine)
                    return "فارسی فعال (${loc.toLanguageTag()}) کد=$setResult"
                }
            }
        }

        val forced = engine.setLanguage(Locale("fa", "IR"))
        pickPersianVoice(engine)
        return if (forced == TextToSpeech.LANG_NOT_SUPPORTED) {
            "موتور کد NOT_SUPPORTED داد؛ اگر SherpaTTS است باز هم امتحان کن"
        } else {
            "فارسی اجباری شد کد=$forced"
        }
    }

    private fun pickPersianVoice(engine: TextToSpeech) {
        try {
            val voices = engine.voices ?: return
            val persian = voices.firstOrNull { v ->
                val tag = v.locale.toLanguageTag().lowercase()
                tag.startsWith("fa") ||
                    v.name.lowercase().contains("fa") ||
                    v.name.lowercase().contains("persian") ||
                    v.name.lowercase().contains("farsi") ||
                    v.name.lowercase().contains("gyro") ||
                    v.name.lowercase().contains("amir")
            }
            if (persian != null) engine.voice = persian
        } catch (_: Exception) {
        }
    }

    private fun canSpeakPersian(): Boolean {
        val engine = tts ?: return false
        if (!ttsReady) return false
        val codes = listOf(
            engine.isLanguageAvailable(Locale("fa", "IR")),
            engine.isLanguageAvailable(Locale("fa")),
            engine.setLanguage(Locale("fa", "IR")),
            engine.setLanguage(Locale("fa"))
        )
        return codes.any { it != TextToSpeech.LANG_NOT_SUPPORTED }
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember { mutableStateOf("ویدئو و زیرنویس فارسی را انتخاب کن.") }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }
        var dubEnabled by remember { mutableStateOf(false) }
        var lowerOriginal by remember { mutableStateOf(true) }
        var currentCueIndex by remember { mutableIntStateOf(-1) }
        var spokenCueIndex by remember { mutableIntStateOf(-1) }
        var engineInfo by remember { mutableStateOf(ttsLangInfo) }

        // engineInfo updates when user taps test / start buttons

        val videoPicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri ->
            if (uri != null) {
                videoUri = uri
                dubEnabled = false
                currentCueIndex = -1
                spokenCueIndex = -1
                status = "ویدئو انتخاب شد. حالا زیرنویس را انتخاب کن."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(
            ActivityResultContracts.OpenDocument()
        ) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: throw IllegalStateException("فایل قابل خواندن نیست")
                    val parsed = parseSrtRobust(raw)
                    cues = parsed
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    dubEnabled = false
                    currentCueIndex = -1
                    spokenCueIndex = -1
                    status = if (parsed.isEmpty()) {
                        "فایل باز شد، اما بخش زمان‌بندی‌شده‌ای پیدا نشد."
                    } else {
                        "زیرنویس خوانده شد: ${parsed.size} بخش."
                    }
                } catch (e: Exception) {
                    status = "خواندن زیرنویس ناموفق بود: ${e.message ?: "خطای ناشناخته"}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            val p = videoUri?.let { uri ->
                ExoPlayer.Builder(this@MainActivity).build().apply {
                    setMediaItem(MediaItem.fromUri(uri))
                    prepare()
                }
            }
            player = p
            onDispose {
                p?.release()
                if (player === p) player = null
            }
        }

        DisposableEffect(player, dubEnabled, cues) {
            if (player == null || !dubEnabled || cues.isEmpty()) {
                onDispose { }
            } else {
                val tick = object : Runnable {
                    override fun run() {
                        val p = player ?: return
                        if (!dubEnabled) return
                        val pos = p.currentPosition
                        val idx = cues.indexOfFirst { pos >= it.start && pos < it.end }
                        if (idx != currentCueIndex) currentCueIndex = idx
                        if (idx >= 0 && idx != spokenCueIndex && p.isPlaying) {
                            speakCue(cues[idx], idx)
                            spokenCueIndex = idx
                        }
                        if (idx >= 0 && spokenCueIndex > idx) spokenCueIndex = idx - 1
                        if (lowerOriginal) {
                            p.volume = if (idx >= 0 && ttsReady) 0.15f else 1.0f
                        } else {
                            p.volume = 1.0f
                        }
                        mainHandler.postDelayed(this, 80L)
                    }
                }
                mainHandler.post(tick)
                onDispose {
                    mainHandler.removeCallbacks(tick)
                    tts?.stop()
                    player?.volume = 1.0f
                }
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0B1020))
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("DUBFA", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF9B7BFF))
                Text("دوبله هوشمند فارسی — نسخه ۰٫۷", color = Color(0xFF9AA6BF), style = MaterialTheme.typography.bodyMedium)

                OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("۱. انتخاب ویدئو")
                }

                if (player != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                        update = { view -> view.player = player },
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                }

                OutlinedButton(
                    onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("۲. انتخاب زیرنویس SRT") }

                Text(subtitleName, color = Color(0xFF9AA6BF))

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                        Text(status, color = Color(0xFFD1D7E8))
                        Text("تعداد بخش‌ها: ${cues.size}", color = Color(0xFF55D6D0))
                        Text("موتور: $engineInfo", color = Color(0xFF9AA6BF), style = MaterialTheme.typography.bodySmall)
                        if (currentCueIndex >= 0 && currentCueIndex < cues.size) {
                            Text(
                                "دیالوگ فعلی: ${currentCueIndex + 1} — ${cues[currentCueIndex].text}",
                                color = Color(0xFFFFD27D),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2438)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("۳. دوبله زنده آفلاین", style = MaterialTheme.typography.titleMedium)

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    if (videoUri == null) { status = "اول ویدئو را انتخاب کن."; return@Button }
                                    if (cues.isEmpty()) { status = "اول زیرنویس SRT را انتخاب کن."; return@Button }

                                    initTts("org.woheller69.ttsengine")
                                    mainHandler.postDelayed({
                                        val info = applyBestPersianLocale()
                                        engineInfo = "$ttsEngineName | $info"
                                        if (!ttsReady) {
                                            status = "موتور گفتار آماده نیست. SherpaTTS را موتور ترجیحی کن و اپ را کامل ببند و باز کن."
                                            return@postDelayed
                                        }
                                        val ok = canSpeakPersian()
                                        spokenCueIndex = -1
                                        currentCueIndex = -1
                                        dubEnabled = true
                                        player?.play()
                                        status = if (ok) "دوبله زنده روشن شد. پخش را ادامه بده."
                                        else "دوبله روشن شد (حالت نرم). اگر صدا نبود مدل fa_IR را در Sherpa چک کن."
                                    }, 700)
                                },
                                enabled = !dubEnabled,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B7BFF))
                            ) { Text("شروع دوبله") }

                            OutlinedButton(
                                onClick = {
                                    dubEnabled = false
                                    tts?.stop()
                                    player?.volume = 1.0f
                                    status = "دوبله متوقف شد."
                                },
                                enabled = dubEnabled,
                                modifier = Modifier.weight(1f)
                            ) { Text("توقف دوبله") }
                        }

                        OutlinedButton(
                            onClick = {
                                initTts("org.woheller69.ttsengine")
                                mainHandler.postDelayed({
                                    val info = applyBestPersianLocale()
                                    engineInfo = "$ttsEngineName | $info"
                                    tts?.speak("سلام. این یک آزمایش صدای فارسی است.", TextToSpeech.QUEUE_FLUSH, null, "test_fa")
                                    status = "آزمایش موتور: $info"
                                }, 600)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("آزمایش موتور فارسی (Sherpa)") }

                        OutlinedButton(
                            onClick = {
                                try {
                                    startActivity(Intent("com.android.settings.TTS_SETTINGS"))
                                } catch (_: Exception) {
                                    status = "تنظیمات TTS را دستی باز کن."
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("باز کردن تنظیمات TTS گوشی") }

                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = lowerOriginal, onCheckedChange = { lowerOriginal = it })
                            Text("کم کردن صدای اصلی فیلم هنگام دوبله", color = Color(0xFFD1D7E8), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                if (cues.isNotEmpty()) {
                    Text("پیش‌نمایش زیرنویس", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    cues.take(15).forEachIndexed { index, cue ->
                        val isActive = index == currentCueIndex && dubEnabled
                        Card(
                            colors = CardDefaults.cardColors(containerColor = if (isActive) Color(0xFF2A1F4D) else Color(0xFF171F33)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}", color = Color(0xFF55D6D0), style = MaterialTheme.typography.labelMedium)
                                Text(cue.text, color = Color.White)
                                TextButton(
                                    onClick = {
                                        applyBestPersianLocale()
                                        tts?.speak(cue.text, TextToSpeech.QUEUE_FLUSH, null, "preview_$index")
                                        status = "آزمایش جمله ${index + 1}"
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("آزمایش خواندن این جمله") }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun speakCue(cue: Cue, index: Int) {
        val engine = tts ?: return
        if (!ttsReady) return
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {}
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {}
        })
        val durationMs = (cue.end - cue.start).coerceAtLeast(500L)
        val naturalMs = (cue.text.length / 12.0 * 1000).toLong().coerceAtLeast(400L)
        engine.setSpeechRate(when {
            naturalMs > durationMs * 1.4 -> 1.25f
            naturalMs > durationMs * 1.15 -> 1.1f
            else -> 1.0f
        })
        engine.speak(cue.text, TextToSpeech.QUEUE_FLUSH, null, "dub_$index")
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

private fun parseSrtRobust(source: String): List<Cue> {
    val text = source.removePrefix("\uFEFF").replace("\u0000", "").replace("\r\n", "\n").replace('\r', '\n')
    val timePattern = Regex("""^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$""")
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0
    fun millis(h: Long, m: Long, s: Long, ms: Long): Long = (((h * 60 + m) * 60 + s) * 1000) + ms
    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) { i++; continue }
        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) { i++; continue }
        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++
        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) textLines.add(line)
            i++
        }
        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .let { removeBraceTags(it) }
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isNotBlank() && end >= start) output.add(Cue(start, end, cleaned))
    }
    return output
}

private fun removeBraceTags(input: String): String {
    val result = StringBuilder()
    var insideTag = false
    for (ch in input) {
        when {
            ch == '{' && !insideTag -> insideTag = true
            ch == '}' && insideTag -> insideTag = false
            !insideTag -> result.append(ch)
        }
    }
    return result.toString()
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
