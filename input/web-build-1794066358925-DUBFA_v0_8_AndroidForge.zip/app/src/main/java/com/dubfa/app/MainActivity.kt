package com.dubfa.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.TextToSpeech.EngineInfo
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Locale

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var boundEngine: String = "-"
    private var langStatus: String = "-"
    private val mainHandler = Handler(Looper.getMainLooper())
    private var availableEngines: List<Pair<String, String>> = emptyList() // name to label

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        refreshEngineList()
        initTts(pickBestEngine())
        setContent { DubfaScreen() }
    }

    private fun refreshEngineList() {
        try {
            val probe = TextToSpeech(this, null)
            availableEngines = probe.engines.map { eng: EngineInfo ->
                eng.name to (eng.label ?: eng.name)
            }
            probe.shutdown()
        } catch (_: Exception) {
            availableEngines = emptyList()
        }
    }

    /** Prefer any engine whose package/label contains sherpa / piper / ttsengine */
    private fun pickBestEngine(): String? {
        val keys = listOf("sherpa", "ttsengine", "woheller", "piper", "tobesaid", "lookbe")
        for ((name, label) in availableEngines) {
            val blob = (name + " " + label).lowercase()
            if (keys.any { it in blob }) return name
        }
        // explicit known package
        if (availableEngines.any { it.first == "org.woheller69.ttsengine" }) {
            return "org.woheller69.ttsengine"
        }
        return availableEngines.firstOrNull()?.first
    }

    private fun initTts(enginePackage: String?) {
        try { tts?.stop() } catch (_: Exception) {}
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        ttsReady = false
        boundEngine = enginePackage ?: "default"

        val listener = TextToSpeech.OnInitListener { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                // Report what we actually got
                boundEngine = try {
                    tts?.defaultEngine ?: enginePackage ?: "unknown"
                } catch (_: Exception) {
                    enginePackage ?: "unknown"
                }
                langStatus = applyPersian()
            } else {
                langStatus = "راه‌اندازی ناموفق"
            }
        }

        tts = if (!enginePackage.isNullOrBlank()) {
            try {
                TextToSpeech(this, listener, enginePackage)
            } catch (_: Exception) {
                TextToSpeech(this, listener)
            }
        } else {
            TextToSpeech(this, listener)
        }
    }

    private fun applyPersian(): String {
        val engine = tts ?: return "TTS خالی"
        val locales = listOf(
            Locale("fa", "IR"),
            Locale("fa"),
            Locale.forLanguageTag("fa-IR"),
            Locale.forLanguageTag("fas"),
            Locale.forLanguageTag("fa")
        )
        val results = mutableListOf<String>()
        for (loc in locales) {
            val avail = engine.isLanguageAvailable(loc)
            results.add("${loc.toLanguageTag()}:$avail")
            if (avail != TextToSpeech.LANG_NOT_SUPPORTED) {
                val set = engine.setLanguage(loc)
                if (set != TextToSpeech.LANG_NOT_SUPPORTED) {
                    pickVoice(engine)
                    return "OK ${loc.toLanguageTag()} set=$set | ${results.joinToString()}"
                }
            }
        }
        // force
        val forced = engine.setLanguage(Locale("fa", "IR"))
        pickVoice(engine)
        return "force set=$forced | ${results.joinToString()}"
    }

    private fun pickVoice(engine: TextToSpeech) {
        try {
            val voices = engine.voices ?: return
            val v = voices.firstOrNull { voice ->
                val n = (voice.name + " " + voice.locale.toLanguageTag()).lowercase()
                n.contains("fa") || n.contains("fas") || n.contains("persian") ||
                    n.contains("farsi") || n.contains("gyro") || n.contains("amir") ||
                    n.contains("ganji")
            }
            if (v != null) engine.voice = v
        } catch (_: Exception) {
        }
    }

    private fun isSamsungEngine(): Boolean {
        val e = boundEngine.lowercase()
        return "samsung" in e || "smt" in e
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember { mutableStateOf("ویدئو و زیرنویس را انتخاب کن.") }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }
        var dubEnabled by remember { mutableStateOf(false) }
        var lowerOriginal by remember { mutableStateOf(true) }
        var currentCueIndex by remember { mutableIntStateOf(-1) }
        var spokenCueIndex by remember { mutableIntStateOf(-1) }
        var info by remember { mutableStateOf("$boundEngine | $langStatus") }
        var enginesText by remember {
            mutableStateOf(availableEngines.joinToString(" | ") { it.first.substringAfterLast('.') })
        }

        fun refreshInfo() {
            info = "$boundEngine | $langStatus"
            enginesText = availableEngines.joinToString(" | ") { it.first.substringAfterLast('.') }
        }

        val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                videoUri = uri
                dubEnabled = false
                currentCueIndex = -1
                spokenCueIndex = -1
                status = "ویدئو انتخاب شد."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: ""
                    cues = parseSrtRobust(raw)
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    dubEnabled = false
                    currentCueIndex = -1
                    spokenCueIndex = -1
                    status = "زیرنویس: ${cues.size} بخش"
                } catch (e: Exception) {
                    status = "خطای SRT: ${e.message}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            val p = videoUri?.let { uri ->
                ExoPlayer.Builder(this@MainActivity).build().apply {
                    setMediaItem(MediaItem.fromUri(uri)); prepare()
                }
            }
            player = p
            onDispose { p?.release(); if (player === p) player = null }
        }

        DisposableEffect(player, dubEnabled, cues) {
            if (player == null || !dubEnabled || cues.isEmpty()) {
                onDispose { }
            } else {
                val tick = object : Runnable {
                    override fun run() {
                        val p = player ?: return
                        if (!dubEnabled) return
                        val pos = p.currentPosition
                        val idx = cues.indexOfFirst { pos >= it.start && pos < it.end }
                        if (idx != currentCueIndex) currentCueIndex = idx
                        if (idx >= 0 && idx != spokenCueIndex && p.isPlaying) {
                            speakCue(cues[idx], idx)
                            spokenCueIndex = idx
                        }
                        if (idx >= 0 && spokenCueIndex > idx) spokenCueIndex = idx - 1
                        p.volume = if (lowerOriginal && idx >= 0) 0.15f else 1f
                        mainHandler.postDelayed(this, 80L)
                    }
                }
                mainHandler.post(tick)
                onDispose {
                    mainHandler.removeCallbacks(tick)
                    tts?.stop()
                    player?.volume = 1f
                }
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            Column(
                Modifier.fillMaxSize().background(Color(0xFF0B1020)).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("DUBFA", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF9B7BFF))
                Text("نسخه ۰٫۸ — انتخاب اجباری موتور Sherpa", color = Color(0xFF9AA6BF), style = MaterialTheme.typography.bodyMedium)

                // Engine diagnostic card
                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF2A1520)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("تشخیص موتور TTS", style = MaterialTheme.typography.titleMedium, color = Color(0xFFFF8A80))
                        Text("موتور فعلی: $info", color = Color.White, style = MaterialTheme.typography.bodySmall)
                        Text("موتورهای نصب‌شده: $enginesText", color = Color(0xFF9AA6BF), style = MaterialTheme.typography.bodySmall)
                        if (isSamsungEngine()) {
                            Text(
                                "⚠ هنوز روی Samsung SMT هستی. انگلیسی کار می‌کند ولی فارسی نه. دکمه زیر را بزن.",
                                color = Color(0xFFFFD27D),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Button(
                            onClick = {
                                refreshEngineList()
                                val best = pickBestEngine()
                                if (best == null) {
                                    status = "هیچ موتور TTS پیدا نشد."
                                    refreshInfo()
                                    return@Button
                                }
                                initTts(best)
                                mainHandler.postDelayed({
                                    langStatus = applyPersian()
                                    refreshInfo()
                                    val sample = "سلام. این آزمایش صدای فارسی است."
                                    val r = tts?.speak(sample, TextToSpeech.QUEUE_FLUSH, null, "test_fa")
                                    status = "اتصال به $best — speak=$r — $langStatus"
                                    if (isSamsungEngine()) {
                                        status += " | هنوز سامسونگ است! در تنظیمات موتور برگزیده را SherpaTTS بگذار و گوشی را یک‌بار قفل/باز کن."
                                    }
                                }, 800)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                        ) {
                            Text("اجبار اتصال به SherpaTTS")
                        }
                    }
                }

                OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("۱. انتخاب ویدئو")
                }

                if (player != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                        update = { v -> v.player = player },
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                }

                OutlinedButton(
                    onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("۲. انتخاب زیرنویس SRT") }

                Text(subtitleName, color = Color(0xFF9AA6BF))

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                        Text(status, color = Color(0xFFD1D7E8))
                        Text("تعداد بخش‌ها: ${cues.size}", color = Color(0xFF55D6D0))
                        if (currentCueIndex >= 0 && currentCueIndex < cues.size) {
                            Text("دیالوگ فعلی: ${currentCueIndex + 1} — ${cues[currentCueIndex].text}", color = Color(0xFFFFD27D), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2438)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("۳. دوبله زنده", style = MaterialTheme.typography.titleMedium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (videoUri == null) { status = "اول ویدئو"; return@Button }
                                    if (cues.isEmpty()) { status = "اول SRT"; return@Button }
                                    // Force sherpa before dub
                                    refreshEngineList()
                                    initTts(pickBestEngine())
                                    mainHandler.postDelayed({
                                        langStatus = applyPersian()
                                        refreshInfo()
                                        if (isSamsungEngine()) {
                                            status = "هنوز موتور سامسونگ است. اول دکمه قرمز «اجبار اتصال به SherpaTTS» را بزن تا موتور عوض شود."
                                            return@postDelayed
                                        }
                                        spokenCueIndex = -1
                                        currentCueIndex = -1
                                        dubEnabled = true
                                        player?.play()
                                        status = "دوبله روشن شد با موتور $boundEngine"
                                    }, 800)
                                },
                                enabled = !dubEnabled,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B7BFF))
                            ) { Text("شروع دوبله") }

                            OutlinedButton(
                                onClick = {
                                    dubEnabled = false
                                    tts?.stop()
                                    player?.volume = 1f
                                    status = "توقف دوبله"
                                },
                                enabled = dubEnabled,
                                modifier = Modifier.weight(1f)
                            ) { Text("توقف") }
                        }

                        OutlinedButton(
                            onClick = {
                                try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                                catch (_: Exception) { status = "تنظیمات TTS را دستی باز کن" }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("باز کردن تنظیمات TTS") }

                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = lowerOriginal, onCheckedChange = { lowerOriginal = it })
                            Text("کم کردن صدای فیلم", color = Color(0xFFD1D7E8), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                if (cues.isNotEmpty()) {
                    Text("پیش‌نمایش", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    cues.take(12).forEachIndexed { index, cue ->
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (index == currentCueIndex && dubEnabled) Color(0xFF2A1F4D) else Color(0xFF171F33)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}", color = Color(0xFF55D6D0), style = MaterialTheme.typography.labelMedium)
                                Text(cue.text, color = Color.White)
                                TextButton(
                                    onClick = {
                                        if (isSamsungEngine()) {
                                            status = "موتور سامسونگ است؛ اول اجبار Sherpa را بزن."
                                            return@TextButton
                                        }
                                        applyPersian()
                                        tts?.speak(cue.text, TextToSpeech.QUEUE_FLUSH, null, "p_$index")
                                        status = "آزمایش جمله ${index + 1}"
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("آزمایش این جمله") }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun speakCue(cue: Cue, index: Int) {
        val engine = tts ?: return
        if (!ttsReady) return
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {}
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {}
        })
        val durationMs = (cue.end - cue.start).coerceAtLeast(500L)
        val naturalMs = (cue.text.length / 12.0 * 1000).toLong().coerceAtLeast(400L)
        engine.setSpeechRate(
            when {
                naturalMs > durationMs * 1.4 -> 1.25f
                naturalMs > durationMs * 1.15 -> 1.1f
                else -> 1.0f
            }
        )
        engine.speak(cue.text, TextToSpeech.QUEUE_FLUSH, null, "dub_$index")
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        try { tts?.stop(); tts?.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }
}

private fun parseSrtRobust(source: String): List<Cue> {
    val text = source.removePrefix("\uFEFF").replace("\u0000", "").replace("\r\n", "\n").replace('\r', '\n')
    val timePattern = Regex("""^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$""")
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0
    fun millis(h: Long, m: Long, s: Long, ms: Long) = (((h * 60 + m) * 60 + s) * 1000) + ms
    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) { i++; continue }
        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) { i++; continue }
        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++
        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) textLines.add(line)
            i++
        }
        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .let { removeBraceTags(it) }
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isNotBlank() && end >= start) output.add(Cue(start, end, cleaned))
    }
    return output
}

private fun removeBraceTags(input: String): String {
    val result = StringBuilder()
    var inside = false
    for (ch in input) {
        when {
            ch == '{' && !inside -> inside = true
            ch == '}' && inside -> inside = false
            !inside -> result.append(ch)
        }
    }
    return result.toString()
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
