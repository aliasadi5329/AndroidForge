package com.dubfa.app

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.Executors

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newFixedThreadPool(2)
    private var voicePlayer: MediaPlayer? = null
    private val ttsCacheDir: File by lazy {
        val dir = File(applicationContext.cacheDir, "tts_fa")
        if (!dir.exists()) dir.mkdirs()
        dir
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DubfaScreen() }
    }

    /** Download Persian speech audio (MP3) via online TTS and return local file. */
    private fun fetchPersianAudio(text: String): File {
        val cleaned = text
            .replace(Regex("""\s+"""), " ")
            .trim()
            .take(160)
        if (cleaned.isEmpty()) throw IllegalStateException("متن خالی")

        val key = sha1(cleaned)
        val out = File(ttsCacheDir, "$key.mp3")
        if (out.exists() && out.length() > 100) return out

        val q = URLEncoder.encode(cleaned, "UTF-8")
        val len = cleaned.length
        val endpoints = listOf(
            "https://translate.googleapis.com/translate_tts?ie=UTF-8&client=gtx&tl=fa&q=$q",
            "https://translate.google.com/translate_tts?ie=UTF-8&client=gtx&tl=fa&q=$q",
            "https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=fa&total=1&idx=0&textlen=$len&q=$q",
            "https://translate.google.com/translate_tts?ie=UTF-8&client=webapp&tl=fa&ttsspeed=1&q=$q"
        )

        val errors = mutableListOf<String>()
        for (endpoint in endpoints) {
            try {
                downloadToFile(endpoint, out)
                if (out.exists() && out.length() > 50) return out
                if (out.exists()) out.delete()
                errors.add("empty")
            } catch (e: Exception) {
                if (out.exists()) out.delete()
                errors.add(e.message ?: "err")
            }
        }
        throw IllegalStateException(
            "همه endpointها شکست: ${errors.joinToString(" | ")}. اگر در ایران هستی VPN را روشن کن و دوباره بزن."
        )
    }

    private fun downloadToFile(endpoint: String, out: File) {
        val url = URL(endpoint)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 25000
            instanceFollowRedirects = true
            requestMethod = "GET"
            setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
            )
            setRequestProperty("Accept", "audio/mpeg, audio/*;q=0.9, */*;q=0.8")
            setRequestProperty("Accept-Language", "fa-IR,fa;q=0.9,en-US;q=0.8")
            setRequestProperty("Referer", "https://translate.google.com/")
            setRequestProperty("Origin", "https://translate.google.com")
        }
        try {
            val code = conn.responseCode
            if (code !in 200..299) {
                throw IllegalStateException("HTTP $code")
            }
            conn.inputStream.use { input ->
                FileOutputStream(out).use { output ->
                    input.copyTo(output)
                }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun playFile(file: File, onDone: (() -> Unit)? = null) {
        mainHandler.post {
            try {
                voicePlayer?.setOnCompletionListener(null)
                voicePlayer?.stop()
                voicePlayer?.release()
            } catch (_: Exception) {
            }
            try {
                val mp = MediaPlayer()
                voicePlayer = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                mp.setDataSource(file.absolutePath)
                mp.setOnCompletionListener {
                    onDone?.invoke()
                }
                mp.setOnErrorListener { _, _, _ ->
                    onDone?.invoke()
                    true
                }
                mp.prepare()
                mp.start()
            } catch (e: Exception) {
                onDone?.invoke()
            }
        }
    }

    private fun speakOnline(
        text: String,
        onStatus: (String) -> Unit,
        onDone: (() -> Unit)? = null
    ) {
        if (text.isBlank()) {
            onDone?.invoke()
            return
        }
        onStatus("در حال دریافت صدای آنلاین...")
        ioExecutor.execute {
            try {
                val file = fetchPersianAudio(text)
                mainHandler.post { onStatus("در حال پخش...") }
                playFile(file, onDone)
            } catch (e: Exception) {
                mainHandler.post {
                    onStatus("خطای TTS آنلاین: ${e.message ?: "نامشخص"}")
                    onDone?.invoke()
                }
            }
        }
    }

    private fun stopVoice() {
        try {
            voicePlayer?.stop()
            voicePlayer?.release()
        } catch (_: Exception) {
        }
        voicePlayer = null
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember { mutableStateOf("ویدئو و زیرنویس فارسی را انتخاب کن. دوبله با TTS آنلاین فارسی کار می‌کند.") }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }
        var dubEnabled by remember { mutableStateOf(false) }
        var lowerOriginal by remember { mutableStateOf(true) }
        var currentCueIndex by remember { mutableIntStateOf(-1) }
        var spokenCueIndex by remember { mutableIntStateOf(-1) }
        var busy by remember { mutableStateOf(false) }

        val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                videoUri = uri
                dubEnabled = false
                currentCueIndex = -1
                spokenCueIndex = -1
                status = "ویدئو انتخاب شد."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: ""
                    cues = parseSrtRobust(raw)
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    dubEnabled = false
                    currentCueIndex = -1
                    spokenCueIndex = -1
                    status = "زیرنویس: ${cues.size} بخش — آماده دوبله آنلاین فارسی"
                } catch (e: Exception) {
                    status = "خطای SRT: ${e.message}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            val p = videoUri?.let { uri ->
                ExoPlayer.Builder(this@MainActivity).build().apply {
                    setMediaItem(MediaItem.fromUri(uri))
                    prepare()
                }
            }
            player = p
            onDispose {
                p?.release()
                if (player === p) player = null
            }
        }

        // Sync loop with online TTS
        DisposableEffect(player, dubEnabled, cues) {
            if (player == null || !dubEnabled || cues.isEmpty()) {
                onDispose { }
            } else {
                val tick = object : Runnable {
                    override fun run() {
                        val p = player ?: return
                        if (!dubEnabled) return
                        val pos = p.currentPosition
                        val idx = cues.indexOfFirst { pos >= it.start && pos < it.end }
                        if (idx != currentCueIndex) currentCueIndex = idx

                        if (idx >= 0 && idx != spokenCueIndex && p.isPlaying && !busy) {
                            spokenCueIndex = idx
                            busy = true
                            val cue = cues[idx]
                            if (lowerOriginal) p.volume = 0.12f
                            speakOnline(
                                text = cue.text,
                                onStatus = { msg -> status = "دیالوگ ${idx + 1}: $msg" },
                                onDone = {
                                    busy = false
                                    if (!dubEnabled) return@speakOnline
                                    // restore volume briefly if no active cue
                                    val now = player?.currentPosition ?: 0L
                                    val still = cues.any { now >= it.start && now < it.end }
                                    if (!still) player?.volume = 1f
                                }
                            )
                        }

                        if (idx < 0) {
                            p.volume = 1f
                        } else if (lowerOriginal) {
                            p.volume = 0.12f
                        }

                        if (idx >= 0 && spokenCueIndex > idx) spokenCueIndex = idx - 1

                        mainHandler.postDelayed(this, 100L)
                    }
                }
                mainHandler.post(tick)
                onDispose {
                    mainHandler.removeCallbacks(tick)
                    stopVoice()
                    busy = false
                    player?.volume = 1f
                }
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0B1020))
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("DUBFA", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF9B7BFF))
                Text(
                    "نسخه ۰٫۱۱ — دوبله آنلاین فارسی (بدون نیاز به Samsung/Sherpa)",
                    color = Color(0xFF9AA6BF),
                    style = MaterialTheme.typography.bodyMedium
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B3A2A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("TTS آنلاین فارسی", style = MaterialTheme.typography.titleMedium, color = Color(0xFF69F0AE))
                        Text(
                            "دیگر وابسته به موتور سامسونگ نیست. اینترنت لازم است. صداها در کش گوشی ذخیره می‌شوند.",
                            color = Color(0xFFD1D7E8),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                OutlinedButton(
                    onClick = { videoPicker.launch("video/*") },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("۱. انتخاب ویدئو") }

                if (player != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                        update = { v -> v.player = player },
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                }

                OutlinedButton(
                    onClick = {
                        subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*"))
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("۲. انتخاب زیرنویس SRT فارسی") }

                Text(subtitleName, color = Color(0xFF9AA6BF))

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                        Text(status, color = Color(0xFFD1D7E8))
                        Text("تعداد بخش‌ها: ${cues.size}", color = Color(0xFF55D6D0))
                        if (currentCueIndex >= 0 && currentCueIndex < cues.size) {
                            Text(
                                "دیالوگ فعلی: ${currentCueIndex + 1} — ${cues[currentCueIndex].text}",
                                color = Color(0xFFFFD27D),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2438)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("۳. دوبله زنده آنلاین", style = MaterialTheme.typography.titleMedium)

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (videoUri == null) {
                                        status = "اول ویدئو را انتخاب کن."
                                        return@Button
                                    }
                                    if (cues.isEmpty()) {
                                        status = "اول زیرنویس فارسی را انتخاب کن."
                                        return@Button
                                    }
                                    spokenCueIndex = -1
                                    currentCueIndex = -1
                                    busy = false
                                    dubEnabled = true
                                    player?.play()
                                    status = "دوبله آنلاین روشن شد. پخش را ادامه بده."
                                },
                                enabled = !dubEnabled,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B7BFF))
                            ) { Text("شروع دوبله") }

                            OutlinedButton(
                                onClick = {
                                    dubEnabled = false
                                    busy = false
                                    stopVoice()
                                    player?.volume = 1f
                                    status = "دوبله متوقف شد."
                                },
                                enabled = dubEnabled,
                                modifier = Modifier.weight(1f)
                            ) { Text("توقف") }
                        }

                        OutlinedButton(
                            onClick = {
                                speakOnline(
                                    text = "سلام. این یک آزمایش صدای فارسی آنلاین است.",
                                    onStatus = { status = it }
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("آزمایش صدای آنلاین فارسی") }

                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = lowerOriginal, onCheckedChange = { lowerOriginal = it })
                            Text(
                                "کم کردن صدای اصلی فیلم هنگام دوبله",
                                color = Color(0xFFD1D7E8),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        Text(
                            "نکته: برای هر جمله یک درخواست اینترنتی زده می‌شود (بار اول). دفعات بعد از کش خوانده می‌شود.",
                            color = Color(0xFF9AA6BF),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                if (cues.isNotEmpty()) {
                    Text("پیش‌نمایش زیرنویس", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    cues.take(15).forEachIndexed { index, cue ->
                        val active = index == currentCueIndex && dubEnabled
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (active) Color(0xFF2A1F4D) else Color(0xFF171F33)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    "${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}",
                                    color = Color(0xFF55D6D0),
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(cue.text, color = Color.White)
                                TextButton(
                                    onClick = {
                                        speakOnline(
                                            text = cue.text,
                                            onStatus = { status = "آزمایش ${index + 1}: $it" }
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("آزمایش آنلاین این جمله") }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        stopVoice()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}

private fun sha1(text: String): String {
    val md = MessageDigest.getInstance("SHA-1")
    val bytes = md.digest(text.toByteArray(Charsets.UTF_8))
    return bytes.joinToString("") { "%02x".format(it) }
}

private fun parseSrtRobust(source: String): List<Cue> {
    val text = source.removePrefix("\uFEFF").replace("\u0000", "").replace("\r\n", "\n").replace('\r', '\n')
    val timePattern = Regex("""^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$""")
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0
    fun millis(h: Long, m: Long, s: Long, ms: Long) = (((h * 60 + m) * 60 + s) * 1000) + ms
    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) { i++; continue }
        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) { i++; continue }
        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++
        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) textLines.add(line)
            i++
        }
        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .let { removeBraceTags(it) }
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isNotBlank() && end >= start) output.add(Cue(start, end, cleaned))
    }
    return output
}

private fun removeBraceTags(input: String): String {
    val result = StringBuilder()
    var inside = false
    for (ch in input) {
        when {
            ch == '{' && !inside -> inside = true
            ch == '}' && inside -> inside = false
            !inside -> result.append(ch)
        }
    }
    return result.toString()
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
