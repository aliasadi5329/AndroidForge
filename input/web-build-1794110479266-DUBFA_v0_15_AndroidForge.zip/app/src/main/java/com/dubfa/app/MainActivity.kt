package com.dubfa.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newFixedThreadPool(2)
    private var voicePlayer: MediaPlayer? = null
    private val ttsCacheDir: File by lazy {
        val dir = File(applicationContext.cacheDir, "tts_fa")
        if (!dir.exists()) dir.mkdirs()
        dir
    }
    private val prefs by lazy { getSharedPreferences("dubfa", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DubfaScreen() }
    }

        private fun cleanApiKey(raw: String): String {
        val compact = buildString {
            for (ch in raw) {
                if (ch != ' ' && ch != '\n' && ch != '\r' && ch != '\t') append(ch)
            }
        }
        val match = Regex("fh_live_[A-Za-z0-9_-]+").find(compact)
        if (match != null) return match.value
        return compact.filter { it.code in 33..126 }
    }

    private fun ensureMinText(text: String): String {
        // FarsiHoosh rejects texts shorter than 10 characters.
        // Pad short dialogues so every cue is spoken, without dropping words.
        val t = text.replace(Regex("""\s+"""), " ").trim()
        if (t.isEmpty()) return "سكوت كوتاه."
        if (t.length >= 10) return t.take(500)
        var s = t
        while (s.length < 10) {
            s = "$s. $t"
        }
        return s.take(500)
    }

    private fun getApiKey(): String = cleanApiKey(prefs.getString("farsihoosh_key", "") ?: "")
    private fun setApiKey(key: String) {
        prefs.edit().putString("farsihoosh_key", cleanApiKey(key)).apply()
    }

    /** Persian TTS via farsihoosh.ir (works in Iran). */
    private fun fetchPersianAudio(text: String, apiKeyRaw: String): File {
        val apiKey = cleanApiKey(apiKeyRaw)
        val cleaned = ensureMinText(text)
        if (cleaned.isEmpty()) throw IllegalStateException("متن خالی")
        if (apiKey.isBlank() || !apiKey.startsWith("fh_live_")) {
            throw IllegalStateException("کلید نامعتبر است. فقط fh_live_... را بدون متن اضافه بچسبان")
        }

        val key = sha1(apiKey + "|" + cleaned)
        val out = File(ttsCacheDir, "$key.mp3")
        if (out.exists() && out.length() > 100) return out

        val url = URL("https://farsihoosh.ir/api/tts")
        val body = """{"text":${jsonString(cleaned)},"model":"pocket"}"""
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 60000
            requestMethod = "POST"
            doOutput = true
            setRequestProperty("Authorization", "Bearer $apiKey")
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "audio/mpeg, application/json, */*")
            setRequestProperty("User-Agent", "DUBFA/0.12 (Android)")
        }
        try {
            OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val bytes = stream?.readBytes() ?: ByteArray(0)
            if (code !in 200..299) {
                val err = bytes.toString(Charsets.UTF_8).take(200)
                throw IllegalStateException("HTTP $code ${err.ifBlank { "" }}")
            }
            if (bytes.size < 80) throw IllegalStateException("پاسخ صوتی خیلی کوتاه است")
            FileOutputStream(out).use { it.write(bytes) }
            return out
        } finally {
            conn.disconnect()
        }
    }

    private fun playFile(file: File, onDone: (() -> Unit)? = null) {
        mainHandler.post {
            try {
                voicePlayer?.setOnCompletionListener(null)
                voicePlayer?.stop()
                voicePlayer?.release()
            } catch (_: Exception) {
            }
            try {
                val mp = MediaPlayer()
                voicePlayer = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                mp.setDataSource(file.absolutePath)
                mp.setOnCompletionListener { onDone?.invoke() }
                mp.setOnErrorListener { _, _, _ ->
                    onDone?.invoke(); true
                }
                mp.prepare()
                mp.start()
            } catch (_: Exception) {
                onDone?.invoke()
            }
        }
    }

    private fun speakOnline(
        text: String,
        apiKey: String,
        onStatus: (String) -> Unit,
        onDone: (() -> Unit)? = null
    ) {
        if (text.isBlank()) {
            onDone?.invoke(); return
        }
        onStatus("در حال دریافت صدا...")
        ioExecutor.execute {
            var lastError: Exception? = null
            repeat(2) { attempt ->
                try {
                    val file = fetchPersianAudio(text, apiKey)
                    mainHandler.post { onStatus("در حال پخش...") }
                    playFile(file, onDone)
                    return@execute
                } catch (e: Exception) {
                    lastError = e
                    try { Thread.sleep(400) } catch (_: Exception) {}
                }
            }
            mainHandler.post {
                onStatus("خطای TTS: ${lastError?.message ?: "نامشخص"}")
                onDone?.invoke()
            }
        }
    }

    private fun stopVoice() {
        try {
            voicePlayer?.stop()
            voicePlayer?.release()
        } catch (_: Exception) {
        }
        voicePlayer = null
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember {
            mutableStateOf("کلید رایگان فارسی‌هوش را بگیر، بعد ویدیو و SRT را انتخاب کن.")
        }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }
        var dubEnabled by remember { mutableStateOf(false) }
        var lowerOriginal by remember { mutableStateOf(true) }
        var currentCueIndex by remember { mutableIntStateOf(-1) }
        var spokenCueIndex by remember { mutableIntStateOf(-1) }
        var busy by remember { mutableStateOf(false) }
        var apiKey by remember { mutableStateOf(getApiKey()) }

        val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                videoUri = uri
                dubEnabled = false
                currentCueIndex = -1
                spokenCueIndex = -1
                status = "ویدئو انتخاب شد."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: ""
                    cues = parseSrtRobust(raw)
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    dubEnabled = false
                    currentCueIndex = -1
                    spokenCueIndex = -1
                    status = "زیرنویس: ${cues.size} بخش"
                } catch (e: Exception) {
                    status = "خطای SRT: ${e.message}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            val p = videoUri?.let { uri ->
                ExoPlayer.Builder(this@MainActivity).build().apply {
                    setMediaItem(MediaItem.fromUri(uri)); prepare()
                }
            }
            player = p
            onDispose { p?.release(); if (player === p) player = null }
        }

        DisposableEffect(player, dubEnabled, cues, apiKey) {
            if (player == null || !dubEnabled || cues.isEmpty()) {
                onDispose { }
            } else {
                val tick = object : Runnable {
                    override fun run() {
                        val p = player ?: return
                        if (!dubEnabled) return
                        val pos = p.currentPosition
                        val idx = cues.indexOfFirst { pos >= it.start && pos < it.end }
                        if (idx != currentCueIndex) currentCueIndex = idx

                        if (idx >= 0 && idx != spokenCueIndex && p.isPlaying && !busy) {
                            spokenCueIndex = idx
                            busy = true
                            val cue = cues[idx]
                            if (lowerOriginal) p.volume = 0.12f
                            speakOnline(
                                text = cue.text,
                                apiKey = apiKey,
                                onStatus = { msg -> status = "دیالوگ ${idx + 1}: $msg" },
                                onDone = {
                                    busy = false
                                    val now = player?.currentPosition ?: 0L
                                    val still = cues.any { now >= it.start && now < it.end }
                                    if (!still) player?.volume = 1f
                                }
                            )
                        }
                        if (idx < 0) p.volume = 1f
                        else if (lowerOriginal) p.volume = 0.12f
                        if (idx >= 0 && spokenCueIndex > idx) spokenCueIndex = idx - 1
                        mainHandler.postDelayed(this, 100L)
                    }
                }
                mainHandler.post(tick)
                onDispose {
                    mainHandler.removeCallbacks(tick)
                    stopVoice()
                    busy = false
                    player?.volume = 1f
                }
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            Column(
                Modifier.fillMaxSize().background(Color(0xFF0B1020)).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("DUBFA", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF9B7BFF))
                Text(
                    "نسخه ۰٫۱۵ — دوبله با فارسی‌هوش (ایرانی)",
                    color = Color(0xFF9AA6BF),
                    style = MaterialTheme.typography.bodyMedium
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B3A2A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("کلید API فارسی‌هوش", style = MaterialTheme.typography.titleMedium, color = Color(0xFF69F0AE))
                        Text(
                            "۱) برو به farsihoosh.ir\n۲) ورود / ثبت‌نام\n۳) تب کلید API → ساخت کلید\n۴) کلید را اینجا بچسبان",
                            color = Color(0xFFD1D7E8),
                            style = MaterialTheme.typography.bodySmall
                        )
                        OutlinedTextField(
                            value = apiKey,
                            onValueChange = {
                                val cleaned = cleanApiKey(it)
                                apiKey = cleaned
                                setApiKey(cleaned)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            label = { Text("fh_live_...") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF69F0AE),
                                unfocusedBorderColor = Color(0xFF556677),
                                focusedLabelColor = Color(0xFF69F0AE),
                                unfocusedLabelColor = Color(0xFF9AA6BF)
                            )
                        )
                    }
                }

                OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("۱. انتخاب ویدئو")
                }

                if (player != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                        update = { v -> v.player = player },
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                }

                OutlinedButton(
                    onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("۲. انتخاب زیرنویس SRT فارسی") }

                Text(subtitleName, color = Color(0xFF9AA6BF))

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                        Text(status, color = Color(0xFFD1D7E8))
                        Text("تعداد بخش‌ها: ${cues.size}", color = Color(0xFF55D6D0))
                        if (currentCueIndex >= 0 && currentCueIndex < cues.size) {
                            Text(
                                "دیالوگ فعلی: ${currentCueIndex + 1} — ${cues[currentCueIndex].text}",
                                color = Color(0xFFFFD27D),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2438)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("۳. دوبله زنده", style = MaterialTheme.typography.titleMedium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (apiKey.isBlank()) {
                                        status = "اول کلید API فارسی‌هوش را وارد کن."
                                        return@Button
                                    }
                                    if (videoUri == null) {
                                        status = "اول ویدئو را انتخاب کن."; return@Button
                                    }
                                    if (cues.isEmpty()) {
                                        status = "اول زیرنویس را انتخاب کن."; return@Button
                                    }
                                    spokenCueIndex = -1
                                    currentCueIndex = -1
                                    busy = false
                                    dubEnabled = true
                                    player?.play()
                                    status = "دوبله روشن شد."
                                },
                                enabled = !dubEnabled,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B7BFF))
                            ) { Text("شروع دوبله") }

                            OutlinedButton(
                                onClick = {
                                    dubEnabled = false
                                    busy = false
                                    stopVoice()
                                    player?.volume = 1f
                                    status = "توقف دوبله"
                                },
                                enabled = dubEnabled,
                                modifier = Modifier.weight(1f)
                            ) { Text("توقف") }
                        }

                        OutlinedButton(
                            onClick = {
                                if (apiKey.isBlank()) {
                                    status = "اول کلید API را وارد کن."
                                    return@OutlinedButton
                                }
                                speakOnline(
                                    text = "سلام. این یک آزمایش صدای فارسی است.",
                                    apiKey = apiKey,
                                    onStatus = { status = it }
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("آزمایش صدای فارسی‌هوش") }

                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = lowerOriginal, onCheckedChange = { lowerOriginal = it })
                            Text(
                                "کم کردن صدای اصلی فیلم هنگام دوبله",
                                color = Color(0xFFD1D7E8),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                if (cues.isNotEmpty()) {
                    Text("پیش‌نمایش", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    cues.take(12).forEachIndexed { index, cue ->
                        val active = index == currentCueIndex && dubEnabled
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (active) Color(0xFF2A1F4D) else Color(0xFF171F33)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    "${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}",
                                    color = Color(0xFF55D6D0),
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(cue.text, color = Color.White)
                                TextButton(
                                    onClick = {
                                        if (apiKey.isBlank()) {
                                            status = "اول کلید API را وارد کن."
                                            return@TextButton
                                        }
                                        speakOnline(
                                            text = cue.text,
                                            apiKey = apiKey,
                                            onStatus = { status = "آزمایش ${index + 1}: $it" }
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("آزمایش این جمله") }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        stopVoice()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}

private fun jsonString(s: String): String {
    val b = StringBuilder("\"")
    for (ch in s) {
        when (ch) {
            '\\' -> b.append("\\\\")
            '"' -> b.append("\\\"")
            '\n' -> b.append("\\n")
            '\r' -> b.append("\\r")
            '\t' -> b.append("\\t")
            else -> b.append(ch)
        }
    }
    b.append('"')
    return b.toString()
}

private fun sha1(text: String): String {
    val md = MessageDigest.getInstance("SHA-1")
    return md.digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

private fun parseSrtRobust(source: String): List<Cue> {
    val text = source.removePrefix("\uFEFF").replace("\u0000", "").replace("\r\n", "\n").replace('\r', '\n')
    val timePattern = Regex("""^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$""")
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0
    fun millis(h: Long, m: Long, s: Long, ms: Long) = (((h * 60 + m) * 60 + s) * 1000) + ms
    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) { i++; continue }
        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) { i++; continue }
        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++
        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) textLines.add(line)
            i++
        }
        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .let { removeBraceTags(it) }
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isNotBlank() && end >= start) output.add(Cue(start, end, cleaned))
    }
    return output
}

private fun removeBraceTags(input: String): String {
    val result = StringBuilder()
    var inside = false
    for (ch in input) {
        when {
            ch == '{' && !inside -> inside = true
            ch == '}' && inside -> inside = false
            !inside -> result.append(ch)
        }
    }
    return result.toString()
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
