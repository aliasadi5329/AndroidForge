package com.dubfa.app

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newFixedThreadPool(2)
    private var voicePlayer: MediaPlayer? = null
    private val ttsCacheDir: File by lazy {
        val dir = File(applicationContext.cacheDir, "tts_edge")
        if (!dir.exists()) dir.mkdirs()
        dir
    }
    private val http by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }

    // Microsoft Edge online TTS token (same as open-source edge-tts clients)
    private val edgeToken = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DubfaScreen() }
    }

    private fun xmlEscape(s: String): String = buildString {
        for (ch in s) {
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> append(ch)
            }
        }
    }

    /**
     * Free Edge neural TTS (no API key). Persian voices:
     * fa-IR-DilaraNeural / fa-IR-FaridNeural
     */
    private fun fetchPersianAudio(text: String, voice: String): File {
        val cleaned = text.replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isEmpty()) throw IllegalStateException("متن خالی")

        val cacheKey = sha1("$voice|$cleaned")
        val out = File(ttsCacheDir, "$cacheKey.mp3")
        if (out.exists() && out.length() > 100) return out

        val audio = synthesizeEdge(cleaned.take(800), voice)
        if (audio.size < 80) throw IllegalStateException("صدا خالی برگشت")
        FileOutputStream(out).use { it.write(audio) }
        return out
    }

    private fun synthesizeEdge(text: String, voice: String): ByteArray {
        val requestId = UUID.randomUUID().toString().replace("-", "")
        val url =
            "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
                "?TrustedClientToken=$edgeToken&ConnectionId=$requestId"

        val latch = CountDownLatch(1)
        val buffer = ByteArrayOutputStream()
        var error: String? = null

        val request = Request.Builder()
            .url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 Edg/122.0.0.0"
            )
            .build()

        val ws = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val config = """
                    {"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}
                """.trimIndent()
                val configMsg =
                    "X-Timestamp:" + System.currentTimeMillis() + "\r\n" +
                        "Content-Type:application/json; charset=utf-8\r\n" +
                        "Path:speech.config\r\n\r\n" + config
                webSocket.send(configMsg)

                val ssml =
                    "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='fa-IR'>" +
                        "<voice name='$voice'>" + xmlEscape(text) + "</voice></speak>"
                val ssmlMsg =
                    "X-RequestId:$requestId\r\n" +
                        "Content-Type:application/ssml+xml\r\n" +
                        "X-Timestamp:" + System.currentTimeMillis() + "Z\r\n" +
                        "Path:ssml\r\n\r\n" + ssml
                webSocket.send(ssmlMsg)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end") || text.contains("Path:turn.end".lowercase())) {
                    webSocket.close(1000, null)
                    latch.countDown()
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                // Binary messages: 2-byte header length + header + audio payload
                val arr = bytes.toByteArray()
                if (arr.size < 2) return
                val headerLen = ((arr[0].toInt() and 0xFF) shl 8) or (arr[1].toInt() and 0xFF)
                val dataStart = 2 + headerLen
                if (dataStart < arr.size) {
                    buffer.write(arr, dataStart, arr.size - dataStart)
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                error = t.message ?: "WebSocket failure"
                latch.countDown()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                latch.countDown()
            }
        })

        val ok = latch.await(45, TimeUnit.SECONDS)
        try {
            ws.cancel()
        } catch (_: Exception) {
        }
        if (!ok) throw IllegalStateException("Timeout در دریافت صدا از Edge")
        if (error != null) throw IllegalStateException(error)
        return buffer.toByteArray()
    }

    private fun playFile(file: File, onDone: (() -> Unit)? = null) {
        mainHandler.post {
            try {
                voicePlayer?.setOnCompletionListener(null)
                voicePlayer?.stop()
                voicePlayer?.release()
            } catch (_: Exception) {
            }
            try {
                val mp = MediaPlayer()
                voicePlayer = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                mp.setDataSource(file.absolutePath)
                mp.setOnCompletionListener { onDone?.invoke() }
                mp.setOnErrorListener { _, _, _ -> onDone?.invoke(); true }
                mp.prepare()
                mp.start()
            } catch (_: Exception) {
                onDone?.invoke()
            }
        }
    }

    private fun speakOnline(
        text: String,
        voice: String,
        onStatus: (String) -> Unit,
        onDone: (() -> Unit)? = null
    ) {
        if (text.isBlank()) {
            onDone?.invoke(); return
        }
        onStatus("در حال دریافت صدا (Edge)...")
        ioExecutor.execute {
            var last: Exception? = null
            repeat(2) {
                try {
                    val file = fetchPersianAudio(text, voice)
                    mainHandler.post { onStatus("در حال پخش...") }
                    playFile(file, onDone)
                    return@execute
                } catch (e: Exception) {
                    last = e
                    try {
                        Thread.sleep(600)
                    } catch (_: Exception) {
                    }
                }
            }
            mainHandler.post {
                onStatus("خطای TTS: ${last?.message ?: "نامشخص"}")
                onDone?.invoke()
            }
        }
    }

    private fun stopVoice() {
        try {
            voicePlayer?.stop()
            voicePlayer?.release()
        } catch (_: Exception) {
        }
        voicePlayer = null
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember {
            mutableStateOf("بدون کلید API. ویدیو و زیرنویس فارسی را انتخاب کن.")
        }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }
        var dubEnabled by remember { mutableStateOf(false) }
        var lowerOriginal by remember { mutableStateOf(true) }
        var currentCueIndex by remember { mutableIntStateOf(-1) }
        var spokenCueIndex by remember { mutableIntStateOf(-1) }
        var busy by remember { mutableStateOf(false) }
        var voiceFemale by remember { mutableStateOf(true) }

        val activeVoice = if (voiceFemale) "fa-IR-DilaraNeural" else "fa-IR-FaridNeural"

        val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                videoUri = uri
                dubEnabled = false
                currentCueIndex = -1
                spokenCueIndex = -1
                status = "ویدئو انتخاب شد."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: ""
                    cues = parseSrtRobust(raw)
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    dubEnabled = false
                    currentCueIndex = -1
                    spokenCueIndex = -1
                    status = "زیرنویس: ${cues.size} بخش"
                } catch (e: Exception) {
                    status = "خطای SRT: ${e.message}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            val p = videoUri?.let { uri ->
                ExoPlayer.Builder(this@MainActivity).build().apply {
                    setMediaItem(MediaItem.fromUri(uri)); prepare()
                }
            }
            player = p
            onDispose { p?.release(); if (player === p) player = null }
        }

        DisposableEffect(player, dubEnabled, cues, activeVoice) {
            if (player == null || !dubEnabled || cues.isEmpty()) {
                onDispose { }
            } else {
                val tick = object : Runnable {
                    override fun run() {
                        val p = player ?: return
                        if (!dubEnabled) return
                        val pos = p.currentPosition
                        val idx = cues.indexOfFirst { pos >= it.start && pos < it.end }
                        if (idx != currentCueIndex) currentCueIndex = idx
                        if (idx >= 0 && idx != spokenCueIndex && p.isPlaying && !busy) {
                            spokenCueIndex = idx
                            busy = true
                            if (lowerOriginal) p.volume = 0.12f
                            speakOnline(
                                text = cues[idx].text,
                                voice = activeVoice,
                                onStatus = { status = "دیالوگ ${idx + 1}: $it" },
                                onDone = {
                                    busy = false
                                    val now = player?.currentPosition ?: 0L
                                    val still = cues.any { now >= it.start && now < it.end }
                                    if (!still) player?.volume = 1f
                                }
                            )
                        }
                        if (idx < 0) p.volume = 1f else if (lowerOriginal) p.volume = 0.12f
                        if (idx >= 0 && spokenCueIndex > idx) spokenCueIndex = idx - 1
                        mainHandler.postDelayed(this, 100L)
                    }
                }
                mainHandler.post(tick)
                onDispose {
                    mainHandler.removeCallbacks(tick)
                    stopVoice()
                    busy = false
                    player?.volume = 1f
                }
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            Column(
                Modifier.fillMaxSize().background(Color(0xFF0B1020)).verticalScroll(rememberScrollState()).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("DUBFA", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF9B7BFF))
                Text(
                    "نسخه ۰٫۱۷ — Edge TTS رایگان (بدون کلید)",
                    color = Color(0xFF9AA6BF),
                    style = MaterialTheme.typography.bodyMedium
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B3A2A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("موتور گفتار", style = MaterialTheme.typography.titleMedium, color = Color(0xFF69F0AE))
                        Text(
                            "از صدای عصبی مایکروسافت Edge استفاده می‌شود.\n" +
                                "نیازی به ثبت‌نام و کلید API نیست.\n" +
                                "اینترنت لازم است. محدودیت ۱۰ کاراکتر ندارد.",
                            color = Color(0xFFD1D7E8),
                            style = MaterialTheme.typography.bodySmall
                        )
                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Text("صدا: ", color = Color.White)
                            FilterChip(
                                selected = voiceFemale,
                                onClick = { voiceFemale = true },
                                label = { Text("دلارا (زن)") }
                            )
                            Spacer(Modifier.width(8.dp))
                            FilterChip(
                                selected = !voiceFemale,
                                onClick = { voiceFemale = false },
                                label = { Text("فرید (مرد)") }
                            )
                        }
                    }
                }

                OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                    Text("۱. انتخاب ویدئو")
                }

                if (player != null) {
                    AndroidView(
                        factory = { ctx -> PlayerView(ctx).apply { this.player = player } },
                        update = { v -> v.player = player },
                        modifier = Modifier.fillMaxWidth().height(220.dp)
                    )
                }

                OutlinedButton(
                    onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("۲. انتخاب زیرنویس SRT فارسی") }

                Text(subtitleName, color = Color(0xFF9AA6BF))

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                        Text(status, color = Color(0xFFD1D7E8))
                        Text("تعداد بخش‌ها: ${cues.size}", color = Color(0xFF55D6D0))
                        if (currentCueIndex >= 0 && currentCueIndex < cues.size) {
                            Text(
                                "دیالوگ فعلی: ${currentCueIndex + 1} — ${cues[currentCueIndex].text}",
                                color = Color(0xFFFFD27D),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2438)), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("۳. دوبله زنده", style = MaterialTheme.typography.titleMedium)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(
                                onClick = {
                                    if (videoUri == null) {
                                        status = "اول ویدئو را انتخاب کن."; return@Button
                                    }
                                    if (cues.isEmpty()) {
                                        status = "اول زیرنویس را انتخاب کن."; return@Button
                                    }
                                    spokenCueIndex = -1
                                    currentCueIndex = -1
                                    busy = false
                                    dubEnabled = true
                                    player?.play()
                                    status = "دوبله روشن شد."
                                },
                                enabled = !dubEnabled,
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B7BFF))
                            ) { Text("شروع دوبله") }

                            OutlinedButton(
                                onClick = {
                                    dubEnabled = false
                                    busy = false
                                    stopVoice()
                                    player?.volume = 1f
                                    status = "توقف دوبله"
                                },
                                enabled = dubEnabled,
                                modifier = Modifier.weight(1f)
                            ) { Text("توقف") }
                        }

                        OutlinedButton(
                            onClick = {
                                speakOnline(
                                    text = "سلام. این یک آزمایش صدای فارسی رایگان است.",
                                    voice = activeVoice,
                                    onStatus = { status = it }
                                )
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("آزمایش صدای Edge") }

                        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Checkbox(checked = lowerOriginal, onCheckedChange = { lowerOriginal = it })
                            Text(
                                "کم کردن صدای اصلی فیلم هنگام دوبله",
                                color = Color(0xFFD1D7E8),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }

                if (cues.isNotEmpty()) {
                    Text("پیش‌نمایش", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    cues.take(12).forEachIndexed { index, cue ->
                        val active = index == currentCueIndex && dubEnabled
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (active) Color(0xFF2A1F4D) else Color(0xFF171F33)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    "${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}",
                                    color = Color(0xFF55D6D0),
                                    style = MaterialTheme.typography.labelMedium
                                )
                                Text(cue.text, color = Color.White)
                                TextButton(
                                    onClick = {
                                        speakOnline(
                                            text = cue.text,
                                            voice = activeVoice,
                                            onStatus = { status = "آزمایش ${index + 1}: $it" }
                                        )
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("آزمایش این جمله") }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacksAndMessages(null)
        stopVoice()
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}

private fun sha1(text: String): String {
    val md = MessageDigest.getInstance("SHA-1")
    return md.digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

private fun parseSrtRobust(source: String): List<Cue> {
    val text = source.removePrefix("\uFEFF").replace("\u0000", "").replace("\r\n", "\n").replace('\r', '\n')
    val timePattern = Regex("""^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$""")
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0
    fun millis(h: Long, m: Long, s: Long, ms: Long) = (((h * 60 + m) * 60 + s) * 1000) + ms
    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) { i++; continue }
        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) { i++; continue }
        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++
        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) textLines.add(line)
            i++
        }
        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .let { removeBraceTags(it) }
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isNotBlank() && end >= start) output.add(Cue(start, end, cleaned))
    }
    return output
}

private fun removeBraceTags(input: String): String {
    val result = StringBuilder()
    var inside = false
    for (ch in input) {
        when {
            ch == '{' && !inside -> inside = true
            ch == '}' && inside -> inside = false
            !inside -> result.append(ch)
        }
    }
    return result.toString()
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
