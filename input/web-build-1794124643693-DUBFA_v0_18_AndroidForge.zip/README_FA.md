# DUBFA v0.17 — Edge TTS رایگان

بدون کلید API. صدای عصبی فارسی Microsoft Edge:
- fa-IR-DilaraNeural
- fa-IR-FaridNeural

اینترنت لازم است. محدودیت ۱۰ کاراکتر ندارد.
اگر از ایران سرویس قطع بود، VPN امتحان کن.
