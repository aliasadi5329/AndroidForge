package com.dubfa.app

import android.content.pm.ActivityInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newFixedThreadPool(2)
    private val ttsSemaphore = java.util.concurrent.Semaphore(2)
    private var voicePlayer: MediaPlayer? = null
    private val ttsCacheDir: File by lazy {
        File(applicationContext.cacheDir, "tts_minimax").also { if (!it.exists()) it.mkdirs() }
    }
    private val http by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }
    private val minimaxApiKey = "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJHcm91cE5hbWUiOiJBbGkgQXNhZGkiLCJVc2VyTmFtZSI6IkFsaSBBc2FkaSIsIkFjY291bnQiOiIiLCJTdWJqZWN0SUQiOiIxOTk0MjczNzA3ODQwNzcwMzAwIiwiUGhvbmUiOiIiLCJHcm91cElEIjoiMTk5NDI3MzcwNzgzNjU4MDA5MiIsIlBhZ2VOYW1lIjoiIiwiTWFpbCI6ImFsaWFzYWRpNzY2NEBnbWFpbC5jb20iLCJDcmVhdGVUaW1lIjoiMjAyNS0xMS0yOCAxMzo0Njo0NiIsIlRva2VuVHlwZSI6MiwiaXNzIjoibWluaW1heCJ9.WMErlvXvLN9ve6-iBgYUo4sL2L59Clqd1I-eOfhwzSCocGzXK7A1iTn7GFyS2KcbwX8w1V-MQmYaGJTth-peMdKL6cpm_W08lDl71PvUxEBidJRlC12T9r8UJdn9ZwB-Nry9MWLxkZ32ebwXfKgSydaUDoUDl4wsGAumrv2gsMUPuQFQRITj8tyfjWBYw666r05lQsIZ5KRgmr6QvRqj16X3PndWDK48JsT3ubUZAVgKVVdbjucWQWlKYbvIQpcgAPWdYsb7dGu_L_zwIz_bVVlgE0wTLkwD2AZATJX-frX1fNEe0XpQPTCBQp-8ftQkz3QgRFxExL9usu3Ss4WAOg"
    private val prefetching = ConcurrentHashMap.newKeySet<String>()
    private val readyFiles = ConcurrentHashMap<String, File>()

    // Dub engine state (outside Compose to avoid crash from recomposition)
    private val pendingQueue = LinkedBlockingQueue<Int>()
    private val speaking = AtomicBoolean(false)
    private val spokenIdx = AtomicInteger(-1)
    @Volatile private var cuesRef: List<Cue> = emptyList()
    @Volatile private var voiceName: String = "English_radiant_girl"
    @Volatile private var dubOn = false
    @Volatile private var lowerVol = true
    @Volatile private var syncOffsetMs = 1500L  // positive = speak earlier (fix lag)
    @Volatile private var showCueOverlay = false
    @Volatile private var playerRef: ExoPlayer? = null
    @Volatile private var statusCb: ((String) -> Unit)? = null
    @Volatile private var currentIdxCb: ((Int) -> Unit)? = null
    private var tickRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            setContent { DubfaScreen() }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun cacheKey(voice: String, text: String) = sha1("$voice|$text")

    private fun xmlEscape(s: String): String = buildString {
        for (ch in s) {
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> append(ch)
            }
        }
    }

    private fun fetchPersianAudio(text: String, voice: String): File {
        val cleaned = text.replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isEmpty()) throw IllegalStateException("متن خالی")
        val key = cacheKey(voice, cleaned)
        readyFiles[key]?.let { if (it.exists() && it.length() > 100) return it }
        val out = File(ttsCacheDir, "$key.mp3")
        if (out.exists() && out.length() > 100) {
            readyFiles[key] = out
            return out
        }
        ttsSemaphore.acquire()
        try {
            val audio = synthesizeMinimax(cleaned.take(800), voice)
            if (audio.size < 80) throw IllegalStateException("صدا خالی")
            FileOutputStream(out).use { it.write(audio) }
            readyFiles[key] = out
            return out
        } finally {
            ttsSemaphore.release()
        }
    }

    private fun prefetchAudio(text: String, voice: String) {
        val cleaned = text.replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isEmpty()) return
        val key = cacheKey(voice, cleaned)
        if (readyFiles.containsKey(key)) return
        if (!prefetching.add(key)) return
        ioExecutor.execute {
            try {
                fetchPersianAudio(cleaned, voice)
            } catch (_: Exception) {
            } finally {
                prefetching.remove(key)
            }
        }
    }

    private fun synthesizeMinimax(text: String, voice: String): ByteArray {
        val bodyJson = org.json.JSONObject().apply {
            put("model", "speech-2.6-hd")
            put("text", text)
            put("stream", false)
            put("language_boost", "Persian")
            put("output_format", "hex")
            put("voice_setting", org.json.JSONObject().apply {
                put("voice_id", voice)
                put("speed", 1.0)
                put("vol", 1.0)
                put("pitch", 0)
            })
            put("audio_setting", org.json.JSONObject().apply {
                put("sample_rate", 32000)
                put("bitrate", 128000)
                put("format", "mp3")
                put("channel", 1)
            })
        }.toString()

        val request = Request.Builder()
            .url("https://api.minimax.io/v1/t2a_v2")
            .header("Authorization", "Bearer $minimaxApiKey")
            .header("Content-Type", "application/json")
            .post(okhttp3.RequestBody.create(bodyJson, okhttp3.MediaType.get("application/json; charset=utf-8")))
            .build()

        http.newCall(request).execute().use { response ->
            val respBody = response.body?.string() ?: throw IllegalStateException("پاسخ خالی از Minimax")
            if (!response.isSuccessful) {
                throw IllegalStateException("خطای HTTP ${response.code}: ${respBody.take(200)}")
            }
            val json = org.json.JSONObject(respBody)
            val base = json.optJSONObject("base_resp")
            val code = base?.optInt("status_code", -1) ?: -1
            if (code != 0) {
                val msg = base?.optString("status_msg", "unknown") ?: "unknown"
                throw IllegalStateException("Minimax: $msg (code=$code)")
            }
            val data = json.optJSONObject("data") ?: throw IllegalStateException("data خالی")
            val hexAudio = data.optString("audio", "")
            if (hexAudio.isBlank()) throw IllegalStateException("صدا خالی از Minimax")
            return hexStringToByteArray(hexAudio)
        }
    }

    private fun hexStringToByteArray(s: String): ByteArray {
        val clean = s.trim().replace(" ", "")
        val len = clean.length
        if (len % 2 != 0) throw IllegalStateException("hex نامعتبر")
        val out = ByteArray(len / 2)
        var i = 0
        while (i < len) {
            val hi = Character.digit(clean[i], 16)
            val lo = Character.digit(clean[i + 1], 16)
            if (hi < 0 || lo < 0) throw IllegalStateException("hex نامعتبر")
            out[i / 2] = ((hi shl 4) + lo).toByte()
            i += 2
        }
        return out
    }

    private fun playFile(file: File, onDone: (() -> Unit)? = null) {
        mainHandler.post {
            try {
                voicePlayer?.setOnCompletionListener(null)
                try {
                    voicePlayer?.stop()
                } catch (_: Exception) {
                }
                try {
                    voicePlayer?.release()
                } catch (_: Exception) {
                }
                val mp = MediaPlayer()
                voicePlayer = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                mp.setDataSource(file.absolutePath)
                mp.setOnCompletionListener { onDone?.invoke() }
                mp.setOnErrorListener { _, _, _ ->
                    onDone?.invoke()
                    true
                }
                mp.prepare()
                mp.start()
            } catch (_: Exception) {
                onDone?.invoke()
            }
        }
    }

    private fun stopVoice() {
        mainHandler.post {
            try {
                voicePlayer?.setOnCompletionListener(null)
                voicePlayer?.stop()
            } catch (_: Exception) {
            }
            try {
                voicePlayer?.release()
            } catch (_: Exception) {
            }
            voicePlayer = null
        }
    }

    private fun playCueIndex(idx: Int) {
        val cues = cuesRef
        if (idx < 0 || idx >= cues.size) {
            speaking.set(false)
            return
        }
        if (!speaking.compareAndSet(false, true)) {
            if (!pendingQueue.contains(idx)) pendingQueue.offer(idx)
            return
        }
        spokenIdx.set(idx)
        currentIdxCb?.invoke(idx)
        val cue = cues[idx]
        if (lowerVol) playerRef?.volume = 0.12f
        statusCb?.invoke("دیالوگ ${idx + 1}/${cues.size}")

        val cleaned = cue.text.replace(Regex("""\s+"""), " ").trim()
        val key = cacheKey(voiceName, cleaned)
        val cached = readyFiles[key]
        if (cached != null && cached.exists()) {
            playFile(cached) {
                speaking.set(false)
                drainQueue()
            }
        } else {
            ioExecutor.execute {
                try {
                    val file = fetchPersianAudio(cleaned, voiceName)
                    mainHandler.post {
                        playFile(file) {
                            speaking.set(false)
                            drainQueue()
                        }
                    }
                } catch (e: Exception) {
                    mainHandler.post {
                        statusCb?.invoke("خطای TTS: ${e.message}")
                        speaking.set(false)
                        drainQueue()
                    }
                }
            }
        }
    }

    private fun drainQueue() {
        if (!dubOn) return
        val next = pendingQueue.poll()
        val p = playerRef ?: return
        val pos = p.currentPosition
        val cues = cuesRef
        val liveIdx = cues.indexOfFirst { pos >= it.start && pos < it.end + 400 }
        when {
            next != null && next < cues.size -> {
                val cue = cues[next]
                if (pos > cue.end + 1500 && liveIdx >= 0 && liveIdx != next) {
                    pendingQueue.clear()
                    if (liveIdx != spokenIdx.get()) playCueIndex(liveIdx)
                } else {
                    playCueIndex(next)
                }
            }
            liveIdx >= 0 && liveIdx != spokenIdx.get() -> playCueIndex(liveIdx)
            liveIdx < 0 -> playerRef?.volume = 1f
        }
    }

    private fun startDubEngine() {
        stopDubEngine()
        dubOn = true
        spokenIdx.set(-1)
        pendingQueue.clear()
        speaking.set(false)
        val pos = playerRef?.currentPosition ?: 0L
        cuesRef.filter { it.start in pos..(pos + 30000L) }.forEach {
            prefetchAudio(it.text, voiceName)
        }
        val tick = object : Runnable {
            private var lastPrefetch = -10_000L
            override fun run() {
                if (!dubOn) return
                val p = playerRef ?: return
                try {
                    val pos = p.currentPosition
                    if (pos - lastPrefetch > 2000) {
                        lastPrefetch = pos
                        ioExecutor.execute {
                            cuesRef.filter { it.start in pos..(pos + 30000L) }
                                .take(6)
                                .forEach { prefetchAudio(it.text, voiceName) }
                        }
                    }
                    // positive offset => trigger earlier to hide network lag
                    val lookAhead = 300L + syncOffsetMs
                    val idx = cuesRef.indexOfFirst {
                        pos + lookAhead >= it.start && pos < it.end + 400
                    }
                    if (idx >= 0) currentIdxCb?.invoke(idx)
                    if (idx >= 0 && idx != spokenIdx.get() && p.isPlaying) {
                        if (!speaking.get()) {
                            playCueIndex(idx)
                        } else if (idx > spokenIdx.get()) {
                            if (!pendingQueue.contains(idx)) pendingQueue.offer(idx)
                        }
                    }
                    if (idx < 0 && !speaking.get()) p.volume = 1f
                    else if (idx >= 0 && lowerVol) p.volume = 0.12f
                    if (idx >= 0 && spokenIdx.get() > idx + 1) {
                        spokenIdx.set(idx - 1)
                        pendingQueue.clear()
                    }
                } catch (e: Exception) {
                    statusCb?.invoke("خطای موتور: ${e.message}")
                }
                mainHandler.postDelayed(this, 40L)
            }
        }
        tickRunnable = tick
        mainHandler.post(tick)
    }

    private fun stopDubEngine() {
        dubOn = false
        tickRunnable?.let { mainHandler.removeCallbacks(it) }
        tickRunnable = null
        pendingQueue.clear()
        speaking.set(false)
        stopVoice()
        playerRef?.volume = 1f
    }

    private fun setFullscreenMode(enabled: Boolean) {
        try {
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            if (enabled) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                WindowCompat.setDecorFitsSystemWindows(window, false)
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.setDecorFitsSystemWindows(window, true)
                controller.show(WindowInsetsCompat.Type.systemBars())
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        } catch (_: Exception) {
        }
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember { mutableStateOf("ویدیو و زیرنویس را انتخاب کن.") }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }
        var dubEnabled by remember { mutableStateOf(false) }
        var lowerOriginal by remember { mutableStateOf(true) }
        var currentCueIndex by remember { mutableIntStateOf(-1) }
        var voiceFemale by remember { mutableStateOf(true) }
        var fullscreen by remember { mutableStateOf(false) }

        // Keep engine refs in sync without heavy work during composition
        SideEffect {
            statusCb = { s -> mainHandler.post { status = s } }
            currentIdxCb = { i -> mainHandler.post { currentCueIndex = i } }
            lowerVol = lowerOriginal
            voiceName = if (voiceFemale) "English_radiant_girl" else "English_expressive_narrator"
            cuesRef = cues
            playerRef = player
        }

        BackHandler(enabled = fullscreen) {
            fullscreen = false
            setFullscreenMode(false)
        }

        LaunchedEffect(fullscreen) {
            setFullscreenMode(fullscreen)
        }

        val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                videoUri = uri
                dubEnabled = false
                stopDubEngine()
                currentCueIndex = -1
                status = "ویدئو انتخاب شد."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: ""
                    val parsed = parseSrtRobust(raw)
                    cues = parsed
                    cuesRef = parsed
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    dubEnabled = false
                    stopDubEngine()
                    currentCueIndex = -1
                    status = "زیرنویس: ${parsed.size} بخش"
                    parsed.take(8).forEach { prefetchAudio(it.text, voiceName) }
                } catch (e: Exception) {
                    status = "خطای SRT: ${e.message}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            var p: ExoPlayer? = null
            try {
                p = videoUri?.let { uri ->
                    ExoPlayer.Builder(this@MainActivity).build().apply {
                        setMediaItem(MediaItem.fromUri(uri))
                        prepare()
                    }
                }
                player = p
                playerRef = p
            } catch (e: Exception) {
                status = "خطای پخش‌کننده: ${e.message}"
            }
            onDispose {
                try {
                    p?.release()
                } catch (_: Exception) {
                }
                if (player === p) {
                    player = null
                    playerRef = null
                }
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            if (fullscreen && player != null) {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                this.player = player
                                layoutParams = FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                useController = true
                            }
                        },
                        update = { it.player = player },
                        modifier = Modifier.fillMaxSize()
                    )
                    Button(
                        onClick = {
                            fullscreen = false
                            setFullscreenMode(false)
                        },
                        modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
                    ,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC9B7BFF))
                    ) { Text("خروج / برگشت عمودی") }
                    if (showCueOverlay && currentCueIndex >= 0 && currentCueIndex < cues.size) {
                        Text(
                            cues[currentCueIndex].text,
                            color = Color.White,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(24.dp)
                                .background(Color(0x88000000))
                                .padding(12.dp)
                        )
                    }
                }
            } else {
                Column(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0B1020))
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("DUBFA", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF9B7BFF))
                    Text("نسخه ۰٫۲۶ — Minimax TTS", color = Color(0xFF9AA6BF))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B3A2A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("موتور Minimax TTS (فارسی)", color = Color(0xFF69F0AE), style = MaterialTheme.typography.titleMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("صدا: ", color = Color.White)
                                FilterChip(
                                    selected = voiceFemale,
                                    onClick = { voiceFemale = true },
                                    label = { Text("زن (Radiant)") }
                                )
                                Spacer(Modifier.width(8.dp))
                                FilterChip(
                                    selected = !voiceFemale,
                                    onClick = { voiceFemale = false },
                                    label = { Text("مرد (Narrator)") }
                                )
                            }
                        }
                    }

                    OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text("۱. انتخاب ویدئو")
                    }

                    if (player != null) {
                        Box(Modifier.fillMaxWidth().height(220.dp)) {
                            AndroidView(
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        this.player = player
                                        useController = true
                                        subtitleView?.visibility = android.view.View.GONE
                                    }
                                },
                                update = { it.player = player },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    fullscreen = true
                                    setFullscreenMode(true)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A6A4A))
                            ) { Text("⛶ پخش افقی تمام‌صفحه") }
                        }
                        Text(
                            "با زدن دکمه بالا، گوشی افقی می‌شود و فیلم تمام‌صفحه پخش می‌شود. برای بازگشت دکمه «خروج» یا Back را بزن.",
                            color = Color(0xFF9AA6BF),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    OutlinedButton(
                        onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("۲. انتخاب زیرنویس SRT فارسی") }

                    Text(subtitleName, color = Color(0xFF9AA6BF))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                            Text(status, color = Color(0xFFD1D7E8))
                            Text("تعداد بخش‌ها: ${cues.size}", color = Color(0xFF55D6D0))
                            if (currentCueIndex >= 0 && currentCueIndex < cues.size) {
                                Text(
                                    "دیالوگ فعلی: ${currentCueIndex + 1} — ${cues[currentCueIndex].text}",
                                    color = Color(0xFFFFD27D),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2438)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("۳. دوبله زنده", style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        if (videoUri == null) {
                                            status = "اول ویدئو را انتخاب کن"
                                            return@Button
                                        }
                                        if (cues.isEmpty()) {
                                            status = "اول زیرنویس را انتخاب کن"
                                            return@Button
                                        }
                                        lowerVol = lowerOriginal
                                        voiceName = if (voiceFemale) "English_radiant_girl" else "English_expressive_narrator"
                                        cuesRef = cues
                                        playerRef = player
                                        dubEnabled = true
                                        startDubEngine()
                                        player?.play()
                                        status = "دوبله روشن شد"
                                    },
                                    enabled = !dubEnabled,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B7BFF))
                                ) { Text("شروع دوبله") }

                                OutlinedButton(
                                    onClick = {
                                        dubEnabled = false
                                        stopDubEngine()
                                        status = "توقف"
                                    },
                                    enabled = dubEnabled,
                                    modifier = Modifier.weight(1f)
                                ) { Text("توقف") }
                            }

                            OutlinedButton(
                                onClick = {
                                    status = "آزمایش صدا..."
                                    ioExecutor.execute {
                                        try {
                                            val f = fetchPersianAudio(
                                                "سلام. این یک آزمایش صدای فارسی است.",
                                                if (voiceFemale) "English_radiant_girl" else "English_expressive_narrator"
                                            )
                                            mainHandler.post {
                                                status = "پخش آزمایشی"
                                                playFile(f)
                                            }
                                        } catch (e: Exception) {
                                            mainHandler.post { status = "خطا: ${e.message}" }
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("آزمایش صدای Minimax") }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = lowerOriginal, onCheckedChange = {
                                    lowerOriginal = it
                                    lowerVol = it
                                })
                                Text("کم کردن صدای فیلم", color = Color(0xFFD1D7E8))
                            }

                            Text(
                                "همگام‌سازی صدا با تصویر",
                                color = Color.White,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                "اگر صدا عقب است، عدد را زیاد کن. اگر جلو افتاده، کم کن.",
                                color = Color(0xFF9AA6BF),
                                style = MaterialTheme.typography.bodySmall
                            )
                            var syncUi by remember { mutableFloatStateOf(1500f) }
                            Text(
                                "جلو انداختن صدا: ${syncUi.toInt()} میلی‌ثانیه (${"%.1f".format(syncUi / 1000f)} ثانیه)",
                                color = Color(0xFF55D6D0),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Slider(
                                value = syncUi,
                                onValueChange = {
                                    syncUi = it
                                    syncOffsetMs = it.toLong()
                                },
                                valueRange = 0f..4000f,
                                steps = 39,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = {
                                    syncUi = 0f; syncOffsetMs = 0L
                                }) { Text("۰") }
                                OutlinedButton(onClick = {
                                    syncUi = 1000f; syncOffsetMs = 1000L
                                }) { Text("۱ث") }
                                OutlinedButton(onClick = {
                                    syncUi = 2000f; syncOffsetMs = 2000L
                                }) { Text("۲ث") }
                                OutlinedButton(onClick = {
                                    syncUi = 3000f; syncOffsetMs = 3000L
                                }) { Text("۳ث") }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = showCueOverlay,
                                    onCheckedChange = { showCueOverlay = it }
                                )
                                Text(
                                    "نمایش متن زیرنویس روی تصویر (معمولاً خاموش بماند)",
                                    color = Color(0xFFD1D7E8),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    if (cues.isNotEmpty()) {
                        Text("پیش‌نمایش", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        cues.take(8).forEachIndexed { index, cue ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (index == currentCueIndex && dubEnabled) Color(0xFF2A1F4D) else Color(0xFF171F33)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(
                                        "${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}",
                                        color = Color(0xFF55D6D0)
                                    )
                                    Text(cue.text, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        stopDubEngine()
        mainHandler.removeCallbacksAndMessages(null)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}

private fun sha1(text: String): String {
    val md = MessageDigest.getInstance("SHA-1")
    return md.digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

private fun parseSrtRobust(source: String): List<Cue> {
    val text = source.removePrefix("\uFEFF").replace("\u0000", "").replace("\r\n", "\n").replace('\r', '\n')
    val timePattern = Regex("""^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$""")
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0
    fun millis(h: Long, m: Long, s: Long, ms: Long) = (((h * 60 + m) * 60 + s) * 1000) + ms
    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) {
            i++; continue
        }
        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) {
            i++; continue
        }
        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++
        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) textLines.add(line)
            i++
        }
        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .let { removeBraceTags(it) }
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isNotBlank() && end >= start) output.add(Cue(start, end, cleaned))
    }
    return output
}

private fun removeBraceTags(input: String): String {
    val result = StringBuilder()
    var inside = false
    for (ch in input) {
        when {
            ch == '{' && !inside -> inside = true
            ch == '}' && inside -> inside = false
            !inside -> result.append(ch)
        }
    }
    return result.toString()
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
