# DUBFA v0.26 — Minimax TTS

دوبله زنده فیلم با زیرنویس SRT فارسی و صدای Minimax AI.

- کلید API از https://platform.minimax.io/console/keys داخل کد قرار داده شده.
- مدل: speech-2.6-hd
- پشتیبانی زبان فارسی با language_boost=Persian
- صداا: زن (English_radiant_girl) و مرد (English_expressive_narrator)

اینترنت لازم است.
اگر از ایران سرویس قطع بود، VPN امتحان کن.

برای بیلد:
./gradlew assembleDebug
