package com.dubfa.app

import android.content.pm.ActivityInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

data class Cue(val start: Long, val end: Long, val text: String)

class MainActivity : ComponentActivity() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor = Executors.newFixedThreadPool(2)
    private val ttsSemaphore = java.util.concurrent.Semaphore(2)
    private var voicePlayer: MediaPlayer? = null
    private val ttsCacheDir: File by lazy {
        File(applicationContext.cacheDir, "tts_edge").also { if (!it.exists()) it.mkdirs() }
    }
    private val http by lazy {
        OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .build()
    }
    private val edgeToken = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private val prefs by lazy { getSharedPreferences("dubfa", MODE_PRIVATE) }
    private val prefetching = ConcurrentHashMap.newKeySet<String>()
    private val readyFiles = ConcurrentHashMap<String, File>()

    // Dub engine state (outside Compose to avoid crash from recomposition)
    private val pendingQueue = LinkedBlockingQueue<Int>()
    private val speaking = AtomicBoolean(false)
    private val spokenIdx = AtomicInteger(-1)
    @Volatile private var cuesRef: List<Cue> = emptyList()
    @Volatile private var voiceName: String = "fa-IR-DilaraNeural"
    @Volatile private var dubOn = false
    @Volatile private var lowerVol = true
    @Volatile private var syncOffsetMs: Long = 1500L
    private fun loadSyncOffset() {
        syncOffsetMs = prefs.getLong("sync_offset_ms", 1500L)
    }
    private fun saveSyncOffset(v: Long) {
        syncOffsetMs = v.coerceIn(0L, 5000L)
        prefs.edit().putLong("sync_offset_ms", syncOffsetMs).apply()
    }
    @Volatile private var showCueOverlay = false
    @Volatile private var playerRef: ExoPlayer? = null
    @Volatile private var statusCb: ((String) -> Unit)? = null
    @Volatile private var currentIdxCb: ((Int) -> Unit)? = null
    private var tickRunnable: Runnable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            loadSyncOffset()
            WindowCompat.setDecorFitsSystemWindows(window, true)
            setContent { DubfaScreen() }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun cacheKey(voice: String, text: String) = sha1("$voice|$text")

    private fun xmlEscape(s: String): String = buildString {
        for (ch in s) {
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> append(ch)
            }
        }
    }

    private fun fetchPersianAudio(text: String, voice: String): File {
        val cleaned = text.replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isEmpty()) throw IllegalStateException("متن خالی")
        val key = cacheKey(voice, cleaned)
        readyFiles[key]?.let { if (it.exists() && it.length() > 100) return it }
        val out = File(ttsCacheDir, "$key.mp3")
        if (out.exists() && out.length() > 100) {
            readyFiles[key] = out
            return out
        }
        ttsSemaphore.acquire()
        try {
            val audio = synthesizeEdge(cleaned.take(800), voice)
            if (audio.size < 80) throw IllegalStateException("صدا خالی")
            FileOutputStream(out).use { it.write(audio) }
            readyFiles[key] = out
            return out
        } finally {
            ttsSemaphore.release()
        }
    }

    private fun prefetchAudio(text: String, voice: String) {
        val cleaned = text.replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isEmpty()) return
        val key = cacheKey(voice, cleaned)
        if (readyFiles.containsKey(key)) return
        if (!prefetching.add(key)) return
        ioExecutor.execute {
            try {
                fetchPersianAudio(cleaned, voice)
            } catch (_: Exception) {
            } finally {
                prefetching.remove(key)
            }
        }
    }

    private fun synthesizeEdge(text: String, voice: String): ByteArray {
        val requestId = UUID.randomUUID().toString().replace("-", "")
        val gec = generateSecMsGec()
        val gecVersion = "1-143.0.3650.75"
        val urls = listOf(
            "wss://api.msedgeservices.com/tts/cognitiveservices/websocket/v1" +
                "?Ocp-Apim-Subscription-Key=$edgeToken&ConnectionId=$requestId" +
                "&Sec-MS-GEC=$gec&Sec-MS-GEC-Version=$gecVersion",
            "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
                "?TrustedClientToken=$edgeToken&ConnectionId=$requestId" +
                "&Sec-MS-GEC=$gec&Sec-MS-GEC-Version=$gecVersion"
        )
        var last: Exception? = null
        for (url in urls) {
            try {
                return synthesizeEdgeOnce(url, requestId, text, voice)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Edge TTS failed")
    }

    private fun generateSecMsGec(): String {
        val ticks = ((System.currentTimeMillis() / 1000L) + 11644473600L) * 10_000_000L
        val rounded = ticks - (ticks % 3_000_000_000L)
        val str = rounded.toString() + edgeToken
        val digest = MessageDigest.getInstance("SHA-256").digest(str.toByteArray(Charsets.US_ASCII))
        return digest.joinToString("") { "%02X".format(it) }
    }

    private fun synthesizeEdgeOnce(url: String, requestId: String, text: String, voice: String): ByteArray {
        val latch = CountDownLatch(1)
        val buffer = ByteArrayOutputStream()
        var error: String? = null
        val request = Request.Builder()
            .url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"
            )
            .build()

        val ws = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val config =
                    """{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}"""
                webSocket.send(
                    "X-Timestamp:${System.currentTimeMillis()}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n$config"
                )
                val ssml =
                    "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='fa-IR'>" +
                        "<voice name='$voice'>${xmlEscape(text)}</voice></speak>"
                webSocket.send(
                    "X-RequestId:$requestId\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${System.currentTimeMillis()}Z\r\nPath:ssml\r\n\r\n$ssml"
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end")) {
                    webSocket.close(1000, null)
                    latch.countDown()
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val arr = bytes.toByteArray()
                if (arr.size < 2) return
                val headerLen = ((arr[0].toInt() and 0xFF) shl 8) or (arr[1].toInt() and 0xFF)
                val dataStart = 2 + headerLen
                if (dataStart < arr.size) buffer.write(arr, dataStart, arr.size - dataStart)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                error = t.message ?: "WebSocket failure"
                latch.countDown()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                latch.countDown()
            }
        })

        val ok = latch.await(45, TimeUnit.SECONDS)
        try {
            ws.cancel()
        } catch (_: Exception) {
        }
        if (!ok) throw IllegalStateException("Timeout Edge TTS")
        if (error != null) throw IllegalStateException(error)
        val audio = buffer.toByteArray()
        if (audio.size < 80) throw IllegalStateException("صدا خالی")
        return audio
    }

    private fun playFile(file: File, onDone: (() -> Unit)? = null) {
        mainHandler.post {
            try {
                voicePlayer?.setOnCompletionListener(null)
                try {
                    voicePlayer?.stop()
                } catch (_: Exception) {
                }
                try {
                    voicePlayer?.release()
                } catch (_: Exception) {
                }
                val mp = MediaPlayer()
                voicePlayer = mp
                mp.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                mp.setDataSource(file.absolutePath)
                mp.setOnCompletionListener { onDone?.invoke() }
                mp.setOnErrorListener { _, _, _ ->
                    onDone?.invoke()
                    true
                }
                mp.prepare()
                mp.start()
            } catch (_: Exception) {
                onDone?.invoke()
            }
        }
    }

    private fun stopVoice() {
        mainHandler.post {
            try {
                voicePlayer?.setOnCompletionListener(null)
                voicePlayer?.stop()
            } catch (_: Exception) {
            }
            try {
                voicePlayer?.release()
            } catch (_: Exception) {
            }
            voicePlayer = null
        }
    }

    private fun playCueIndex(idx: Int) {
        val cues = cuesRef
        if (idx < 0 || idx >= cues.size) {
            speaking.set(false)
            return
        }
        if (!speaking.compareAndSet(false, true)) {
            if (!pendingQueue.contains(idx)) pendingQueue.offer(idx)
            return
        }
        spokenIdx.set(idx)
        currentIdxCb?.invoke(idx)
        val cue = cues[idx]
        if (lowerVol) playerRef?.volume = 0.12f
        statusCb?.invoke("دیالوگ ${idx + 1}/${cues.size}")

        val cleaned = cue.text.replace(Regex("""\s+"""), " ").trim()
        val key = cacheKey(voiceName, cleaned)
        val cached = readyFiles[key]
        if (cached != null && cached.exists()) {
            playFile(cached) {
                speaking.set(false)
                drainQueue()
            }
        } else {
            ioExecutor.execute {
                try {
                    val file = fetchPersianAudio(cleaned, voiceName)
                    mainHandler.post {
                        playFile(file) {
                            speaking.set(false)
                            drainQueue()
                        }
                    }
                } catch (e: Exception) {
                    mainHandler.post {
                        statusCb?.invoke("خطای TTS: ${e.message}")
                        speaking.set(false)
                        drainQueue()
                    }
                }
            }
        }
    }

    private fun drainQueue() {
        if (!dubOn) return
        val next = pendingQueue.poll()
        val p = playerRef ?: return
        val pos = p.currentPosition
        val cues = cuesRef
        val liveIdx = cues.indexOfFirst {
            val ep = pos + syncOffsetMs
            ep >= it.start && ep < it.end + 200
        }
        when {
            next != null && next < cues.size -> {
                val cue = cues[next]
                if (pos > cue.end + 1500 && liveIdx >= 0 && liveIdx != next) {
                    pendingQueue.clear()
                    if (liveIdx != spokenIdx.get()) playCueIndex(liveIdx)
                } else {
                    playCueIndex(next)
                }
            }
            liveIdx >= 0 && liveIdx != spokenIdx.get() -> playCueIndex(liveIdx)
            liveIdx < 0 -> playerRef?.volume = 1f
        }
    }

    private fun startDubEngine() {
        stopDubEngine()
        dubOn = true
        spokenIdx.set(-1)
        pendingQueue.clear()
        speaking.set(false)
        val pos = playerRef?.currentPosition ?: 0L
        cuesRef.filter { it.start in pos..(pos + 30000L) }.forEach {
            prefetchAudio(it.text, voiceName)
        }
        val tick = object : Runnable {
            private var lastPrefetch = -10_000L
            override fun run() {
                if (!dubOn) return
                val p = playerRef ?: return
                try {
                    val pos = p.currentPosition
                    if (pos - lastPrefetch > 2000) {
                        lastPrefetch = pos
                        ioExecutor.execute {
                            cuesRef.filter { it.start in pos..(pos + 30000L) }
                                .take(6)
                                .forEach { prefetchAudio(it.text, voiceName) }
                        }
                    }
                    // effectivePos is "where we pretend the playhead is" for dubbing.
                    // Larger syncOffsetMs => treat video as further ahead => speak earlier.
                    val offset = syncOffsetMs
                    val effectivePos = pos + offset
                    val idx = cuesRef.indexOfFirst {
                        effectivePos >= it.start && effectivePos < it.end + 200
                    }
                    if (idx >= 0) currentIdxCb?.invoke(idx)
                    if (idx >= 0 && idx != spokenIdx.get() && p.isPlaying) {
                        if (!speaking.get()) {
                            playCueIndex(idx)
                        } else if (idx > spokenIdx.get()) {
                            if (!pendingQueue.contains(idx)) pendingQueue.offer(idx)
                        }
                    }
                    if (idx < 0 && !speaking.get()) p.volume = 1f
                    else if (idx >= 0 && lowerVol) p.volume = 0.12f
                    if (idx >= 0 && spokenIdx.get() > idx + 1) {
                        spokenIdx.set(idx - 1)
                        pendingQueue.clear()
                    }
                } catch (e: Exception) {
                    statusCb?.invoke("خطای موتور: ${e.message}")
                }
                mainHandler.postDelayed(this, 40L)
            }
        }
        tickRunnable = tick
        mainHandler.post(tick)
    }

    private fun stopDubEngine() {
        dubOn = false
        tickRunnable?.let { mainHandler.removeCallbacks(it) }
        tickRunnable = null
        pendingQueue.clear()
        speaking.set(false)
        stopVoice()
        playerRef?.volume = 1f
    }

    private fun setFullscreenMode(enabled: Boolean) {
        try {
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            if (enabled) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                WindowCompat.setDecorFitsSystemWindows(window, false)
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.setDecorFitsSystemWindows(window, true)
                controller.show(WindowInsetsCompat.Type.systemBars())
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        } catch (_: Exception) {
        }
    }

    @Composable
    private fun DubfaScreen() {
        var videoUri by remember { mutableStateOf<Uri?>(null) }
        var cues by remember { mutableStateOf<List<Cue>>(emptyList()) }
        var subtitleName by remember { mutableStateOf("هنوز زیرنویسی انتخاب نشده") }
        var status by remember { mutableStateOf("ویدیو و زیرنویس را انتخاب کن.") }
        var player by remember { mutableStateOf<ExoPlayer?>(null) }
        var dubEnabled by remember { mutableStateOf(false) }
        var lowerOriginal by remember { mutableStateOf(true) }
        var currentCueIndex by remember { mutableIntStateOf(-1) }
        var voiceFemale by remember { mutableStateOf(true) }
        var fullscreen by remember { mutableStateOf(false) }
        var syncUi by remember { mutableFloatStateOf(syncOffsetMs.toFloat().coerceIn(0f, 5000f)) }

        // Keep engine refs in sync without heavy work during composition
        SideEffect {
            statusCb = { s -> mainHandler.post { status = s } }
            currentIdxCb = { i -> mainHandler.post { currentCueIndex = i } }
            lowerVol = lowerOriginal
            voiceName = if (voiceFemale) "fa-IR-DilaraNeural" else "fa-IR-FaridNeural"
            cuesRef = cues
            playerRef = player
        }

        BackHandler(enabled = fullscreen) {
            fullscreen = false
            setFullscreenMode(false)
        }

        LaunchedEffect(fullscreen) {
            setFullscreenMode(fullscreen)
        }

        val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                videoUri = uri
                dubEnabled = false
                stopDubEngine()
                currentCueIndex = -1
                status = "ویدئو انتخاب شد."
            }
        }

        val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    val raw = contentResolver.openInputStream(uri)?.use { input ->
                        BufferedReader(InputStreamReader(input, Charsets.UTF_8)).readText()
                    } ?: ""
                    val parsed = parseSrtRobust(raw)
                    cues = parsed
                    cuesRef = parsed
                    subtitleName = uri.lastPathSegment ?: "subtitle.srt"
                    dubEnabled = false
                    stopDubEngine()
                    currentCueIndex = -1
                    status = "زیرنویس: ${parsed.size} بخش"
                    parsed.take(8).forEach { prefetchAudio(it.text, voiceName) }
                } catch (e: Exception) {
                    status = "خطای SRT: ${e.message}"
                    cues = emptyList()
                }
            }
        }

        DisposableEffect(videoUri) {
            var p: ExoPlayer? = null
            try {
                p = videoUri?.let { uri ->
                    ExoPlayer.Builder(this@MainActivity).build().apply {
                        setMediaItem(MediaItem.fromUri(uri))
                        prepare()
                    }
                }
                player = p
                playerRef = p
            } catch (e: Exception) {
                status = "خطای پخش‌کننده: ${e.message}"
            }
            onDispose {
                try {
                    p?.release()
                } catch (_: Exception) {
                }
                if (player === p) {
                    player = null
                    playerRef = null
                }
            }
        }

        MaterialTheme(
            colorScheme = darkColorScheme(
                background = Color(0xFF0B1020),
                surface = Color(0xFF171F33),
                primary = Color(0xFF9B7BFF),
                secondary = Color(0xFF55D6D0),
                onBackground = Color.White,
                onSurface = Color.White
            )
        ) {
            if (fullscreen && player != null) {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    AndroidView(
                        factory = { ctx ->
                            PlayerView(ctx).apply {
                                this.player = player
                                layoutParams = FrameLayout.LayoutParams(
                                    ViewGroup.LayoutParams.MATCH_PARENT,
                                    ViewGroup.LayoutParams.MATCH_PARENT
                                )
                                useController = true
                                subtitleView?.visibility = android.view.View.GONE
                            }
                        },
                        update = { it.player = player },
                        modifier = Modifier.fillMaxSize()
                    )
                    Column(
                        Modifier.align(Alignment.TopEnd).padding(12.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Button(
                            onClick = {
                                fullscreen = false
                                setFullscreenMode(false)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xCC9B7BFF))
                        ) { Text("خروج / برگشت عمودی") }
                        Text(
                            "همگام: ${syncOffsetMs}ms",
                            color = Color.White,
                            modifier = Modifier.padding(top = 6.dp).background(Color(0x88000000)).padding(6.dp)
                        )
                        Row {
                            listOf(-500L, 500L).forEach { delta ->
                                Button(
                                    onClick = {
                                        val nv = (syncOffsetMs + delta).coerceIn(0L, 5000L)
                                        saveSyncOffset(nv)
                                        syncUi = nv.toFloat()
                                        spokenIdx.set(-1)
                                        pendingQueue.clear()
                                    },
                                    modifier = Modifier.padding(2.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xAA333333))
                                ) { Text(if (delta < 0) "-0.5ث" else "+0.5ث") }
                            }
                        }
                    }
                    if (showCueOverlay && currentCueIndex >= 0 && currentCueIndex < cues.size) {
                        Text(
                            cues[currentCueIndex].text,
                            color = Color.White,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(24.dp)
                                .background(Color(0x88000000))
                                .padding(12.dp)
                        )
                    }
                }
            } else {
                Column(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0xFF0B1020))
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("DUBFA", style = MaterialTheme.typography.headlineMedium, color = Color(0xFF9B7BFF))
                    Text("نسخه ۰٫۲۷ — افقی کامل", color = Color(0xFF9AA6BF))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1B3A2A)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("موتور Edge TTS", color = Color(0xFF69F0AE), style = MaterialTheme.typography.titleMedium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("صدا: ", color = Color.White)
                                FilterChip(
                                    selected = voiceFemale,
                                    onClick = { voiceFemale = true },
                                    label = { Text("دلارا") }
                                )
                                Spacer(Modifier.width(8.dp))
                                FilterChip(
                                    selected = !voiceFemale,
                                    onClick = { voiceFemale = false },
                                    label = { Text("فرید") }
                                )
                            }
                        }
                    }

                    OutlinedButton(onClick = { videoPicker.launch("video/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text("۱. انتخاب ویدئو")
                    }

                    if (player != null) {
                        Box(Modifier.fillMaxWidth().height(220.dp)) {
                            AndroidView(
                                factory = { ctx ->
                                    PlayerView(ctx).apply {
                                        this.player = player
                                        useController = true
                                        subtitleView?.visibility = android.view.View.GONE
                                    }
                                },
                                update = { it.player = player },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    fullscreen = true
                                    setFullscreenMode(true)
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A6A4A))
                            ) { Text("⛶ پخش افقی تمام‌صفحه") }
                        }
                        Text(
                            "با زدن دکمه بالا، گوشی افقی می‌شود و فیلم تمام‌صفحه پخش می‌شود. برای بازگشت دکمه «خروج» یا Back را بزن.",
                            color = Color(0xFF9AA6BF),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }

                    OutlinedButton(
                        onClick = { subtitlePicker.launch(arrayOf("application/x-subrip", "text/*", "*/*")) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("۲. انتخاب زیرنویس SRT فارسی") }

                    Text(subtitleName, color = Color(0xFF9AA6BF))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF171F33)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("وضعیت", style = MaterialTheme.typography.titleMedium)
                            Text(status, color = Color(0xFFD1D7E8))
                            Text("تعداد بخش‌ها: ${cues.size}", color = Color(0xFF55D6D0))
                            if (currentCueIndex >= 0 && currentCueIndex < cues.size) {
                                Text(
                                    "دیالوگ فعلی: ${currentCueIndex + 1} — ${cues[currentCueIndex].text}",
                                    color = Color(0xFFFFD27D),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2438)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("۳. دوبله زنده", style = MaterialTheme.typography.titleMedium)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        if (videoUri == null) {
                                            status = "اول ویدئو را انتخاب کن"
                                            return@Button
                                        }
                                        if (cues.isEmpty()) {
                                            status = "اول زیرنویس را انتخاب کن"
                                            return@Button
                                        }
                                        lowerVol = lowerOriginal
                                        voiceName = if (voiceFemale) "fa-IR-DilaraNeural" else "fa-IR-FaridNeural"
                                        cuesRef = cues
                                        playerRef = player
                                        dubEnabled = true
                                        startDubEngine()
                                        player?.play()
                                        status = "دوبله روشن شد"
                                    },
                                    enabled = !dubEnabled,
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF9B7BFF))
                                ) { Text("شروع دوبله") }

                                OutlinedButton(
                                    onClick = {
                                        dubEnabled = false
                                        stopDubEngine()
                                        status = "توقف"
                                    },
                                    enabled = dubEnabled,
                                    modifier = Modifier.weight(1f)
                                ) { Text("توقف") }
                            }

                            OutlinedButton(
                                onClick = {
                                    status = "آزمایش صدا..."
                                    ioExecutor.execute {
                                        try {
                                            val f = fetchPersianAudio(
                                                "سلام. این یک آزمایش صدای فارسی است.",
                                                if (voiceFemale) "fa-IR-DilaraNeural" else "fa-IR-FaridNeural"
                                            )
                                            mainHandler.post {
                                                status = "پخش آزمایشی"
                                                playFile(f)
                                            }
                                        } catch (e: Exception) {
                                            mainHandler.post { status = "خطا: ${e.message}" }
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text("آزمایش صدای Edge") }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(checked = lowerOriginal, onCheckedChange = {
                                    lowerOriginal = it
                                    lowerVol = it
                                })
                                Text("کم کردن صدای فیلم", color = Color(0xFFD1D7E8))
                            }

                            Text(
                                "همگام‌سازی صدا با تصویر",
                                color = Color.White,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                "اگر صدا عقب است، عدد را زیاد کن. اگر جلو افتاده، کم کن.",
                                color = Color(0xFF9AA6BF),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Text(
                                "جلو انداختن صدا: ${syncUi.toInt()}ms (${"%.1f".format(syncUi / 1000f)} ثانیه) — ذخیره می‌شود",
                                color = Color(0xFF55D6D0),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Slider(
                                value = syncUi,
                                onValueChange = { v ->
                                    syncUi = v
                                    saveSyncOffset(v.toLong())
                                    // re-sync from next cue
                                    spokenIdx.set(-1)
                                    pendingQueue.clear()
                                },
                                valueRange = 0f..5000f,
                                steps = 49,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(0f, 1000f, 2000f, 3000f, 4000f).forEach { v ->
                                    OutlinedButton(onClick = {
                                        syncUi = v
                                        saveSyncOffset(v.toLong())
                                        spokenIdx.set(-1)
                                        pendingQueue.clear()
                                    }) {
                                        Text(if (v == 0f) "۰" else "${(v / 1000f).toInt()}ث")
                                    }
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = showCueOverlay,
                                    onCheckedChange = { showCueOverlay = it }
                                )
                                Text(
                                    "نمایش متن زیرنویس روی تصویر (معمولاً خاموش بماند)",
                                    color = Color(0xFFD1D7E8),
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }

                    if (cues.isNotEmpty()) {
                        Text("پیش‌نمایش", style = MaterialTheme.typography.titleMedium, color = Color.White)
                        cues.take(8).forEachIndexed { index, cue ->
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = if (index == currentCueIndex && dubEnabled) Color(0xFF2A1F4D) else Color(0xFF171F33)
                                ),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(
                                        "${index + 1} | ${timeLabel(cue.start)} – ${timeLabel(cue.end)}",
                                        color = Color(0xFF55D6D0)
                                    )
                                    Text(cue.text, color = Color.White)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        stopDubEngine()
        mainHandler.removeCallbacksAndMessages(null)
        ioExecutor.shutdownNow()
        super.onDestroy()
    }
}

private fun sha1(text: String): String {
    val md = MessageDigest.getInstance("SHA-1")
    return md.digest(text.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

private fun parseSrtRobust(source: String): List<Cue> {
    val text = source.removePrefix("\uFEFF").replace("\u0000", "").replace("\r\n", "\n").replace('\r', '\n')
    val timePattern = Regex("""^\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3})\s*-->\s*(\d{2}):(\d{2}):(\d{2})[,.](\d{3}).*$""")
    val lines = text.lines()
    val output = mutableListOf<Cue>()
    var i = 0
    fun millis(h: Long, m: Long, s: Long, ms: Long) = (((h * 60 + m) * 60 + s) * 1000) + ms
    while (i < lines.size) {
        val match = timePattern.matchEntire(lines[i])
        if (match == null) {
            i++; continue
        }
        val values = match.groupValues.drop(1).take(8).mapNotNull { it.toLongOrNull() }
        if (values.size != 8) {
            i++; continue
        }
        val start = millis(values[0], values[1], values[2], values[3])
        val end = millis(values[4], values[5], values[6], values[7])
        i++
        val textLines = mutableListOf<String>()
        while (i < lines.size && !timePattern.matches(lines[i])) {
            val line = lines[i].trim()
            if (line.isNotEmpty() && !line.matches(Regex("""^\d+$"""))) textLines.add(line)
            i++
        }
        val cleaned = textLines.joinToString(" ")
            .replace(Regex("""<[^>]*>"""), "")
            .let { removeBraceTags(it) }
            .replace(Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]"""), "")
            .replace("&nbsp;", " ").replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace(Regex("""\s+"""), " ").trim()
        if (cleaned.isNotBlank() && end >= start) output.add(Cue(start, end, cleaned))
    }
    return output
}

private fun removeBraceTags(input: String): String {
    val result = StringBuilder()
    var inside = false
    for (ch in input) {
        when {
            ch == '{' && !inside -> inside = true
            ch == '}' && inside -> inside = false
            !inside -> result.append(ch)
        }
    }
    return result.toString()
}

private fun timeLabel(ms: Long): String {
    val sec = ms / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
