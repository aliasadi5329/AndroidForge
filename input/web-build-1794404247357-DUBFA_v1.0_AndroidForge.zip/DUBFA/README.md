# DUBFA v1.0 — دوبله زنده فارسی

اپلیکیشن اندروید برای دوبله زنده فیلم با صدای عصبی فارسی Microsoft Edge TTS (بدون نیاز به کلید API).

## ویژگی‌ها

- انتخاب ویدیو محلی و زیرنویس SRT (با تشخیص encoding UTF-8 / UTF-16 / Windows-1256)
- صدای عصبی فارسی: **دلارا** (زن) و **فرید** (مرد)
- دوبله زنده با همگام‌سازی قابل تنظیم (sync offset از −۲ تا +۵ ثانیه)
- کاهش خودکار صدای فیلم هنگام پخش دیالوگ (duck)
- تنظیم خودکار سرعت صحبت برای جا شدن در بازه زمانی دیالوگ
- کش دیسک با محدودیت حجم + prefetch هوشمند
- حالت تمام‌صفحه افقی با کنترل‌های سریع
- رابط کاربری RTL و تم تیره Material 3

## نیازمندی‌ها

- اندروید ۸ (API 24) به بالا
- اینترنت برای Edge TTS
- در صورت قطع سرویس از ایران، VPN پیشنهاد می‌شود

## ساختار پروژه

```
app/src/main/java/com/dubfa/app/
├── MainActivity.kt
├── engine/DubEngine.kt          # موتور دوبله و state
├── subtitle/SubtitleParser.kt   # پارس SRT مقاوم
├── tts/
│   ├── EdgeTtsClient.kt         # کلاینت WebSocket Edge TTS
│   └── TtsRepository.kt         # کش + صف urgent/prefetch
└── ui/
    ├── DubfaApp.kt              # صفحه اصلی
    ├── FullscreenPlayer.kt
    ├── PlayerComponents.kt
    └── Theme.kt
```

## بیلد

با Android Studio (Giraffe یا جدیدتر) پروژه را باز کنید و Sync + Run کنید.  
یا از خط فرمان:

```bash
./gradlew assembleDebug
```

(برای اولین بار، Gradle Wrapper را با Android Studio یا `gradle wrapper` تولید کنید.)

## نسخه

- versionName: **1.0**
- versionCode: **28**
