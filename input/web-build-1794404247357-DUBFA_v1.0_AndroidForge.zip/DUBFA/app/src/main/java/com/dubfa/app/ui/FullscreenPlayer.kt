package com.dubfa.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.exoplayer.ExoPlayer
import com.dubfa.app.engine.DubEngine

@Composable
fun FullscreenPlayer(engine: DubEngine, player: ExoPlayer, onExit: () -> Unit) {
    BackHandler(onBack = onExit)
    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        PlayerSurface(player, Modifier.fillMaxSize())
        CueOverlay(
            text = engine.overlayText,
            visible = engine.showOverlay,
            modifier = Modifier.fillMaxSize(),
            fontSize = 20.sp,
            bottomPadding = 72.dp
        )
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .fillMaxWidth()
                .padding(12.dp)
                .background(Color(0x88000000), RoundedCornerShape(14.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilledTonalButton(onClick = onExit) { Text("خروج") }
            Button(
                onClick = engine::toggleDub,
                colors = if (engine.running) ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                ) else ButtonDefaults.buttonColors()
            ) { Text(if (engine.running) "توقف دوبله" else "شروع دوبله") }
            FilledTonalButton(onClick = { engine.nudgeSync(-500) }) { Text("−۰٫۵") }
            Text(
                formatSync(engine.syncOffsetMs),
                color = Color.White,
                style = MaterialTheme.typography.labelLarge
            )
            FilledTonalButton(onClick = { engine.nudgeSync(500) }) { Text("+۰٫۵") }
            Text(
                "سرعت ×" + "%.2f".format(engine.lastSpeed),
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
