package com.dubfa.app.export

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.dubfa.app.subtitle.Cue
import com.dubfa.app.tts.TtsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.math.abs
import kotlin.math.max

/**
 * Builds a full offline MP4: original video + synchronized dubbed Persian audio.
 * Uses FFmpeg for speed adjustment, timed overlay, and muxing.
 */
class DubExporter(
    private val context: Context,
    private val repo: TtsRepository
) {
    data class Progress(val fraction: Float, val message: String)
    data class Result(val file: File, val displayName: String)

    data class Options(
        val voice: String,
        val syncOffsetMs: Long,
        val fitSpeed: Boolean,
        val maxSpeed: Float,
        val duckEnabled: Boolean,
        val duckLevel: Float,
        val replaceOriginalAudio: Boolean = false
    )

    suspend fun export(
        videoUri: Uri,
        videoName: String,
        cues: List<Cue>,
        options: Options,
        onProgress: (Progress) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        require(cues.isNotEmpty()) { "زیرنویس خالی است" }

        val workDir = File(context.cacheDir, "dub_export_${System.currentTimeMillis()}").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        try {
            onProgress(Progress(0.02f, "کپی ویدئو..."))
            val videoFile = copyUriToFile(videoUri, File(workDir, "input.mp4"))
            val durationMs = probeDurationMs(videoFile).coerceAtLeast(
                cues.maxOfOrNull { it.end } ?: 0L
            )

            onProgress(Progress(0.06f, "تولید صداهای دوبله (${cues.size} دیالوگ)..."))
            val segments = generateSegments(cues, options, workDir) { done, total ->
                val p = 0.06f + 0.50f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "ساخت صدا $done از $total"))
            }

            onProgress(Progress(0.58f, "تنظیم سرعت و زمان‌بندی..."))
            val prepared = prepareSegments(segments, options, workDir) { done, total ->
                val p = 0.58f + 0.18f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "پردازش صدا $done از $total"))
            }

            onProgress(Progress(0.78f, "میکس و ساخت MP4 نهایی..."))
            val outFile = File(workDir, "dubbed_output.mp4")
            mux(videoFile, prepared, durationMs, options, outFile) { msg ->
                onProgress(Progress(0.85f, msg))
            }

            if (!outFile.exists() || outFile.length() < 1000) {
                error("ساخت فایل خروجی ناموفق بود")
            }

            onProgress(Progress(0.95f, "ذخیره در گالری..."))
            val saved = publishToMovies(outFile, videoName)
            onProgress(Progress(1f, "تمام شد"))
            saved
        } finally {
            // keep workDir briefly for debugging; clean old ones
            workDir.deleteRecursively()
        }
    }

    private data class RawSeg(val cue: Cue, val file: File)
    private data class PreparedSeg(val cue: Cue, val file: File, val startMs: Long)

    private suspend fun generateSegments(
        cues: List<Cue>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): List<RawSeg> = coroutineScope {
        val total = cues.size
        val done = AtomicInteger(0)
        // Limit parallelism to avoid saturating TTS / memory
        val batchSize = 4
        val result = Array<RawSeg?>(total) { null }
        var i = 0
        while (i < total) {
            val end = minOf(total, i + batchSize)
            val jobs = (i until end).map { idx ->
                async {
                    val cue = cues[idx]
                    val future = repo.request(cue.text, options.voice, urgent = true)
                    val file = suspendCancellableCoroutine<File> { cont ->
                        future.whenComplete { f, err ->
                            if (err != null || f == null) cont.resumeWith(Result.failure(err ?: IllegalStateException("TTS failed")))
                            else cont.resume(f)
                        }
                    }
                    // Copy into work dir so cache eviction cannot delete mid-export
                    val local = File(workDir, "tts_%04d.mp3".format(idx))
                    file.copyTo(local, overwrite = true)
                    result[idx] = RawSeg(cue, local)
                    onEach(done.incrementAndGet(), total)
                }
            }
            jobs.awaitAll()
            i = end
        }
        result.map { it!! }
    }

    private fun prepareSegments(
        segs: List<RawSeg>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): List<PreparedSeg> {
        val out = ArrayList<PreparedSeg>(segs.size)
        segs.forEachIndexed { idx, seg ->
            val cue = seg.cue
            // Positive syncOffset means speak earlier → place audio earlier on timeline
            val startMs = (cue.start - options.syncOffsetMs).coerceAtLeast(0L)
            val windowMs = (cue.end - cue.start + 200L).coerceAtLeast(300L)

            val durationMs = audioDurationMs(seg.file) ?: (windowMs)
            var input = seg.file
            var speed = 1.0

            if (options.fitSpeed && durationMs > windowMs) {
                speed = (durationMs.toDouble() / windowMs).coerceIn(1.0, options.maxSpeed.toDouble().coerceAtLeast(1.0))
                if (abs(speed - 1.0) > 0.02) {
                    val sped = File(workDir, "spd_%04d.mp3".format(idx))
                    // Chain atempo filters (each must be 0.5..2.0)
                    val filter = atempoChain(speed)
                    val cmd = "-y -i \"${input.absolutePath}\" -filter:a \"$filter\" -vn \"${sped.absolutePath}\""
                    val session = FFmpegKit.execute(cmd)
                    if (ReturnCode.isSuccess(session.returnCode) && sped.exists() && sped.length() > 100) {
                        input = sped
                    }
                }
            }

            out.add(PreparedSeg(cue, input, startMs))
            onEach(idx + 1, segs.size)
        }
        return out
    }

    /** Build atempo chain for arbitrary speed > 1 (FFmpeg atempo is limited to 0.5–2.0). */
    private fun atempoChain(speed: Double): String {
        var s = speed
        val parts = mutableListOf<String>()
        while (s > 2.0 + 1e-6) {
            parts += "atempo=2.0"
            s /= 2.0
        }
        if (s < 0.5) s = 0.5
        parts += "atempo=${"%.4f".format(s)}"
        return parts.joinToString(",")
    }

    private fun mux(
        video: File,
        segs: List<PreparedSeg>,
        durationMs: Long,
        options: Options,
        out: File,
        onMsg: (String) -> Unit
    ) {
        if (segs.isEmpty()) error("هیچ قطعه‌ای برای میکس نیست")

        // Cap number of inputs to keep filter graph reasonable
        val maxSegs = 120
        val used = if (segs.size > maxSegs) {
            onMsg("تعداد دیالوگ زیاد است؛ $maxSegs دیالوگ اول استفاده می‌شود")
            segs.take(maxSegs)
        } else segs

        val inputs = StringBuilder()
        inputs.append("-i \"${video.absolutePath}\" ")
        used.forEach { inputs.append("-i \"${it.file.absolutePath}\" ") }

        val fc = StringBuilder()
        // Delay each dub clip to its start time (ms for adelay)
        used.forEachIndexed { i, seg ->
            val delay = seg.startMs.coerceAtLeast(0L)
            // input index = i+1 (0 is video)
            fc.append("[${i + 1}:a]adelay=${delay}|${delay},volume=1.0[a$i];")
        }

        val duck = if (options.replaceOriginalAudio) 0.0
        else if (options.duckEnabled) options.duckLevel.toDouble().coerceIn(0.0, 1.0)
        else 1.0

        // Prefer original audio when present; otherwise generate silence of video length
        // anullsrc is always available as a fallback path via a second attempt
        fc.append("[0:a]volume=${"%.3f".format(duck)}[orig];")

        // Mix: orig + all dub segments
        fc.append("[orig]")
        used.indices.forEach { i -> fc.append("[a$i]") }
        val n = used.size + 1
        fc.append("amix=inputs=$n:duration=first:dropout_transition=0:normalize=0[aout]")

        val cmd = buildString {
            append("-y ")
            append(inputs)
            append("-filter_complex \"").append(fc).append("\" ")
            append("-map 0:v:0 -map \"[aout]\" ")
            append("-c:v copy -c:a aac -b:a 192k ")
            append("-shortest ")
            append("\"${out.absolutePath}\"")
        }

        onMsg("اجرای FFmpeg...")
        FFmpegKitConfig.enableStatisticsCallback { }
        val session = FFmpegKit.execute(cmd)
        if (!ReturnCode.isSuccess(session.returnCode)) {
            val fail = session.failStackTrace ?: session.output ?: "unknown"
            error("FFmpeg خطا داد: ${fail.take(400)}")
        }
    }

    private fun copyUriToFile(uri: Uri, dest: File): File {
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { output -> input.copyTo(output) }
        } ?: error("باز کردن ویدئو ممکن نشد")
        if (dest.length() < 1000) error("فایل ویدئو نامعتبر است")
        return dest
    }

    private fun probeDurationMs(file: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun audioDurationMs(file: File): Long? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun publishToMovies(src: File, videoName: String): Result {
        val base = videoName.substringBeforeLast('.').ifBlank { "DUBFA" }
            .replace(Regex("""[^\w\u0600-\u06FF\- ]+"""), "_")
            .take(40)
        val display = "${base}_dubbed.mp4"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, display)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DUBFA")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("ذخیره در گالری ممکن نشد")
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(src).use { it.copyTo(out) }
            } ?: error("نوشتن فایل خروجی ممکن نشد")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)

            // Also keep a copy in app files for sharing path
            val local = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), display)
            src.copyTo(local, overwrite = true)
            return Result(local, display)
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val dubfa = File(dir, "DUBFA").apply { mkdirs() }
            val dest = File(dubfa, display)
            src.copyTo(dest, overwrite = true)
            // notify media scanner lightly
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DATA, dest.absolutePath)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            }
            context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            return Result(dest, display)
        }
    }
}
