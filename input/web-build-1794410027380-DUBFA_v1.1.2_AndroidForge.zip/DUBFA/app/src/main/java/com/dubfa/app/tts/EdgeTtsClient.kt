package com.dubfa.app.tts

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.security.MessageDigest
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class EdgeTtsClient(private val http: OkHttpClient) {

    companion object {
        const val VOICE_FEMALE = "fa-IR-DilaraNeural"
        const val VOICE_MALE = "fa-IR-FaridNeural"
        private const val TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
        private const val GEC_VERSION = "1-143.0.3650.75"
        private const val TIMEOUT_SEC = 30L
    }

    /** Index of the endpoint that last worked; tried first next time. */
    @Volatile private var preferredEndpoint = 0

    fun synthesize(text: String, voice: String): ByteArray {
        val requestId = UUID.randomUUID().toString().replace("-", "")
        val gec = generateSecMsGec()
        val urls = listOf(
            "wss://api.msedgeservices.com/tts/cognitiveservices/websocket/v1" +
                "?Ocp-Apim-Subscription-Key=$TOKEN&ConnectionId=$requestId" +
                "&Sec-MS-GEC=$gec&Sec-MS-GEC-Version=$GEC_VERSION",
            "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
                "?TrustedClientToken=$TOKEN&ConnectionId=$requestId" +
                "&Sec-MS-GEC=$gec&Sec-MS-GEC-Version=$GEC_VERSION"
        )
        val first = preferredEndpoint
        val order = listOf(first) + urls.indices.filter { it != first }
        var last: Exception? = null
        for (i in order) {
            try {
                val audio = synthesizeOnce(urls[i], requestId, text, voice)
                preferredEndpoint = i
                return audio
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IllegalStateException("Edge TTS failed")
    }

    private fun generateSecMsGec(): String {
        val ticks = ((System.currentTimeMillis() / 1000L) + 11644473600L) * 10_000_000L
        val rounded = ticks - (ticks % 3_000_000_000L)
        val digest = MessageDigest.getInstance("SHA-256")
            .digest((rounded.toString() + TOKEN).toByteArray(Charsets.US_ASCII))
        return digest.joinToString("") { "%02X".format(it) }
    }

    private fun xmlEscape(s: String): String = buildString {
        for (ch in s) {
            when (ch) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> append(ch)
            }
        }
    }

    private fun synthesizeOnce(url: String, requestId: String, text: String, voice: String): ByteArray {
        val latch = CountDownLatch(1)
        val buffer = ByteArrayOutputStream()
        val error = AtomicReference<String?>(null)
        val turnEnded = AtomicBoolean(false)

        val request = Request.Builder()
            .url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header(
                "User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
                    "(KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"
            )
            .build()

        val ws = http.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val config =
                    """{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"false"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}"""
                webSocket.send(
                    "X-Timestamp:${System.currentTimeMillis()}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n$config"
                )
                val ssml =
                    "<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='fa-IR'>" +
                        "<voice name='$voice'>${xmlEscape(text)}</voice></speak>"
                webSocket.send(
                    "X-RequestId:$requestId\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${System.currentTimeMillis()}Z\r\nPath:ssml\r\n\r\n$ssml"
                )
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end")) {
                    turnEnded.set(true)
                    webSocket.close(1000, null)
                    latch.countDown()
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val arr = bytes.toByteArray()
                if (arr.size < 2) return
                val headerLen = ((arr[0].toInt() and 0xFF) shl 8) or (arr[1].toInt() and 0xFF)
                val dataStart = 2 + headerLen
                if (dataStart > arr.size) return
                val header = String(arr, 2, headerLen, Charsets.US_ASCII)
                if (!header.contains("Path:audio")) return
                if (dataStart < arr.size) {
                    synchronized(buffer) { buffer.write(arr, dataStart, arr.size - dataStart) }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                error.set(t.message ?: "WebSocket failure")
                latch.countDown()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                latch.countDown()
            }
        })

        val ok = latch.await(TIMEOUT_SEC, TimeUnit.SECONDS)
        try {
            ws.cancel()
        } catch (_: Exception) {
        }
        if (!ok) throw IllegalStateException("Timeout Edge TTS")
        error.get()?.let { throw IllegalStateException(it) }
        if (!turnEnded.get()) throw IllegalStateException("پاسخ ناقص از سرور")
        val audio = synchronized(buffer) { buffer.toByteArray() }
        if (audio.size < 80) throw IllegalStateException("صدا خالی")
        return audio
    }
}
