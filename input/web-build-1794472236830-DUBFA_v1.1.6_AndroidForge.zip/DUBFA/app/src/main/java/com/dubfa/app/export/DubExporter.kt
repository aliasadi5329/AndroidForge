package com.dubfa.app.export

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.dubfa.app.subtitle.Cue
import com.dubfa.app.tts.TtsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs

/**
 * Offline dubbed MP4 exporter.
 * Designed to survive long movies (hundreds/thousands of cues) without OOM:
 * - TTS in small batches
 * - speed adjust only when needed
 * - audio mixed in waves of ~20 clips, then final mux with video
 */
class DubExporter(
    private val context: Context,
    private val repo: TtsRepository
) {
    data class Progress(val fraction: Float, val message: String)
    data class Result(val file: File, val displayName: String)

    data class Options(
        val voice: String,
        val syncOffsetMs: Long,
        val fitSpeed: Boolean,
        val maxSpeed: Float,
        val duckEnabled: Boolean,
        val duckLevel: Float,
        val replaceOriginalAudio: Boolean = false
    )

    companion object {
        /** Hard safety cap — beyond this, export first N only (avoids native crash). */
        private const val MAX_CUES = 800
        private const val TTS_BATCH = 3
        private const val MIX_BATCH = 15
    }

    suspend fun export(
        videoUri: Uri,
        videoName: String,
        cuesIn: List<Cue>,
        options: Options,
        onProgress: (Progress) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        require(cuesIn.isNotEmpty()) { "زیرنویس خالی است" }

        val cues = if (cuesIn.size > MAX_CUES) {
            onProgress(Progress(0.01f, "دیالوگ‌ها زیاد است؛ $MAX_CUES دیالوگ اول خروجی گرفته می‌شود"))
            cuesIn.take(MAX_CUES)
        } else cuesIn

        val workDir = File(context.cacheDir, "dub_export_${System.currentTimeMillis()}").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        try {
            onProgress(Progress(0.01f, "آماده‌سازی موتور ویدیو..."))
            ensureFfmpegReady()

            onProgress(Progress(0.02f, "کپی ویدئو..."))
            val videoFile = copyUriToFile(videoUri, File(workDir, "input.mp4"))
            val durationMs = probeDurationMs(videoFile).coerceAtLeast(
                cues.maxOfOrNull { it.end } ?: 0L
            ).coerceAtLeast(1000L)

            onProgress(Progress(0.05f, "تولید صدا (${cues.size} دیالوگ)..."))
            val raw = generateSegments(cues, options, workDir) { done, total ->
                val p = 0.05f + 0.45f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "ساخت صدا $done از $total"))
            }

            onProgress(Progress(0.52f, "تنظیم سرعت..."))
            val prepared = prepareSegments(raw, options, workDir) { done, total ->
                val p = 0.52f + 0.15f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "پردازش صدا $done از $total"))
            }
            // free raw refs
            raw.clear()
            System.gc()

            onProgress(Progress(0.68f, "میکس صدا..."))
            val dubTrack = mixBatched(prepared, durationMs, workDir) { done, total ->
                val p = 0.68f + 0.18f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "میکس $done از $total"))
            }

            onProgress(Progress(0.88f, "ساخت MP4 نهایی..."))
            val outFile = File(workDir, "dubbed_output.mp4")
            finalMux(videoFile, dubTrack, options, outFile)

            if (!outFile.exists() || outFile.length() < 1000L) {
                error("ساخت فایل خروجی ناموفق بود")
            }

            onProgress(Progress(0.96f, "ذخیره در گالری..."))
            val saved = publishToMovies(outFile, videoName)
            onProgress(Progress(1f, "تمام شد: ${saved.displayName}"))
            saved
        } finally {
            try {
                workDir.deleteRecursively()
            } catch (_: Exception) {
            }
        }
    }

    private data class RawSeg(val cue: Cue, val file: File)
    private data class PreparedSeg(val cue: Cue, val file: File, val startMs: Long)

    private suspend fun generateSegments(
        cues: List<Cue>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): MutableList<RawSeg> = coroutineScope {
        val total = cues.size
        val done = AtomicInteger(0)
        val result = arrayOfNulls<RawSeg>(total)
        var i = 0
        while (i < total) {
            val end = minOf(total, i + TTS_BATCH)
            val jobs = (i until end).map { idx ->
                async {
                    val cue = cues[idx]
                    val future = repo.request(cue.text, options.voice, urgent = true)
                    val file = suspendCancellableCoroutine<File> { cont ->
                        future.whenComplete { f, err ->
                            if (err != null || f == null) {
                                cont.resumeWithException(err ?: IllegalStateException("TTS failed"))
                            } else cont.resume(f)
                        }
                    }
                    val local = File(workDir, "tts_%04d.mp3".format(idx))
                    file.copyTo(local, overwrite = true)
                    result[idx] = RawSeg(cue, local)
                    onEach(done.incrementAndGet(), total)
                }
            }
            // Fail-soft: one bad line shouldn't kill entire export
            jobs.forEach { job ->
                try {
                    job.await()
                } catch (_: Exception) {
                    onEach(done.incrementAndGet(), total)
                }
            }
            i = end
        }
        result.filterNotNull().toMutableList()
    }

    private fun prepareSegments(
        segs: List<RawSeg>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): List<PreparedSeg> {
        val out = ArrayList<PreparedSeg>(segs.size)
        segs.forEachIndexed { idx, seg ->
            try {
                val cue = seg.cue
                val startMs = (cue.start - options.syncOffsetMs).coerceAtLeast(0L)
                val windowMs = (cue.end - cue.start + 200L).coerceAtLeast(300L)
                val durationMs = audioDurationMs(seg.file) ?: windowMs
                var input = seg.file

                if (options.fitSpeed && durationMs > windowMs) {
                    val speed = (durationMs.toDouble() / windowMs)
                        .coerceIn(1.0, options.maxSpeed.toDouble().coerceAtLeast(1.0))
                    if (abs(speed - 1.0) > 0.03) {
                        val sped = File(workDir, "spd_%04d.mp3".format(idx))
                        val filter = atempoChain(speed)
                        val cmd =
                            "-y -i \"${input.absolutePath}\" -filter:a \"$filter\" -vn -ac 1 -ar 24000 \"${sped.absolutePath}\""
                        val session = FFmpegKit.execute(cmd)
                        if (ReturnCode.isSuccess(session.returnCode) && sped.length() > 100) {
                            input = sped
                        }
                    }
                }
                out.add(PreparedSeg(cue, input, startMs))
            } catch (_: Throwable) {
                // skip broken segment
            }
            onEach(idx + 1, segs.size)
            if (idx % 40 == 0) System.gc()
        }
        return out
    }

    private fun atempoChain(speed: Double): String {
        var s = speed
        val parts = mutableListOf<String>()
        while (s > 2.0 + 1e-6) {
            parts += "atempo=2.0"
            s /= 2.0
        }
        if (s < 0.5) s = 0.5
        parts += "atempo=${"%.4f".format(s)}"
        return parts.joinToString(",")
    }

    /**
     * Mix speech clips in waves of MIX_BATCH into intermediate tracks,
     * then amix intermediates → one dubbed mono track. Avoids huge filter graphs.
     */
    private fun mixBatched(
        segs: List<PreparedSeg>,
        durationMs: Long,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): File {
        if (segs.isEmpty()) error("هیچ صدایی برای میکس ساخته نشد")

        val durationSec = (durationMs / 1000.0).coerceAtLeast(1.0)
        val waves = segs.chunked(MIX_BATCH)
        val waveFiles = ArrayList<File>()

        waves.forEachIndexed { wi, batch ->
            val waveOut = File(workDir, "wave_%03d.m4a".format(wi))
            val inputs = StringBuilder()
            val fc = StringBuilder()
            batch.forEachIndexed { i, seg ->
                inputs.append("-i \"${seg.file.absolutePath}\" ")
                val delay = seg.startMs.coerceAtLeast(0L)
                fc.append("[$i:a]adelay=${delay}|${delay},apad=whole_dur=$durationSec,atrim=0:$durationSec,asetpts=PTS-STARTPTS[a$i];")
            }
            fc.append(batch.indices.joinToString("") { "[a$it]" })
            fc.append("amix=inputs=${batch.size}:duration=longest:dropout_transition=0:normalize=0[aout]")

            val cmd = buildString {
                append("-y ")
                append(inputs)
                append("-filter_complex \"").append(fc).append("\" ")
                append("-map \"[aout]\" -ac 1 -ar 24000 -c:a aac -b:a 128k ")
                append("-t $durationSec ")
                append("\"${waveOut.absolutePath}\"")
            }
            val session = FFmpegKit.execute(cmd)
            if (!ReturnCode.isSuccess(session.returnCode) || waveOut.length() < 100) {
                // fallback: skip this wave rather than crash
            } else {
                waveFiles.add(waveOut)
            }
            onEach(wi + 1, waves.size)
            System.gc()
        }

        if (waveFiles.isEmpty()) error("میکس صدا ناموفق بود")

        if (waveFiles.size == 1) return waveFiles[0]

        // Final mix of waves
        val finalAudio = File(workDir, "dub_track.m4a")
        val inputs = StringBuilder()
        val fc = StringBuilder()
        waveFiles.forEachIndexed { i, f ->
            inputs.append("-i \"${f.absolutePath}\" ")
            fc.append("[$i:a]apad=whole_dur=$durationSec,atrim=0:$durationSec,asetpts=PTS-STARTPTS[a$i];")
        }
        fc.append(waveFiles.indices.joinToString("") { "[a$it]" })
        fc.append("amix=inputs=${waveFiles.size}:duration=longest:dropout_transition=0:normalize=0[aout]")

        val cmd = buildString {
            append("-y ")
            append(inputs)
            append("-filter_complex \"").append(fc).append("\" ")
            append("-map \"[aout]\" -ac 1 -ar 24000 -c:a aac -b:a 128k ")
            append("-t $durationSec ")
            append("\"${finalAudio.absolutePath}\"")
        }
        val session = FFmpegKit.execute(cmd)
        if (!ReturnCode.isSuccess(session.returnCode) || finalAudio.length() < 100) {
            error("میکس نهایی صدا ناموفق: ${session.output?.take(200) ?: ""}")
        }
        return finalAudio
    }

    private fun finalMux(video: File, dubTrack: File, options: Options, out: File) {
        val duck = when {
            options.replaceOriginalAudio -> 0.0
            options.duckEnabled -> options.duckLevel.toDouble().coerceIn(0.0, 1.0)
            else -> 1.0
        }

        // Try with original audio + dub
        val cmdWithOrig = buildString {
            append("-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\" ")
            append("-filter_complex \"[0:a]volume=${"%.3f".format(duck)}[orig];[1:a]volume=1.0[dub];")
            append("[orig][dub]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]\" ")
            append("-map 0:v:0 -map \"[aout]\" -c:v copy -c:a aac -b:a 192k -shortest ")
            append("\"${out.absolutePath}\"")
        }
        var session = FFmpegKit.execute(cmdWithOrig)
        if (ReturnCode.isSuccess(session.returnCode) && out.length() > 1000) return

        // Fallback: video without relying on original audio stream
        out.delete()
        val cmdReplace = buildString {
            append("-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\" ")
            append("-map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -shortest ")
            append("\"${out.absolutePath}\"")
        }
        session = FFmpegKit.execute(cmdReplace)
        if (!ReturnCode.isSuccess(session.returnCode) || out.length() < 1000) {
            error("Mux ناموفق: ${session.output?.take(300) ?: session.failStackTrace?.take(300) ?: "unknown"}")
        }
    }

    private fun ensureFfmpegReady() {
        try {
            // Force native load early with a clear error if .so is missing
            val ver = FFmpegKitConfig.getVersion()
            if (ver.isNullOrBlank()) {
                error("موتور FFmpeg بارگذاری نشد")
            }
            val probe = FFmpegKit.execute("-version")
            if (!ReturnCode.isSuccess(probe.returnCode) && !ReturnCode.isCancel(probe.returnCode)) {
                // some builds still return non-zero for -version; only fail on link errors
                val out = (probe.output ?: "") + (probe.failStackTrace ?: "")
                if (out.contains("UnsatisfiedLinkError", true) || out.contains("dlopen", true)) {
                    error("کتابخانه بومی FFmpeg روی این گوشی اجرا نشد")
                }
            }
        } catch (t: Throwable) {
            val msg = fullError(t)
            throw IllegalStateException(
                "موتور ساخت ویدیو آماده نشد. $msg — اپ را پاک کنید و دوباره نصب کنید. اگر ادامه داشت، گوشی/ABI پشتیبانی نمی‌شود.",
                t
            )
        }
    }

    private fun fullError(t: Throwable): String {
        val parts = ArrayList<String>(4)
        var c: Throwable? = t
        var i = 0
        while (c != null && i < 5) {
            val m = c.message?.trim().orEmpty()
            if (m.isNotEmpty()) parts.add(m) else parts.add(c.javaClass.simpleName)
            c = c.cause
            i++
        }
        return parts.distinct().joinToString(" | ").take(280)
    }

    private fun copyUriToFile(uri: Uri, dest: File): File {
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { output -> input.copyTo(output) }
        } ?: error("باز کردن ویدئو ممکن نشد")
        if (dest.length() < 1000) error("فایل ویدئو نامعتبر است")
        return dest
    }

    private fun probeDurationMs(file: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun audioDurationMs(file: File): Long? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun publishToMovies(src: File, videoName: String): Result {
        val base = videoName.substringBeforeLast('.').ifBlank { "DUBFA" }
            .replace(Regex("""[^\w\u0600-\u06FF\- ]+"""), "_")
            .take(40)
        val display = "${base}_dubbed.mp4"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, display)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DUBFA")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("ذخیره در گالری ممکن نشد")
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(src).use { it.copyTo(out) }
            } ?: error("نوشتن فایل خروجی ممکن نشد")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)

            val local = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), display)
            src.copyTo(local, overwrite = true)
            return Result(local, display)
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val dubfa = File(dir, "DUBFA").apply { mkdirs() }
            val dest = File(dubfa, display)
            src.copyTo(dest, overwrite = true)
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DATA, dest.absolutePath)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            }
            context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            return Result(dest, display)
        }
    }
}
