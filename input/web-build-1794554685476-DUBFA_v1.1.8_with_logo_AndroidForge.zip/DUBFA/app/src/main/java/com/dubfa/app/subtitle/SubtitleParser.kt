package com.dubfa.app.subtitle

import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

data class Cue(val index: Int, val start: Long, val end: Long, val text: String)

object SubtitleParser {

    private val timeRegex = Regex(
        """^\s*(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[,.](\d{1,3})\s*-->\s*(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[,.](\d{1,3}).*$"""
    )
    private val numberLine = Regex("""^\d+$""")
    private val htmlTag = Regex("""<[^>]*>""")
    private val bidiMarks = Regex("""[\u200E\u200F\u202A-\u202E\u2066-\u2069]""")
    private val whitespace = Regex("""\s+""")

    /** UTF-8 / UTF-16 (BOM) / Windows-1256 detection. */
    fun decode(bytes: ByteArray): String {
        if (bytes.size >= 2 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xFE.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16LE)
        }
        if (bytes.size >= 2 && bytes[0] == 0xFE.toByte() && bytes[1] == 0xFF.toByte()) {
            return String(bytes, 2, bytes.size - 2, Charsets.UTF_16BE)
        }
        val decoder = Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
        return try {
            decoder.decode(ByteBuffer.wrap(bytes)).toString()
        } catch (_: CharacterCodingException) {
            val cp = runCatching { Charset.forName("windows-1256") }.getOrNull() ?: Charsets.ISO_8859_1
            String(bytes, cp)
        }
    }

    fun parse(source: String): List<Cue> {
        val text = source.removePrefix("\uFEFF").replace("\u0000", "")
            .replace("\r\n", "\n").replace('\r', '\n')
        val lines = text.split('\n')
        val raw = mutableListOf<Triple<Long, Long, String>>()
        var i = 0
        while (i < lines.size) {
            val match = timeRegex.matchEntire(lines[i])
            if (match == null) {
                i++; continue
            }
            val g = match.groupValues
            val start = millis(g[1], g[2], g[3], g[4])
            val end = millis(g[5], g[6], g[7], g[8])
            i++
            val textLines = mutableListOf<String>()
            while (i < lines.size && !timeRegex.matches(lines[i])) {
                val line = lines[i].trim()
                val isIndexOfNext = line.matches(numberLine) &&
                    i + 1 < lines.size && timeRegex.matches(lines[i + 1])
                if (line.isNotEmpty() && !isIndexOfNext) textLines.add(line)
                i++
            }
            val cleaned = clean(textLines.joinToString(" "))
            if (start != null && end != null && cleaned.isNotBlank() && end >= start) {
                raw.add(Triple(start, end, cleaned))
            }
        }
        return raw.sortedBy { it.first }
            .mapIndexed { idx, t -> Cue(idx, t.first, t.second, t.third) }
    }

    private fun millis(h: String, m: String, s: String, ms: String): Long? {
        val hh = if (h.isEmpty()) 0L else h.toLongOrNull() ?: return null
        val mm = m.toLongOrNull() ?: return null
        val ss = s.toLongOrNull() ?: return null
        val mss = ms.padEnd(3, '0').toLongOrNull() ?: return null
        return ((hh * 60 + mm) * 60 + ss) * 1000 + mss
    }

    private fun clean(input: String): String =
        removeBraceTags(input.replace(htmlTag, ""))
            .replace(bidiMarks, "")
            .replace("&nbsp;", " ").replace("&amp;", "&")
            .replace("&lt;", "<").replace("&gt;", ">")
            .replace(whitespace, " ").trim()

    private fun removeBraceTags(input: String): String {
        val result = StringBuilder()
        var inside = false
        for (ch in input) {
            when {
                ch == '{' && !inside -> inside = true
                ch == '}' && inside -> inside = false
                !inside -> result.append(ch)
            }
        }
        return result.toString()
    }
}

fun formatTime(ms: Long): String {
    val sec = ms.coerceAtLeast(0L) / 1000
    return "%02d:%02d:%02d".format(sec / 3600, (sec % 3600) / 60, sec % 60)
}
