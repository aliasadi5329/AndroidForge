package com.dubfa.app.engine

import android.content.Context
import android.content.SharedPreferences
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.dubfa.app.subtitle.Cue
import com.dubfa.app.tts.EdgeTtsClient
import com.dubfa.app.tts.TtsRepository
import java.io.File
import java.util.concurrent.CompletionException
import kotlin.math.abs
import kotlinx.coroutines.runBlocking

/** All methods run on the main thread. State is Compose-observable. */
class DubEngine(private val repo: TtsRepository, private val prefs: SharedPreferences) {

    companion object {
        const val MIN_SYNC = -2000L
        const val MAX_SYNC = 5000L
        private const val TICK_MS = 50L
        private const val ACTIVE_TAIL_MS = 200L
        private const val STALE_MS = 1500L
        private const val PREFETCH_WINDOW_MS = 40_000L
        private const val PREFETCH_COUNT = 8
        private const val UI_POSITION_INTERVAL_MS = 500L
        private const val VOLUME_STEP = 0.08f
        private const val K_SYNC = "sync_offset_ms"
        private const val K_VOICE = "voice"
        private const val K_DUCK = "duck"
        private const val K_DUCK_LEVEL = "duck_level"
        private const val K_FIT = "fit_speed"
        private const val K_MAX_SPEED = "max_speed"
        private const val K_OVERLAY = "overlay"
        private const val K_SMART_VOICE = "smart_voice"
    }

    private val main = Handler(Looper.getMainLooper())

    var cues by mutableStateOf<List<Cue>>(emptyList()); private set
    var status by mutableStateOf("ویدئو و زیرنویس را انتخاب کن.")
    var currentIndex by mutableIntStateOf(-1); private set
    var running by mutableStateOf(false); private set
    var lastSpeed by mutableFloatStateOf(1f); private set
    var syncOffsetMs by mutableLongStateOf(prefs.getLong(K_SYNC, 1500L).coerceIn(MIN_SYNC, MAX_SYNC)); private set
    var voice by mutableStateOf(prefs.getString(K_VOICE, null) ?: EdgeTtsClient.VOICE_FEMALE); private set
    var duckEnabled by mutableStateOf(prefs.getBoolean(K_DUCK, true)); private set
    var duckLevel by mutableFloatStateOf(prefs.getFloat(K_DUCK_LEVEL, 0.12f)); private set
    var fitSpeed by mutableStateOf(prefs.getBoolean(K_FIT, true)); private set
    var maxSpeed by mutableFloatStateOf(prefs.getFloat(K_MAX_SPEED, 1.5f)); private set
    var showOverlay by mutableStateOf(prefs.getBoolean(K_OVERLAY, false)); private set
    /** When true: female speakers → Dilara, male → Farid (from subtitle labels / name map). */
    var smartVoice by mutableStateOf(prefs.getBoolean(K_SMART_VOICE, false)); private set
    /** speaker normalized name → true=female */
    var speakerGender by mutableStateOf<Map<String, Boolean>>(emptyMap()); private set
    var detectedSpeakers by mutableStateOf<List<String>>(emptyList()); private set

    var videoName by mutableStateOf<String?>(null); private set
    var subtitleName by mutableStateOf<String?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var isPlaying by mutableStateOf(false); private set
    var overlayText by mutableStateOf(""); private set
    var previewBusy by mutableStateOf(false); private set

    var exportRunning by mutableStateOf(false); private set
    var exportProgress by mutableFloatStateOf(0f); private set
    var exportMessage by mutableStateOf(""); private set
    var lastExportPath by mutableStateOf<String?>(null); private set

    /** Pre-export settings for offline MP4. */
    var exportKeepOriginal by mutableStateOf(true); private set
    var exportOriginalVolume by mutableFloatStateOf(0.28f); private set
    var exportDubVolume by mutableFloatStateOf(1.0f); private set
    var exportEmbedSubs by mutableStateOf(false); private set

    fun updateExportKeepOriginal(v: Boolean) { exportKeepOriginal = v }
    fun updateExportOriginalVolume(v: Float) { exportOriginalVolume = v.coerceIn(0f, 1f) }
    fun updateExportDubVolume(v: Float) { exportDubVolume = v.coerceIn(0.2f, 2f) }
    fun updateExportEmbedSubs(v: Boolean) { exportEmbedSubs = v }

    private var videoUri: Uri? = null
    private var player: ExoPlayer? = null
    private var voicePlayer: MediaPlayer? = null
    private var previewPlayer: MediaPlayer? = null

    private var generation = 0
    private var previewGeneration = 0
    private var spokenIndex = -1
    private var voiceCueIndex = -1
    private var voicePausedByVideo = false
    private var lastPrefetchStart = -1
    private var currentVolume = 1f
    private var lastUiUpdate = 0L
    private var released = false
    private var pendingSpeed = 1f

    private val speechAttributes: AudioAttributes = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_MEDIA)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()

    private val playerListener = object : Player.Listener {
        override fun onIsPlayingChanged(playing: Boolean) {
            isPlaying = playing
            if (playing) resumeVoiceIfValid() else pauseVoice()
        }

        override fun onPositionDiscontinuity(
            oldPosition: Player.PositionInfo,
            newPosition: Player.PositionInfo,
            reason: Int
        ) {
            if (reason == Player.DISCONTINUITY_REASON_SEEK ||
                reason == Player.DISCONTINUITY_REASON_SEEK_ADJUSTMENT
            ) {
                resetDubPosition()
                player?.let { positionMs = it.currentPosition }
            }
        }

        override fun onPlaybackStateChanged(state: Int) {
            val p = player ?: return
            when (state) {
                Player.STATE_READY -> durationMs = p.duration.coerceAtLeast(0L)
                Player.STATE_ENDED -> {
                    stopVoice()
                    status = "پخش ویدئو تمام شد."
                }
                else -> Unit
            }
        }

        override fun onPlayerError(error: PlaybackException) {
            stopVoice()
            status = "خطا در پخش ویدئو: ${error.errorCodeName}"
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (released) return
            try {
                onTick()
            } catch (_: Exception) {
            }
            main.postDelayed(this, TICK_MS)
        }
    }

    init {
        main.post(tick)
    }

    // ---------------- Player / media ----------------

    fun obtainPlayer(context: Context): ExoPlayer {
        player?.let { return it }
        val p = ExoPlayer.Builder(context.applicationContext).build()
        p.addListener(playerListener)
        p.volume = 1f
        currentVolume = 1f
        player = p
        return p
    }

    fun loadVideo(context: Context, uri: Uri, name: String) {
        val p = obtainPlayer(context)
        resetDubPosition()
        p.setMediaItem(MediaItem.fromUri(uri))
        p.prepare()
        p.playWhenReady = false
        videoUri = uri
        videoName = name
        positionMs = 0L
        durationMs = 0L
        lastExportPath = null
        status = "ویدئو بارگذاری شد."
    }

    fun loadSubtitles(list: List<Cue>, name: String) {
        resetDubPosition()
        cues = list
        subtitleName = name
        currentIndex = -1
        overlayText = ""
        lastPrefetchStart = -1
        rebuildSpeakerMap(list)
        val spCount = detectedSpeakers.size
        status = when {
            list.isEmpty() -> "زیرنویس معتبری پیدا نشد."
            spCount > 0 -> "${list.size} دیالوگ — $spCount شخصیت تشخیص داده شد."
            else -> "${list.size} دیالوگ بارگذاری شد."
        }
        if (list.isNotEmpty()) prefetchFrom(0, list.first().start)
    }

    private fun rebuildSpeakerMap(list: List<Cue>) {
        val speakers = com.dubfa.app.tts.VoiceRouter.collectSpeakers(list)
        detectedSpeakers = speakers
        val map = LinkedHashMap<String, Boolean>()
        for (s in speakers) {
            val auto = com.dubfa.app.tts.VoiceRouter.autoIsFemale(s)
            map[s] = auto ?: true // unknown → female default; user can flip
        }
        speakerGender = map
    }

    fun voiceFor(cue: Cue): String =
        com.dubfa.app.tts.VoiceRouter.voiceFor(cue, smartVoice, voice, speakerGender)

    fun updateSmartVoice(enabled: Boolean) {
        smartVoice = enabled
        prefs.edit().putBoolean(K_SMART_VOICE, enabled).apply()
        resetDubPosition()
        lastPrefetchStart = -1
        status = if (enabled) {
            if (detectedSpeakers.isEmpty())
                "صدای هوشمند روشن شد. اگر نام شخصیت در زیرنویس باشد (مثل سارا: ...) صدا جدا می‌شود."
            else
                "صدای هوشمند روشن — ${detectedSpeakers.size} شخصیت."
        } else "صدای هوشمند خاموش — یک صدا برای همه."
    }

    fun setSpeakerFemale(speaker: String, female: Boolean) {
        val key = com.dubfa.app.tts.VoiceRouter.normalize(speaker)
        if (key.isEmpty()) return
        val next = speakerGender.toMutableMap()
        next[key] = female
        speakerGender = next
        resetDubPosition()
        lastPrefetchStart = -1
    }

    fun seekTo(cue: Cue) {
        val p = player ?: return
        p.seekTo((cue.start - syncOffsetMs).coerceAtLeast(0L))
        resetDubPosition()
    }

    fun seekBy(deltaMs: Long) {
        val p = player ?: return
        p.seekTo((p.currentPosition + deltaMs).coerceAtLeast(0L))
    }

    fun togglePlayback() {
        val p = player ?: return
        if (p.isPlaying) p.pause() else {
            if (p.playbackState == Player.STATE_ENDED) p.seekTo(0L)
            p.play()
        }
    }

    // ---------------- Dub control ----------------

    fun startDub() {
        if (cues.isEmpty()) {
            status = "اول یک زیرنویس انتخاب کن."
            return
        }
        running = true
        resetDubPosition()
        status = "دوبله فعال است."
    }

    fun stopDub() {
        running = false
        resetDubPosition()
        status = "دوبله متوقف شد."
    }

    fun toggleDub() = if (running) stopDub() else startDub()

    // ---------------- Settings ----------------

    /** Live update while dragging; no disk write. */
    fun previewSync(ms: Long) {
        syncOffsetMs = ms.coerceIn(MIN_SYNC, MAX_SYNC)
    }

    fun commitSync() {
        prefs.edit().putLong(K_SYNC, syncOffsetMs).apply()
        resetDubPosition()
    }

    fun setSync(ms: Long) {
        previewSync(ms)
        commitSync()
    }

    fun nudgeSync(deltaMs: Long) = setSync(syncOffsetMs + deltaMs)

    fun updateVoice(v: String) {
        if (v == voice) return
        voice = v
        prefs.edit().putString(K_VOICE, v).apply()
        resetDubPosition()
        lastPrefetchStart = -1
    }

    fun updateDuck(enabled: Boolean) {
        duckEnabled = enabled
        prefs.edit().putBoolean(K_DUCK, enabled).apply()
    }

    fun previewDuckLevel(level: Float) {
        duckLevel = level.coerceIn(0f, 1f)
    }

    fun commitDuckLevel() {
        prefs.edit().putFloat(K_DUCK_LEVEL, duckLevel).apply()
    }

    fun updateFitSpeed(enabled: Boolean) {
        fitSpeed = enabled
        prefs.edit().putBoolean(K_FIT, enabled).apply()
    }

    fun previewMaxSpeed(speed: Float) {
        maxSpeed = speed.coerceIn(1f, 2.5f)
    }

    fun commitMaxSpeed() {
        prefs.edit().putFloat(K_MAX_SPEED, maxSpeed).apply()
    }

    fun updateOverlay(enabled: Boolean) {
        showOverlay = enabled
        prefs.edit().putBoolean(K_OVERLAY, enabled).apply()
    }

    // ---------------- Voice test ----------------

    fun testVoice() {
        val gen = ++previewGeneration
        previewBusy = true
        status = "در حال آماده‌سازی نمونه صدا..."
        repo.request("سلام، این یک نمونه از صدای دوبله فارسی است.", voice, urgent = true)
            .whenComplete { file, err ->
                main.post {
                    if (released || gen != previewGeneration) return@post
                    previewBusy = false
                    if (err != null || file == null) {
                        status = "خطا در ساخت صدا: ${errorMessage(err)}"
                    } else {
                        playPreview(file)
                    }
                }
            }
    }

    private fun playPreview(file: File) {
        releasePreview()
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(speechAttributes)
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener { if (previewPlayer === it) releasePreview() }
            mp.setOnErrorListener { m, _, _ -> if (previewPlayer === m) releasePreview(); true }
            mp.prepare()
            previewPlayer = mp
            mp.start()
            status = "نمونه صدا در حال پخش است."
        } catch (e: Exception) {
            try { mp.release() } catch (_: Exception) {}
            if (previewPlayer === mp) previewPlayer = null
            status = "پخش نمونه صدا ناموفق بود."
        }
    }

    private fun releasePreview() {
        previewPlayer?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        previewPlayer = null
    }

    // ---------------- Engine loop ----------------

    private fun onTick() {
        val p = player ?: return
        val pos = p.currentPosition
        val now = SystemClock.uptimeMillis()
        if (now - lastUiUpdate >= UI_POSITION_INTERVAL_MS) {
            positionMs = pos
            lastUiUpdate = now
        }

        val voiceActive = try { voicePlayer?.isPlaying == true } catch (_: Exception) { false }
        applyVolume(if (running && duckEnabled && voiceActive) duckLevel else 1f)

        val list = cues
        if (list.isEmpty()) return

        val effective = pos + syncOffsetMs
        val idx = findCue(list, effective)
        if (idx != currentIndex) {
            currentIndex = idx
            overlayText = if (idx >= 0) list[idx].text else ""
        }

        if (!running || !p.isPlaying) return

        if (idx >= 0 && idx != spokenIndex) {
            val cue = list[idx]
            if (effective - cue.start <= STALE_MS) speak(idx, cue) else spokenIndex = idx
            prefetchFrom(idx + 1, effective)
        } else if (idx < 0) {
            val next = nextCueAfter(list, effective)
            if (next >= 0) prefetchFrom(next, effective)
        }
    }

    private fun findCue(list: List<Cue>, t: Long): Int {
        var lo = 0
        var hi = list.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (list[mid].start <= t) {
                ans = mid; lo = mid + 1
            } else hi = mid - 1
        }
        if (ans < 0) return -1
        return if (t < list[ans].end + ACTIVE_TAIL_MS) ans else -1
    }

    private fun nextCueAfter(list: List<Cue>, t: Long): Int {
        var lo = 0
        var hi = list.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (list[mid].start > t) {
                ans = mid; hi = mid - 1
            } else lo = mid + 1
        }
        return ans
    }

    private fun prefetchFrom(start: Int, effective: Long) {
        if (start == lastPrefetchStart) return
        lastPrefetchStart = start
        val list = cues
        val end = minOf(list.size, start + PREFETCH_COUNT)
        for (i in start until end) {
            if (list[i].start - effective > PREFETCH_WINDOW_MS) break
            val cue = list[i]
            repo.prefetch(cue.text, voiceFor(cue))
        }
    }

    private fun speak(idx: Int, cue: Cue) {
        spokenIndex = idx
        val gen = generation
        val lineVoice = voiceFor(cue)
        repo.request(cue.text, lineVoice, urgent = true).whenComplete { file, err ->
            main.post {
                if (released || gen != generation || !running) return@post
                if (err != null || file == null) {
                    status = "خطای TTS: ${errorMessage(err)}"
                    return@post
                }
                val p = player ?: return@post
                val effective = p.currentPosition + syncOffsetMs
                if (effective > cue.end + STALE_MS) return@post
                playVoice(file, cue, idx, effective, startNow = p.isPlaying)
            }
        }
    }

    private fun playVoice(file: File, cue: Cue, idx: Int, effective: Long, startNow: Boolean) {
        stopVoice()
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(speechAttributes)
            mp.setDataSource(file.absolutePath)
            mp.setOnCompletionListener { if (voicePlayer === it) stopVoice() }
            mp.setOnErrorListener { m, _, _ -> if (voicePlayer === m) stopVoice(); true }
            mp.prepare()

            val audioMs = mp.duration.toLong().coerceAtLeast(1L)
            val window = (cue.end + ACTIVE_TAIL_MS - effective).coerceAtLeast(300L)
            var speed = 1f
            if (fitSpeed && audioMs > window) {
                speed = (audioMs.toFloat() / window).coerceIn(1f, maxSpeed.coerceAtLeast(1f))
            }

            voicePlayer = mp
            voiceCueIndex = idx
            lastSpeed = speed
            if (startNow) {
                mp.start()
                if (speed != 1f) mp.playbackParams = mp.playbackParams.setSpeed(speed)
                if (status.startsWith("خطای TTS")) status = "دوبله فعال است."
            } else {
                voicePausedByVideo = true
                pendingSpeed = speed
            }
        } catch (e: Exception) {
            try { mp.release() } catch (_: Exception) {}
            if (voicePlayer === mp) voicePlayer = null
            status = "پخش صدای دوبله ناموفق بود."
        }
    }

    private fun pauseVoice() {
        val mp = voicePlayer ?: return
        try {
            if (mp.isPlaying) {
                mp.pause()
                voicePausedByVideo = true
            }
        } catch (_: Exception) {
            stopVoice()
        }
    }

    private fun resumeVoiceIfValid() {
        val mp = voicePlayer ?: return
        if (!voicePausedByVideo || !running) return
        val p = player ?: return
        val idx = findCue(cues, p.currentPosition + syncOffsetMs)
        if (idx != voiceCueIndex) {
            stopVoice()
            return
        }
        try {
            mp.start()
            val speed = if (lastSpeed != 1f) lastSpeed else pendingSpeed
            if (speed != 1f) mp.playbackParams = mp.playbackParams.setSpeed(speed)
            voicePausedByVideo = false
        } catch (_: Exception) {
            stopVoice()
        }
    }

    private fun stopVoice() {
        voicePlayer?.let {
            try { it.stop() } catch (_: Exception) {}
            try { it.release() } catch (_: Exception) {}
        }
        voicePlayer = null
        voicePausedByVideo = false
        voiceCueIndex = -1
        pendingSpeed = 1f
    }

    private fun resetDubPosition() {
        generation++
        spokenIndex = -1
        lastPrefetchStart = -1
        stopVoice()
    }

    private fun applyVolume(target: Float) {
        val p = player ?: return
        val next = if (abs(target - currentVolume) <= VOLUME_STEP) target
        else currentVolume + if (target > currentVolume) VOLUME_STEP else -VOLUME_STEP
        if (next != currentVolume) {
            currentVolume = next
            p.volume = next
        }
    }

    private fun errorMessage(t: Throwable?): String {
        if (t == null) return "نامشخص"
        val c = if (t is CompletionException) t.cause ?: t else t
        return c.message ?: c.javaClass.simpleName
    }

    // ---------------- Offline MP4 export ----------------

    fun startExport(context: Context) {
        if (exportRunning) return
        val uri = videoUri
        if (uri == null) {
            status = "اول ویدئو را انتخاب کن."
            return
        }
        if (cues.isEmpty()) {
            status = "اول زیرنویس را انتخاب کن."
            return
        }
        exportRunning = true
        exportProgress = 0f
        exportMessage = "شروع خروجی..."
        lastExportPath = null
        status = "در حال ساخت فیلم دوبله‌شده..."
        player?.pause()
        stopDub()

        val exporter = com.dubfa.app.export.DubExporter(context.applicationContext, repo)
        val opts = com.dubfa.app.export.DubExporter.Options(
            voice = voice,
            syncOffsetMs = syncOffsetMs,
            fitSpeed = fitSpeed,
            maxSpeed = maxSpeed,
            duckEnabled = duckEnabled,
            duckLevel = duckLevel,
            keepOriginalAudio = exportKeepOriginal,
            originalVolume = exportOriginalVolume,
            dubVolume = exportDubVolume,
            embedSubtitles = exportEmbedSubs,
            smartVoice = smartVoice,
            speakerIsFemale = speakerGender
        )
        val list = cues
        val name = videoName ?: "video"

        Thread {
            try {
                val result = runBlocking {
                    exporter.export(uri, name, list, opts) { p ->
                        main.post {
                            if (!released) {
                                exportProgress = p.fraction
                                exportMessage = p.message
                            }
                        }
                    }
                }
                main.post {
                    if (released) return@post
                    exportRunning = false
                    exportProgress = 1f
                    lastExportPath = result.file.absolutePath
                    exportMessage = "ذخیره شد: ${result.displayName}"
                    status = "خروجی آماده است: ${result.displayName}"
                }
            } catch (t: Throwable) {
                main.post {
                    if (released) return@post
                    exportRunning = false
                    val parts = ArrayList<String>()
                    var c: Throwable? = t
                    var i = 0
                    while (c != null && i < 4) {
                        val m = c.message?.trim().orEmpty()
                        if (m.isNotEmpty()) parts.add(m) else parts.add(c.javaClass.simpleName)
                        c = c.cause
                        i++
                    }
                    val msg = parts.distinct().joinToString(" | ").ifBlank { t.javaClass.simpleName }.take(280)
                    exportMessage = "خطا: $msg"
                    status = "خطای خروجی: $msg"
                }
            }
        }.apply {
            this.name = "dubfa-export"
            this.isDaemon = true
            this.priority = Thread.NORM_PRIORITY - 1
        }.start()
    }

    // ---------------- Lifecycle ----------------

    fun onHostStopped() {
        player?.pause()
        stopVoice()
        releasePreview()
    }

    fun release() {
        released = true
        main.removeCallbacksAndMessages(null)
        stopVoice()
        releasePreview()
        player?.let {
            it.removeListener(playerListener)
            it.release()
        }
        player = null
    }
}
