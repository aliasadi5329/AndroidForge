package com.dubfa.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.media3.exoplayer.ExoPlayer
import com.dubfa.app.engine.DubEngine
import com.dubfa.app.subtitle.Cue
import com.dubfa.app.subtitle.SubtitleParser
import com.dubfa.app.subtitle.formatTime
import com.dubfa.app.tts.EdgeTtsClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToLong

private const val MAX_SUBTITLE_BYTES = 10L * 1024 * 1024

@Composable
fun DubfaApp(engine: DubEngine, onFullscreenChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    val player = remember { engine.obtainPlayer(context) }
    var fullscreen by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(fullscreen) { onFullscreenChange(fullscreen) }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        if (fullscreen) {
            FullscreenPlayer(engine, player, onExit = { fullscreen = false })
        } else {
            MainScreen(engine, player, onFullscreen = { fullscreen = true })
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainScreen(engine: DubEngine, player: ExoPlayer, onFullscreen: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            persistPermission(context, uri)
            engine.loadVideo(context, uri, displayName(context, uri) ?: "ویدئو")
        }
    }

    val subtitlePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                engine.status = "در حال خواندن زیرنویس..."
                val name = displayName(context, uri) ?: "زیرنویس"
                val result = withContext(Dispatchers.IO) {
                    runCatching {
                        val size = fileSize(context, uri)
                        if (size != null && size > MAX_SUBTITLE_BYTES) error("فایل زیرنویس بیش از حد بزرگ است")
                        val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                            ?: error("فایل باز نشد")
                        SubtitleParser.parse(SubtitleParser.decode(bytes))
                    }
                }
                result
                    .onSuccess { engine.loadSubtitles(it, name) }
                    .onFailure { engine.status = "خطا در خواندن زیرنویس: ${it.message ?: "نامشخص"}" }
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("DUBFA — دوبله فارسی", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(key = "video") {
                VideoCard(engine, player, onPick = { videoPicker.launch(arrayOf("video/*")) }, onFullscreen)
            }
            item(key = "subtitle") {
                SubtitleCard(engine, onPick = { subtitlePicker.launch(arrayOf("*/*")) })
            }
            item(key = "dub") { DubCard(engine) }
            item(key = "export") { ExportCard(engine) }
            item(key = "sync") { SyncCard(engine) }
            item(key = "audio") { AudioCard(engine) }
            if (engine.cues.isNotEmpty()) {
                item(key = "cues_header") {
                    Text(
                        "دیالوگ‌ها (${engine.cues.size})",
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
                items(engine.cues, key = { "cue_${it.index}" }) { cue ->
                    CueRow(cue, active = cue.index == engine.currentIndex, onClick = { engine.seekTo(cue) })
                }
            }
        }
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
            content()
        }
    }
}

@Composable
private fun VideoCard(engine: DubEngine, player: ExoPlayer, onPick: () -> Unit, onFullscreen: () -> Unit) {
    SectionCard("ویدئو") {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(16f / 9f)
                .background(Color.Black, RoundedCornerShape(12.dp))
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                PlayerSurface(player, Modifier.fillMaxSize())
            }
            CueOverlay(engine.overlayText, engine.showOverlay, Modifier.fillMaxSize())
        }
        Text(
            engine.videoName ?: "ویدئویی انتخاب نشده",
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            "${formatTime(engine.positionMs)} / ${formatTime(engine.durationMs)}",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onPick) { Text("انتخاب ویدئو") }
            FilledTonalButton(onClick = engine::togglePlayback, enabled = engine.videoName != null) {
                Text(if (engine.isPlaying) "توقف" else "پخش")
            }
            OutlinedButton(onClick = onFullscreen, enabled = engine.videoName != null) { Text("تمام‌صفحه") }
        }
    }
}

@Composable
private fun SubtitleCard(engine: DubEngine, onPick: () -> Unit) {
    SectionCard("زیرنویس") {
        Text(
            engine.subtitleName ?: "زیرنویسی انتخاب نشده (SRT / VTT)",
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        if (engine.cues.isNotEmpty()) {
            Text(
                "${engine.cues.size} دیالوگ",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Button(onClick = onPick) { Text("انتخاب زیرنویس") }
    }
}

@Composable
private fun DubCard(engine: DubEngine) {
    SectionCard("دوبله") {
        Text(engine.status, style = MaterialTheme.typography.bodyMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            FilterChip(
                selected = engine.voice == EdgeTtsClient.VOICE_FEMALE,
                onClick = { engine.updateVoice(EdgeTtsClient.VOICE_FEMALE) },
                label = { Text("دلارا (زن)") }
            )
            FilterChip(
                selected = engine.voice == EdgeTtsClient.VOICE_MALE,
                onClick = { engine.updateVoice(EdgeTtsClient.VOICE_MALE) },
                label = { Text("فرید (مرد)") }
            )
        }
        Text(
            if (engine.smartVoice) "صدای پیش‌فرض برای دیالوگ‌های بدون نام شخصیت"
            else "یک صدا برای همه دیالوگ‌ها",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("صدای هوشمند زن/مرد", style = MaterialTheme.typography.bodyMedium)
                Text(
                    "اگر در زیرنویس نام باشد (مثل سارا: سلام) صدا جدا می‌شود",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Switch(
                checked = engine.smartVoice,
                onCheckedChange = engine::updateSmartVoice
            )
        }
        if (engine.smartVoice && engine.detectedSpeakers.isNotEmpty()) {
            Text(
                "شخصیت‌ها — برای هرکدام زن یا مرد را انتخاب کن:",
                style = MaterialTheme.typography.labelMedium
            )
            engine.detectedSpeakers.forEach { sp ->
                val female = engine.speakerGender[sp] ?: true
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(sp, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = female,
                            onClick = { engine.setSpeakerFemale(sp, true) },
                            label = { Text("دلارا") }
                        )
                        FilterChip(
                            selected = !female,
                            onClick = { engine.setSpeakerFemale(sp, false) },
                            label = { Text("فرید") }
                        )
                    }
                }
            }
        } else if (engine.smartVoice && engine.detectedSpeakers.isEmpty()) {
            Text(
                "در این زیرنویس نام شخصیت پیدا نشد. برای تشخیص خودکار، خطوط را به شکل «سارا: متن» بنویس.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = engine::toggleDub,
                enabled = engine.cues.isNotEmpty(),
                colors = if (engine.running) ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.error
                ) else ButtonDefaults.buttonColors()
            ) { Text(if (engine.running) "توقف دوبله" else "شروع دوبله") }
            OutlinedButton(onClick = engine::testVoice, enabled = !engine.previewBusy) {
                Text(if (engine.previewBusy) "در حال ساخت..." else "آزمایش صدا")
            }
        }
        if (engine.running) {
            Text(
                "سرعت آخرین دیالوگ: ×" + "%.2f".format(engine.lastSpeed),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ExportCard(engine: DubEngine) {
    val context = LocalContext.current
    SectionCard("خروجی آفلاین MP4") {
        Text(
            "یک فیلم کامل دوبله‌شده با همان همگام‌سازی و سرعت دیالوگ‌ها می‌سازد و در پوشه Movies/DUBFA ذخیره می‌کند.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (engine.exportRunning) {
            Text(
                engine.exportMessage.ifBlank { "در حال پردازش..." },
                style = MaterialTheme.typography.bodyMedium
            )
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Slider(
                    value = engine.exportProgress.coerceIn(0f, 1f),
                    onValueChange = {},
                    valueRange = 0f..1f,
                    enabled = false
                )
            }
            Text(
                "${(engine.exportProgress * 100).toInt()}٪",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.secondary
            )
        } else {
            Text("تنظیمات قبل از خروجی", style = MaterialTheme.typography.titleSmall)
            Text(
                "صدای دوبله از بخش «دوبله» (دلارا/فرید و صدای هوشمند) گرفته می‌شود.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("نگه‌داشتن صدای اصلی فیلم", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "موزیک و صدای محیط فیلم حفظ شود",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = engine.exportKeepOriginal,
                    onCheckedChange = engine::updateExportKeepOriginal
                )
            }
            if (engine.exportKeepOriginal) {
                Text(
                    "بلندی صدای اصلی فیلم: ${(engine.exportOriginalVolume * 100).toInt()}٪",
                    style = MaterialTheme.typography.bodySmall
                )
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Slider(
                        value = engine.exportOriginalVolume,
                        onValueChange = engine::updateExportOriginalVolume,
                        valueRange = 0.05f..1f
                    )
                }
            }
            Text(
                "بلندی صدای دوبله: ${(engine.exportDubVolume * 100).toInt()}٪",
                style = MaterialTheme.typography.bodySmall
            )
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Slider(
                    value = engine.exportDubVolume,
                    onValueChange = engine::updateExportDubVolume,
                    valueRange = 0.3f..1.5f
                )
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("زیرنویس داخل فایل خروجی", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        "به‌صورت Soft Sub (در پلیر روشن/خاموش می‌شود)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = engine.exportEmbedSubs,
                    onCheckedChange = engine::updateExportEmbedSubs
                )
            }
            Button(
                onClick = { engine.startExport(context) },
                enabled = engine.videoName != null && engine.cues.isNotEmpty(),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A6A4A))
            ) {
                Text("شروع ساخت فیلم دوبله‌شده (MP4)")
            }
            if (engine.lastExportPath != null) {
                Text(
                    "آخرین خروجی: ${engine.lastExportPath}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.secondary
                )
            } else if (engine.exportMessage.startsWith("خطا")) {
                Text(
                    engine.exportMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            }
        }
        Text(
            "نکته: برای فیلم‌های طولانی چند دقیقه تا چند ده دقیقه طول می‌کشد و اینترنت برای تولید صدا لازم است.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun SyncCard(engine: DubEngine) {
    SectionCard("همگام‌سازی") {
        Text("جابه‌جایی: ${formatSync(engine.syncOffsetMs)}", style = MaterialTheme.typography.bodyMedium)
        Text(
            "مقدار مثبت یعنی صدا زودتر پخش شود، مقدار منفی یعنی دیرتر.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Slider(
                value = engine.syncOffsetMs / 1000f,
                onValueChange = { engine.previewSync(((it * 10).roundToLong()) * 100L) },
                onValueChangeFinished = engine::commitSync,
                valueRange = (DubEngine.MIN_SYNC / 1000f)..(DubEngine.MAX_SYNC / 1000f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(0L, 500L, 1000L, 1500L, 2000L, 3000L).forEach { ms ->
                FilterChip(
                    selected = engine.syncOffsetMs == ms,
                    onClick = { engine.setSync(ms) },
                    label = { Text("%.1f".format(ms / 1000f)) }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilledTonalButton(onClick = { engine.nudgeSync(-500) }) { Text("−۰٫۵ ثانیه") }
            FilledTonalButton(onClick = { engine.nudgeSync(500) }) { Text("+۰٫۵ ثانیه") }
        }
    }
}

@Composable
private fun AudioCard(engine: DubEngine) {
    SectionCard("صدا و نمایش") {
        SettingSwitch("کم کردن صدای فیلم هنگام دوبله", engine.duckEnabled, engine::updateDuck)
        if (engine.duckEnabled) {
            Text("صدای فیلم هنگام دیالوگ: ${(engine.duckLevel * 100).toInt()}٪", style = MaterialTheme.typography.bodySmall)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Slider(
                    value = engine.duckLevel,
                    onValueChange = engine::previewDuckLevel,
                    onValueChangeFinished = engine::commitDuckLevel,
                    valueRange = 0f..1f
                )
            }
        }
        SettingSwitch("تنظیم خودکار سرعت برای جا شدن در زمان دیالوگ", engine.fitSpeed, engine::updateFitSpeed)
        if (engine.fitSpeed) {
            Text("حداکثر سرعت: ×" + "%.2f".format(engine.maxSpeed), style = MaterialTheme.typography.bodySmall)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Slider(
                    value = engine.maxSpeed,
                    onValueChange = engine::previewMaxSpeed,
                    onValueChangeFinished = engine::commitMaxSpeed,
                    valueRange = 1f..2.5f
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = engine.showOverlay, onCheckedChange = engine::updateOverlay)
            Text("نمایش متن روی تصویر", style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun SettingSwitch(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun CueRow(cue: Cue, active: Boolean, onClick: () -> Unit) {
    val bg = if (active) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant
    Column(
        Modifier
            .fillMaxWidth()
            .background(bg, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(
            "${cue.index + 1}  •  ${formatTime(cue.start)}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(2.dp))
        Text(cue.text, style = MaterialTheme.typography.bodyMedium)
    }
}

fun formatSync(ms: Long): String = "%+.1f ثانیه".format(ms / 1000f)

private fun displayName(context: Context, uri: Uri): String? = try {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    } ?: uri.lastPathSegment
} catch (_: Exception) {
    uri.lastPathSegment
}

private fun fileSize(context: Context, uri: Uri): Long? = try {
    context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
        if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
    }
} catch (_: Exception) {
    null
}

private fun persistPermission(context: Context, uri: Uri) {
    try {
        context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (_: Exception) {
    }
}
