package com.dubfa.app.export

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.dubfa.app.subtitle.Cue
import com.dubfa.app.tts.TtsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs

/**
 * Offline dubbed MP4 exporter.
 * Designed to survive long movies (hundreds/thousands of cues) without OOM:
 * - TTS in small batches
 * - speed adjust only when needed
 * - audio mixed in waves of ~20 clips, then final mux with video
 */
class DubExporter(
    private val context: Context,
    private val repo: TtsRepository
) {
    data class Progress(val fraction: Float, val message: String)
    data class Result(val file: File, val displayName: String)

    data class Options(
        val voice: String,
        val syncOffsetMs: Long,
        val fitSpeed: Boolean,
        val maxSpeed: Float,
        val duckEnabled: Boolean,
        val duckLevel: Float,
        /** Keep music / ambient from original film (recommended true). */
        val keepOriginalAudio: Boolean = true,
        /** Volume of original film audio 0..1 when NOT using dynamic duck. */
        val originalVolume: Float = 0.28f,
        /** Volume of Persian dub track 0..1 */
        val dubVolume: Float = 1.0f,
        /**
         * If true: original stays ~100% except during each dialogue window,
         * where it drops to [dialogueDuckLevel] so dub is clear (auto-duck).
         */
        val dynamicDuck: Boolean = false,
        /** Original volume during dialogue when dynamicDuck is on (0..1). */
        val dialogueDuckLevel: Float = 0.18f,
        /** Embed soft SRT subtitle track in the MP4 (players can show/hide). */
        val embedSubtitles: Boolean = false,
        val smartVoice: Boolean = false,
        val speakerIsFemale: Map<String, Boolean> = emptyMap()
    )

    companion object {
        /** Hard safety cap — beyond this, export first N only (avoids native crash). */
        private const val MAX_CUES = 800
        private const val TTS_BATCH = 3
        private const val MIX_BATCH = 15
    }

    suspend fun export(
        videoUri: Uri,
        videoName: String,
        cuesIn: List<Cue>,
        options: Options,
        onProgress: (Progress) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        require(cuesIn.isNotEmpty()) { "زیرنویس خالی است" }

        val cues = if (cuesIn.size > MAX_CUES) {
            onProgress(Progress(0.01f, "دیالوگ‌ها زیاد است؛ $MAX_CUES دیالوگ اول خروجی گرفته می‌شود"))
            cuesIn.take(MAX_CUES)
        } else cuesIn

        val workDir = File(context.cacheDir, "dub_export_${System.currentTimeMillis()}").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        try {
            onProgress(Progress(0.01f, "آماده‌سازی موتور ویدیو..."))
            ensureFfmpegReady()

            onProgress(Progress(0.02f, "کپی ویدئو..."))
            val videoFile = copyUriToFile(videoUri, File(workDir, "input.mp4"))
            val durationMs = probeDurationMs(videoFile).coerceAtLeast(
                cues.maxOfOrNull { it.end } ?: 0L
            ).coerceAtLeast(1000L)

            onProgress(Progress(0.05f, "تولید صدا (${cues.size} دیالوگ)..."))
            val raw = generateSegments(cues, options, workDir) { done, total ->
                val p = 0.05f + 0.45f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "ساخت صدا $done از $total"))
            }

            onProgress(Progress(0.52f, "تنظیم سرعت..."))
            val prepared = prepareSegments(raw, options, workDir) { done, total ->
                val p = 0.52f + 0.15f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "پردازش صدا $done از $total"))
            }
            // free raw refs
            raw.clear()
            System.gc()

            onProgress(Progress(0.68f, "میکس صدا..."))
            val dubTrack = mixBatched(prepared, durationMs, workDir) { frac, msg ->
                onProgress(Progress(0.68f + 0.20f * frac.coerceIn(0f, 1f), msg))
            }

            onProgress(Progress(0.88f, "ساخت MP4 نهایی..."))
            val outFile = File(workDir, "dubbed_output.mp4")
            val srtFile = if (options.embedSubtitles) {
                writeSrt(cues, File(workDir, "export.srt"))
            } else null
            val envelope = if (options.keepOriginalAudio && options.dynamicDuck) {
                onProgress(Progress(0.89f, "ساخت منحنی صدای داک..."))
                writeDuckEnvelope(
                    cues = cues,
                    durationMs = durationMs,
                    syncOffsetMs = options.syncOffsetMs,
                    duckLevel = options.dialogueDuckLevel,
                    outFile = File(workDir, "duck_env.wav")
                )
            } else null
            finalMux(videoFile, dubTrack, durationMs, options, outFile, srtFile, envelope)
            onProgress(Progress(0.95f, "Mux تمام شد"))

            if (!outFile.exists() || outFile.length() < 1000L) {
                error("ساخت فایل خروجی ناموفق بود")
            }

            onProgress(Progress(0.96f, "ذخیره در گالری..."))
            val saved = publishToMovies(outFile, videoName)
            onProgress(Progress(1f, "تمام شد: ${saved.displayName}"))
            saved
        } finally {
            try {
                workDir.deleteRecursively()
            } catch (_: Exception) {
            }
        }
    }

    private data class RawSeg(val cue: Cue, val file: File)
    private data class PreparedSeg(val cue: Cue, val file: File, val startMs: Long)

    private suspend fun generateSegments(
        cues: List<Cue>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): MutableList<RawSeg> = coroutineScope {
        val total = cues.size
        val done = AtomicInteger(0)
        val result = arrayOfNulls<RawSeg>(total)
        var i = 0
        while (i < total) {
            val end = minOf(total, i + TTS_BATCH)
            val jobs = (i until end).map { idx ->
                async {
                    val cue = cues[idx]
                    val lineVoice = com.dubfa.app.tts.VoiceRouter.voiceFor(
                        cue, options.smartVoice, options.voice, options.speakerIsFemale
                    )
                    val future = repo.request(cue.text, lineVoice, urgent = true)
                    val file = suspendCancellableCoroutine<File> { cont ->
                        future.whenComplete { f, err ->
                            if (err != null || f == null) {
                                cont.resumeWithException(err ?: IllegalStateException("TTS failed"))
                            } else cont.resume(f)
                        }
                    }
                    val local = File(workDir, "tts_%04d.mp3".format(idx))
                    file.copyTo(local, overwrite = true)
                    result[idx] = RawSeg(cue, local)
                    onEach(done.incrementAndGet(), total)
                }
            }
            // Fail-soft: one bad line shouldn't kill entire export
            jobs.forEach { job ->
                try {
                    job.await()
                } catch (_: Exception) {
                    onEach(done.incrementAndGet(), total)
                }
            }
            i = end
        }
        result.filterNotNull().toMutableList()
    }

    private fun prepareSegments(
        segs: List<RawSeg>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): List<PreparedSeg> {
        val out = ArrayList<PreparedSeg>(segs.size)
        segs.forEachIndexed { idx, seg ->
            try {
                val cue = seg.cue
                val startMs = (cue.start - options.syncOffsetMs).coerceAtLeast(0L)
                val windowMs = (cue.end - cue.start + 200L).coerceAtLeast(300L)
                val durationMs = audioDurationMs(seg.file) ?: windowMs
                var input = seg.file

                if (options.fitSpeed && durationMs > windowMs) {
                    val speed = (durationMs.toDouble() / windowMs)
                        .coerceIn(1.0, options.maxSpeed.toDouble().coerceAtLeast(1.0))
                    if (abs(speed - 1.0) > 0.03) {
                        val sped = File(workDir, "spd_%04d.mp3".format(idx))
                        val filter = atempoChain(speed)
                        val cmd =
                            "-y -i \"${input.absolutePath}\" -filter:a \"$filter\" -vn -ac 1 -ar 24000 \"${sped.absolutePath}\""
                        val session = FFmpegKit.execute(cmd)
                        if (ReturnCode.isSuccess(session.returnCode) && sped.length() > 100) {
                            input = sped
                        }
                    }
                }
                out.add(PreparedSeg(cue, input, startMs))
            } catch (_: Throwable) {
                // skip broken segment
            }
            onEach(idx + 1, segs.size)
            if (idx % 40 == 0) System.gc()
        }
        return out
    }

    private fun atempoChain(speed: Double): String {
        var s = speed
        val parts = mutableListOf<String>()
        while (s > 2.0 + 1e-6) {
            parts += "atempo=2.0"
            s /= 2.0
        }
        if (s < 0.5) s = 0.5
        parts += "atempo=${"%.4f".format(s)}"
        return parts.joinToString(",")
    }

    /**
     * Mix speech clips in small waves, then pairwise-reduce wave files.
     * Avoids one giant amix (which froze at "54 of 54") and full-duration padding.
     */
    private fun mixBatched(
        segs: List<PreparedSeg>,
        durationMs: Long,
        workDir: File,
        onProgress: (fraction: Float, message: String) -> Unit
    ): File {
        if (segs.isEmpty()) error("هیچ صدایی برای میکس ساخته نشد")

        val durationSec = (durationMs / 1000.0).coerceAtLeast(1.0)
        val waves = segs.chunked(MIX_BATCH)
        val waveFiles = ArrayList<File>()

        waves.forEachIndexed { wi, batch ->
            val waveOut = File(workDir, "wave_%03d.m4a".format(wi))
            val ok = mixClipsWithDelay(batch, waveOut)
            if (ok) waveFiles.add(waveOut)
            val frac = (wi + 1).toFloat() / waves.size.coerceAtLeast(1)
            onProgress(frac * 0.70f, "میکس موج ${wi + 1} از ${waves.size}")
            if (wi % 5 == 0) System.gc()
        }

        if (waveFiles.isEmpty()) error("میکس صدا ناموفق بود")

        // Pairwise reduce so we never amix 50+ full tracks at once
        var level = 0
        var current = ArrayList(waveFiles)
        while (current.size > 1) {
            val next = ArrayList<File>()
            var i = 0
            val pairs = (current.size + 1) / 2
            var pairIdx = 0
            while (i < current.size) {
                if (i == current.size - 1) {
                    next.add(current[i])
                    i++
                } else {
                    val out = File(workDir, "reduce_L${level}_%03d.m4a".format(pairIdx))
                    val a = current[i]
                    val b = current[i + 1]
                    val merged = amixTwo(a, b, out, durationSec)
                    next.add(if (merged) out else a)
                    i += 2
                    pairIdx++
                }
                onProgress(
                    0.70f + 0.25f * ((pairIdx).toFloat() / pairs.coerceAtLeast(1)).coerceAtMost(1f),
                    "ادغام نهایی ${pairIdx} / $pairs (مرحله ${level + 1})"
                )
            }
            // delete previous level files we no longer need (except if reused)
            if (level > 0) {
                current.forEach { f ->
                    if (f !in next) try { f.delete() } catch (_: Exception) {}
                }
            }
            current = next
            level++
            System.gc()
        }

        val track = current.first()
        // Ensure track is at least long enough (pad end with silence for mux stability)
        val padded = File(workDir, "dub_track.m4a")
        val padCmd =
            "-y -i \"${track.absolutePath}\" -af \"apad=whole_dur=$durationSec\" -t $durationSec -ac 1 -ar 24000 -c:a aac -b:a 128k \"${padded.absolutePath}\""
        val padSession = FFmpegKit.execute(padCmd)
        onProgress(0.97f, "آماده‌سازی ترک صدا...")
        return if (ReturnCode.isSuccess(padSession.returnCode) && padded.length() > 100) padded else track
    }

    /** Mix up to MIX_BATCH speech files with adelay (no full-length pad — much faster). */
    private fun mixClipsWithDelay(batch: List<PreparedSeg>, out: File): Boolean {
        if (batch.isEmpty()) return false
        if (batch.size == 1) {
            val seg = batch[0]
            val delay = seg.startMs.coerceAtLeast(0L)
            val cmd =
                "-y -i \"${seg.file.absolutePath}\" -af \"adelay=${delay}|${delay}\" -ac 1 -ar 24000 -c:a aac -b:a 128k \"${out.absolutePath}\""
            val session = FFmpegKit.execute(cmd)
            return ReturnCode.isSuccess(session.returnCode) && out.length() > 50
        }
        val inputs = StringBuilder()
        val fc = StringBuilder()
        batch.forEachIndexed { i, seg ->
            inputs.append("-i \"${seg.file.absolutePath}\" ")
            val delay = seg.startMs.coerceAtLeast(0L)
            fc.append("[$i:a]adelay=${delay}|${delay},asetpts=PTS-STARTPTS[a$i];")
        }
        fc.append(batch.indices.joinToString("") { "[a$it]" })
        fc.append("amix=inputs=${batch.size}:duration=longest:dropout_transition=0:normalize=0[aout]")
        val cmd = buildString {
            append("-y ")
            append(inputs)
            append("-filter_complex \"").append(fc).append("\" ")
            append("-map \"[aout]\" -ac 1 -ar 24000 -c:a aac -b:a 128k ")
            append("\"${out.absolutePath}\"")
        }
        val session = FFmpegKit.execute(cmd)
        return ReturnCode.isSuccess(session.returnCode) && out.length() > 50
    }

    private fun amixTwo(a: File, b: File, out: File, durationSec: Double): Boolean {
        val cmd = buildString {
            append("-y -i \"${a.absolutePath}\" -i \"${b.absolutePath}\" ")
            append("-filter_complex \"[0:a][1:a]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0[aout]\" ")
            append("-map \"[aout]\" -ac 1 -ar 24000 -c:a aac -b:a 128k ")
            append("\"${out.absolutePath}\"")
        }
        val session = FFmpegKit.execute(cmd)
        return ReturnCode.isSuccess(session.returnCode) && out.length() > 50
    }

    private fun writeSrt(cues: List<Cue>, file: File): File {
        val sb = StringBuilder()
        fun ts(ms: Long): String {
            val t = ms.coerceAtLeast(0L)
            val h = t / 3_600_000
            val m = (t % 3_600_000) / 60_000
            val s = (t % 60_000) / 1000
            val milli = t % 1000
            return "%02d:%02d:%02d,%03d".format(h, m, s, milli)
        }
        cues.forEachIndexed { i, c ->
            sb.append(i + 1).append('\n')
            sb.append(ts(c.start)).append(" --> ").append(ts(c.end)).append('\n')
            sb.append(c.text.replace('\n', ' ')).append("\n\n")
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    /**
     * Mix original film audio + Persian dub.
     * - constant originalVolume, or
     * - dynamic duck: original ~100% except during dialogue windows
     */
    private fun finalMux(
        video: File,
        dubTrack: File,
        durationMs: Long,
        options: Options,
        out: File,
        srtFile: File?,
        duckEnvelope: File?
    ) {
        val durationSec = (durationMs / 1000.0).coerceAtLeast(1.0)
        val dubVol = options.dubVolume.toDouble().coerceIn(0.05, 2.0)
        val hasOrig = options.keepOriginalAudio && videoHasAudio(video)
        val useDynamic = hasOrig && options.dynamicDuck && duckEnvelope != null && duckEnvelope.exists()
        val origVol = when {
            !hasOrig -> 0.0
            useDynamic -> 1.0
            else -> options.originalVolume.toDouble().coerceIn(0.0, 1.0)
        }

        val hasSrt = srtFile != null && srtFile.exists()
        val subArgs = if (hasSrt) " -i \"${srtFile!!.absolutePath}\" " else ""

        if (hasOrig && (origVol > 0.001 || useDynamic)) {
            val cmd = if (useDynamic) {
                // inputs: 0=video, 1=dub, 2=envelope, [3=srt?]
                val envIdx = 2
                val srtIdx = if (hasSrt) 3 else -1
                buildString {
                    append("-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\" ")
                    append("-i \"${duckEnvelope!!.absolutePath}\"")
                    append(subArgs)
                    append(" -filter_complex ")
                    // envelope is mono gain curve → stereo, multiply with original, mix with dub
                    append("\"[0:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[oa];")
                    append("[$envIdx:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo[env];")
                    append("[oa][env]amultiply[orig];")
                    append("[1:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,volume=${"%.3f".format(dubVol)}[dub];")
                    append("[orig][dub]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[aout]\" ")
                    append("-map 0:v:0 -map \"[aout]\" ")
                    if (srtIdx >= 0) append("-map $srtIdx:0 -c:s mov_text ")
                    append("-c:v copy -c:a aac -b:a 192k -t $durationSec ")
                    append("\"${out.absolutePath}\"")
                }
            } else {
                buildString {
                    append("-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\"")
                    append(subArgs)
                    append(" -filter_complex ")
                    append("\"[0:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,volume=${"%.3f".format(origVol)}[orig];")
                    append("[1:a]aformat=sample_fmts=fltp:sample_rates=44100:channel_layouts=stereo,volume=${"%.3f".format(dubVol)}[dub];")
                    append("[orig][dub]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[aout]\" ")
                    append("-map 0:v:0 -map \"[aout]\" ")
                    if (hasSrt) append("-map 2:0 -c:s mov_text ")
                    append("-c:v copy -c:a aac -b:a 192k -t $durationSec ")
                    append("\"${out.absolutePath}\"")
                }
            }
            val session = FFmpegKit.execute(cmd)
            if (ReturnCode.isSuccess(session.returnCode) && out.length() > 1000) return
            out.delete()

            // Fallback without aformat / amultiply
            if (useDynamic) {
                // constant duck as last resort for dynamic mode
                val duck = options.dialogueDuckLevel.toDouble().coerceIn(0.05, 0.8)
                val cmdFb = buildString {
                    append("-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\"")
                    append(subArgs)
                    append(" -filter_complex ")
                    append("\"[0:a]volume=${"%.3f".format(duck)}[orig];[1:a]volume=${"%.3f".format(dubVol)}[dub];")
                    append("[orig][dub]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[aout]\" ")
                    append("-map 0:v:0 -map \"[aout]\" ")
                    if (hasSrt) append("-map 2:0 -c:s mov_text ")
                    append("-c:v copy -c:a aac -b:a 192k -t $durationSec ")
                    append("\"${out.absolutePath}\"")
                }
                val sf = FFmpegKit.execute(cmdFb)
                if (ReturnCode.isSuccess(sf.returnCode) && out.length() > 1000) return
                out.delete()
            } else {
                val cmd2 = buildString {
                    append("-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\"")
                    append(subArgs)
                    append(" -filter_complex ")
                    append("\"[0:a]volume=${"%.3f".format(origVol)}[orig];[1:a]volume=${"%.3f".format(dubVol)}[dub];")
                    append("[orig][dub]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[aout]\" ")
                    append("-map 0:v:0 -map \"[aout]\" ")
                    if (hasSrt) append("-map 2:0 -c:s mov_text ")
                    append("-c:v copy -c:a aac -b:a 192k -t $durationSec ")
                    append("\"${out.absolutePath}\"")
                }
                val s2 = FFmpegKit.execute(cmd2)
                if (ReturnCode.isSuccess(s2.returnCode) && out.length() > 1000) return
                out.delete()
            }
        }

        // Dub-only path
        val cmdReplace = buildString {
            append("-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\"")
            append(subArgs)
            append(" -filter_complex \"[1:a]volume=${"%.3f".format(dubVol)}[dub]\" ")
            append("-map 0:v:0 -map \"[dub]\" ")
            if (hasSrt) append("-map 2:0 -c:s mov_text ")
            append("-c:v copy -c:a aac -b:a 192k -t $durationSec ")
            append("\"${out.absolutePath}\"")
        }
        val session = FFmpegKit.execute(cmdReplace)
        if (!ReturnCode.isSuccess(session.returnCode) || out.length() < 1000) {
            error(
                "Mux ناموفق: " + (session.output?.take(280) ?: session.failStackTrace?.take(280) ?: "unknown")
            )
        }
    }

    /**
     * Mono 16-bit WAV gain envelope at 50 Hz:
     * 1.0 outside dialogue, [duckLevel] inside each cue window (with sync offset).
     */
    private fun writeDuckEnvelope(
        cues: List<Cue>,
        durationMs: Long,
        syncOffsetMs: Long,
        duckLevel: Float,
        outFile: File
    ): File {
        val sampleRate = 50 // enough for dialogue windows; tiny file
        val totalSamples = ((durationMs / 1000.0) * sampleRate).toInt().coerceAtLeast(sampleRate)
        val duck = duckLevel.coerceIn(0.05f, 0.9f)
        val gains = FloatArray(totalSamples) { 1f }

        for (cue in cues) {
            val startMs = (cue.start - syncOffsetMs).coerceAtLeast(0L)
            val endMs = (cue.end - syncOffsetMs + 200L).coerceAtLeast(startMs + 100L)
            var i0 = ((startMs / 1000.0) * sampleRate).toInt().coerceIn(0, totalSamples - 1)
            var i1 = ((endMs / 1000.0) * sampleRate).toInt().coerceIn(0, totalSamples)
            // short linear ramps (~120ms) to avoid clicks
            val ramp = ((0.12 * sampleRate).toInt()).coerceAtLeast(1)
            for (i in i0 until i1) {
                gains[i] = minOf(gains[i], duck)
            }
            val rampStart = (i0 - ramp).coerceAtLeast(0)
            for (i in rampStart until i0) {
                val t = (i - rampStart + 1).toFloat() / (i0 - rampStart + 1)
                val g = 1f + (duck - 1f) * t
                gains[i] = minOf(gains[i], g)
            }
            val rampEnd = (i1 + ramp).coerceAtMost(totalSamples)
            for (i in i1 until rampEnd) {
                val t = (i - i1 + 1).toFloat() / (rampEnd - i1 + 1)
                val g = duck + (1f - duck) * t
                gains[i] = minOf(gains[i], g)
            }
        }

        // Write PCM16 mono WAV
        val dataSize = totalSamples * 2
        val out = java.io.DataOutputStream(java.io.BufferedOutputStream(FileOutputStream(outFile)))
        fun writeStr(s: String) = s.forEach { out.write(it.code) }
        fun writeIntLE(v: Int) {
            out.write(v and 0xff); out.write(v shr 8 and 0xff)
            out.write(v shr 16 and 0xff); out.write(v shr 24 and 0xff)
        }
        fun writeShortLE(v: Int) {
            out.write(v and 0xff); out.write(v shr 8 and 0xff)
        }
        writeStr("RIFF"); writeIntLE(36 + dataSize); writeStr("WAVE")
        writeStr("fmt "); writeIntLE(16); writeShortLE(1); writeShortLE(1)
        writeIntLE(sampleRate); writeIntLE(sampleRate * 2); writeShortLE(2); writeShortLE(16)
        writeStr("data"); writeIntLE(dataSize)
        for (g in gains) {
            val s = (g.coerceIn(0f, 1f) * 32767f).toInt().coerceIn(-32768, 32767)
            writeShortLE(s)
        }
        out.flush(); out.close()
        return outFile
    }

    private fun videoHasAudio(video: File): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(video.absolutePath)
            val has = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            has == null || has == "yes" || has == "true"
        } catch (_: Exception) {
            true // assume yes; mix will fail soft to dub-only
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun ensureFfmpegReady() {
        try {
            // Force native load early with a clear error if .so is missing
            val ver = FFmpegKitConfig.getVersion()
            if (ver.isNullOrBlank()) {
                error("موتور FFmpeg بارگذاری نشد")
            }
            val probe = FFmpegKit.execute("-version")
            if (!ReturnCode.isSuccess(probe.returnCode) && !ReturnCode.isCancel(probe.returnCode)) {
                // some builds still return non-zero for -version; only fail on link errors
                val out = (probe.output ?: "") + (probe.failStackTrace ?: "")
                if (out.contains("UnsatisfiedLinkError", true) || out.contains("dlopen", true)) {
                    error("کتابخانه بومی FFmpeg روی این گوشی اجرا نشد")
                }
            }
        } catch (t: Throwable) {
            val msg = fullError(t)
            throw IllegalStateException(
                "موتور ساخت ویدیو آماده نشد. $msg — اپ را پاک کنید و دوباره نصب کنید. اگر ادامه داشت، گوشی/ABI پشتیبانی نمی‌شود.",
                t
            )
        }
    }

    private fun fullError(t: Throwable): String {
        val parts = ArrayList<String>(4)
        var c: Throwable? = t
        var i = 0
        while (c != null && i < 5) {
            val m = c.message?.trim().orEmpty()
            if (m.isNotEmpty()) parts.add(m) else parts.add(c.javaClass.simpleName)
            c = c.cause
            i++
        }
        return parts.distinct().joinToString(" | ").take(280)
    }

    private fun copyUriToFile(uri: Uri, dest: File): File {
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { output -> input.copyTo(output) }
        } ?: error("باز کردن ویدئو ممکن نشد")
        if (dest.length() < 1000) error("فایل ویدئو نامعتبر است")
        return dest
    }

    private fun probeDurationMs(file: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun audioDurationMs(file: File): Long? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun publishToMovies(src: File, videoName: String): Result {
        val base = videoName.substringBeforeLast('.').ifBlank { "DUBFA" }
            .replace(Regex("""[^\w\u0600-\u06FF\- ]+"""), "_")
            .take(40)
        val display = "${base}_dubbed.mp4"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, display)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DUBFA")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("ذخیره در گالری ممکن نشد")
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(src).use { it.copyTo(out) }
            } ?: error("نوشتن فایل خروجی ممکن نشد")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)

            val local = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), display)
            src.copyTo(local, overwrite = true)
            return Result(local, display)
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val dubfa = File(dir, "DUBFA").apply { mkdirs() }
            val dest = File(dubfa, display)
            src.copyTo(dest, overwrite = true)
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DATA, dest.absolutePath)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            }
            context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            return Result(dest, display)
        }
    }
}
