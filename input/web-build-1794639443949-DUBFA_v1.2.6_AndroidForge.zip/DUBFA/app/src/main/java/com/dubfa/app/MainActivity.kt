package com.dubfa.app

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.dubfa.app.engine.DubEngine
import com.dubfa.app.tts.EdgeTtsClient
import com.dubfa.app.tts.TtsRepository
import com.dubfa.app.ui.DubfaApp
import com.dubfa.app.ui.DubfaTheme
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {

    private lateinit var http: OkHttpClient
    private lateinit var repo: TtsRepository
    private lateinit var engine: DubEngine

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        http = OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(40, TimeUnit.SECONDS)
            .writeTimeout(15, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
        repo = TtsRepository(cacheDir, EdgeTtsClient(http))
        engine = DubEngine(repo, getSharedPreferences("dubfa", MODE_PRIVATE))

        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContent {
            DubfaTheme {
                DubfaApp(engine = engine, onFullscreenChange = ::setFullscreenMode)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        engine.onHostStopped()
    }

    override fun onDestroy() {
        engine.release()
        repo.shutdown()
        try {
            http.dispatcher.executorService.shutdown()
            http.connectionPool.evictAll()
        } catch (_: Exception) {
        }
        super.onDestroy()
    }

    private fun setFullscreenMode(enabled: Boolean) {
        try {
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            if (enabled) {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                WindowCompat.setDecorFitsSystemWindows(window, false)
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.setDecorFitsSystemWindows(window, true)
                controller.show(WindowInsetsCompat.Type.systemBars())
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
        } catch (_: Exception) {
        }
    }
}
