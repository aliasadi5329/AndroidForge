package com.dubfa.app.export

import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.FFmpegKitConfig
import com.arthenica.ffmpegkit.ReturnCode
import com.dubfa.app.subtitle.Cue
import com.dubfa.app.tts.TtsRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs

/**
 * Offline dubbed MP4 exporter.
 * Designed to survive long movies (hundreds/thousands of cues) without OOM:
 * - TTS in small batches
 * - speed adjust only when needed
 * - audio mixed in waves of ~20 clips, then final mux with video
 */
class DubExporter(
    private val context: Context,
    private val repo: TtsRepository
) {
    data class Progress(val fraction: Float, val message: String)
    data class Result(val file: File, val displayName: String)

    data class Options(
        val voice: String,
        val syncOffsetMs: Long,
        val fitSpeed: Boolean,
        val maxSpeed: Float,
        val duckEnabled: Boolean,
        val duckLevel: Float,
        /** Keep music / ambient from original film (recommended true). */
        val keepOriginalAudio: Boolean = true,
        /** Volume of original film audio 0..1 when NOT using dynamic duck. */
        val originalVolume: Float = 0.28f,
        /** Volume of Persian dub track 0..1 */
        val dubVolume: Float = 1.0f,
        /**
         * If true: original stays ~100% except during each dialogue window,
         * where it drops to [dialogueDuckLevel] so dub is clear (auto-duck).
         */
        val dynamicDuck: Boolean = false,
        /** Original volume during dialogue when dynamicDuck is on (0..1). */
        val dialogueDuckLevel: Float = 0.18f,
        /** Embed soft SRT subtitle track in the MP4 (players can show/hide). */
        val embedSubtitles: Boolean = false,
        val smartVoice: Boolean = false,
        val speakerIsFemale: Map<String, Boolean> = emptyMap()
    )

    companion object {
        /** Hard safety cap — beyond this, export first N only (avoids native crash). */
        private const val MAX_CUES = 800
        private const val TTS_BATCH = 3
        private const val MIX_BATCH = 15
    }

    suspend fun export(
        videoUri: Uri,
        videoName: String,
        cuesIn: List<Cue>,
        options: Options,
        onProgress: (Progress) -> Unit
    ): Result = withContext(Dispatchers.IO) {
        require(cuesIn.isNotEmpty()) { "زیرنویس خالی است" }

        val workDir = File(context.cacheDir, "dub_export_${System.currentTimeMillis()}").apply {
            if (exists()) deleteRecursively()
            mkdirs()
        }

        try {
            onProgress(Progress(0.01f, "آماده‌سازی موتور ویدیو..."))
            ensureFfmpegReady()

            onProgress(Progress(0.02f, "کپی ویدئو..."))
            val videoFile = copyUriToFile(videoUri, File(workDir, "input.mp4"))
            // IMPORTANT: use the actual video length, NOT the full subtitle timeline
            val durationMs = probeDurationMs(videoFile).coerceAtLeast(1000L)

            // Only dialogues that fall inside this video clip (plus small margin / sync)
            val marginMs = 2_000L + kotlin.math.abs(options.syncOffsetMs)
            val inRange = cuesIn.filter { cue ->
                cue.start < durationMs + marginMs && cue.end > -marginMs
            }
            val cues = if (inRange.size > MAX_CUES) {
                onProgress(
                    Progress(
                        0.03f,
                        "دیالوگ‌های داخل این تکه زیاد است؛ $MAX_CUES مورد اول استفاده می‌شود"
                    )
                )
                inRange.take(MAX_CUES)
            } else inRange

            require(cues.isNotEmpty()) {
                "در این تکه فیلم هیچ دیالوگی از زیرنویس پیدا نشد. زیرنویس باید با زمان همین فایل هم‌خوان باشد."
            }
            onProgress(
                Progress(
                    0.04f,
                    "از ${cuesIn.size} دیالوگ کل، ${cues.size} مورد داخل این ${durationMs / 1000}ثانیه انتخاب شد"
                )
            )

            onProgress(Progress(0.05f, "تولید صدا (${cues.size} دیالوگ)..."))
            val raw = generateSegments(cues, options, workDir) { done, total ->
                val p = 0.05f + 0.45f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "ساخت صدا $done از $total"))
            }

            onProgress(Progress(0.52f, "تنظیم سرعت..."))
            val prepared = prepareSegments(raw, options, workDir) { done, total ->
                val p = 0.52f + 0.15f * (done.toFloat() / total.coerceAtLeast(1))
                onProgress(Progress(p, "پردازش صدا $done از $total"))
            }
            // free raw refs
            raw.clear()
            System.gc()

            onProgress(Progress(0.68f, "میکس صدا..."))
            val dubTrack = mixBatched(prepared, durationMs, workDir) { frac, msg ->
                onProgress(Progress(0.68f + 0.20f * frac.coerceIn(0f, 1f), msg))
            }

            onProgress(Progress(0.88f, "ساخت MP4 نهایی..."))
            val outFile = File(workDir, "dubbed_output.mp4")
            val srtFile = if (options.embedSubtitles) {
                writeSrt(cues, File(workDir, "export.srt"))
            } else null
            // Cues are already shifted to the clip timeline; used for dynamic-duck enable=between
            exportCuesForDuck = cues
            lastMuxWarning = null
            try {
                finalMux(videoFile, dubTrack, durationMs, options, outFile, srtFile, null)
            } finally {
                exportCuesForDuck = null
            }
            onProgress(Progress(0.95f, lastMuxWarning ?: "Mux تمام شد"))

            if (!outFile.exists() || outFile.length() < 1000L) {
                error("ساخت فایل خروجی ناموفق بود")
            }

            onProgress(Progress(0.96f, "ذخیره در گالری..."))
            val saved = publishToMovies(outFile, videoName)
            val doneMsg = buildString {
                append("تمام شد: ${saved.displayName}")
                lastMuxWarning?.let { append(" — ").append(it) }
            }
            onProgress(Progress(1f, doneMsg))
            saved
        } finally {
            try {
                workDir.deleteRecursively()
            } catch (_: Exception) {
            }
        }
    }

    private data class RawSeg(val cue: Cue, val file: File)
    private data class PreparedSeg(val cue: Cue, val file: File, val startMs: Long)

    private suspend fun generateSegments(
        cues: List<Cue>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): MutableList<RawSeg> = coroutineScope {
        val total = cues.size
        val done = AtomicInteger(0)
        val result = arrayOfNulls<RawSeg>(total)
        var i = 0
        while (i < total) {
            val end = minOf(total, i + TTS_BATCH)
            val jobs = (i until end).map { idx ->
                async {
                    val cue = cues[idx]
                    val lineVoice = com.dubfa.app.tts.VoiceRouter.voiceFor(
                        cue, options.smartVoice, options.voice, options.speakerIsFemale
                    )
                    val future = repo.request(cue.text, lineVoice, urgent = true)
                    val file = suspendCancellableCoroutine<File> { cont ->
                        future.whenComplete { f, err ->
                            if (err != null || f == null) {
                                cont.resumeWithException(err ?: IllegalStateException("TTS failed"))
                            } else cont.resume(f)
                        }
                    }
                    val local = File(workDir, "tts_%04d.mp3".format(idx))
                    file.copyTo(local, overwrite = true)
                    result[idx] = RawSeg(cue, local)
                    onEach(done.incrementAndGet(), total)
                }
            }
            // Fail-soft: one bad line shouldn't kill entire export
            jobs.forEach { job ->
                try {
                    job.await()
                } catch (_: Exception) {
                    onEach(done.incrementAndGet(), total)
                }
            }
            i = end
        }
        result.filterNotNull().toMutableList()
    }

    private fun prepareSegments(
        segs: List<RawSeg>,
        options: Options,
        workDir: File,
        onEach: (done: Int, total: Int) -> Unit
    ): List<PreparedSeg> {
        val out = ArrayList<PreparedSeg>(segs.size)
        segs.forEachIndexed { idx, seg ->
            try {
                val cue = seg.cue
                val startMs = (cue.start - options.syncOffsetMs).coerceAtLeast(0L)
                val windowMs = (cue.end - cue.start + 200L).coerceAtLeast(300L)
                val durationMs = audioDurationMs(seg.file) ?: windowMs
                var input = seg.file

                if (options.fitSpeed && durationMs > windowMs) {
                    val speed = (durationMs.toDouble() / windowMs)
                        .coerceIn(1.0, options.maxSpeed.toDouble().coerceAtLeast(1.0))
                    if (abs(speed - 1.0) > 0.03) {
                        val sped = File(workDir, "spd_%04d.mp3".format(idx))
                        val filter = atempoChain(speed)
                        val cmd =
                            "-y -i \"${input.absolutePath}\" -filter:a \"$filter\" -vn -ac 1 -ar 24000 \"${sped.absolutePath}\""
                        val session = FFmpegKit.execute(cmd)
                        if (ReturnCode.isSuccess(session.returnCode) && sped.length() > 100) {
                            input = sped
                        }
                    }
                }
                out.add(PreparedSeg(cue, input, startMs))
            } catch (_: Throwable) {
                // skip broken segment
            }
            onEach(idx + 1, segs.size)
            if (idx % 40 == 0) System.gc()
        }
        return out
    }

    private fun atempoChain(speed: Double): String {
        var s = speed
        val parts = mutableListOf<String>()
        while (s > 2.0 + 1e-6) {
            parts += "atempo=2.0"
            s /= 2.0
        }
        if (s < 0.5) s = 0.5
        parts += "atempo=${"%.4f".format(s)}"
        return parts.joinToString(",")
    }

    /**
     * Mix speech clips in small waves, then pairwise-reduce wave files.
     * Avoids one giant amix (which froze at "54 of 54") and full-duration padding.
     */
    private fun mixBatched(
        segs: List<PreparedSeg>,
        durationMs: Long,
        workDir: File,
        onProgress: (fraction: Float, message: String) -> Unit
    ): File {
        if (segs.isEmpty()) error("هیچ صدایی برای میکس ساخته نشد")

        val durationSec = (durationMs / 1000.0).coerceAtLeast(1.0)
        val waves = segs.chunked(MIX_BATCH)
        val waveFiles = ArrayList<File>()

        waves.forEachIndexed { wi, batch ->
            val waveOut = File(workDir, "wave_%03d.m4a".format(wi))
            val ok = mixClipsWithDelay(batch, waveOut)
            if (ok) waveFiles.add(waveOut)
            val frac = (wi + 1).toFloat() / waves.size.coerceAtLeast(1)
            onProgress(frac * 0.70f, "میکس موج ${wi + 1} از ${waves.size}")
            if (wi % 5 == 0) System.gc()
        }

        if (waveFiles.isEmpty()) error("میکس صدا ناموفق بود")

        // Pairwise reduce so we never amix 50+ full tracks at once
        var level = 0
        var current = ArrayList(waveFiles)
        while (current.size > 1) {
            val next = ArrayList<File>()
            var i = 0
            val pairs = (current.size + 1) / 2
            var pairIdx = 0
            while (i < current.size) {
                if (i == current.size - 1) {
                    next.add(current[i])
                    i++
                } else {
                    val out = File(workDir, "reduce_L${level}_%03d.m4a".format(pairIdx))
                    val a = current[i]
                    val b = current[i + 1]
                    val merged = amixTwo(a, b, out, durationSec)
                    next.add(if (merged) out else a)
                    i += 2
                    pairIdx++
                }
                onProgress(
                    0.70f + 0.25f * ((pairIdx).toFloat() / pairs.coerceAtLeast(1)).coerceAtMost(1f),
                    "ادغام نهایی ${pairIdx} / $pairs (مرحله ${level + 1})"
                )
            }
            // delete previous level files we no longer need (except if reused)
            if (level > 0) {
                current.forEach { f ->
                    if (f !in next) try { f.delete() } catch (_: Exception) {}
                }
            }
            current = next
            level++
            System.gc()
        }

        val track = current.first()
        // Ensure track is at least long enough (pad end with silence for mux stability)
        val padded = File(workDir, "dub_track.m4a")
        val padCmd =
            "-y -i \"${track.absolutePath}\" -af \"apad=whole_dur=$durationSec\" -t $durationSec -ac 1 -ar 24000 -c:a aac -b:a 128k \"${padded.absolutePath}\""
        val padSession = FFmpegKit.execute(padCmd)
        onProgress(0.97f, "آماده‌سازی ترک صدا...")
        return if (ReturnCode.isSuccess(padSession.returnCode) && padded.length() > 100) padded else track
    }

    /** Mix up to MIX_BATCH speech files with adelay (no full-length pad — much faster). */
    private fun mixClipsWithDelay(batch: List<PreparedSeg>, out: File): Boolean {
        if (batch.isEmpty()) return false
        if (batch.size == 1) {
            val seg = batch[0]
            val delay = seg.startMs.coerceAtLeast(0L)
            val cmd =
                "-y -i \"${seg.file.absolutePath}\" -af \"adelay=${delay}|${delay}\" -ac 1 -ar 24000 -c:a aac -b:a 128k \"${out.absolutePath}\""
            val session = FFmpegKit.execute(cmd)
            return ReturnCode.isSuccess(session.returnCode) && out.length() > 50
        }
        val inputs = StringBuilder()
        val fc = StringBuilder()
        batch.forEachIndexed { i, seg ->
            inputs.append("-i \"${seg.file.absolutePath}\" ")
            val delay = seg.startMs.coerceAtLeast(0L)
            fc.append("[$i:a]adelay=${delay}|${delay},asetpts=PTS-STARTPTS[a$i];")
        }
        fc.append(batch.indices.joinToString("") { "[a$it]" })
        fc.append("amix=inputs=${batch.size}:duration=longest:dropout_transition=0:normalize=0[aout]")
        val cmd = buildString {
            append("-y ")
            append(inputs)
            append("-filter_complex \"").append(fc).append("\" ")
            append("-map \"[aout]\" -ac 1 -ar 24000 -c:a aac -b:a 128k ")
            append("\"${out.absolutePath}\"")
        }
        val session = FFmpegKit.execute(cmd)
        return ReturnCode.isSuccess(session.returnCode) && out.length() > 50
    }

    private fun amixTwo(a: File, b: File, out: File, durationSec: Double): Boolean {
        val cmd = buildString {
            append("-y -i \"${a.absolutePath}\" -i \"${b.absolutePath}\" ")
            append("-filter_complex \"[0:a][1:a]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0[aout]\" ")
            append("-map \"[aout]\" -ac 1 -ar 24000 -c:a aac -b:a 128k ")
            append("\"${out.absolutePath}\"")
        }
        val session = FFmpegKit.execute(cmd)
        return ReturnCode.isSuccess(session.returnCode) && out.length() > 50
    }

    private fun writeSrt(cues: List<Cue>, file: File): File {
        val sb = StringBuilder()
        fun ts(ms: Long): String {
            val t = ms.coerceAtLeast(0L)
            val h = t / 3_600_000
            val m = (t % 3_600_000) / 60_000
            val s = (t % 60_000) / 1000
            val milli = t % 1000
            return "%02d:%02d:%02d,%03d".format(h, m, s, milli)
        }
        cues.forEachIndexed { i, c ->
            sb.append(i + 1).append('\n')
            sb.append(ts(c.start)).append(" --> ").append(ts(c.end)).append('\n')
            sb.append(c.text.replace('\n', ' ')).append("\n\n")
        }
        file.writeText(sb.toString(), Charsets.UTF_8)
        return file
    }

    /**
     * Reliable 3-step mux:
     * 1) extract original audio from video
     * 2) mix original + dub → one AAC track
     * 3) attach that track to video (copy video stream)
     * Soft-subs are optional after that.
     */
    private fun finalMux(
        video: File,
        dubTrack: File,
        durationMs: Long,
        options: Options,
        out: File,
        srtFile: File?,
        duckEnvelope: File?
    ) {
        val durationSec = (durationMs / 1000.0).coerceAtLeast(1.0)
        val dubVol = options.dubVolume.toDouble().coerceIn(0.05, 2.0)
        val wantOrig = options.keepOriginalAudio
        val wantDynamic = wantOrig && options.dynamicDuck
        val duckLvl = options.dialogueDuckLevel.toDouble().coerceIn(0.05, 0.8)
        val constOrig = options.originalVolume.toDouble().coerceIn(0.05, 1.0)
        val work = out.parentFile ?: context.cacheDir
        val origAudio = File(work, "orig_audio.m4a")
        val mixedAudio = File(work, "mixed_audio.m4a")
        origAudio.delete(); mixedAudio.delete(); out.delete()

        var usedOriginal = false
        var lastErr = ""

        if (wantOrig) {
            // --- 1) Extract original soundtrack ---
            val extractOk = runExtractOriginal(video, origAudio, durationSec)
            if (extractOk) {
                // --- 2) Mix original + dub ---
                val enableExpr = if (wantDynamic) buildDuckEnableExpr(durationSec) else null
                val origFilter = when {
                    wantDynamic && !enableExpr.isNullOrBlank() ->
                        "volume=${"%.3f".format(duckLvl)}:enable='$enableExpr'"
                    wantDynamic ->
                        "volume=${"%.3f".format(duckLvl)}"
                    else ->
                        "volume=${"%.3f".format(constOrig)}"
                }
                val mixOk = runMixAudio(origAudio, dubTrack, mixedAudio, durationSec, origFilter, dubVol)
                if (mixOk) {
                    // --- 3) Mux video + mixed audio ---
                    if (runAttachAudio(video, mixedAudio, out, durationSec)) {
                        usedOriginal = true
                    } else {
                        lastErr = "چسباندن صدای میکس‌شده به ویدیو ناموفق بود"
                    }
                } else {
                    lastErr = "میکس صدای اصلی با دوبله ناموفق بود"
                }
            } else {
                lastErr = "استخراج صدای اصلی از ویدیو ناموفق بود (ممکن است فایل صدا نداشته باشد)"
            }
        }

        // Fallback: dub-only (only if original path failed or user disabled it)
        if (!out.exists() || out.length() < 1000) {
            out.delete()
            val dubOnly = listOf(
                "-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\" " +
                    "-filter_complex \"[1:a]volume=${"%.3f".format(dubVol)},aformat=sample_rates=44100:channel_layouts=stereo[aout]\" " +
                    "-map 0:v:0 -map \"[aout]\" -c:v copy -c:a aac -b:a 192k -t $durationSec \"${out.absolutePath}\"",
                "-y -i \"${video.absolutePath}\" -i \"${dubTrack.absolutePath}\" " +
                    "-map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -shortest -t $durationSec \"${out.absolutePath}\""
            )
            for (cmd in dubOnly) {
                out.delete()
                val s = FFmpegKit.execute(cmd)
                if (ReturnCode.isSuccess(s.returnCode) && out.length() > 1000) break
                lastErr = cleanFfmpegError(s)
            }
            if (!out.exists() || out.length() < 1000) {
                error("Mux ناموفق: $lastErr")
            }
            if (wantOrig && !usedOriginal) {
                // Still succeed, but mark clearly in message path via exception? 
                // Don't fail — user gets file; UI progress already past this.
            }
        }

        // Soft-subs optional
        val srt = srtFile
        if (srt != null && srt.exists()) {
            val withSubs = File(work, "dubbed_with_subs.mp4")
            val subCmd =
                "-y -i \"${out.absolutePath}\" -i \"${srt.absolutePath}\" " +
                    "-map 0 -map 1 -c copy -c:s mov_text -t $durationSec \"${withSubs.absolutePath}\""
            val s = FFmpegKit.execute(subCmd)
            if (ReturnCode.isSuccess(s.returnCode) && withSubs.length() > 1000) {
                withSubs.copyTo(out, overwrite = true)
            }
            withSubs.delete()
        }

        lastMuxWarning = if (wantOrig && !usedOriginal) {
            "هشدار: صدای اصلی فیلم به خروجی اضافه نشد (${lastErr.ifBlank { "استخراج ناموفق" }}). فقط دوبله ذخیره شد."
        } else null
    }

    @Volatile private var lastMuxWarning: String? = null

    private fun runExtractOriginal(video: File, dest: File, durationSec: Double): Boolean {
        dest.delete()
        val cmds = listOf(
            // Prefer re-encode to AAC stereo (most compatible for later amix)
            "-y -i \"${video.absolutePath}\" -vn -sn -ac 2 -ar 44100 -c:a aac -b:a 192k -t $durationSec \"${dest.absolutePath}\"",
            "-y -i \"${video.absolutePath}\" -map 0:a:0 -vn -sn -ac 2 -ar 44100 -c:a aac -b:a 192k -t $durationSec \"${dest.absolutePath}\"",
            // WAV fallback
            "-y -i \"${video.absolutePath}\" -vn -sn -ac 2 -ar 44100 -c:a pcm_s16le -t $durationSec \"${dest.absolutePath.removeSuffix(".m4a")}.wav\""
        )
        for (cmd in cmds) {
            dest.delete()
            val wav = File(dest.absolutePath.removeSuffix(".m4a") + ".wav")
            wav.delete()
            val s = FFmpegKit.execute(cmd)
            val outFile = if (cmd.endsWith(".wav\"")) wav else dest
            if (ReturnCode.isSuccess(s.returnCode) && outFile.exists() && outFile.length() > 500) {
                if (outFile != dest) {
                    // convert wav → m4a for consistent mixing
                    val c2 = FFmpegKit.execute(
                        "-y -i \"${outFile.absolutePath}\" -c:a aac -b:a 192k \"${dest.absolutePath}\""
                    )
                    outFile.delete()
                    if (ReturnCode.isSuccess(c2.returnCode) && dest.length() > 500) return true
                } else return true
            }
        }
        return false
    }

    private fun runMixAudio(
        orig: File,
        dub: File,
        dest: File,
        durationSec: Double,
        origFilter: String,
        dubVol: Double
    ): Boolean {
        dest.delete()
        val attempts = listOf(
            "-y -i \"${orig.absolutePath}\" -i \"${dub.absolutePath}\" " +
                "-filter_complex \"[0:a]$origFilter[o];[1:a]volume=${"%.3f".format(dubVol)}[d];" +
                "[o][d]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0[a]\" " +
                "-map \"[a]\" -ac 2 -ar 44100 -c:a aac -b:a 192k -t $durationSec \"${dest.absolutePath}\"",
            "-y -i \"${orig.absolutePath}\" -i \"${dub.absolutePath}\" " +
                "-filter_complex \"[0:a]volume=0.35[o];[1:a]volume=${"%.3f".format(dubVol)}[d];" +
                "[o][d]amix=inputs=2:duration=longest:dropout_transition=0:normalize=0[a]\" " +
                "-map \"[a]\" -ac 2 -ar 44100 -c:a aac -b:a 192k -t $durationSec \"${dest.absolutePath}\""
        )
        for (cmd in attempts) {
            dest.delete()
            val s = FFmpegKit.execute(cmd)
            if (ReturnCode.isSuccess(s.returnCode) && dest.length() > 500) return true
        }
        return false
    }

    private fun runAttachAudio(video: File, audio: File, out: File, durationSec: Double): Boolean {
        out.delete()
        val cmds = listOf(
            "-y -i \"${video.absolutePath}\" -i \"${audio.absolutePath}\" " +
                "-map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 192k -shortest -t $durationSec \"${out.absolutePath}\"",
            "-y -i \"${video.absolutePath}\" -i \"${audio.absolutePath}\" " +
                "-map 0:v:0 -map 1:a:0 -c:v copy -c:a copy -shortest -t $durationSec \"${out.absolutePath}\""
        )
        for (cmd in cmds) {
            out.delete()
            val s = FFmpegKit.execute(cmd)
            if (ReturnCode.isSuccess(s.returnCode) && out.length() > 1000) return true
        }
        return false
    }

    /** volume enable='between(t,a,b)+...' for cues already shifted to clip timeline. */
    private fun buildDuckEnableExpr(durationSec: Double): String? {
        // cues for export are the filtered list stored indirectly via writeDuckEnvelope call site —
        // we rebuild from the same file progress path: read from a field set during export
        val list = exportCuesForDuck ?: return null
        if (list.isEmpty()) return null
        val parts = ArrayList<String>()
        var len = 0
        for (c in list) {
            val s = (c.start / 1000.0).coerceAtLeast(0.0)
            val e = (c.end / 1000.0 + 0.25).coerceAtMost(durationSec + 1.0)
            if (e <= s) continue
            val piece = "between(t,${"%.3f".format(s)},${"%.3f".format(e)})"
            if (len + piece.length > 3500) break
            parts += piece
            len += piece.length + 1
        }
        if (parts.isEmpty()) return null
        return parts.joinToString("+")
    }

    @Volatile private var exportCuesForDuck: List<Cue>? = null

    private fun cleanFfmpegError(session: com.arthenica.ffmpegkit.Session): String {
        val raw = listOfNotNull(
            session.failStackTrace,
            session.allLogsAsString,
            session.output
        ).joinToString("\n")
        val lines = raw.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .filterNot {
                it.startsWith("ffmpeg version", ignoreCase = true) ||
                    it.startsWith("configuration:", ignoreCase = true) ||
                    it.startsWith("built with", ignoreCase = true) ||
                    it.startsWith("libav", ignoreCase = true) ||
                    it.contains("Copyright", ignoreCase = true)
            }
            .toList()
        val useful = lines.takeLast(12).joinToString(" | ")
        return useful.ifBlank { "کد=${session.returnCode}" }.take(320)
    }

    /**
     * Mono 16-bit WAV gain envelope at 50 Hz:
     * 1.0 outside dialogue, [duckLevel] inside each cue window (with sync offset).
     */
    private fun writeDuckEnvelope(
        cues: List<Cue>,
        durationMs: Long,
        syncOffsetMs: Long,
        duckLevel: Float,
        outFile: File
    ): File {
        val sampleRate = 50 // enough for dialogue windows; tiny file
        val totalSamples = ((durationMs / 1000.0) * sampleRate).toInt().coerceAtLeast(sampleRate)
        val duck = duckLevel.coerceIn(0.05f, 0.9f)
        val gains = FloatArray(totalSamples) { 1f }

        for (cue in cues) {
            val startMs = (cue.start - syncOffsetMs).coerceAtLeast(0L)
            val endMs = (cue.end - syncOffsetMs + 200L).coerceAtLeast(startMs + 100L)
            var i0 = ((startMs / 1000.0) * sampleRate).toInt().coerceIn(0, totalSamples - 1)
            var i1 = ((endMs / 1000.0) * sampleRate).toInt().coerceIn(0, totalSamples)
            // short linear ramps (~120ms) to avoid clicks
            val ramp = ((0.12 * sampleRate).toInt()).coerceAtLeast(1)
            for (i in i0 until i1) {
                gains[i] = minOf(gains[i], duck)
            }
            val rampStart = (i0 - ramp).coerceAtLeast(0)
            for (i in rampStart until i0) {
                val t = (i - rampStart + 1).toFloat() / (i0 - rampStart + 1)
                val g = 1f + (duck - 1f) * t
                gains[i] = minOf(gains[i], g)
            }
            val rampEnd = (i1 + ramp).coerceAtMost(totalSamples)
            for (i in i1 until rampEnd) {
                val t = (i - i1 + 1).toFloat() / (rampEnd - i1 + 1)
                val g = duck + (1f - duck) * t
                gains[i] = minOf(gains[i], g)
            }
        }

        // Write PCM16 mono WAV
        val dataSize = totalSamples * 2
        val out = java.io.DataOutputStream(java.io.BufferedOutputStream(FileOutputStream(outFile)))
        fun writeStr(s: String) = s.forEach { out.write(it.code) }
        fun writeIntLE(v: Int) {
            out.write(v and 0xff); out.write(v shr 8 and 0xff)
            out.write(v shr 16 and 0xff); out.write(v shr 24 and 0xff)
        }
        fun writeShortLE(v: Int) {
            out.write(v and 0xff); out.write(v shr 8 and 0xff)
        }
        writeStr("RIFF"); writeIntLE(36 + dataSize); writeStr("WAVE")
        writeStr("fmt "); writeIntLE(16); writeShortLE(1); writeShortLE(1)
        writeIntLE(sampleRate); writeIntLE(sampleRate * 2); writeShortLE(2); writeShortLE(16)
        writeStr("data"); writeIntLE(dataSize)
        for (g in gains) {
            val s = (g.coerceIn(0f, 1f) * 32767f).toInt().coerceIn(-32768, 32767)
            writeShortLE(s)
        }
        out.flush(); out.close()
        return outFile
    }

    private fun videoHasAudio(video: File): Boolean {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(video.absolutePath)
            val has = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO)
            has == null || has == "yes" || has == "true"
        } catch (_: Exception) {
            true // assume yes; mix will fail soft to dub-only
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun ensureFfmpegReady() {
        try {
            // Force native load early with a clear error if .so is missing
            val ver = FFmpegKitConfig.getVersion()
            if (ver.isNullOrBlank()) {
                error("موتور FFmpeg بارگذاری نشد")
            }
            val probe = FFmpegKit.execute("-version")
            if (!ReturnCode.isSuccess(probe.returnCode) && !ReturnCode.isCancel(probe.returnCode)) {
                // some builds still return non-zero for -version; only fail on link errors
                val out = (probe.output ?: "") + (probe.failStackTrace ?: "")
                if (out.contains("UnsatisfiedLinkError", true) || out.contains("dlopen", true)) {
                    error("کتابخانه بومی FFmpeg روی این گوشی اجرا نشد")
                }
            }
        } catch (t: Throwable) {
            val msg = fullError(t)
            throw IllegalStateException(
                "موتور ساخت ویدیو آماده نشد. $msg — اپ را پاک کنید و دوباره نصب کنید. اگر ادامه داشت، گوشی/ABI پشتیبانی نمی‌شود.",
                t
            )
        }
    }

    private fun fullError(t: Throwable): String {
        val parts = ArrayList<String>(4)
        var c: Throwable? = t
        var i = 0
        while (c != null && i < 5) {
            val m = c.message?.trim().orEmpty()
            if (m.isNotEmpty()) parts.add(m) else parts.add(c.javaClass.simpleName)
            c = c.cause
            i++
        }
        return parts.distinct().joinToString(" | ").take(280)
    }

    private fun copyUriToFile(uri: Uri, dest: File): File {
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(dest).use { output -> input.copyTo(output) }
        } ?: error("باز کردن ویدئو ممکن نشد")
        if (dest.length() < 1000) error("فایل ویدئو نامعتبر است")
        return dest
    }

    private fun probeDurationMs(file: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (_: Exception) {
            0L
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun audioDurationMs(file: File): Long? {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: Exception) {
            null
        } finally {
            try { r.release() } catch (_: Exception) {}
        }
    }

    private fun publishToMovies(src: File, videoName: String): Result {
        val base = videoName.substringBeforeLast('.').ifBlank { "DUBFA" }
            .replace(Regex("""[^\w\u0600-\u06FF\- ]+"""), "_")
            .take(40)
        val display = "${base}_dubbed.mp4"

        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, display)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DUBFA")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: error("ذخیره در گالری ممکن نشد")
            resolver.openOutputStream(uri)?.use { out ->
                FileInputStream(src).use { it.copyTo(out) }
            } ?: error("نوشتن فایل خروجی ممکن نشد")
            values.clear()
            values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)

            val local = File(context.getExternalFilesDir(Environment.DIRECTORY_MOVIES), display)
            src.copyTo(local, overwrite = true)
            return Result(local, display)
        } else {
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
            val dubfa = File(dir, "DUBFA").apply { mkdirs() }
            val dest = File(dubfa, display)
            src.copyTo(dest, overwrite = true)
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DATA, dest.absolutePath)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            }
            context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            return Result(dest, display)
        }
    }
}
