package com.dubfa.app.tts

import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException
import java.util.concurrent.ThreadFactory
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Disk cache + two queues: urgent (current dialogue) and prefetch.
 * Identical requests share one job; urgent requests can steal a queued prefetch job.
 */
class TtsRepository(cacheRoot: File, private val client: EdgeTtsClient) {

    private class Job(val future: CompletableFuture<File>, val started: AtomicBoolean = AtomicBoolean(false))

    private val dir = File(cacheRoot, "tts_edge").apply { if (!exists()) mkdirs() }
    private val urgentPool = Executors.newFixedThreadPool(2, named("tts-urgent"))
    private val prefetchPool = Executors.newFixedThreadPool(2, named("tts-prefetch"))
    private val inFlight = ConcurrentHashMap<String, Job>()
    private val whitespace = Regex("""\s+""")
    @Volatile private var closed = false

    companion object {
        private const val MAX_CACHE_BYTES = 150L * 1024 * 1024
        private const val MAX_CHARS = 800
    }

    init {
        submit(prefetchPool) { trimCache() }
    }

    fun request(text: String, voice: String, urgent: Boolean): CompletableFuture<File> {
        val cleaned = text.replace(whitespace, " ").trim()
        if (cleaned.isEmpty()) return failed(IllegalStateException("متن خالی"))
        if (closed) return failed(IllegalStateException("closed"))
        val key = sha1("$voice|$cleaned")
        val out = File(dir, "$key.mp3")
        if (out.length() > 100) {
            out.setLastModified(System.currentTimeMillis())
            return CompletableFuture.completedFuture(out)
        }
        val existing = inFlight[key]
        if (existing != null) {
            if (urgent && !existing.started.get()) schedule(existing, key, cleaned, voice, out, urgentPool)
            return existing.future
        }
        val job = Job(CompletableFuture())
        val raced = inFlight.putIfAbsent(key, job)
        if (raced != null) return raced.future
        schedule(job, key, cleaned, voice, out, if (urgent) urgentPool else prefetchPool)
        return job.future
    }

    fun prefetch(text: String, voice: String) {
        request(text, voice, urgent = false)
    }

    private fun schedule(job: Job, key: String, text: String, voice: String, out: File, pool: ExecutorService) {
        val ok = submit(pool) {
            if (!job.started.compareAndSet(false, true)) return@submit
            try {
                job.future.complete(synthesizeToFile(text.take(MAX_CHARS), voice, out))
            } catch (e: Throwable) {
                job.future.completeExceptionally(e)
            } finally {
                inFlight.remove(key, job)
            }
        }
        if (!ok && !job.started.get()) {
            inFlight.remove(key, job)
            job.future.completeExceptionally(IllegalStateException("صف TTS بسته است"))
        }
    }

    private fun synthesizeToFile(text: String, voice: String, out: File): File {
        var last: Exception? = null
        repeat(2) { attempt ->
            try {
                val audio = client.synthesize(text, voice)
                val tmp = File(dir, out.name + ".tmp")
                FileOutputStream(tmp).use { it.write(audio) }
                if (!tmp.renameTo(out)) {
                    tmp.copyTo(out, overwrite = true)
                    tmp.delete()
                }
                return out
            } catch (e: Exception) {
                last = e
                if (closed) throw e
                if (attempt == 0) Thread.sleep(400)
            }
        }
        throw last ?: IllegalStateException("TTS failed")
    }

    private fun trimCache() {
        try {
            val files = dir.listFiles() ?: return
            files.filter { it.name.endsWith(".tmp") }.forEach { it.delete() }
            val mp3 = files.filter { it.name.endsWith(".mp3") }.sortedBy { it.lastModified() }
            var total = mp3.sumOf { it.length() }
            for (f in mp3) {
                if (total <= MAX_CACHE_BYTES) break
                total -= f.length()
                f.delete()
            }
        } catch (_: Exception) {
        }
    }

    fun shutdown() {
        closed = true
        urgentPool.shutdownNow()
        prefetchPool.shutdownNow()
        inFlight.values.forEach { it.future.completeExceptionally(IllegalStateException("closed")) }
        inFlight.clear()
    }

    private fun submit(pool: ExecutorService, block: () -> Unit): Boolean = try {
        pool.execute(block); true
    } catch (_: RejectedExecutionException) {
        false
    }

    private fun failed(e: Throwable) = CompletableFuture<File>().apply { completeExceptionally(e) }

    private fun named(prefix: String): ThreadFactory {
        val n = AtomicInteger()
        return ThreadFactory { r -> Thread(r, "$prefix-${n.incrementAndGet()}").apply { isDaemon = true } }
    }

    private fun sha1(text: String): String =
        MessageDigest.getInstance("SHA-1").digest(text.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
}
