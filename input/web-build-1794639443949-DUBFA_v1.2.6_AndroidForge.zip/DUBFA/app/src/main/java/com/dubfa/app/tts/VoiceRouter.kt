package com.dubfa.app.tts

import com.dubfa.app.subtitle.Cue

/**
 * Maps dialogue lines to Dilara (female) or Farid (male).
 *
 * Priority:
 * 1) Explicit speaker map (user override)
 * 2) Auto gender from speaker name (Persian / English lists)
 * 3) Default voice selected in UI
 */
object VoiceRouter {

    private val femaleNames = setOf(
        // Persian
        "سارا", "مریم", "زهرا", "فاطمه", "نرگس", "نازنین", "دلارا", "مینا", "الهام",
        "شیرین", "لیلا", "لی‌لا", "مهسا", "هستی", "آیدا", "آیدا", "یاسمن", "یاسمین",
        "نگار", "نیلوفر", "نسترن", "پریسا", "پگاه", "ستایش", "ترانه", "رویا", "رؤیا",
        "سمیرا", "سمیه", "زینب", "زینت", "حدیث", "هانیه", "هانیّه", "مرجان", "گلی",
        "مادر", "مامان", "خانم", "دختر", "زن", "همسر", "عروس",
        // English common
        "sara", "sarah", "mary", "maria", "emma", "olivia", "sophia", "mia", "anna",
        "lisa", "lucy", "jane", "jessica", "emily", "mother", "mom", "woman", "girl",
        "lady", "mrs", "miss", "ms"
    )

    private val maleNames = setOf(
        "علی", "محمد", "رضا", "حسین", "حسن", "فرید", "امیر", "مهدی", "سعید", "سعید",
        "امیرحسین", "محمدرضا", "احمد", "حامد", "پویا", "کیان", "آرمان", "سینا", "بهرام",
        "نادر", "کامران", "فرهاد", "بابک", "داریوش", "پرویز", "جواد", "یوسف", "ابراهیم",
        "پدر", "بابا", "آقا", "مرد", "پسر", "شوهر", "داماد",
        "ali", "mohammad", "john", "jack", "james", "michael", "david", "tom", "thomas",
        "robert", "father", "dad", "man", "boy", "mr", "sir"
    )

    /** speaker name (normalized) → true=female, false=male */
    fun autoIsFemale(speaker: String): Boolean? {
        val key = normalize(speaker)
        if (key.isEmpty()) return null
        if (key in femaleNames) return true
        if (key in maleNames) return false
        // Light heuristics for Persian names
        if (key.endsWith("ه") || key.endsWith("ة")) {
            // many female names end with ه — weak signal, only if not in male set
            if (key !in maleNames) return true
        }
        return null
    }

    fun normalize(name: String): String =
        name.trim()
            .replace(Regex("""\s+"""), " ")
            .removePrefix("آقای ").removePrefix("خانم ")
            .removePrefix("mr ").removePrefix("mrs ").removePrefix("ms ").removePrefix("miss ")
            .lowercase()
            .trim()

    fun voiceFor(
        cue: Cue,
        smartEnabled: Boolean,
        defaultVoice: String,
        speakerIsFemale: Map<String, Boolean>
    ): String {
        if (!smartEnabled) return defaultVoice
        val sp = cue.speaker?.let { normalize(it) }.orEmpty()
        if (sp.isNotEmpty()) {
            speakerIsFemale[sp]?.let { female ->
                return if (female) EdgeTtsClient.VOICE_FEMALE else EdgeTtsClient.VOICE_MALE
            }
            autoIsFemale(sp)?.let { female ->
                return if (female) EdgeTtsClient.VOICE_FEMALE else EdgeTtsClient.VOICE_MALE
            }
        }
        return defaultVoice
    }

    fun collectSpeakers(cues: List<Cue>): List<String> =
        cues.mapNotNull { it.speaker?.let { s -> normalize(s) } }
            .filter { it.isNotEmpty() }
            .distinct()
            .sorted()
}
