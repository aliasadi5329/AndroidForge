package com.dubfa.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.exoplayer.ExoPlayer
import com.dubfa.app.engine.DubEngine
import kotlinx.coroutines.delay

@Composable
fun FullscreenPlayer(engine: DubEngine, player: ExoPlayer, onExit: () -> Unit) {
    BackHandler(onBack = onExit)

    var controlsVisible by remember { mutableStateOf(false) }
    var hideToken by remember { mutableStateOf(0) }

    // Auto-hide controls a few seconds after they appear
    LaunchedEffect(controlsVisible, hideToken) {
        if (controlsVisible) {
            delay(3500)
            controlsVisible = false
        }
    }

    fun showControls() {
        controlsVisible = true
        hideToken++
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() }
            ) {
                if (controlsVisible) controlsVisible = false else showControls()
            }
    ) {
        PlayerSurface(player, Modifier.fillMaxSize())

        CueOverlay(
            text = engine.overlayText,
            visible = engine.showOverlay,
            modifier = Modifier.fillMaxSize(),
            fontSize = 20.sp,
            bottomPadding = 72.dp
        )

        // Small always-visible menu button (does not block the picture much)
        AnimatedVisibility(
            visible = !controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(Color(0x66000000), CircleShape)
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) { showControls() },
                contentAlignment = Alignment.Center
            ) {
                Text("☰", color = Color.White, fontSize = 18.sp)
            }
        }

        // Full control bar — only when user wants it
        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .background(Color(0x99000000), RoundedCornerShape(14.dp))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() }
                    ) {
                        // keep open while interacting
                        hideToken++
                    },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilledTonalButton(onClick = onExit) { Text("خروج") }
                Button(
                    onClick = {
                        engine.toggleDub()
                        hideToken++
                    },
                    colors = if (engine.running) ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ) else ButtonDefaults.buttonColors()
                ) { Text(if (engine.running) "توقف دوبله" else "شروع دوبله") }
                FilledTonalButton(onClick = {
                    engine.nudgeSync(-500)
                    hideToken++
                }) { Text("−۰٫۵") }
                Text(
                    formatSync(engine.syncOffsetMs),
                    color = Color.White,
                    style = MaterialTheme.typography.labelLarge
                )
                FilledTonalButton(onClick = {
                    engine.nudgeSync(500)
                    hideToken++
                }) { Text("+۰٫۵") }
                Text(
                    "سرعت ×" + "%.2f".format(engine.lastSpeed),
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
