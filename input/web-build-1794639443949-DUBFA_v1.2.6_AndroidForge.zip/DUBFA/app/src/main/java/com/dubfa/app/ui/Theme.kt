package com.dubfa.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DubfaColors = darkColorScheme(
    primary = Color(0xFF9B7BFF),
    onPrimary = Color.White,
    primaryContainer = Color(0xFF3A2D73),
    onPrimaryContainer = Color(0xFFE6DEFF),
    secondary = Color(0xFF5CC8FF),
    onSecondary = Color(0xFF00283A),
    background = Color(0xFF0B1020),
    onBackground = Color(0xFFE8EAF6),
    surface = Color(0xFF141A2E),
    onSurface = Color(0xFFE8EAF6),
    surfaceVariant = Color(0xFF1C2340),
    onSurfaceVariant = Color(0xFFB8BED8),
    error = Color(0xFFFF6B7A)
)

@Composable
fun DubfaTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DubfaColors, typography = Typography(), content = content)
}
