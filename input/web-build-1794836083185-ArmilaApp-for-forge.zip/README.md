# Armila ❤️ – Android App

اپلیکیشن اختصاصی اندروید برای آرمیلا با پیام‌های عاشقانه ساعتی.

## ویژگی‌ها

- **صفحه خوشامدگویی سینمایی** با افکت نور، ذرات و تایپوگرافی فارسی
- **سیستم ۱ میلیون پیام عاشقانه یکتا** (تولید روی‌پروسه‌ای با ترکیب هوشمند)
- **اعلان ساعتی** با WorkManager (حتی وقتی اپ بسته است)
- **بازیابی زمان‌بندی** بعد از ری‌استارت گوشی (BootReceiver)
- **دیتابیس محلی Room** برای تاریخچه پیام‌ها
- **رابط کاربری مدرن و رمانتیک** (Jetpack Compose + RTL فارسی)
- **درخواست مجوز اعلان** (Android 13+)

## ساختار پروژه

```
ArmilaApp/
├── app/
│   ├── src/main/
│   │   ├── java/com/armila/app/
│   │   │   ├── data/          # Room + DataStore + Repository
│   │   │   ├── ui/            # Compose screens + ViewModel
│   │   │   ├── util/          # MessageGenerator (1M unique)
│   │   │   ├── worker/        # WorkManager + BootReceiver
│   │   │   ├── ArmilaApplication.kt
│   │   │   └── MainActivity.kt
│   │   ├── res/
│   │   └── AndroidManifest.xml
│   └── build.gradle.kts
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## ساخت APK

1. پروژه را در **Android Studio** (Hedgehog یا جدیدتر) باز کنید.
2. Sync Gradle.
3. Build → Build Bundle(s) / APK(s) → Build APK(s).

یا از خط فرمان:

```bash
./gradlew assembleDebug
```

خروجی: `app/build/outputs/apk/debug/app-debug.apk`

## نکات فنی

- **تولید پیام**: `MessageGenerator` با ترکیب چند لیست بزرگ، فضای ترکیبی > ۱ میلیون جمله یکتا ایجاد می‌کند. هیچ جمله‌ای تکرار نمی‌شود تا چرخه کامل شود.
- **زمان‌بندی**: `PeriodicWorkRequest` با فاصله ۱ ساعت + `ExistingPeriodicWorkPolicy.KEEP`.
- **دیتابیس**: Room + DataStore (برای اندیس بعدی پیام).
- **حداقل SDK**: 26 (Android 8.0).

## مجوزها

- `POST_NOTIFICATIONS`
- `RECEIVE_BOOT_COMPLETED`
- `VIBRATE`
- `WAKE_LOCK`

---
ساخته‌شده با ❤️ برای آرمیلا
