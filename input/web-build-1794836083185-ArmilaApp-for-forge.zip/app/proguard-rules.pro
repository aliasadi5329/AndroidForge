# Keep Room entities
-keep class com.armila.app.data.** { *; }
