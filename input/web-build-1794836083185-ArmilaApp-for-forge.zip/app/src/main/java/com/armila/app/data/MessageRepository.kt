package com.armila.app.data

import android.content.Context
import com.armila.app.util.MessageGenerator
import com.armila.app.worker.AlarmScheduler
import com.armila.app.worker.MessageAlarmReceiver
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class MessageRepository(context: Context) {

    private val appContext = context.applicationContext
    private val dao = AppDatabase.getInstance(appContext).messageDao()
    private val prefs = PreferencesManager(appContext)

    val allMessages: Flow<List<MessageEntity>> = dao.getAllMessages()
    val latestMessage: Flow<MessageEntity?> = dao.getLatestMessage()
    val messageCount: Flow<Int> = dao.getMessageCount()
    val nextIndexFlow: Flow<Long> = prefs.nextMessageIndex
    val lastNotificationTime: Flow<Long> = prefs.lastNotificationTime
    val unreadCount: Flow<Int> = prefs.unreadCount

    suspend fun getNextIndex(): Long = prefs.nextMessageIndex.first()

    suspend fun getLastNotificationTime(): Long = prefs.lastNotificationTime.first()

    /**
     * Generates the next unique message, stores it, advances the index,
     * increments unread badge count, and returns the new entity + unread count.
     */
    suspend fun deliverNextMessage(): Pair<MessageEntity, Int> {
        val index = prefs.nextMessageIndex.first()
        val content = MessageGenerator.generate(index)
        val entity = MessageEntity(
            messageIndex = index,
            content = content,
            receivedAt = System.currentTimeMillis()
        )
        dao.insert(entity)
        val next = MessageGenerator.nextIndex(index)
        prefs.setNextMessageIndex(next)
        prefs.setLastNotificationTime(System.currentTimeMillis())
        val unread = prefs.incrementUnreadCount()
        return entity to unread
    }

    /**
     * If the last message is older than 60 minutes, deliver missed ones
     * (max 3 at once so we don't spam) and reschedule the alarm.
     * Returns how many messages were delivered.
     */
    suspend fun catchUpIfNeeded(): Int {
        val last = prefs.lastNotificationTime.first()
        val now = System.currentTimeMillis()
        if (last <= 0L) {
            // Never had a message – deliver one and schedule
            val (msg, unread) = deliverNextMessage()
            showNotif(msg.content, msg.id, unread)
            AlarmScheduler.scheduleNext(appContext)
            return 1
        }

        val elapsed = now - last
        if (elapsed < AlarmScheduler.INTERVAL_MS) {
            // Still waiting – just ensure alarm is set from last time
            AlarmScheduler.scheduleNext(appContext, last)
            return 0
        }

        // Overdue – deliver up to 3 missed messages
        var delivered = 0
        var from = last
        while (now - from >= AlarmScheduler.INTERVAL_MS && delivered < 3) {
            val (msg, unread) = deliverNextMessage()
            showNotif(msg.content, msg.id, unread)
            from += AlarmScheduler.INTERVAL_MS
            delivered++
        }
        AlarmScheduler.scheduleNext(appContext)
        return delivered
    }

    private fun showNotif(content: String, messageId: Long, unreadCount: Int) {
        // Reuse receiver helper by posting via a lightweight path
        try {
            val intent = android.content.Intent(appContext, MessageAlarmReceiver::class.java).apply {
                action = MessageAlarmReceiver.ACTION_DELIVER
                // We already delivered; just need notification UI – call static helper if needed
            }
            // Direct notification via duplicating minimal logic is avoided –
            // MessageAlarmReceiver path is for alarms. For catch-up we notify here:
            CatchUpNotifier.notify(appContext, content, messageId, unreadCount)
        } catch (_: Exception) {
        }
    }

    suspend fun markFirstLaunchDone() {
        prefs.setFirstLaunchDone()
    }

    suspend fun isFirstLaunchDone(): Boolean = prefs.isFirstLaunchDone.first()

    suspend fun clearUnread() {
        prefs.clearUnreadCount()
    }
}
