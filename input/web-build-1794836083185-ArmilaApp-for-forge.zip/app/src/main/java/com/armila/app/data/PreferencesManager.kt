package com.armila.app.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "armila_prefs")

class PreferencesManager(private val context: Context) {

    private val KEY_NEXT_INDEX = longPreferencesKey("next_message_index")
    private val KEY_FIRST_LAUNCH = booleanPreferencesKey("first_launch_done")
    private val KEY_LAST_NOTIFICATION_TIME = longPreferencesKey("last_notification_time")
    private val KEY_UNREAD_COUNT = intPreferencesKey("unread_count")

    val nextMessageIndex: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_NEXT_INDEX] ?: 0L
    }

    val isFirstLaunchDone: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[KEY_FIRST_LAUNCH] ?: false
    }

    val lastNotificationTime: Flow<Long> = context.dataStore.data.map { prefs ->
        prefs[KEY_LAST_NOTIFICATION_TIME] ?: 0L
    }

    val unreadCount: Flow<Int> = context.dataStore.data.map { prefs ->
        prefs[KEY_UNREAD_COUNT] ?: 0
    }

    suspend fun setNextMessageIndex(index: Long) {
        context.dataStore.edit { prefs ->
            prefs[KEY_NEXT_INDEX] = index
        }
    }

    suspend fun setFirstLaunchDone() {
        context.dataStore.edit { prefs ->
            prefs[KEY_FIRST_LAUNCH] = true
        }
    }

    suspend fun setLastNotificationTime(time: Long) {
        context.dataStore.edit { prefs ->
            prefs[KEY_LAST_NOTIFICATION_TIME] = time
        }
    }

    suspend fun incrementUnreadCount(): Int {
        var newCount = 1
        context.dataStore.edit { prefs ->
            val current = prefs[KEY_UNREAD_COUNT] ?: 0
            newCount = current + 1
            prefs[KEY_UNREAD_COUNT] = newCount
        }
        return newCount
    }

    suspend fun clearUnreadCount() {
        context.dataStore.edit { prefs ->
            prefs[KEY_UNREAD_COUNT] = 0
        }
    }

    suspend fun getUnreadCount(): Int = unreadCount.first()
}
