package com.armila.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.armila.app.ui.theme.DeepPink
import com.armila.app.ui.theme.SoftPink
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun WelcomeScreen(
    onFinished: () -> Unit
) {
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.7f) }
    val glow = remember { Animatable(0.3f) }
    var particles by remember { mutableStateOf(listOf<Particle>()) }

    LaunchedEffect(Unit) {
        // Generate particles
        particles = List(60) {
            Particle(
                x = Random.nextFloat(),
                y = Random.nextFloat(),
                radius = Random.nextFloat() * 3f + 1f,
                speed = Random.nextFloat() * 0.3f + 0.1f,
                angle = Random.nextFloat() * 360f
            )
        }

        // Fade + scale in
        alpha.animateTo(1f, tween(1800, easing = FastOutSlowInEasing))
        scale.animateTo(1f, tween(1800, easing = FastOutSlowInEasing))

        // Gentle glow pulse
        glow.animateTo(
            1f,
            infiniteRepeatable(
                animation = tween(2000, easing = LinearEasing),
                repeatMode = RepeatMode.Reverse
            )
        )
    }

    LaunchedEffect(Unit) {
        delay(4200)
        onFinished()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0D0D0D),
                        Color(0xFF1A0A14),
                        Color(0xFF0D0D0D)
                    )
                )
            ),
        contentAlignment = Alignment.Center
    ) {
        // Particle layer
        Canvas(modifier = Modifier.fillMaxSize()) {
            val time = System.currentTimeMillis() / 1000f
            particles.forEach { p ->
                val px = (p.x + cos(Math.toRadians((p.angle + time * p.speed * 20).toDouble())).toFloat() * 0.05f) * size.width
                val py = (p.y + sin(Math.toRadians((p.angle + time * p.speed * 15).toDouble())).toFloat() * 0.05f) * size.height
                drawCircle(
                    color = SoftPink.copy(alpha = 0.4f + (sin(time + p.angle) * 0.3f).toFloat()),
                    radius = p.radius * density,
                    center = Offset(px, py)
                )
            }
        }

        // Soft radial glow behind text
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        DeepPink.copy(alpha = 0.25f * glow.value),
                        Color.Transparent
                    ),
                    center = center,
                    radius = size.minDimension * 0.55f
                ),
                radius = size.minDimension * 0.55f,
                center = center
            )
        }

        Text(
            text = "ارمیلام، به زندگی شایان خوش اومدی ❤️",
            modifier = Modifier
                .padding(horizontal = 32.dp)
                .padding(bottom = 24.dp),
            style = TextStyle(
                color = SoftPink.copy(alpha = alpha.value),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                lineHeight = 40.sp,
                shadow = Shadow(
                    color = DeepPink.copy(alpha = 0.7f * glow.value),
                    offset = Offset(0f, 0f),
                    blurRadius = 28f
                )
            )
        )
    }
}

private data class Particle(
    val x: Float,
    val y: Float,
    val radius: Float,
    val speed: Float,
    val angle: Float
)
