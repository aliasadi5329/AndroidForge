package com.armila.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val SoftPink = Color(0xFFF8C8DC)
val DeepPink = Color(0xFFFF69B4)
val Purple = Color(0xFF9B59B6)
val SoftPurple = Color(0xFFDDA0DD)
val Glow = Color(0xFFFFB6C1)
val DarkBg = Color(0xFF0D0D0D)
val DarkSurface = Color(0xFF1A1A1A)
val CardBg = Color(0xFF1F1A24)

private val DarkColorScheme = darkColorScheme(
    primary = DeepPink,
    onPrimary = Color.White,
    secondary = SoftPurple,
    onSecondary = Color.White,
    tertiary = Purple,
    background = DarkBg,
    onBackground = SoftPink,
    surface = DarkSurface,
    onSurface = SoftPink,
    surfaceVariant = CardBg,
    onSurfaceVariant = SoftPink.copy(alpha = 0.8f)
)

@Composable
fun ArmilaTheme(
    darkTheme: Boolean = true, // always dark romantic theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
