package com.armila.app.worker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.armila.app.MainActivity

/**
 * Most reliable hourly scheduling on modern Android (incl. Samsung / Xiaomi):
 * uses setAlarmClock which survives Doze.
 */
object AlarmScheduler {

    private const val TAG = "ArmilaAlarm"
    const val REQUEST_CODE = 4101
    const val INTERVAL_MS = 60L * 60L * 1000L // 60 minutes

    fun scheduleNext(context: Context, fromTime: Long = System.currentTimeMillis()) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = fromTime + INTERVAL_MS

        val deliverIntent = Intent(context, MessageAlarmReceiver::class.java).apply {
            action = MessageAlarmReceiver.ACTION_DELIVER
        }
        val deliverPi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            deliverIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Visible clock intent (required by setAlarmClock)
        val showIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val showPi = PendingIntent.getActivity(
            context,
            REQUEST_CODE + 1,
            showIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                // Highest priority – works in Doze / battery optimization better than setExact
                am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, showPi), deliverPi)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, deliverPi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, deliverPi)
            }
            Log.d(TAG, "Scheduled next at $triggerAt (in ${INTERVAL_MS / 60000} min)")
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact/AlarmClock denied, fallback", e)
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, deliverPi)
                } else {
                    am.set(AlarmManager.RTC_WAKEUP, triggerAt, deliverPi)
                }
            } catch (e2: Exception) {
                Log.e(TAG, "All schedule methods failed", e2)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Schedule failed", e)
        }
    }

    fun cancel(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, MessageAlarmReceiver::class.java).apply {
            action = MessageAlarmReceiver.ACTION_DELIVER
        }
        val pi = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
    }

    fun ensureScheduled(context: Context) {
        scheduleNext(context)
    }
}
