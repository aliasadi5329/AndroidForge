package com.armila.app.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.armila.app.MainActivity
import com.armila.app.R

object CatchUpNotifier {

    fun notify(context: Context, content: String, messageId: Long, unreadCount: Int) {
        createChannel(context)
        val soundUri = Uri.parse("android.resource://${context.packageName}/${R.raw.armila_notif}")

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            putExtra(MessageAlarmReceiver.EXTRA_MESSAGE_ID, messageId)
            data = Uri.parse("armila://message/$messageId")
        }
        val pi = PendingIntent.getActivity(
            context,
            messageId.toInt().and(0x7FFFFFFF),
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notifId = (MessageAlarmReceiver.NOTIFICATION_ID_BASE + (messageId % 40_000)).toInt()

        val notification = NotificationCompat.Builder(context, MessageAlarmReceiver.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("آرمیلا ❤️")
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setSound(soundUri)
            .setVibrate(longArrayOf(0, 300, 200, 300))
            .setGroup(MessageAlarmReceiver.GROUP_KEY)
            .setNumber(unreadCount)
            .build()

        val summary = NotificationCompat.Builder(context, MessageAlarmReceiver.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("آرمیلا ❤️")
            .setContentText("$unreadCount پیام عاشقانه جدید")
            .setStyle(NotificationCompat.InboxStyle().setSummaryText("$unreadCount پیام خوانده‌نشده"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pi)
            .setGroup(MessageAlarmReceiver.GROUP_KEY)
            .setGroupSummary(true)
            .setNumber(unreadCount)
            .setOnlyAlertOnce(true)
            .setSound(null)
            .build()

        with(NotificationManagerCompat.from(context)) {
            try {
                notify(notifId, notification)
                notify(MessageAlarmReceiver.SUMMARY_ID, summary)
            } catch (_: SecurityException) {
            }
        }
    }

    private fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val soundUri = Uri.parse("android.resource://${context.packageName}/${R.raw.armila_notif}")
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val channel = NotificationChannel(
                MessageAlarmReceiver.CHANNEL_ID,
                context.getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.notification_channel_desc)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 300, 200, 300)
                setSound(soundUri, attrs)
                setShowBadge(true)
            }
            context.getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }
}
