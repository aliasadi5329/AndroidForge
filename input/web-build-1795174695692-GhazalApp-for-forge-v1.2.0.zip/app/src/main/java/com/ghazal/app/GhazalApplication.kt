package com.ghazal.app

import android.app.Application
import com.ghazal.app.data.Repository
import com.ghazal.app.util.TargetTime
import com.ghazal.app.worker.AlarmScheduler
import com.ghazal.app.worker.BirthdayMusicService
import com.ghazal.app.worker.NotifHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class GhazalApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        NotifHelper.ensureChannels(this)
        AlarmScheduler.ensureScheduled(this)
        AlarmScheduler.scheduleBirthday(this)
        // If the special moment already passed (e.g. device was off), start music once
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val repo = Repository(this@GhazalApplication)
                if (TargetTime.isBirthdayReached(repo.trustedNow()) && !repo.isMusicStarted()) {
                    repo.setMusicStarted()
                    repo.markBirthdayPending()
                    BirthdayMusicService.start(this@GhazalApplication)
                }
            } catch (_: Exception) { }
        }
    }
}
