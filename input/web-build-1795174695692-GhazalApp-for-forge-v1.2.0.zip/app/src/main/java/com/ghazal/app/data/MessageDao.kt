package com.ghazal.app.data
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface MessageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: MessageEntity): Long

    @Query("SELECT * FROM messages ORDER BY receivedAt DESC")
    fun getAll(): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY receivedAt DESC LIMIT 1")
    fun getLatest(): Flow<MessageEntity?>

    @Query("SELECT COUNT(*) FROM messages")
    fun getCount(): Flow<Int>
}
