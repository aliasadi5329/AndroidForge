package com.ghazal.app.data
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val messageIndex: Long,
    val content: String,
    val receivedAt: Long
)
