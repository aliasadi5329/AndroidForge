package com.ghazal.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

private val Context.ds by preferencesDataStore("ghazal_prefs")

class Prefs(private val context: Context) {
    private val KEY_NEXT = longPreferencesKey("next_index")
    private val KEY_MORNING = longPreferencesKey("idx_morning")
    private val KEY_NOON = longPreferencesKey("idx_noon")
    private val KEY_EVENING = longPreferencesKey("idx_evening")
    private val KEY_NIGHT = longPreferencesKey("idx_night")
    private val KEY_FIRST = booleanPreferencesKey("first_done")
    private val KEY_LAST = longPreferencesKey("last_msg_time")
    private val KEY_UNREAD = intPreferencesKey("unread")
    private val KEY_BDAY_SHOWN = booleanPreferencesKey("birthday_shown")
    private val KEY_BDAY_PENDING = booleanPreferencesKey("birthday_pending")
    private val KEY_TIME_OFFSET = longPreferencesKey("server_time_offset")
    private val KEY_MUSIC_STARTED = booleanPreferencesKey("birthday_music_started")

    val nextIndex: Flow<Long> = context.ds.data.map { it[KEY_NEXT] ?: 0L }
    val firstDone: Flow<Boolean> = context.ds.data.map { it[KEY_FIRST] ?: false }
    val lastMsgTime: Flow<Long> = context.ds.data.map { it[KEY_LAST] ?: 0L }
    val unread: Flow<Int> = context.ds.data.map { it[KEY_UNREAD] ?: 0 }
    val birthdayShown: Flow<Boolean> = context.ds.data.map { it[KEY_BDAY_SHOWN] ?: false }
    val birthdayPending: Flow<Boolean> = context.ds.data.map { it[KEY_BDAY_PENDING] ?: false }
    val timeOffset: Flow<Long> = context.ds.data.map { it[KEY_TIME_OFFSET] ?: 0L }

    suspend fun setNext(v: Long) { context.ds.edit { it[KEY_NEXT] = v } }
    suspend fun setFirstDone() { context.ds.edit { it[KEY_FIRST] = true } }
    suspend fun setLast(v: Long) { context.ds.edit { it[KEY_LAST] = v } }
    suspend fun incUnread(): Int {
        var n = 1
        context.ds.edit {
            n = (it[KEY_UNREAD] ?: 0) + 1
            it[KEY_UNREAD] = n
        }
        return n
    }
    suspend fun clearUnread() { context.ds.edit { it[KEY_UNREAD] = 0 } }
    suspend fun setBirthdayShown() { context.ds.edit { it[KEY_BDAY_SHOWN] = true; it[KEY_BDAY_PENDING] = false } }
    suspend fun setBirthdayPending() { context.ds.edit { it[KEY_BDAY_PENDING] = true } }
    suspend fun setTimeOffset(v: Long) { context.ds.edit { it[KEY_TIME_OFFSET] = v } }

    suspend fun getSlotIndex(slot: String): Long = context.ds.data.map {
        when (slot) {
            "MORNING" -> it[KEY_MORNING] ?: 0L
            "NOON" -> it[KEY_NOON] ?: 0L
            "EVENING" -> it[KEY_EVENING] ?: 0L
            else -> it[KEY_NIGHT] ?: 0L
        }
    }.first()

    suspend fun incSlotIndex(slot: String): Long {
        var next = 0L
        context.ds.edit {
            val key = when (slot) {
                "MORNING" -> KEY_MORNING
                "NOON" -> KEY_NOON
                "EVENING" -> KEY_EVENING
                else -> KEY_NIGHT
            }
            next = (it[key] ?: 0L) + 1
            it[key] = next
        }
        return next
    }

    suspend fun getNext() = nextIndex.first()
    suspend fun getLast() = lastMsgTime.first()
    suspend fun getOffset() = timeOffset.first()
    suspend fun isFirstDone() = firstDone.first()
    suspend fun isBirthdayShown() = birthdayShown.first()
    suspend fun isBirthdayPending() = birthdayPending.first()
    suspend fun isMusicStarted() = context.ds.data.map { it[KEY_MUSIC_STARTED] ?: false }.first()
    suspend fun setMusicStarted() { context.ds.edit { it[KEY_MUSIC_STARTED] = true } }
}
