package com.ghazal.app.data

import android.content.Context
import com.ghazal.app.util.MessageGenerator
import com.ghazal.app.util.TargetTime
import com.ghazal.app.worker.AlarmScheduler
import com.ghazal.app.worker.NotifHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant
import java.time.ZonedDateTime

class Repository(context: Context) {
    private val app = context.applicationContext
    private val dao = AppDatabase.get(app).messageDao()
    private val prefs = Prefs(app)

    val messages: Flow<List<MessageEntity>> = dao.getAll()
    val latest: Flow<MessageEntity?> = dao.getLatest()
    val count: Flow<Int> = dao.getCount()
    val nextIndex = prefs.nextIndex
    val lastMsgTime = prefs.lastMsgTime
    val birthdayShown = prefs.birthdayShown
    val birthdayPending = prefs.birthdayPending
    val timeOffset = prefs.timeOffset

    suspend fun trustedNow(): Long = System.currentTimeMillis() + prefs.getOffset()

    suspend fun syncNetworkTime() = withContext(Dispatchers.IO) {
        try {
            val conn = URL("https://worldtimeapi.org/api/timezone/Asia/Tehran").openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.inputStream.bufferedReader().use { reader ->
                val body = reader.readText()
                val marker = "\"unixtime\":"
                val i = body.indexOf(marker)
                if (i >= 0) {
                    val start = i + marker.length
                    val end = body.indexOfAny(charArrayOf(',', '}'), start)
                    val unix = body.substring(start, end).trim().toLong()
                    val serverMs = unix * 1000L
                    prefs.setTimeOffset(serverMs - System.currentTimeMillis())
                }
            }
            conn.disconnect()
        } catch (_: Exception) { }
    }

    /** Core text without trailing emoji — used to detect true duplicates. */
    private fun coreText(s: String): String =
        s.replace(Regex("[\\s\\p{So}\\p{Sk}\\uFE0F\\u200D]+$"), "").trim()

    suspend fun deliverNextMessage(): Pair<MessageEntity, Int> {
        val now = trustedNow()
        val hour = ZonedDateTime.ofInstant(Instant.ofEpochMilli(now), TargetTime.ZONE).hour
        val slot = MessageGenerator.slotForHour(hour)
        val slotName = slot.name

        // Collect cores already delivered to guarantee no repeat across app lifetime
        val existing = try {
            dao.getAll().first().map { coreText(it.content) }.toSet()
        } catch (_: Exception) {
            emptySet()
        }

        var content: String
        var attempts = 0
        var slotIdx = prefs.getSlotIndex(slotName)
        do {
            content = MessageGenerator.generateForSlot(slot, slotIdx)
            prefs.incSlotIndex(slotName)
            slotIdx++
            attempts++
            // safety: if all unique cores already used, allow the pick
            if (attempts > 40) break
        } while (coreText(content) in existing)

        val globalIndex = prefs.getNext()
        val entity = MessageEntity(messageIndex = globalIndex, content = content, receivedAt = now)
        val id = dao.insert(entity)
        val saved = entity.copy(id = id)
        prefs.setNext(MessageGenerator.nextIndex(globalIndex))
        prefs.setLast(now)
        val unread = prefs.incUnread()
        return saved to unread
    }

    suspend fun catchUpIfNeeded(): Int {
        val last = prefs.getLast()
        val now = trustedNow()
        if (TargetTime.isBirthdayReached(now)) {
            if (!prefs.isBirthdayShown()) prefs.setBirthdayPending()
            return 0
        }
        if (last <= 0L) {
            val (msg, unread) = deliverNextMessage()
            NotifHelper.showMessage(app, msg.content, msg.id, unread)
            AlarmScheduler.scheduleNext(app)
            return 1
        }
        if (now - last < AlarmScheduler.INTERVAL_MS) {
            AlarmScheduler.scheduleNext(app, last)
            return 0
        }
        // Max 1 catch-up to avoid bulk spam after long absence
        if (now - last < AlarmScheduler.INTERVAL_MS * 3) {
            val (msg, unread) = deliverNextMessage()
            NotifHelper.showMessage(app, msg.content, msg.id, unread)
        }
        AlarmScheduler.scheduleNext(app)
        return 1
    }

    suspend fun markFirstDone() = prefs.setFirstDone()
    suspend fun isFirstDone() = prefs.isFirstDone()
    suspend fun clearUnread() = prefs.clearUnread()
    suspend fun markBirthdayShown() = prefs.setBirthdayShown()
    suspend fun isBirthdayShown() = prefs.isBirthdayShown()
    suspend fun isBirthdayPending() = prefs.isBirthdayPending()
    suspend fun markBirthdayPending() = prefs.setBirthdayPending()
    suspend fun isMusicStarted() = prefs.isMusicStarted()
    suspend fun setMusicStarted() = prefs.setMusicStarted()
}
