package com.ghazal.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghazal.app.ui.theme.Gold
import com.ghazal.app.ui.theme.SoftPink
import kotlinx.coroutines.delay
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun BirthdayScreen(onReplay: () -> Unit = {}) {
    var showText by remember { mutableStateOf(false) }
    val alpha = remember { Animatable(0f) }
    val particles = remember {
        List(80) {
            Particle(
                Random.nextFloat(), Random.nextFloat(),
                Random.nextFloat() * 6f + 2f,
                Color(Random.nextFloat(), Random.nextFloat() * 0.5f + 0.5f, Random.nextFloat(), 1f),
                Random.nextFloat() * 360f, Random.nextFloat() * 2f + 0.5f
            )
        }
    }

    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(2000))
        delay(800)
        showText = true
    }

    val infinite = rememberInfiniteTransition(label = "confetti")
    val t by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "t")

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF1A0530), Color(0xFF4A1060), Color(0xFF1A0530)))
        )
    ) {
        // Confetti / fireworks particles
        Canvas(Modifier.fillMaxSize()) {
            particles.forEach { p ->
                val py = ((p.y + t * p.speed) % 1.2f) * size.height
                val px = p.x * size.width + sin((t * 6 + p.angle) * Math.PI).toFloat() * 20f
                drawCircle(p.color.copy(alpha = 0.7f), p.r, Offset(px, py))
            }
            // radial bursts
            val cx = size.width / 2
            val cy = size.height * 0.3f
            for (i in 0 until 24) {
                val ang = i * 15f + t * 40f
                val rad = 40f + t * 120f
                val x = cx + cos(Math.toRadians(ang.toDouble())).toFloat() * rad
                val y = cy + sin(Math.toRadians(ang.toDouble())).toFloat() * rad
                drawCircle(Gold.copy(alpha = (1f - t) * 0.8f), 4f, Offset(x, y))
            }
        }

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(48.dp))
            Text("🎂", fontSize = 64.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "غزل",
                style = TextStyle(
                    color = Gold.copy(alpha = alpha.value),
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    shadow = Shadow(Gold.copy(alpha = 0.8f), blurRadius = 32f)
                )
            )
            Text("تولدت مبارک! ❤️", color = SoftPink, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(24.dp))

            if (showText) {
                Text(
                    text = """غزل جان، تولدت مبارک! ❤️🎂

امروز روز توئه؛ روز کسی که امیدوارم سهمش از زندگی، پر از خنده‌های واقعی، اتفاق‌های قشنگ، آرامش و آرزوهای برآورده‌شده باشه.

امیدوارم سال جدید زندگیت شروع فصل‌هایی باشه که همیشه با لبخند ازشون یاد کنی.

همیشه بخند غزل؛ دنیا با لبخند تو قشنگ‌تره.

تولدت مبارک! ❤️""",
                    color = SoftPink.copy(alpha = 0.95f),
                    fontSize = 16.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 28.sp,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )
            }

            Spacer(Modifier.height(32.dp))
            Button(
                onClick = onReplay,
                colors = ButtonDefaults.buttonColors(containerColor = Gold.copy(0.2f), contentColor = Gold)
            ) {
                Text("پخش دوباره انیمیشن ✨")
            }
            Spacer(Modifier.height(48.dp))
        }
    }
}

private data class Particle(
    val x: Float, val y: Float, val r: Float,
    val color: Color, val angle: Float, val speed: Float
)
