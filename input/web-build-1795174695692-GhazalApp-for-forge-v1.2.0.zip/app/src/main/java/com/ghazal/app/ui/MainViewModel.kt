package com.ghazal.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ghazal.app.data.MessageEntity
import com.ghazal.app.data.Repository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)
    val latest: StateFlow<MessageEntity?> = repo.latest.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)
    val messages: StateFlow<List<MessageEntity>> = repo.messages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val count: StateFlow<Int> = repo.count.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val birthdayShown: StateFlow<Boolean> = repo.birthdayShown.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
    val birthdayPending: StateFlow<Boolean> = repo.birthdayPending.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)
}
