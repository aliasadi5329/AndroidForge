package com.ghazal.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ghazal.app.ui.theme.Gold
import com.ghazal.app.ui.theme.SoftPink
import kotlinx.coroutines.delay
import kotlin.random.Random

@Composable
fun WelcomeScreen(onFinished: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        alpha.animateTo(1f, tween(1800, easing = FastOutSlowInEasing))
        delay(2800)
        onFinished()
    }
    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF0D0D12), Color(0xFF2A1040), Color(0xFF0D0D12)))
        ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            repeat(40) {
                val x = Random.nextFloat() * size.width
                val y = Random.nextFloat() * size.height
                drawCircle(SoftPink.copy(alpha = 0.25f + Random.nextFloat() * 0.3f),
                    radius = 2f + Random.nextFloat() * 3f, center = Offset(x, y))
            }
        }
        Text(
            text = "خوش اومدی غزل ✨\n\nامیدوارم هر بار که اینجا رو باز می‌کنی،\nیه لبخند مهمون دلت بشه.",
            modifier = Modifier.padding(32.dp),
            style = TextStyle(
                color = SoftPink.copy(alpha = alpha.value),
                fontSize = 22.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, lineHeight = 36.sp,
                shadow = Shadow(Gold.copy(alpha = 0.6f * alpha.value), blurRadius = 24f)
            )
        )
    }
}
