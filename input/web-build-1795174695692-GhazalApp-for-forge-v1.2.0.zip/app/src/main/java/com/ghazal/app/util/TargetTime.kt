package com.ghazal.app.util

import java.time.ZoneId
import java.time.ZonedDateTime

/**
 * Fixed target: 11 آذر ۱۴۰۵ = 2 December 2026, 00:00 Asia/Tehran
 * Hardcoded so uninstall/reinstall cannot change it.
 */
object TargetTime {
    val ZONE: ZoneId = ZoneId.of("Asia/Tehran")

    val TARGET: ZonedDateTime = ZonedDateTime.of(2026, 12, 2, 0, 0, 0, 0, ZONE)

    fun targetEpochMs(): Long = TARGET.toInstant().toEpochMilli()

    fun remainingMs(nowMs: Long = System.currentTimeMillis()): Long =
        (targetEpochMs() - nowMs).coerceAtLeast(0L)

    fun isBirthdayReached(nowMs: Long = System.currentTimeMillis()): Boolean =
        nowMs >= targetEpochMs()
}
