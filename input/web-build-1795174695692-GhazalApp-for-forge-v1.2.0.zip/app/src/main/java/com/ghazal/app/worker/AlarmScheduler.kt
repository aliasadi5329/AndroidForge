package com.ghazal.app.worker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.ghazal.app.MainActivity
import com.ghazal.app.util.TargetTime

object AlarmScheduler {
    const val REQUEST_CODE = 5201
    const val INTERVAL_MS = 60L * 60L * 1000L
    private const val BDAY_CODE = 5202

    fun scheduleNext(context: Context, fromTime: Long = System.currentTimeMillis()) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = fromTime + INTERVAL_MS
        // Don't schedule past birthday
        if (triggerAt >= TargetTime.targetEpochMs()) {
            scheduleBirthday(context)
            return
        }
        val deliver = Intent(context, MessageAlarmReceiver::class.java).apply {
            action = MessageAlarmReceiver.ACTION_DELIVER
        }
        val pi = PendingIntent.getBroadcast(context, REQUEST_CODE, deliver,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val show = PendingIntent.getActivity(context, REQUEST_CODE + 1,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), pi)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else {
                am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            }
        } catch (_: SecurityException) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else am.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        }
        scheduleBirthday(context)
    }

    fun scheduleBirthday(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val triggerAt = TargetTime.targetEpochMs()
        if (System.currentTimeMillis() >= triggerAt) return
        val intent = Intent(context, MessageAlarmReceiver::class.java).apply {
            action = MessageAlarmReceiver.ACTION_BIRTHDAY
        }
        val pi = PendingIntent.getBroadcast(context, BDAY_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val show = PendingIntent.getActivity(context, BDAY_CODE + 1,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                am.setAlarmClock(AlarmManager.AlarmClockInfo(triggerAt, show), pi)
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pi)
            } else am.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pi)
        } catch (_: Exception) { }
    }

    fun ensureScheduled(context: Context) = scheduleNext(context)
}
