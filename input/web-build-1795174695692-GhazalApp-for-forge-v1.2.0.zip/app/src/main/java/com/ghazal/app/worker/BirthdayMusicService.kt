package com.ghazal.app.worker

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.ghazal.app.MainActivity
import com.ghazal.app.R

/**
 * Plays the birthday song for up to 5 minutes, even when the app is in background or closed.
 * Started from the birthday alarm / when the special moment is reached.
 */
class BirthdayMusicService : Service() {

    private var player: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val stopRunnable = Runnable { stopSelf() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIF_ID, buildNotification())
        acquireWakeLock()
        startPlayback()
        // Stop after 5 minutes
        handler.removeCallbacks(stopRunnable)
        handler.postDelayed(stopRunnable, PLAY_DURATION_MS)
        return START_STICKY
    }

    private fun startPlayback() {
        if (player != null) return
        try {
            player = MediaPlayer.create(this, R.raw.birthday_song)?.apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                isLooping = true // loop within the 5-minute window
                setOnCompletionListener {
                    // if not looping path ends early, restart until timer stops us
                    try {
                        seekTo(0)
                        start()
                    } catch (_: Exception) { }
                }
                start()
            }
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun buildNotification(): Notification {
        NotifHelper.ensureChannels(this)
        val open = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_birthday", true)
        }
        val pi = PendingIntent.getActivity(
            this, 9100, open,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 9101,
            Intent(this, BirthdayMusicService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, NotifHelper.CHANNEL_BDAY)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("غزل، تولدت مبارک 🎂")
            .setContentText("آهنگ در حال پخش…")
            .setOngoing(true)
            .setContentIntent(pi)
            .addAction(0, "توقف", stop)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun acquireWakeLock() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ghazal:birthday_music").apply {
                acquire(PLAY_DURATION_MS + 10_000L)
            }
        } catch (_: Exception) { }
    }

    override fun onDestroy() {
        handler.removeCallbacks(stopRunnable)
        try {
            player?.stop()
            player?.release()
        } catch (_: Exception) { }
        player = null
        try { wakeLock?.release() } catch (_: Exception) { }
        wakeLock = null
        super.onDestroy()
    }

    companion object {
        const val NOTIF_ID = 9200
        const val ACTION_STOP = "com.ghazal.app.STOP_BIRTHDAY_MUSIC"
        const val PLAY_DURATION_MS = 5L * 60L * 1000L // 5 minutes

        fun start(context: Context) {
            val i = Intent(context, BirthdayMusicService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }
    }
}
